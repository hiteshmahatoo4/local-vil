if [ -z "$LIFERAY_ENV" ]
then
	export LIFERAY_ENV="local-dev"
fi

if [ -z "$LIFERAY_DOCKER_TAG" ]
then
	echo "LIFERAY_DOCKER_TAG is not set, defaulting to 7.4.13-u46-d5.0.1-20221013175637"
	export LIFERAY_DOCKER_TAG="7.4.13-u46-d5.0.1-20221013175637"
else
	echo "LIFERAY_DOCKER_TAG is set as "$LIFERAY_DOCKER_TAG
fi

echo "LIFERAY_ENV is set as "$LIFERAY_ENV

export JAVA_HOME=/home/liferay/zulu11.58.23-ca-jdk11.0.16.1-linux_x64
export PATH=$JAVA_HOME/bin:$PATH
echo "Using below JDK to build custom liferay"
which java
java -version
javac -version

docker images | grep vil-dev
./gradlew clean buildDockerImage -Pliferay.workspace.environment=$LIFERAY_ENV
docker tag liferay-liferay:$LIFERAY_DOCKER_TAG localhost:5000/vil-dev:latest
docker push localhost:5000/vil-dev:latest
docker image prune -f
echo "Checking the timestamp below to confirm if custom liferay docker image is built successfully"
docker images | grep vil-dev
