if [ -z "$LIFERAY_ENV" ]
then
	export LIFERAY_ENV="local-dev"
fi

export NAMESPACE="vil"

kubectl -n $NAMESPACE delete -f configs/$LIFERAY_ENV/k8s/service/liferay-cluster-ip-service.yaml
kubectl -n $NAMESPACE delete -f configs/$LIFERAY_ENV/k8s/service/glowroot-cluster-ip-service.yaml
kubectl -n $NAMESPACE delete -f configs/$LIFERAY_ENV/k8s/ingress/liferay-ingress.yaml
kubectl -n $NAMESPACE delete -f configs/$LIFERAY_ENV/k8s/deployment/liferay-deployment.yaml
sleep 20

kubectl -n $NAMESPACE apply -f configs/$LIFERAY_ENV/k8s/pvc/liferay-pvc.yaml
kubectl -n $NAMESPACE apply -f configs/$LIFERAY_ENV/k8s/service/liferay-cluster-ip-service.yaml
kubectl -n $NAMESPACE apply -f configs/$LIFERAY_ENV/k8s/service/glowroot-cluster-ip-service.yaml
kubectl -n $NAMESPACE apply -f configs/$LIFERAY_ENV/k8s/ingress/liferay-ingress.yaml
kubectl -n $NAMESPACE apply -f configs/$LIFERAY_ENV/k8s/deployment/liferay-deployment.yaml
