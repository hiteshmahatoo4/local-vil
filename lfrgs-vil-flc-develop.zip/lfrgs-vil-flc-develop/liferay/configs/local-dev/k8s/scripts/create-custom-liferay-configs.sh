if [ -z "$LIFERAY_ENV" ]
then
	export LIFERAY_ENV="local-dev"
fi

export NAMESPACE="vil"

#kubectl -n $NAMESPACE delete configmap activation-key
#kubectl -n $NAMESPACE create configmap activation-key --from-file=configs/$LIFERAY_ENV/deploy/activation-key.xml

kubectl -n $NAMESPACE delete configmap portal-ext
kubectl -n $NAMESPACE create configmap portal-ext --from-file=configs/$LIFERAY_ENV/portal-ext.properties

kubectl -n $NAMESPACE delete configmap portal-setup-wizard
kubectl -n $NAMESPACE create configmap portal-setup-wizard --from-file=configs/$LIFERAY_ENV/portal-setup-wizard.properties
