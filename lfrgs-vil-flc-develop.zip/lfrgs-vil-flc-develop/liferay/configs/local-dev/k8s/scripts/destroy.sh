if [ -z "$LIFERAY_ENV" ]
then
	echo "LIFERAY_ENV is not set, defaulting to dev"
	export LIFERAY_ENV="local-dev"
else
	echo "LIFERAY_ENV is set as "$LIFERAY_ENV
fi

export NAMESPACE="vil"

kubectl -n $NAMESPACE delete -f configs/$LIFERAY_ENV/k8s/service/liferay-cluster-ip-service.yaml
kubectl -n $NAMESPACE delete -f configs/$LIFERAY_ENV/k8s/ingress/liferay-ingress.yaml
kubectl -n $NAMESPACE delete -f configs/$LIFERAY_ENV/k8s/deployment/liferay-deployment.yaml

echo "Hi, I'm sleeping for 2 mins waiting for the Liferay pods deletion."
sleep 2m  
echo "Lets check now"

kubectl -n $NAMESPACE get all
