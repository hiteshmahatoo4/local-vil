if [ -z "$LIFERAY_ENV" ]
then
	export LIFERAY_ENV="local-dev"
fi

export NAMESPACE="vil"

kubectl -n $NAMESPACE delete events --all

configs/$LIFERAY_ENV/k8s/scripts/create-custom-liferay.sh

configs/$LIFERAY_ENV/k8s/scripts/create-custom-liferay-configs.sh

configs/$LIFERAY_ENV/k8s/scripts/deploy-custom-liferay.sh

echo "Custom Liferay is deployed and will be available in around 5-10 mins. Please check liferay logs at http://kibana.local/kibana/goto/d5b40cb088a0beb3366768098e636380 and application at http://vil.local-dev/"

kubectl -n $NAMESPACE get events --sort-by=.metadata.creationTimestamp

sleep 5m

kubectl -n $NAMESPACE get pods
