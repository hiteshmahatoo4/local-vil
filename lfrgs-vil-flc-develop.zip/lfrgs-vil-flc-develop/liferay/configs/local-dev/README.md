All the below will work only on Liferay Office OpenVPN

Add below to hosts file  
192.168.1.112   kibana.local  
192.168.1.112	vil.local-dev  
192.168.1.112   glowroot.vil.local-dev  

Github: Push code here https://github.com/liferay/lfrgs-vil-flc/tree/develop/liferay  

Jenkins: Check deployment status here: http://192.168.1.109:8087/job/VIL  

Kibana: Check liferay logs here: http://kibana.local/kibana/goto/d5b40cb088a0beb3366768098e636380  
14-Oct-2022 06:40:46.924 INFO [main] org.apache.catalina.startup.Catalina.load Server initialization in [204] milliseconds  
14-Oct-2022 06:41:40.102 INFO [main] org.apache.catalina.startup.Catalina.start Server startup in [53177] milliseconds  

Liferay: Check liferay application here: http://vil.local-dev/  

Glowroot: Check liferay performance here: http://glowroot.vil.local-dev/  

Below Stack is deployed to this Local Dev Env:  
Liferay DXP 7.4 U44  
OpenJDK 64-Bit Server VM Zulu11.58+23-CA (build 11.0.16.1+1-LTS, mixed mode)  
MySQL 5.7  
Embedded Elasticsearch 7.17.x  
