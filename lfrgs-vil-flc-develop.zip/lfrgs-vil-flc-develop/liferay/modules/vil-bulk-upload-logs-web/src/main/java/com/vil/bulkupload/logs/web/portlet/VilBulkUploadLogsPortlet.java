package com.vil.bulkupload.logs.web.portlet;

import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.PortletURLUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowTask;
import com.vil.bulkupload.logs.web.constants.VilBulkUploadLogsPortletKeys;
import com.vil.bulkupload.logs.web.display.context.UsersManagementToolbarDisplayContext;
import com.vil.bulkupload.model.BulkUpload;
import com.vil.bulkupload.service.BulkUploadLocalService;
import com.vil.common.util.VilRoleUtil;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerUsersLocalService;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * The purpose of this class is to show bulk upload logs and download excel
 * sheets based on upload file id.
 *
 * @author Ankita Malik
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=VilBulkUploadLogs", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + VilBulkUploadLogsPortletKeys.VILBULKUPLOADLOGS,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)

public class VilBulkUploadLogsPortlet extends MVCPortlet {

	/**
	 * This method is used to display the bulk upload logs.
	 *
	 * @param renderRequest  : holds and sets the attributes and renders when page
	 *                       is loading
	 * 
	 * @param renderResponse : holds the html and displays it to the end users
	 * 
	 * @throws IOException
	 * @throws PortletException : Hold detail of exception if there is problem while
	 *                          fetching the logs
	 */

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {

		String categoryName = null;

		try {
			
			usersListAttributes(renderRequest);

			addtToolbarAttributes(renderRequest, renderResponse);

			renderRequest.setAttribute("categoryName", categoryName);

		} catch (Exception e) {
			log.error("Error in getting category name:" + e.getMessage());

		}
		
		super.render(renderRequest, renderResponse);
	}
	/*
	 * This method is used to respond to the end user's command
	 * 
	 * @param resourceRequest :Holds Current Id
	 * 
	 * @param resourceResponse :Holds the response to the commandn given vy the
	 * user.
	 * 
	 * @return : Workbook (.xlsx file containing the list of products of that
	 * particular categories which is selected by the user)
	 */

	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		try {
			String curId = resourceRequest.getParameter("curId");
			byte[] bytes = createProductExcel(Long.parseLong(curId));
			BulkUpload bulkUploads = bulkUploadLocalService.fetchBulkUpload(Long.parseLong(curId));
			String myFile;
			if (Validator.isBlank(bulkUploads.getFileName())) {
				myFile = "Download.xlsx";
			} else {
				myFile = bulkUploads.getFileName() + ".xlsx";
			}

			PortletResponseUtil.sendFile(resourceRequest, resourceResponse, myFile, bytes,
					ContentTypes.APPLICATION_VND_MS_EXCEL);
		
			super.serveResource(resourceRequest, resourceResponse);
		} catch (Exception e) {
			log.error(e);
		}
	}

	/**
	 * This method is used to create the excel sheet and writes in the workbook
	 * 
	 * @param curId : gets the current id of the uploaded entry
	 *
	 */
	private byte[] createProductExcel(long curId) {
		Workbook workbook = new SXSSFWorkbook();
		byte[] outArray = null;
		int max = 0;
		try (ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();) {
			BulkUpload bulkUploads = bulkUploadLocalService.fetchBulkUpload(curId);

			if (Validator.isNotNull(bulkUploads)) {

				JSONObject mainJsonObj = JSONFactoryUtil.createJSONObject(bulkUploads.getRowDetail());

				if (Validator.isNotNull(mainJsonObj)) {
					JSONArray rowArray = mainJsonObj.getJSONArray("rows");
					if (Validator.isNotNull(rowArray)) {
						// creating sheet
						Sheet excelSheet;
						if (Validator.isBlank(bulkUploads.getFileName())) {
							excelSheet = workbook.createSheet("Download");
						} else {
							excelSheet = workbook.createSheet(bulkUploads.getFileName());
						}
						CellStyle headerCellStyle = workbook.createCellStyle();
						Font headerFont = workbook.createFont();
						// headerFont.setBoldweight(true);
						headerCellStyle.setFont(headerFont);
						headerCellStyle.setWrapText(true);
						// creating excel header rows
						Row headerRow = excelSheet.createRow(0);

						// itertaing over headerlist
						int rowsize = rowArray.length();
						for (int i = 1; i <= rowsize; i++) {
							JSONObject rowObj = rowArray.getJSONObject(i - 1);
							if (Validator.isNotNull(rowObj)) {
								// creating rows for data
								Row row = excelSheet.createRow(i);
								CellStyle defaultCellStyle = workbook.createCellStyle();
								defaultCellStyle.setWrapText(true);
								// gettting column array
								JSONArray columnArray = rowObj.getJSONArray("columns");

								if (Validator.isNotNull(columnArray)) {
									int size = columnArray.length();
									if (max < size) {
										max = size;
									}

									for (int k = 0; k < size; k++) {
										JSONObject colObj = columnArray.getJSONObject(k);
										if (Validator.isNotNull(colObj)) {
											// getting column values and create cell

											createCell(headerRow, k, colObj.getString("header"), defaultCellStyle);
											createCell(row, k, colObj.getString("value"), defaultCellStyle);

										}

									}
								}

							}
						}
						createCell(headerRow, max, "Status", headerCellStyle);
						createCell(headerRow, max + 1, "Remarks", headerCellStyle);

						for (int i = 1; i <= rowsize; i++) {
							JSONObject rowObj = rowArray.getJSONObject(i - 1);
							Row row = excelSheet.getRow(i);
							createCell(row, max, rowObj.getString("message"), headerCellStyle);
							createCell(row, max + 1, rowObj.getString("remarks"), headerCellStyle);
						}

					}
				}
			}
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();

		}

		catch (Exception e) {
			log.error("Error in createProduct Excel method : " + e);
		}
		return outArray;
	}

	/**
	 * This method is used to get specification based on product Id
	 * 
	 * @param productId : holds selected product
	 * @return : List<String> containing all specifications
	 */
	/**
	 * This method is used to add the liferay toolbar
	 * 
	 */

	private void addtToolbarAttributes(RenderRequest renderRequest, RenderResponse renderResponse) {
		try {
			SearchContainer<BulkUpload> searchContainer = getSearchContainer(renderRequest, renderResponse);
			LiferayPortletRequest liferayPortletRequest = portal.getLiferayPortletRequest(renderRequest);
			LiferayPortletResponse liferayPortletResponse = portal.getLiferayPortletResponse(renderResponse);
			HttpServletRequest httpServletRequest = portal.getHttpServletRequest(renderRequest);

			UsersManagementToolbarDisplayContext memberRegManagementToolbarDisplayContext = new UsersManagementToolbarDisplayContext(
					liferayPortletRequest, liferayPortletResponse, httpServletRequest,searchContainer);

			renderRequest.setAttribute("usersManagementToolbarDisplayContext",
					memberRegManagementToolbarDisplayContext);
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	/**
	 * This method is used to get search container object
	 * 
	 * @param renderRequest
	 * @param renderResponse
	 * @return
	 */
	private SearchContainer<BulkUpload> getSearchContainer(RenderRequest renderRequest,
			RenderResponse renderResponse) {
		SearchContainer<BulkUpload> searchContainer = new SearchContainer<>();
		try {
			String orderByType = ParamUtil.getString(renderRequest, "orderByType", "desc");
			searchContainer = new SearchContainer<BulkUpload>(renderRequest,
					getPortletURL(renderRequest, renderResponse), null, "emptyResultsMessage");
		
			searchContainer.setOrderByCol("createDate");
			searchContainer.setOrderByType(orderByType);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return searchContainer;
	}
	/**
	 * This method is used to get portal url
	 * 
	 * @param renderRequest
	 * @param renderResponse
	 * @return
	 */
	@SuppressWarnings("deprecation")
	private PortletURL getPortletURL(RenderRequest renderRequest, RenderResponse renderResponse) {
		try {
			LiferayPortletRequest liferayPortletRequest = portal.getLiferayPortletRequest(renderRequest);
			LiferayPortletResponse liferayPortletResponse = portal.getLiferayPortletResponse(renderResponse);
			PortletURL currentURLObj = PortletURLUtil.getCurrent(liferayPortletRequest, liferayPortletResponse);
			PortletURL portletURL = PortletURLUtil.clone(currentURLObj, liferayPortletResponse);
			portletURL.setParameter("orderByCol", "createDate");
			portletURL.setParameter("orderByType", "desc");
			return portletURL;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	/**
	 * This method is used to add list to the container
	 * 
	 */

	private void usersListAttributes(RenderRequest renderRequest) {
		try {
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			boolean isPartner = VilRoleUtil.isPartnerKAM(themeDisplay.getUserId());

			List<BulkUpload> list = new ArrayList<>();
			String keywords = ParamUtil.getString(renderRequest, "keywords");

		List<BulkUpload> bulkUploadList = bulkUploadLocalService.getUsersByKeywords(keywords, QueryUtil.ALL_POS, QueryUtil.ALL_POS);
		//	List<BulkUpload> list = bulkUploadLocalService.getKeywordSe
			
			if (isPartner) {
				PartnerUsers partnerUser = partnerUsersLocalService.findByLiferayUserId(themeDisplay.getUserId());

				long partnerid = partnerUser.getPartnerId();
				for (BulkUpload bulkUpload : bulkUploadList) {
					if (Validator.isNotNull(bulkUpload.getPartnerId())) {
						if (bulkUpload.getPartnerId() == partnerid) {
							list.add(bulkUpload);
						}
					}
				}
			} else {
				for (BulkUpload bulkUpload : bulkUploadList) {

					list.add(bulkUpload);
				}
			}

			//long bulkUploadCount = bulkUploadLocalService.getUsersCountsByKeywords(keywords);
			sortWorkflowTasksList(renderRequest, list);
			renderRequest.setAttribute("entries", list);
			
			renderRequest.setAttribute("totalUsers", list.size());
		} catch (Exception e) {
			log.error(e);
		}
	}
	/**
	 * This method is used to sort list
	 * 
	 * @param renderRequest
	 * @param list
	 */
	private static void sortWorkflowTasksList(RenderRequest renderRequest, List<BulkUpload> list) {
		try {
			String orderByType = ParamUtil.getString(renderRequest, "orderByType", "desc");
			if ("desc".equalsIgnoreCase(orderByType)) {
				Collections.sort(list,
						(BulkUpload o1, BulkUpload o2) -> o2.getCreateDate().compareTo(o1.getCreateDate()));
			} else if ("asc".equalsIgnoreCase(orderByType)) {
				Collections.sort(list,
						(BulkUpload o1, BulkUpload o2) -> o1.getCreateDate().compareTo(o2.getCreateDate()));
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
	/**
	 * This method is used to create cells in the excel sheet
	 *
	 * @param row       : sets the row in which cell is to be created
	 * @param cellIndex : sets the position of the cell
	 * @param cellValue : sets the value of the cell
	 * @param cellStyle : sets the style of the cell
	 */
	private static void createCell(Row row, int cellIndex, String cellValue, CellStyle cellStyle) {
		Cell cell = row.createCell(cellIndex);
		cell.setCellValue(cellValue);
		cell.setCellStyle(cellStyle);
	}

	@Reference
	private Portal portal;

	@Reference
	private BulkUploadLocalService bulkUploadLocalService;
	@Reference
	private PartnerUsersLocalService partnerUsersLocalService;

	private static final Log log = LogFactoryUtil.getLog(VilBulkUploadLogsPortlet.class.getName());
}