package com.vil.bulkupload.logs.web.constants;

/**
 * @author gayatrilalluvadiya
 */
public class VilBulkUploadLogsPortletKeys {

	public static final String VILBULKUPLOADLOGS =
		"com_vil_bulkupload_logs_web_VilBulkUploadLogsPortlet";
	
}