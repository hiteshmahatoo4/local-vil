package com.vil.bulkupload.logs.web.portlet;

import com.liferay.asset.category.property.model.AssetCategoryProperty;
import com.liferay.asset.category.property.service.AssetCategoryPropertyLocalServiceUtil;
import com.liferay.asset.entry.rel.model.AssetEntryAssetCategoryRel;
import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CPDefinitionSpecificationOptionValue;
import com.liferay.commerce.product.model.CPSpecificationOption;
import com.liferay.commerce.product.model.CProduct;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.commerce.product.service.CPDefinitionSpecificationOptionValueLocalServiceUtil;
import com.liferay.commerce.product.service.CProductLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.ArrayList;
import java.util.List;

/**
 * The purpose of this class is Utility class
 *
 * Accessibility : This class gets executed from portlet class Module available
 * to end users. When user performs Upload,Download action
 *
 * @author Ankita Malik
 * 
 */
public class BulkUploadWebUtil {
	/**
	 * This method is used to get specification based on product Id
	 * 
	 * @param productId : holds selected product
	 * @return : List<String> containing all specifications
	 */
	public static List<String> getCategorHeaders(long productId) {
		List<String> headerList = new ArrayList<>();
		try {
			CPDefinition cpDefinition = CPDefinitionLocalServiceUtil.fetchCPDefinitionByCProductId(productId);
			if (Validator.isNotNull(cpDefinition)) {
				List<CPDefinitionSpecificationOptionValue> cpDefinitionSpecificationOptionValues = CPDefinitionSpecificationOptionValueLocalServiceUtil
						.getCPDefinitionSpecificationOptionValues(cpDefinition.getCPDefinitionId(), QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
				if (Validator.isNotNull(cpDefinitionSpecificationOptionValues)) {
					for (CPDefinitionSpecificationOptionValue cpDefinitionSpecificationOptionValue : cpDefinitionSpecificationOptionValues) {
						CPSpecificationOption cpSpecificationOption = cpDefinitionSpecificationOptionValue
								.getCPSpecificationOption();
						String key = cpSpecificationOption.getTitle(LocaleUtil.getSiteDefault());
						headerList.add(key);
						
					}
				}

			}
		} catch (Exception e) {
			_log.error("Error in getting headers : " + e);
		}

		return headerList;
	}

	/**
	 * This method is used to get master product based on category selected
	 *
	 * @param categoryId
	 * @return : CProduct object holds product details
	 */
	public static CProduct getMasterProductFromCategory(long categoryId) {
		CProduct product = null;
		try {
			AssetCategory fetchAssetCategory = AssetCategoryLocalServiceUtil.fetchAssetCategory(categoryId);
			_log.info("fetchAssetCategory"   +fetchAssetCategory);
			
			if(Validator.isNotNull(fetchAssetCategory)) {
				AssetCategoryProperty fetchCategoryProperty = AssetCategoryPropertyLocalServiceUtil.
						fetchCategoryProperty(fetchAssetCategory.getCategoryId(),"TEMPLATE_PRODUCT_ID");
				_log.info("fetchCategoryProperty"   +fetchCategoryProperty);
				if(Validator.isNotNull(fetchCategoryProperty)) {
					CPDefinition cpDefinition = CPDefinitionLocalServiceUtil
							.fetchCPDefinition(Long.parseLong(fetchCategoryProperty.getValue()));
					
					if (Validator.isNotNull(cpDefinition)) {
						// from cp defination get product
						product = CProductLocalServiceUtil.fetchCProduct(cpDefinition.getCProductId());
					}
				}
			}
		} catch (Exception e) {
			_log.error("Error while getting product :" + e);
		}
		return product;
	}
	

	private static final Log _log = LogFactoryUtil.getLog(BulkUploadWebUtil.class.getName());
}
