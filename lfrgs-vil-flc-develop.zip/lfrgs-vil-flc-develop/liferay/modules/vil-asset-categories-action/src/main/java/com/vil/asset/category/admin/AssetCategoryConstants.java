package com.vil.asset.category.admin;

/**
 * 
 * The purpose of this class is constant class
 *
 *@author Chinmay Abhyankar
 *
 */
public class AssetCategoryConstants {

	 static final String TEMPLATE_PRODUCT_ID = "TEMPLATE_PRODUCT_ID";
	 static final String END_CATEGORY = "END_CATEGORY";
	 static final String APPLICABLE_AS_LEAD = "APPLICABLE_AS_LEAD";
	 static final String FULFILMENT_BY_ADMIN = "FULFILMENT_BY_ADMIN";
	 static final String FULFILMENT_BY_VI = "FULFILMENT_BY_VI";
}
