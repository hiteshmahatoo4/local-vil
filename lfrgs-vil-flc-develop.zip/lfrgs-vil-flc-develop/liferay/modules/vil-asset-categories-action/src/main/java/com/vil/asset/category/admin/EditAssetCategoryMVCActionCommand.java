package com.vil.asset.category.admin;

import static com.vil.asset.category.admin.AssetCategoryConstants.APPLICABLE_AS_LEAD;
import static com.vil.asset.category.admin.AssetCategoryConstants.END_CATEGORY;
import static com.vil.asset.category.admin.AssetCategoryConstants.FULFILMENT_BY_ADMIN;
import static com.vil.asset.category.admin.AssetCategoryConstants.FULFILMENT_BY_VI;
import static com.vil.asset.category.admin.AssetCategoryConstants.TEMPLATE_PRODUCT_ID;

import com.liferay.asset.categories.admin.web.constants.AssetCategoriesAdminPortletKeys;
import com.liferay.asset.category.property.model.AssetCategoryProperty;
import com.liferay.asset.category.property.service.AssetCategoryPropertyLocalService;
import com.liferay.asset.display.page.portlet.AssetDisplayPageEntryFormProcessor;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetCategoryConstants;
import com.liferay.asset.kernel.service.AssetCategoryService;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CommerceCatalog;
import com.liferay.commerce.product.service.CPDefinitionLocalService;
import com.liferay.commerce.product.service.CommerceCatalogLocalService;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.language.Language;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.module.configuration.ConfigurationProviderUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.servlet.MultiSessionMessages;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.Localization;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.security.audit.event.generators.constants.EventTypes;
import com.vil.common.util.VILCommonUtil;
import com.vil.system.settings.MasterProductTemplateConfiguration;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Chinmay Abhyankar
 */
@Component(immediate = true, property = {
		"javax.portlet.name=" + AssetCategoriesAdminPortletKeys.ASSET_CATEGORIES_ADMIN,
		"mvc.command.name=/asset_categories_admin/edit_asset_category",
		"service.ranking:Integer=100" }, service = MVCActionCommand.class)
public class EditAssetCategoryMVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		long categoryId = ParamUtil.getLong(actionRequest, "categoryId");

		long parentCategoryId = ParamUtil.getLong(actionRequest, "parentCategoryId");
		Map<Locale, String> titleMap = _localization.getLocalizationMap(actionRequest, "title");
		Map<Locale, String> descriptionMap = _localization.getLocalizationMap(actionRequest, "description");
		long vocabularyId = ParamUtil.getLong(actionRequest, "vocabularyId");

		boolean endCategory = ParamUtil.get(actionRequest, "endCategory", false);
		boolean applicable = ParamUtil.get(actionRequest, "applicable", false);

		Integer fulfilment = ParamUtil.get(actionRequest, "fulfilment", 0);
		_log.info("Check box Value fulfilment : " + ParamUtil.get(actionRequest, "fulfilment", 0));
		_log.debug("Check box Value : " + ParamUtil.get(actionRequest, "endCategory", false));

		MasterProductTemplateConfiguration masterConfig = ConfigurationProviderUtil
				.getSystemConfiguration(MasterProductTemplateConfiguration.class);

		_log.debug("Master Product catalog Id : " + masterConfig.masterProductTemplateCatalogId());

		long masterProductCatalogId = Long.parseLong(masterConfig.masterProductTemplateCatalogId());

		ServiceContext serviceContext = ServiceContextFactory.getInstance(AssetCategory.class.getName(), actionRequest);

		hideDefaultSuccessMessage(actionRequest);

		MultiSessionMessages.add(actionRequest, actionResponse.getNamespace() + "requestProcessed");

		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);

		AssetCategory category = null;

		if (categoryId <= 0) {

			// Add category

			long groupId = ParamUtil.getLong(actionRequest, "groupId");

			category = _assetCategoryService.addCategory(groupId, parentCategoryId, titleMap, descriptionMap,
					vocabularyId, null, serviceContext);

			MultiSessionMessages.add(actionRequest, "categoryAdded",
					_language.format(_portal.getHttpServletRequest(actionRequest), "x-was-created-successfully",
							new Object[] { HtmlUtil.escape(titleMap.get(themeDisplay.getLocale())) }));
		} else {
			String[] categoryPropertiesArray = _getCategoryProperties(
					_assetCategoryPropertyLocalService.getCategoryProperties(categoryId));

			category = _assetCategoryService.updateCategory(categoryId, parentCategoryId, titleMap, descriptionMap,
					vocabularyId, categoryPropertiesArray, serviceContext);

			MultiSessionMessages.add(actionRequest, "categoryUpdated",
					_language.format(_portal.getHttpServletRequest(actionRequest), "x-was-updated-successfully",
							new Object[] { HtmlUtil.escape(titleMap.get(themeDisplay.getLocale())) }));
		}

		try {
			if (endCategory) {
				AssetCategoryProperty assetCategoryProperty = _assetCategoryPropertyLocalService
						.getCategoryProperty(category.getCategoryId(), TEMPLATE_PRODUCT_ID);

				if (Validator.isNotNull(assetCategoryProperty)
						&& Long.parseLong(assetCategoryProperty.getValue()) > 0) {
					CPDefinition cpDefinition = _cpDefinitionLocalService
							.fetchCPDefinition(Long.parseLong(assetCategoryProperty.getValue()));
					if (Validator.isNull(cpDefinition)) {
						// add master template
						_log.info(" : Adding Master Product Template : ");
						CommerceCatalog fetchCommerceCatalog = _commerceCatalogLocalService
								.fetchCommerceCatalog(masterProductCatalogId);
						if (Validator.isNotNull(fetchCommerceCatalog)) {
							double defaultValue = 0.0d;
							Map<Locale, String> nameMap = new HashMap<Locale, String>();
							LocalDateTime currentDate = LocalDateTime.now();
							nameMap.put(themeDisplay.getLocale(), category.getName() + " Master Template");
							cpDefinition = _cpDefinitionLocalService.addCPDefinition(null,
									fetchCommerceCatalog.getGroupId(), category.getUserId(), nameMap, nameMap, nameMap,
									nameMap, nameMap, nameMap, nameMap, "simple", true, true, true, true, defaultValue,
									defaultValue, defaultValue, defaultValue, defaultValue, 0, false, false, "", true,
									currentDate.getMonthValue() - 1, currentDate.getDayOfMonth(), currentDate.getYear(),
									currentDate.getHour(), currentDate.getMinute(), 11, 31, 2099, 23, 59, false, "",
									false, 1, "", null, 0, 0, serviceContext);
							_log.info(" : Master product Template created : " + cpDefinition.getCPDefinitionId());

							// add category to creadted cp definition
							updateCPDefinition(cpDefinition, categoryId, actionRequest, themeDisplay);

							// add value to category property
							_assetCategoryPropertyLocalService.updateCategoryProperty(
									assetCategoryProperty.getCategoryPropertyId(), "TEMPLATE_PRODUCT_ID",
									String.valueOf(cpDefinition.getCPDefinitionId()));
						}
					}
					addOrUpdateCategoryProperties(themeDisplay, categoryId, END_CATEGORY, String.valueOf(endCategory),
							actionRequest);
					addOrUpdateCategoryProperties(themeDisplay, categoryId, APPLICABLE_AS_LEAD,
							String.valueOf(applicable), actionRequest);

				} else {
					// add master template
					_log.info(" : Adding Master Product Template : ");
					CommerceCatalog fetchCommerceCatalog = _commerceCatalogLocalService
							.fetchCommerceCatalog(masterProductCatalogId);
					if (Validator.isNotNull(fetchCommerceCatalog)) {
						double defaultValue = 0.0d;
						Map<Locale, String> nameMap = new HashMap<Locale, String>();
						LocalDateTime currentDate = LocalDateTime.now();
						nameMap.put(themeDisplay.getLocale(), category.getName() + " Master Template");
						CPDefinition cpDefinition = _cpDefinitionLocalService.addCPDefinition(null,
								fetchCommerceCatalog.getGroupId(), category.getUserId(), nameMap, nameMap, nameMap,
								nameMap, nameMap, nameMap, nameMap, "simple", true, true, true, true, defaultValue,
								defaultValue, defaultValue, defaultValue, defaultValue, 0, false, false, "", true,
								currentDate.getMonthValue() - 1, currentDate.getDayOfMonth(), currentDate.getYear(),
								currentDate.getHour(), currentDate.getMinute(), 11, 31, 2099, 23, 59, false, "", false,
								1, "", null, 0, 0, serviceContext);
						_log.info(" : Master product Template created : " + cpDefinition.getCPDefinitionId());

						// add category to creadted cp definition
						updateCPDefinition(cpDefinition, categoryId, actionRequest, themeDisplay);

						// add value to category property
						_assetCategoryPropertyLocalService.updateCategoryProperty(
								assetCategoryProperty.getCategoryPropertyId(), "TEMPLATE_PRODUCT_ID",
								String.valueOf(cpDefinition.getCPDefinitionId()));
						addOrUpdateCategoryProperties(themeDisplay, categoryId, END_CATEGORY,
								String.valueOf(endCategory), actionRequest);
						addOrUpdateCategoryProperties(themeDisplay, categoryId, APPLICABLE_AS_LEAD,
								String.valueOf(applicable), actionRequest);
					}
					addOrUpdateCategoryProperties(themeDisplay, categoryId, END_CATEGORY, String.valueOf(endCategory),
							actionRequest);
					addOrUpdateCategoryProperties(themeDisplay, categoryId, APPLICABLE_AS_LEAD,
							String.valueOf(applicable), actionRequest);

				}
			}
			if (Validator.isNotNull(fulfilment)) {
				if (fulfilment == 1) {
					addOrUpdateCategoryProperties(themeDisplay, categoryId, FULFILMENT_BY_ADMIN, "true", actionRequest);
					addOrUpdateCategoryProperties(themeDisplay, categoryId, FULFILMENT_BY_VI, "false", actionRequest);

				} else {
					addOrUpdateCategoryProperties(themeDisplay, categoryId, FULFILMENT_BY_VI, "true", actionRequest);
					addOrUpdateCategoryProperties(themeDisplay, categoryId, FULFILMENT_BY_ADMIN, "false", actionRequest);

				}
			}
		} catch (Exception e) {
			_log.error("Error while adding master Product Template : " + e);
			VILCommonUtil.updateAudit(EventTypes.ADD, category.getCompanyId(), category.getUserId(),
					category.getUserName(), EditAssetCategoryMVCActionCommand.class.getName(), categoryId,
					"Error while adding master Product Template : " + e.getMessage(), null);
		}
		// Asset display page

		_assetDisplayPageEntryFormProcessor.process(AssetCategory.class.getName(), category.getCategoryId(),
				actionRequest);

		sendRedirect(actionRequest, actionResponse);
	}

	/**
	 * 
	 * This method is used to add or update category properties
	 *
	 * @param categoryId
	 * @param key
	 * @param value
	 */
	public void addOrUpdateCategoryProperties(ThemeDisplay themeDisplay, long categoryId, String key, String value,
			ActionRequest actionRequest) {
		try {
			AssetCategoryProperty categoryProperty = _assetCategoryPropertyLocalService.getCategoryProperty(categoryId,
					key);
			if (Validator.isNotNull(categoryProperty)) {
				_assetCategoryPropertyLocalService.updateCategoryProperty(categoryProperty.getCategoryPropertyId(), key,
						value);
			}
		} catch (Exception e) {
			_log.error("Error in category properties : " + e);
			SessionErrors.add(actionRequest, "error-category");
		}
	}

	/**
	 * 
	 * This method is used to update cp definition with category selected
	 * 
	 * @param cpDefinition       : holds cpdefinition object
	 * @param categoryId         : holds category Id
	 * @param httpServletRequest : holds servlet request
	 * @param themeDisplay       : holds them display object
	 */
	public void updateCPDefinition(CPDefinition cpDefinition, long categoryId, ActionRequest actionRequest,
			ThemeDisplay themeDisplay) {
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		try {
			if (Validator.isNotNull(categoryId)) {
				long[] categoriesArray = { categoryId };
				// create service context object
				ServiceContext serviceContext = ServiceContextFactory.getInstance(CPDefinition.class.getName(),
						actionRequest);
				serviceContext.setAssetCategoryIds(categoriesArray);
				// update values in cpDefinition
				cpDefinition = _cpDefinitionLocalService
						.updateCPDefinitionCategorization(cpDefinition.getCPDefinitionId(), serviceContext);
			}
		} catch (Exception e) {
			_log.error("Error while updating cpdefinition :" + e);

			// logging details in audit_auditevent table
			VILCommonUtil.updateAudit(EventTypes.UPDATE, themeDisplay.getCompanyId(), themeDisplay.getUserId(),
					themeDisplay.getUser().getFullName(), EditAssetCategoryMVCActionCommand.class.getName(),
					cpDefinition.getPrimaryKey(), "Error while updating Cp Definition : " + e.getMessage(), jsonObject);
		}

	}

	private String[] _getCategoryProperties(List<AssetCategoryProperty> categoryProperties) {

		String[] categoryPropertiesArray = new String[categoryProperties.size()];

		for (int i = 0; i < categoryProperties.size(); i++) {
			AssetCategoryProperty categoryProperty = categoryProperties.get(i);

			categoryPropertiesArray[i] = categoryProperty.getKey() + AssetCategoryConstants.PROPERTY_KEY_VALUE_SEPARATOR
					+ categoryProperty.getValue();
		}

		return categoryPropertiesArray;
	}

	@Reference
	private AssetCategoryPropertyLocalService _assetCategoryPropertyLocalService;

	@Reference
	private AssetCategoryService _assetCategoryService;

	@Reference
	private AssetDisplayPageEntryFormProcessor _assetDisplayPageEntryFormProcessor;

	@Reference
	private Language _language;

	@Reference
	private Localization _localization;

	@Reference
	private Portal _portal;

	@Reference
	private CPDefinitionLocalService _cpDefinitionLocalService;

	@Reference
	private CommerceCatalogLocalService _commerceCatalogLocalService;

	private static final Log _log = LogFactoryUtil.getLog(EditAssetCategoryMVCActionCommand.class.getName());

}