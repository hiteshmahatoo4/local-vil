package com.vil.asset.category.admin;


import static com.vil.asset.category.admin.AssetCategoryConstants.*;

import com.liferay.asset.categories.admin.web.constants.AssetCategoriesAdminPortletKeys;
import com.liferay.asset.category.property.model.AssetCategoryProperty;
import com.liferay.asset.category.property.service.AssetCategoryPropertyLocalServiceUtil;
import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetCategoryService;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;

import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
/**
 * @author Diego Hu
 */
@Component(
	property = {
		"javax.portlet.name=" + AssetCategoriesAdminPortletKeys.ASSET_CATEGORIES_ADMIN,
		"mvc.command.name=/asset_categories_admin/delete_asset_category",
		"service.ranking:Integer=100"
	},
	service = MVCActionCommand.class
)
public class DeleteAssetCategoryMVCActionCommand extends BaseMVCActionCommand {

	@Override
	protected void doProcessAction(
			ActionRequest actionRequest, ActionResponse actionResponse)
		throws Exception {
		long categoryId = ParamUtil.getLong(actionRequest, "categoryId");
		try {
			ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
			
			//check sub category count should be zero
			int childCategoryCount  = getChildCategoryCount(categoryId);
			if(childCategoryCount == 0) {
				_log.debug(" Number of assoicated child category ::: "+childCategoryCount);
			//check associated product count should be zero
				int productCount = getProductsByCategoryId(categoryId);
				if(productCount == 0) {
					_log.debug(" Number of assoicated product  ::: "+productCount);
					AssetCategory assetCategory = assetCategoryService.fetchCategory(categoryId);
					if(Validator.isNotNull(assetCategory)) {
						assetCategory.setGroupId(QueryUtil.ALL_POS);
						assetCategory.setModifiedDate(new Date());
						assetCategory.setUserId(themeDisplay.getUserId());
						assetCategory.setUserName(themeDisplay.getUser().getFullName());
						AssetCategoryLocalServiceUtil.updateAssetCategory(assetCategory);
					}
				}else {
					SessionErrors.add(actionRequest,"product-error");
				}
			}else {
				SessionErrors.add(actionRequest,"subcategory-error");
			}

		}catch (Exception e) {
			_log.error("Error in deleting asset category : "+e);
		}
	}

	/**
	 * 
	 * This method is used to get usages of category
	 *
	 * @param categoryId : current category Id
	 * @return : count of assets associated with category
	 */
	private int getProductsByCategoryId(long categoryId) {
		return AssetEntryAssetCategoryRelLocalServiceUtil.getAssetEntryAssetCategoryRelsCountByAssetCategoryId(categoryId);
	}

	/**
	 * 
	 * This method is used to get child category count
	 *
	 * @param categoryId : current category Id 
	 * @return : count of sub category Ids
	 */
	private int getChildCategoryCount(long categoryId) {
		return AssetCategoryLocalServiceUtil.getChildCategoriesCount(categoryId);
	}
	
	
	@Reference
	AssetCategoryService assetCategoryService;
	
	
	private static final Log _log = LogFactoryUtil.getLog(DeleteAssetCategoryMVCActionCommand.class.getName());
	
}