package com.vil.api.common.util;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.liferay.portal.kernel.module.configuration.ConfigurationProviderUtil;
import com.liferay.portal.kernel.util.Validator;
import com.vil.system.settings.ChannelConfiguration;

/**
 * 
 * The purpose of this class is to validate channel Name
 *
 *@author Chinmay Abhyankar
 *
 */
public class ValidateChannel {
	/**
	 * This method is used to validate if the channel name is the same as configured in the system
	 * 
	 * @param channelName
	 * @return boolean validChannel or not
	 */
	public static boolean validateChannelName(String channelName){
		boolean validChannel = false;
		try {
			ChannelConfiguration channelConfiguration = ConfigurationProviderUtil.getSystemConfiguration(ChannelConfiguration.class);
			if(Validator.isNotNull(channelConfiguration.channelNames())) {
				String[] channelNames = channelConfiguration.channelNames().split(",");
				for (String channel : channelNames) {
					if(validChannel = channel.trim().equalsIgnoreCase(channelName)) {
						validChannel = true;
						break;
					}
				}
				
			}
		} catch (ConfigurationException e) {
			_log.error("Error while fetching Channel Configuration - " + e.getMessage());
		}
		return validChannel;
	}
	
	private static final Log _log = LogFactoryUtil.getLog(ValidateChannel.class.getName());
}
