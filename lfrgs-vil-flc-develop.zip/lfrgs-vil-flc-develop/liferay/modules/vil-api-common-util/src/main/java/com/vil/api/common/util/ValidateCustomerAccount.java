package com.vil.api.common.util;

import com.liferay.commerce.account.model.CommerceAccount;
import com.liferay.commerce.account.service.CommerceAccountLocalServiceUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

/**
 * 
 * The purpose of this class is to validate customer account
 *
 *@author Chinmay Abhyankar
 *
 */
public class ValidateCustomerAccount {
	/**
	 * 
	 * This method is used to get customer specific commerce account
	 *
	 * @param customerId : holds userid related to account
	 * @return : commerce account object
	 */
	 public static CommerceAccount getCommerceAccount(long customerId) {
		try {
			return CommerceAccountLocalServiceUtil.fetchCommerceAccount(customerId);
		} catch (Exception e) {
			_log.error("Error in getting commerce account : " + e);
		}
		return null;
	}
	 
	 private static final Log _log = LogFactoryUtil.getLog(ValidateCustomerAccount.class.getName());
}
