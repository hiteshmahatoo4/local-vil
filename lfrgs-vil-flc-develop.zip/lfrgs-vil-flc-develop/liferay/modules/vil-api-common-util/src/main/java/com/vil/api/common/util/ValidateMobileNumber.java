package com.vil.api.common.util;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * 
 * The purpose of this class is to validate mobile Number
 *
 *@author Ankita Malik
 *
 */
public class ValidateMobileNumber {


		/**
		 * This method is used to validate mobile number a/c to regex
		 * 
		 * @param mobileNumber
		 * @return boolean valid or not
		 */
		public static boolean validateMobile(String mobileNumber){
			boolean valid = false;
			try {
				String pattern = "^[6789]\\d{9}$";
				Pattern regex = Pattern.compile(pattern);

				Matcher matcher = regex.matcher(mobileNumber);
				if (matcher.matches()) {
					valid=true;
				} 
				
			} catch (Exception e) {
				_log.error("Error while validating Mobile Number - " + e.getMessage());
			}
			return valid;
		}
		
		private static final Log _log = LogFactoryUtil.getLog(ValidateMobileNumber.class.getName());
	
	
	
	
}
