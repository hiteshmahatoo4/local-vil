package com.vil.api.common.util;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * The purpose of this class is to declare status and message code for all VIL apis
 *
 *
 *@author Chinmay Abhyankar
 *
 */
public class ApiResponseConstants {
	
	public static final String SUCCESS = "Success";
	public static final String FAILED = "Failed";
	public static final String MP100 = "MP100";
	public static final String MP101 = "MP101";
	public static final String MP102 = "MP102";
	public static final String MP103 = "MP103";
	public static final String MP104 = "MP104";
	public static final String MP105 = "MP105";
	public static final String MP106 = "MP106";
	public static final String MP107 = "MP107";
	
	
	/**
	 * 
	 * This method is used to get response message for all api codes
	 *
	 * @param key : status code key
	 * @return : response message
	 */
	public static final String getApiResponseMessage(String key) {
		Map<String, String> messageResponse = new HashMap<String, String>();
		messageResponse.put(MP100, "Request Processed Successfully");
		messageResponse.put(MP101, "Mandatory Parameters blank or missing in request : ");
		messageResponse.put(MP102, "Parameter doesn’t exist in Marketplace : ");
		messageResponse.put(MP103, "Customer ID doesn’t exist in Marketplace : ");
		messageResponse.put(MP104, "Duplicate Data : ");
		messageResponse.put(MP105, "Error in Processing request : ");
		messageResponse.put(MP106, "Unable to fetch details : ");
		messageResponse.put(MP107, "Unable to process cart : ");
		
		return messageResponse.get(key);
	}
}
