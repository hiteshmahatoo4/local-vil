package com.vil.api.common.util;

import com.liferay.petra.string.StringPool;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * 
 * The purpose of this class is class is for date operations
 *
 *@author Chinmay Abhyankar
 *
 */
public class DateUtil {
	
	public static final String LONG_DATE_FORMAT = "dd-MM-yyyy hh:mm:ss";
	public static final String SHORT_DATE_FORMAT = "dd-MM-yyyy";
	public static final String ZONE = "Asia/Calcutta";
	
	/**
	 * 
	 * This method is used to long formatted date
	 *
	 * @param dateStr
	 * @return : long format date
	 */
	public static String getLongFormatDate(Date dateStr) {
		try {
			DateFormat format = new SimpleDateFormat(LONG_DATE_FORMAT);
			format.setTimeZone(TimeZone.getTimeZone(ZONE));
			return format.format(dateStr);
		}catch (Exception e) {
			return StringPool.BLANK;
		}
	}
	
	
	/**
	 * 
	 * This method is used to long formatted date
	 *
	 * @param dateStr
	 * @return : long format date
	 */
	public static String getShortFormatDate(Date dateStr) {
		try {
			DateFormat format = new SimpleDateFormat(SHORT_DATE_FORMAT);
			format.setTimeZone(TimeZone.getTimeZone(ZONE));
			return format.format(dateStr);
		}catch (Exception e) {
			return StringPool.BLANK;
		}
	}
	
	/**
	 * 
	 * This method is used to check long  date format
	 *
	 * @param dateStr
	 * @return : true if valid else false
	 */
	public static boolean isValidLongFormat(String dateStr) {
        DateFormat sdf = new SimpleDateFormat(LONG_DATE_FORMAT);
        sdf.setLenient(false);
        try {
            sdf.parse(dateStr);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
	
	
	/**
	 * 
	 * This method is used to check short  date format
	 *
	 * @param dateStr
	 * @return : true if valid else false
	 */
	public static boolean isValidShortFormat(String dateStr) {
        DateFormat sdf = new SimpleDateFormat(SHORT_DATE_FORMAT);
        sdf.setLenient(false);
        try {
            sdf.parse(dateStr);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }

	/*public static void main(String[] args) {
		System.out.println("long date format : " + getLongFormatDate(new Date())); // returns : 29-03-2023 11:36:15
		System.out.println("short date format : " + getShortFormatDate(new Date())); //returns : 29-03-2023 
	}*/
	
}
