package com.vil.api.common.util;

import com.liferay.petra.string.StringPool;

import java.text.DecimalFormat;

/**
 * 
 * The purpose of this class is for price related operations
 *
 *
 *@author Chinmay Abhyankar
 *
 */
public class PriceFormatUtil {

	/**
	 * 
	 * This method is used to get price formatted
	 *
	 * @param value
	 * @return : string
	 */
	public static String getPriceFormatted(double value) {
		try {
			String pattern = ".00";
			DecimalFormat decimalFormat = new DecimalFormat(pattern);
			return decimalFormat.format(value);
		}catch (Exception e) {
			return StringPool.BLANK;
		}
	}
	
	/*public static void main(String[] args) {
		System.out.println(" with decimal values : "+getPriceFormatted(123.415354354354353)); // return 123.42
		System.out.println(" with decimal values : "+getPriceFormatted(445.00)); // return 445.00
		System.out.println(" with decimal values : "+getPriceFormatted(567)); // return 567.00
		System.out.println(" with decimal values : "+getPriceFormatted(567.01234)); // return 567.01
	}*/
}
