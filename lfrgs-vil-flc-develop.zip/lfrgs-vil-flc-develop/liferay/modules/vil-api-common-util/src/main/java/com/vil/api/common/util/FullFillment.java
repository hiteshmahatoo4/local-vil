package com.vil.api.common.util;

import com.liferay.asset.category.property.model.AssetCategoryProperty;
import com.liferay.asset.category.property.service.AssetCategoryPropertyLocalServiceUtil;
import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.model.CommerceOrderItem;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.util.Validator;
import com.vil.cart.model.VilOrderDetails;
import com.vil.cart.service.VilOrderDetailsLocalServiceUtil;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import vil.reverse.coupons.model.ReverseCoupons;
import vil.reverse.coupons.service.ReverseCouponsLocalServiceUtil;

/**
 * 
 * The purpose of this class is for fullFillment
 *
 * Accessibility : using class name
 *
 *
 *@author Chinmay Abhyankar
 *
 */
public class FullFillment {
	private static final String FULFILMENT_BY_VI = "FULFILMENT_BY_VI";
	
	public static void validateCouponsDetails(CommerceOrder commerceOrder) throws PortalException {
		List<CommerceOrderItem> commerceOrderItems = commerceOrder.getCommerceOrderItems();
		for (CommerceOrderItem commerceOrderItem : commerceOrderItems) {
			CPDefinition cpDefinition = commerceOrderItem.getCPDefinition();
			boolean isvi = getFullfilment(cpDefinition);
			if (isvi) {
				fulfillmentByAdmin(commerceOrder, commerceOrderItem, cpDefinition);
			} else {
				fulfillmentByPartner(commerceOrder, commerceOrderItem, cpDefinition);
			}
		}
	}
	
	
	public static boolean getFullfilment(CPDefinition cpDefinition) {
		AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(CPDefinition.class.getName(),
				cpDefinition.getCPDefinitionId());
		if (assetEntry != null) {
			long[] assetEntryAssetCategoryRel = AssetEntryAssetCategoryRelLocalServiceUtil
					.getAssetCategoryPrimaryKeys(assetEntry.getEntryId());
			if (assetEntryAssetCategoryRel != null) {
				for (Long longValue : assetEntryAssetCategoryRel) {
					AssetCategory fetchAssetCategory = AssetCategoryLocalServiceUtil.fetchAssetCategory(longValue);
					if (Validator.isNotNull(fetchAssetCategory)) {
						DynamicQuery dynamicQuery = AssetCategoryPropertyLocalServiceUtil.dynamicQuery();
						Criterion criterion = RestrictionsFactoryUtil.eq("categoryId",
								fetchAssetCategory.getCategoryId());
						dynamicQuery.add(criterion);

						List<AssetCategoryProperty> categoryPropertyList = AssetCategoryPropertyLocalServiceUtil
								.dynamicQuery(dynamicQuery);

						if (!categoryPropertyList.isEmpty()) {
							for (AssetCategoryProperty a : categoryPropertyList) {
								if (a.getKey().equalsIgnoreCase(FULFILMENT_BY_VI)
										&& a.getValue().equalsIgnoreCase("true")) {
									return true;
								}
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	private static void fulfillmentByPartner(CommerceOrder commerceOrder, CommerceOrderItem commerceOrderItem,
			CPDefinition cpDefinition) {
		Map<String, Object> taskContextMap = new HashMap<>();
		taskContextMap.put("commerceOrder", commerceOrder);
		taskContextMap.put("commerceOrderItem", commerceOrderItem);
		taskContextMap.put("cpDefinition", cpDefinition);
		// calling background task
		Thread thread = new Thread(new FulfillmentThreadExecutor(taskContextMap));
		thread.start();
	}

	
	private static void fulfillmentByAdmin(CommerceOrder commerceOrder, CommerceOrderItem commerceOrderItem,
			CPDefinition cpDefinition) throws PortalException {
		VilOrderDetails vilOrderDetails = VilOrderDetailsLocalServiceUtil
				.findByCommerceOrderItemId(commerceOrderItem.getCommerceOrderId());
		if (!Validator.isNull(vilOrderDetails.getCouponKey())) {
			List<ReverseCoupons> reverseCouponList = ReverseCouponsLocalServiceUtil.getByCouponKey(
					vilOrderDetails.getCouponKey(), commerceOrderItem.getCPInstance().getSku(),
					cpDefinition.getCPDefinitionId());
			if (reverseCouponList != null) {
				ReverseCoupons reverseCoupons = reverseCouponList.get(0);
				reverseCoupons.setIsUsed(true);
				reverseCoupons.setUsedDate(new Date().toString());
				reverseCoupons.setOrderId(commerceOrder.getCommerceOrderId());
				reverseCoupons.setOrderItemId(commerceOrderItem.getCommerceOrderItemId());
				ReverseCouponsLocalServiceUtil.updateReverseCoupons(reverseCoupons);
			}
		}
	}
}
