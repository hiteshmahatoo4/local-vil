package com.vil.api.common.util;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.model.CommerceOrderItem;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.module.framework.ModuleServiceLifecycle;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.ecom.createFulfillmentOrder.request.pojo.Address;
import com.vil.ecom.createFulfillmentOrder.request.pojo.Agent;
import com.vil.ecom.createFulfillmentOrder.request.pojo.CommonServiceRequest;
import com.vil.ecom.createFulfillmentOrder.request.pojo.Customer;
import com.vil.ecom.createFulfillmentOrder.request.pojo.EcomCreateFulfillmentOrderRequest;
import com.vil.ecom.createFulfillmentOrder.request.pojo.Fulfillment;
import com.vil.ecom.createFulfillmentOrder.request.pojo.Item;
import com.vil.ecom.createFulfillmentOrder.request.pojo.Order;
import com.vil.ecom.createFulfillmentOrder.request.pojo.Payment;
import com.vil.ecom.createFulfillmentOrder.request.pojo.RequestMessage;
import com.vil.partner.model.PartnerAddresses;
import com.vil.partner.model.PartnerBankDetails;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerAddressesLocalServiceUtil;
import com.vil.partner.service.PartnerBankDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.osgi.service.component.annotations.Reference;

public class FulfillmentThreadExecutor implements Runnable {
	
	private static final Log _log = LogFactoryUtil.getLog(FulfillmentThreadExecutor.class.getName());

	private Map<String, Object> taskContextMap;

	@Reference(target = ModuleServiceLifecycle.PORTAL_INITIALIZED, unbind = "-")
	protected void setModuleServiceLifecycle(ModuleServiceLifecycle moduleServiceLifecycle) {
		// To Do : Nothing
	}

	public FulfillmentThreadExecutor(Map<String, Object> taskContextMap2) {
		taskContextMap = taskContextMap2;
	}

	@Override
	public void run() {
		CommerceOrder commerceOrder = (CommerceOrder) taskContextMap.get("commerceOrder");
		CommerceOrderItem commerceOrderItem = (CommerceOrderItem) taskContextMap.get("commerceOrderItem");
		CPDefinition cpDefinition = (CPDefinition) taskContextMap.get("cpDefinition");
		doFulfillment(commerceOrder, commerceOrderItem, cpDefinition);
	}

	private void doFulfillment(CommerceOrder commerceOrder, CommerceOrderItem commerceOrderItem,
			CPDefinition cpDefinition) {
		EcomCreateFulfillmentOrderRequest ecomCreateFulfillmentOrderRequest = new EcomCreateFulfillmentOrderRequest();
		RequestMessage requestMessage = new RequestMessage();
		Order order = new Order();
		order.setId(String.valueOf(commerceOrder.getCommerceOrderId()));
		order.setState(WorkflowConstants.getStatusLabel(commerceOrder.getOrderStatus()));
		Payment payment = new Payment();
		payment.setAmount(commerceOrder.getTotal().setScale(2, RoundingMode.HALF_UP).toString());
		payment.setStatus(WorkflowConstants.getStatusLabel(commerceOrder.getPaymentStatus()));
		payment.setPaymentMode(commerceOrder.getCommercePaymentMethodKey());
		payment.setTransactionId(commerceOrder.getTransactionId());
		payment.setTransactionStatus(WorkflowConstants.getStatusLabel(commerceOrder.getPaymentStatus()));
		payment.setTimestamp(commerceOrder.getCreateDate().toLocaleString());
//		payment.setProperty1(commerceOrder.getcommerce);
		try {
			if (commerceOrder.getCommerceAccount() != null) {
				payment.setCollectedBy(commerceOrder.getCommerceAccount().getName());
			}
			payment.setCurrency(commerceOrder.getCommerceCurrency().getName());
		} catch (Exception e) {
			_log.error("Error getting account details : " + e);
		}
		order.setPayment(payment);
		List<Item> items = new ArrayList<>();
		Item item = new Item();
		item.setSkuId(commerceOrderItem.getSku());
		item.setDescription(cpDefinition.getDescription());
		item.setQuantity(String.valueOf(commerceOrderItem.getQuantity()));
		item.setUnitPrice(commerceOrderItem.getUnitPrice().setScale(2, RoundingMode.HALF_UP).toString());
		item.setTotalPrice(commerceOrderItem.getFinalPrice().setScale(2, RoundingMode.HALF_UP).toString());
		List<AssetCategory> assetCategories = AssetCategoryLocalServiceUtil.getCategories(CPDefinition.class.getName(),
				cpDefinition.getCPDefinitionId());
		if (assetCategories != null && assetCategories.get(0) != null) {
			item.setProductCategory(assetCategories.get(0).getName());
		}
		Fulfillment fulfillment = new Fulfillment();
		Agent agent = new Agent();
		Customer customer = new Customer();
		agent.setName(commerceOrder.getUserName());
		try {
			User user = UserLocalServiceUtil.getUser(commerceOrder.getUserId());
			agent.setPhone(user.getPhones().get(0).getNumber());
			customer.setEmailid(commerceOrder.getCommerceAccount().getEmail());
			int age = 0;
			user = UserLocalServiceUtil.getUser(commerceOrder.getCommerceAccount().getUserId());
			customer.setDob(user.getBirthday().toString());
			LocalDate localDate = LocalDate.of(user.getBirthday().getYear(), user.getBirthday().getMonth(),
					user.getBirthday().getDate());
			age = Period.between(localDate, LocalDate.now()).getYears();
			customer.setAge(age + " Years");
			PartnerUsers partnerUsers = PartnerUsersLocalServiceUtil
					.getPartnerUsers(commerceOrder.getCommerceAccountId());
			PartnerBankDetails partnerBankDetails = PartnerBankDetailsLocalServiceUtil
					.findByPartnerId(partnerUsers.getPartnerId());
			customer.setBankAccountNumber(partnerBankDetails.getAccountNumber());
			customer.setBankName(partnerBankDetails.getBank());
			customer.setBankAccountType(partnerBankDetails.getAccountName());
//			customer.setEducation(partnerUsers.gete);
			customer.setEmploymentType(partnerUsers.getDesignation());
//			customer.setSalary(salary);
//			customer.setFatherName(user.getf);
			customer.setFirstName(user.getFirstName());
			customer.setGender(user.isFemale() ? "Female" : "Male");
//			customer.setIdentityProof(identityProof);
			customer.setLastName(user.getLastName());
//			customer.setMaritalStatus);
			customer.setMobileNumber(partnerUsers.getMobile());
//			customer.setMotherName();
//			customer.setProperty1(property1);
			PartnerAddresses partnerAddresses = PartnerAddressesLocalServiceUtil.findByAT_PID("primary",
					partnerUsers.getPartnerId());
			Address address = new Address();
			address.setCity(partnerAddresses.getCity());
			address.setState(String.valueOf(partnerAddresses.getState()));
			address.setZipcode(partnerAddresses.getPin());
			address.setLine1(partnerAddresses.getAddress1());
			address.setLine2(partnerAddresses.getAddress2());
			customer.setAddress(address);
			
		} catch (PortalException e) {
			_log.error("Error in do fullfilment : " +e);
		}
		fulfillment.setAgent(agent);

		fulfillment.setCustomer(customer);
		item.setFulfillment(fulfillment);
		items.add(item);
		order.setItems(items);
		requestMessage.setOrder(order);
		CommonServiceRequest commonServiceRequest = new CommonServiceRequest();
//		commonServiceRequest.setChannel(channel);
		commonServiceRequest.setPartnerId(String.valueOf(commerceOrder.getCommerceAccountId()));
//		commonServiceRequest.setRequestId(requestId);
		requestMessage.setCommonServiceRequest(commonServiceRequest);
		ecomCreateFulfillmentOrderRequest.setRequestMessage(requestMessage);
	}

}
