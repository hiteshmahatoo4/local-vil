/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EcomSrvcConfigCnstnts}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSrvcConfigCnstnts
 * @generated
 */
public class EcomSrvcConfigCnstntsWrapper
	extends BaseModelWrapper<EcomSrvcConfigCnstnts>
	implements EcomSrvcConfigCnstnts, ModelWrapper<EcomSrvcConfigCnstnts> {

	public EcomSrvcConfigCnstntsWrapper(
		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts) {

		super(ecomSrvcConfigCnstnts);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("id", getId());
		attributes.put("srvc_type", getSrvc_type());
		attributes.put("srvc_key", getSrvc_key());
		attributes.put("value", getValue());
		attributes.put("description", getDescription());
		attributes.put("crtn_on", getCrtn_on());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String srvc_type = (String)attributes.get("srvc_type");

		if (srvc_type != null) {
			setSrvc_type(srvc_type);
		}

		String srvc_key = (String)attributes.get("srvc_key");

		if (srvc_key != null) {
			setSrvc_key(srvc_key);
		}

		String value = (String)attributes.get("value");

		if (value != null) {
			setValue(value);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Date crtn_on = (Date)attributes.get("crtn_on");

		if (crtn_on != null) {
			setCrtn_on(crtn_on);
		}
	}

	@Override
	public EcomSrvcConfigCnstnts cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the crtn_on of this ecom srvc config cnstnts.
	 *
	 * @return the crtn_on of this ecom srvc config cnstnts
	 */
	@Override
	public Date getCrtn_on() {
		return model.getCrtn_on();
	}

	/**
	 * Returns the description of this ecom srvc config cnstnts.
	 *
	 * @return the description of this ecom srvc config cnstnts
	 */
	@Override
	public String getDescription() {
		return model.getDescription();
	}

	/**
	 * Returns the ID of this ecom srvc config cnstnts.
	 *
	 * @return the ID of this ecom srvc config cnstnts
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the primary key of this ecom srvc config cnstnts.
	 *
	 * @return the primary key of this ecom srvc config cnstnts
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the srvc_key of this ecom srvc config cnstnts.
	 *
	 * @return the srvc_key of this ecom srvc config cnstnts
	 */
	@Override
	public String getSrvc_key() {
		return model.getSrvc_key();
	}

	/**
	 * Returns the srvc_type of this ecom srvc config cnstnts.
	 *
	 * @return the srvc_type of this ecom srvc config cnstnts
	 */
	@Override
	public String getSrvc_type() {
		return model.getSrvc_type();
	}

	/**
	 * Returns the value of this ecom srvc config cnstnts.
	 *
	 * @return the value of this ecom srvc config cnstnts
	 */
	@Override
	public String getValue() {
		return model.getValue();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the crtn_on of this ecom srvc config cnstnts.
	 *
	 * @param crtn_on the crtn_on of this ecom srvc config cnstnts
	 */
	@Override
	public void setCrtn_on(Date crtn_on) {
		model.setCrtn_on(crtn_on);
	}

	/**
	 * Sets the description of this ecom srvc config cnstnts.
	 *
	 * @param description the description of this ecom srvc config cnstnts
	 */
	@Override
	public void setDescription(String description) {
		model.setDescription(description);
	}

	/**
	 * Sets the ID of this ecom srvc config cnstnts.
	 *
	 * @param id the ID of this ecom srvc config cnstnts
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the primary key of this ecom srvc config cnstnts.
	 *
	 * @param primaryKey the primary key of this ecom srvc config cnstnts
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the srvc_key of this ecom srvc config cnstnts.
	 *
	 * @param srvc_key the srvc_key of this ecom srvc config cnstnts
	 */
	@Override
	public void setSrvc_key(String srvc_key) {
		model.setSrvc_key(srvc_key);
	}

	/**
	 * Sets the srvc_type of this ecom srvc config cnstnts.
	 *
	 * @param srvc_type the srvc_type of this ecom srvc config cnstnts
	 */
	@Override
	public void setSrvc_type(String srvc_type) {
		model.setSrvc_type(srvc_type);
	}

	/**
	 * Sets the value of this ecom srvc config cnstnts.
	 *
	 * @param value the value of this ecom srvc config cnstnts
	 */
	@Override
	public void setValue(String value) {
		model.setValue(value);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected EcomSrvcConfigCnstntsWrapper wrap(
		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts) {

		return new EcomSrvcConfigCnstntsWrapper(ecomSrvcConfigCnstnts);
	}

}