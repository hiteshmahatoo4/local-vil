/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;ecom_srvc_cmmnd_mppng&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see EcomSrvcCmmndMppng
 * @generated
 */
public class EcomSrvcCmmndMppngTable
	extends BaseTable<EcomSrvcCmmndMppngTable> {

	public static final EcomSrvcCmmndMppngTable INSTANCE =
		new EcomSrvcCmmndMppngTable();

	public final Column<EcomSrvcCmmndMppngTable, Long> id = createColumn(
		"id_", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<EcomSrvcCmmndMppngTable, String> srvc_key =
		createColumn(
			"srvc_key", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, String> srvc_req =
		createColumn(
			"srvc_req", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, String> srvc_util_class =
		createColumn(
			"srvc_util_class", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, String> util_signature =
		createColumn(
			"util_signature", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, String> event = createColumn(
		"event", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, String> filler1 = createColumn(
		"filler1", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, String> filler2 = createColumn(
		"filler2", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, String> filler3 = createColumn(
		"filler3", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSrvcCmmndMppngTable, Date> crtd_on = createColumn(
		"crtd_on", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);

	private EcomSrvcCmmndMppngTable() {
		super("ecom_srvc_cmmnd_mppng", EcomSrvcCmmndMppngTable::new);
	}

}