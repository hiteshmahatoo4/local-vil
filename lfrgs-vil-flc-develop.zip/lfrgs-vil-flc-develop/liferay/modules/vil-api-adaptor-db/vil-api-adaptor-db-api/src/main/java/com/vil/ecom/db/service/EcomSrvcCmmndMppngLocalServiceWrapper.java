/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link EcomSrvcCmmndMppngLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see EcomSrvcCmmndMppngLocalService
 * @generated
 */
public class EcomSrvcCmmndMppngLocalServiceWrapper
	implements EcomSrvcCmmndMppngLocalService,
			   ServiceWrapper<EcomSrvcCmmndMppngLocalService> {

	public EcomSrvcCmmndMppngLocalServiceWrapper() {
		this(null);
	}

	public EcomSrvcCmmndMppngLocalServiceWrapper(
		EcomSrvcCmmndMppngLocalService ecomSrvcCmmndMppngLocalService) {

		_ecomSrvcCmmndMppngLocalService = ecomSrvcCmmndMppngLocalService;
	}

	/**
	 * Adds the ecom srvc cmmnd mppng to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomSrvcCmmndMppngLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomSrvcCmmndMppng the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng that was added
	 */
	@Override
	public com.vil.ecom.db.model.EcomSrvcCmmndMppng addEcomSrvcCmmndMppng(
		com.vil.ecom.db.model.EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {

		return _ecomSrvcCmmndMppngLocalService.addEcomSrvcCmmndMppng(
			ecomSrvcCmmndMppng);
	}

	/**
	 * Creates a new ecom srvc cmmnd mppng with the primary key. Does not add the ecom srvc cmmnd mppng to the database.
	 *
	 * @param id the primary key for the new ecom srvc cmmnd mppng
	 * @return the new ecom srvc cmmnd mppng
	 */
	@Override
	public com.vil.ecom.db.model.EcomSrvcCmmndMppng createEcomSrvcCmmndMppng(
		long id) {

		return _ecomSrvcCmmndMppngLocalService.createEcomSrvcCmmndMppng(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomSrvcCmmndMppngLocalService.createPersistedModel(
			primaryKeyObj);
	}

	/**
	 * Deletes the ecom srvc cmmnd mppng from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomSrvcCmmndMppngLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomSrvcCmmndMppng the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng that was removed
	 */
	@Override
	public com.vil.ecom.db.model.EcomSrvcCmmndMppng deleteEcomSrvcCmmndMppng(
		com.vil.ecom.db.model.EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {

		return _ecomSrvcCmmndMppngLocalService.deleteEcomSrvcCmmndMppng(
			ecomSrvcCmmndMppng);
	}

	/**
	 * Deletes the ecom srvc cmmnd mppng with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomSrvcCmmndMppngLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng that was removed
	 * @throws PortalException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomSrvcCmmndMppng deleteEcomSrvcCmmndMppng(
			long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomSrvcCmmndMppngLocalService.deleteEcomSrvcCmmndMppng(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomSrvcCmmndMppngLocalService.deletePersistedModel(
			persistedModel);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _ecomSrvcCmmndMppngLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _ecomSrvcCmmndMppngLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _ecomSrvcCmmndMppngLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _ecomSrvcCmmndMppngLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _ecomSrvcCmmndMppngLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _ecomSrvcCmmndMppngLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _ecomSrvcCmmndMppngLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _ecomSrvcCmmndMppngLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.vil.ecom.db.model.EcomSrvcCmmndMppng fetchEcomSrvcCmmndMppng(
		long id) {

		return _ecomSrvcCmmndMppngLocalService.fetchEcomSrvcCmmndMppng(id);
	}

	@Override
	public java.util.List<com.vil.ecom.db.model.EcomSrvcCmmndMppng>
		findBySrvcKey(String srvc_key) {

		return _ecomSrvcCmmndMppngLocalService.findBySrvcKey(srvc_key);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _ecomSrvcCmmndMppngLocalService.getActionableDynamicQuery();
	}

	/**
	 * Returns the ecom srvc cmmnd mppng with the primary key.
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng
	 * @throws PortalException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomSrvcCmmndMppng getEcomSrvcCmmndMppng(
			long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomSrvcCmmndMppngLocalService.getEcomSrvcCmmndMppng(id);
	}

	/**
	 * Returns a range of all the ecom srvc cmmnd mppngs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @return the range of ecom srvc cmmnd mppngs
	 */
	@Override
	public java.util.List<com.vil.ecom.db.model.EcomSrvcCmmndMppng>
		getEcomSrvcCmmndMppngs(int start, int end) {

		return _ecomSrvcCmmndMppngLocalService.getEcomSrvcCmmndMppngs(
			start, end);
	}

	/**
	 * Returns the number of ecom srvc cmmnd mppngs.
	 *
	 * @return the number of ecom srvc cmmnd mppngs
	 */
	@Override
	public int getEcomSrvcCmmndMppngsCount() {
		return _ecomSrvcCmmndMppngLocalService.getEcomSrvcCmmndMppngsCount();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _ecomSrvcCmmndMppngLocalService.
			getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _ecomSrvcCmmndMppngLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomSrvcCmmndMppngLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the ecom srvc cmmnd mppng in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomSrvcCmmndMppngLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomSrvcCmmndMppng the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng that was updated
	 */
	@Override
	public com.vil.ecom.db.model.EcomSrvcCmmndMppng updateEcomSrvcCmmndMppng(
		com.vil.ecom.db.model.EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {

		return _ecomSrvcCmmndMppngLocalService.updateEcomSrvcCmmndMppng(
			ecomSrvcCmmndMppng);
	}

	@Override
	public EcomSrvcCmmndMppngLocalService getWrappedService() {
		return _ecomSrvcCmmndMppngLocalService;
	}

	@Override
	public void setWrappedService(
		EcomSrvcCmmndMppngLocalService ecomSrvcCmmndMppngLocalService) {

		_ecomSrvcCmmndMppngLocalService = ecomSrvcCmmndMppngLocalService;
	}

	private EcomSrvcCmmndMppngLocalService _ecomSrvcCmmndMppngLocalService;

}