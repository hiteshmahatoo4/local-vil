/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EcomSrvcCmmndMppng}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSrvcCmmndMppng
 * @generated
 */
public class EcomSrvcCmmndMppngWrapper
	extends BaseModelWrapper<EcomSrvcCmmndMppng>
	implements EcomSrvcCmmndMppng, ModelWrapper<EcomSrvcCmmndMppng> {

	public EcomSrvcCmmndMppngWrapper(EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {
		super(ecomSrvcCmmndMppng);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("id", getId());
		attributes.put("srvc_key", getSrvc_key());
		attributes.put("srvc_req", getSrvc_req());
		attributes.put("srvc_util_class", getSrvc_util_class());
		attributes.put("util_signature", getUtil_signature());
		attributes.put("event", getEvent());
		attributes.put("filler1", getFiller1());
		attributes.put("filler2", getFiller2());
		attributes.put("filler3", getFiller3());
		attributes.put("crtd_on", getCrtd_on());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String srvc_key = (String)attributes.get("srvc_key");

		if (srvc_key != null) {
			setSrvc_key(srvc_key);
		}

		String srvc_req = (String)attributes.get("srvc_req");

		if (srvc_req != null) {
			setSrvc_req(srvc_req);
		}

		String srvc_util_class = (String)attributes.get("srvc_util_class");

		if (srvc_util_class != null) {
			setSrvc_util_class(srvc_util_class);
		}

		String util_signature = (String)attributes.get("util_signature");

		if (util_signature != null) {
			setUtil_signature(util_signature);
		}

		String event = (String)attributes.get("event");

		if (event != null) {
			setEvent(event);
		}

		String filler1 = (String)attributes.get("filler1");

		if (filler1 != null) {
			setFiller1(filler1);
		}

		String filler2 = (String)attributes.get("filler2");

		if (filler2 != null) {
			setFiller2(filler2);
		}

		String filler3 = (String)attributes.get("filler3");

		if (filler3 != null) {
			setFiller3(filler3);
		}

		Date crtd_on = (Date)attributes.get("crtd_on");

		if (crtd_on != null) {
			setCrtd_on(crtd_on);
		}
	}

	@Override
	public EcomSrvcCmmndMppng cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the crtd_on of this ecom srvc cmmnd mppng.
	 *
	 * @return the crtd_on of this ecom srvc cmmnd mppng
	 */
	@Override
	public Date getCrtd_on() {
		return model.getCrtd_on();
	}

	/**
	 * Returns the event of this ecom srvc cmmnd mppng.
	 *
	 * @return the event of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getEvent() {
		return model.getEvent();
	}

	/**
	 * Returns the filler1 of this ecom srvc cmmnd mppng.
	 *
	 * @return the filler1 of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getFiller1() {
		return model.getFiller1();
	}

	/**
	 * Returns the filler2 of this ecom srvc cmmnd mppng.
	 *
	 * @return the filler2 of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getFiller2() {
		return model.getFiller2();
	}

	/**
	 * Returns the filler3 of this ecom srvc cmmnd mppng.
	 *
	 * @return the filler3 of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getFiller3() {
		return model.getFiller3();
	}

	/**
	 * Returns the ID of this ecom srvc cmmnd mppng.
	 *
	 * @return the ID of this ecom srvc cmmnd mppng
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the primary key of this ecom srvc cmmnd mppng.
	 *
	 * @return the primary key of this ecom srvc cmmnd mppng
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the srvc_key of this ecom srvc cmmnd mppng.
	 *
	 * @return the srvc_key of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getSrvc_key() {
		return model.getSrvc_key();
	}

	/**
	 * Returns the srvc_req of this ecom srvc cmmnd mppng.
	 *
	 * @return the srvc_req of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getSrvc_req() {
		return model.getSrvc_req();
	}

	/**
	 * Returns the srvc_util_class of this ecom srvc cmmnd mppng.
	 *
	 * @return the srvc_util_class of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getSrvc_util_class() {
		return model.getSrvc_util_class();
	}

	/**
	 * Returns the util_signature of this ecom srvc cmmnd mppng.
	 *
	 * @return the util_signature of this ecom srvc cmmnd mppng
	 */
	@Override
	public String getUtil_signature() {
		return model.getUtil_signature();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the crtd_on of this ecom srvc cmmnd mppng.
	 *
	 * @param crtd_on the crtd_on of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setCrtd_on(Date crtd_on) {
		model.setCrtd_on(crtd_on);
	}

	/**
	 * Sets the event of this ecom srvc cmmnd mppng.
	 *
	 * @param event the event of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setEvent(String event) {
		model.setEvent(event);
	}

	/**
	 * Sets the filler1 of this ecom srvc cmmnd mppng.
	 *
	 * @param filler1 the filler1 of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setFiller1(String filler1) {
		model.setFiller1(filler1);
	}

	/**
	 * Sets the filler2 of this ecom srvc cmmnd mppng.
	 *
	 * @param filler2 the filler2 of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setFiller2(String filler2) {
		model.setFiller2(filler2);
	}

	/**
	 * Sets the filler3 of this ecom srvc cmmnd mppng.
	 *
	 * @param filler3 the filler3 of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setFiller3(String filler3) {
		model.setFiller3(filler3);
	}

	/**
	 * Sets the ID of this ecom srvc cmmnd mppng.
	 *
	 * @param id the ID of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the primary key of this ecom srvc cmmnd mppng.
	 *
	 * @param primaryKey the primary key of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the srvc_key of this ecom srvc cmmnd mppng.
	 *
	 * @param srvc_key the srvc_key of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setSrvc_key(String srvc_key) {
		model.setSrvc_key(srvc_key);
	}

	/**
	 * Sets the srvc_req of this ecom srvc cmmnd mppng.
	 *
	 * @param srvc_req the srvc_req of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setSrvc_req(String srvc_req) {
		model.setSrvc_req(srvc_req);
	}

	/**
	 * Sets the srvc_util_class of this ecom srvc cmmnd mppng.
	 *
	 * @param srvc_util_class the srvc_util_class of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setSrvc_util_class(String srvc_util_class) {
		model.setSrvc_util_class(srvc_util_class);
	}

	/**
	 * Sets the util_signature of this ecom srvc cmmnd mppng.
	 *
	 * @param util_signature the util_signature of this ecom srvc cmmnd mppng
	 */
	@Override
	public void setUtil_signature(String util_signature) {
		model.setUtil_signature(util_signature);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected EcomSrvcCmmndMppngWrapper wrap(
		EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {

		return new EcomSrvcCmmndMppngWrapper(ecomSrvcCmmndMppng);
	}

}