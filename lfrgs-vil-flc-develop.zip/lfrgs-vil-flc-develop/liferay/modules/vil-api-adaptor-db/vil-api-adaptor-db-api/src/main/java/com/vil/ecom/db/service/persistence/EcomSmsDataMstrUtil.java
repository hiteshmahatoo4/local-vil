/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.vil.ecom.db.model.EcomSmsDataMstr;

import java.io.Serializable;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the ecom sms data mstr service. This utility wraps <code>com.vil.ecom.db.service.persistence.impl.EcomSmsDataMstrPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSmsDataMstrPersistence
 * @generated
 */
public class EcomSmsDataMstrUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(EcomSmsDataMstr ecomSmsDataMstr) {
		getPersistence().clearCache(ecomSmsDataMstr);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, EcomSmsDataMstr> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<EcomSmsDataMstr> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<EcomSmsDataMstr> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<EcomSmsDataMstr> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static EcomSmsDataMstr update(EcomSmsDataMstr ecomSmsDataMstr) {
		return getPersistence().update(ecomSmsDataMstr);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static EcomSmsDataMstr update(
		EcomSmsDataMstr ecomSmsDataMstr, ServiceContext serviceContext) {

		return getPersistence().update(ecomSmsDataMstr, serviceContext);
	}

	/**
	 * Returns all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @return the matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByMsisdn(String msisdn) {
		return getPersistence().findByMsisdn(msisdn);
	}

	/**
	 * Returns a range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end) {

		return getPersistence().findByMsisdn(msisdn, start, end);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().findByMsisdn(
			msisdn, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByMsisdn(
			msisdn, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr findByMsisdn_First(
			String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().findByMsisdn_First(msisdn, orderByComparator);
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr fetchByMsisdn_First(
		String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().fetchByMsisdn_First(msisdn, orderByComparator);
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr findByMsisdn_Last(
			String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().findByMsisdn_Last(msisdn, orderByComparator);
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr fetchByMsisdn_Last(
		String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().fetchByMsisdn_Last(msisdn, orderByComparator);
	}

	/**
	 * Returns the ecom sms data mstrs before and after the current ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param id the primary key of the current ecom sms data mstr
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public static EcomSmsDataMstr[] findByMsisdn_PrevAndNext(
			long id, String msisdn,
			OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().findByMsisdn_PrevAndNext(
			id, msisdn, orderByComparator);
	}

	/**
	 * Removes all the ecom sms data mstrs where msisdn = &#63; from the database.
	 *
	 * @param msisdn the msisdn
	 */
	public static void removeByMsisdn(String msisdn) {
		getPersistence().removeByMsisdn(msisdn);
	}

	/**
	 * Returns the number of ecom sms data mstrs where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @return the number of matching ecom sms data mstrs
	 */
	public static int countByMsisdn(String msisdn) {
		return getPersistence().countByMsisdn(msisdn);
	}

	/**
	 * Returns all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @return the matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByCrtnOn(Date crtn_on) {
		return getPersistence().findByCrtnOn(crtn_on);
	}

	/**
	 * Returns a range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end) {

		return getPersistence().findByCrtnOn(crtn_on, start, end);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().findByCrtnOn(
			crtn_on, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByCrtnOn(
			crtn_on, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr findByCrtnOn_First(
			Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().findByCrtnOn_First(crtn_on, orderByComparator);
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr fetchByCrtnOn_First(
		Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().fetchByCrtnOn_First(crtn_on, orderByComparator);
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr findByCrtnOn_Last(
			Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().findByCrtnOn_Last(crtn_on, orderByComparator);
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public static EcomSmsDataMstr fetchByCrtnOn_Last(
		Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().fetchByCrtnOn_Last(crtn_on, orderByComparator);
	}

	/**
	 * Returns the ecom sms data mstrs before and after the current ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param id the primary key of the current ecom sms data mstr
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public static EcomSmsDataMstr[] findByCrtnOn_PrevAndNext(
			long id, Date crtn_on,
			OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().findByCrtnOn_PrevAndNext(
			id, crtn_on, orderByComparator);
	}

	/**
	 * Removes all the ecom sms data mstrs where crtn_on = &#63; from the database.
	 *
	 * @param crtn_on the crtn_on
	 */
	public static void removeByCrtnOn(Date crtn_on) {
		getPersistence().removeByCrtnOn(crtn_on);
	}

	/**
	 * Returns the number of ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @return the number of matching ecom sms data mstrs
	 */
	public static int countByCrtnOn(Date crtn_on) {
		return getPersistence().countByCrtnOn(crtn_on);
	}

	/**
	 * Caches the ecom sms data mstr in the entity cache if it is enabled.
	 *
	 * @param ecomSmsDataMstr the ecom sms data mstr
	 */
	public static void cacheResult(EcomSmsDataMstr ecomSmsDataMstr) {
		getPersistence().cacheResult(ecomSmsDataMstr);
	}

	/**
	 * Caches the ecom sms data mstrs in the entity cache if it is enabled.
	 *
	 * @param ecomSmsDataMstrs the ecom sms data mstrs
	 */
	public static void cacheResult(List<EcomSmsDataMstr> ecomSmsDataMstrs) {
		getPersistence().cacheResult(ecomSmsDataMstrs);
	}

	/**
	 * Creates a new ecom sms data mstr with the primary key. Does not add the ecom sms data mstr to the database.
	 *
	 * @param id the primary key for the new ecom sms data mstr
	 * @return the new ecom sms data mstr
	 */
	public static EcomSmsDataMstr create(long id) {
		return getPersistence().create(id);
	}

	/**
	 * Removes the ecom sms data mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr that was removed
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public static EcomSmsDataMstr remove(long id)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().remove(id);
	}

	public static EcomSmsDataMstr updateImpl(EcomSmsDataMstr ecomSmsDataMstr) {
		return getPersistence().updateImpl(ecomSmsDataMstr);
	}

	/**
	 * Returns the ecom sms data mstr with the primary key or throws a <code>NoSuchEcomSmsDataMstrException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public static EcomSmsDataMstr findByPrimaryKey(long id)
		throws com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException {

		return getPersistence().findByPrimaryKey(id);
	}

	/**
	 * Returns the ecom sms data mstr with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr, or <code>null</code> if a ecom sms data mstr with the primary key could not be found
	 */
	public static EcomSmsDataMstr fetchByPrimaryKey(long id) {
		return getPersistence().fetchByPrimaryKey(id);
	}

	/**
	 * Returns all the ecom sms data mstrs.
	 *
	 * @return the ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findAll(
		int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom sms data mstrs
	 */
	public static List<EcomSmsDataMstr> findAll(
		int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the ecom sms data mstrs from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of ecom sms data mstrs.
	 *
	 * @return the number of ecom sms data mstrs
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static EcomSmsDataMstrPersistence getPersistence() {
		return _persistence;
	}

	private static volatile EcomSmsDataMstrPersistence _persistence;

}