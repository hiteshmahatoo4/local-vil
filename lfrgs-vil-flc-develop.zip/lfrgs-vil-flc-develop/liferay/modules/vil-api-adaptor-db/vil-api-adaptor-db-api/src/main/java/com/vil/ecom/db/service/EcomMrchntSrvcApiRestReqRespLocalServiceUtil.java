/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service;

import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp;

import java.io.Serializable;

import java.util.List;

/**
 * Provides the local service utility for EcomMrchntSrvcApiRestReqResp. This utility wraps
 * <code>com.vil.ecom.db.service.impl.EcomMrchntSrvcApiRestReqRespLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see EcomMrchntSrvcApiRestReqRespLocalService
 * @generated
 */
public class EcomMrchntSrvcApiRestReqRespLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.vil.ecom.db.service.impl.EcomMrchntSrvcApiRestReqRespLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the ecom mrchnt srvc api rest req resp to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomMrchntSrvcApiRestReqResp the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was added
	 */
	public static EcomMrchntSrvcApiRestReqResp addEcomMrchntSrvcApiRestReqResp(
		EcomMrchntSrvcApiRestReqResp ecomMrchntSrvcApiRestReqResp) {

		return getService().addEcomMrchntSrvcApiRestReqResp(
			ecomMrchntSrvcApiRestReqResp);
	}

	public static EcomMrchntSrvcApiRestReqResp addMrchntLogRecord(
		com.vil.ecom.db.custommodel.EcomMrchntSrvcApiRestReqRespCustomModel
			model) {

		return getService().addMrchntLogRecord(model);
	}

	/**
	 * Creates a new ecom mrchnt srvc api rest req resp with the primary key. Does not add the ecom mrchnt srvc api rest req resp to the database.
	 *
	 * @param id the primary key for the new ecom mrchnt srvc api rest req resp
	 * @return the new ecom mrchnt srvc api rest req resp
	 */
	public static EcomMrchntSrvcApiRestReqResp
		createEcomMrchntSrvcApiRestReqResp(long id) {

		return getService().createEcomMrchntSrvcApiRestReqResp(id);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel createPersistedModel(
			Serializable primaryKeyObj)
		throws PortalException {

		return getService().createPersistedModel(primaryKeyObj);
	}

	/**
	 * Deletes the ecom mrchnt srvc api rest req resp from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomMrchntSrvcApiRestReqResp the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was removed
	 */
	public static EcomMrchntSrvcApiRestReqResp
		deleteEcomMrchntSrvcApiRestReqResp(
			EcomMrchntSrvcApiRestReqResp ecomMrchntSrvcApiRestReqResp) {

		return getService().deleteEcomMrchntSrvcApiRestReqResp(
			ecomMrchntSrvcApiRestReqResp);
	}

	/**
	 * Deletes the ecom mrchnt srvc api rest req resp with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param id the primary key of the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was removed
	 * @throws PortalException if a ecom mrchnt srvc api rest req resp with the primary key could not be found
	 */
	public static EcomMrchntSrvcApiRestReqResp
			deleteEcomMrchntSrvcApiRestReqResp(long id)
		throws PortalException {

		return getService().deleteEcomMrchntSrvcApiRestReqResp(id);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel deletePersistedModel(
			PersistedModel persistedModel)
		throws PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static <T> T dslQuery(DSLQuery dslQuery) {
		return getService().dslQuery(dslQuery);
	}

	public static int dslQueryCount(DSLQuery dslQuery) {
		return getService().dslQueryCount(dslQuery);
	}

	public static DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> List<T> dynamicQuery(DynamicQuery dynamicQuery) {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomMrchntSrvcApiRestReqRespModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomMrchntSrvcApiRestReqRespModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(DynamicQuery dynamicQuery) {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static EcomMrchntSrvcApiRestReqResp
		fetchEcomMrchntSrvcApiRestReqResp(long id) {

		return getService().fetchEcomMrchntSrvcApiRestReqResp(id);
	}

	public static com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return getService().getActionableDynamicQuery();
	}

	/**
	 * Returns the ecom mrchnt srvc api rest req resp with the primary key.
	 *
	 * @param id the primary key of the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp
	 * @throws PortalException if a ecom mrchnt srvc api rest req resp with the primary key could not be found
	 */
	public static EcomMrchntSrvcApiRestReqResp getEcomMrchntSrvcApiRestReqResp(
			long id)
		throws PortalException {

		return getService().getEcomMrchntSrvcApiRestReqResp(id);
	}

	/**
	 * Returns a range of all the ecom mrchnt srvc api rest req resps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomMrchntSrvcApiRestReqRespModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom mrchnt srvc api rest req resps
	 * @param end the upper bound of the range of ecom mrchnt srvc api rest req resps (not inclusive)
	 * @return the range of ecom mrchnt srvc api rest req resps
	 */
	public static List<EcomMrchntSrvcApiRestReqResp>
		getEcomMrchntSrvcApiRestReqResps(int start, int end) {

		return getService().getEcomMrchntSrvcApiRestReqResps(start, end);
	}

	/**
	 * Returns the number of ecom mrchnt srvc api rest req resps.
	 *
	 * @return the number of ecom mrchnt srvc api rest req resps
	 */
	public static int getEcomMrchntSrvcApiRestReqRespsCount() {
		return getService().getEcomMrchntSrvcApiRestReqRespsCount();
	}

	public static
		com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
			getIndexableActionableDynamicQuery() {

		return getService().getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel getPersistedModel(Serializable primaryKeyObj)
		throws PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the ecom mrchnt srvc api rest req resp in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomMrchntSrvcApiRestReqResp the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was updated
	 */
	public static EcomMrchntSrvcApiRestReqResp
		updateEcomMrchntSrvcApiRestReqResp(
			EcomMrchntSrvcApiRestReqResp ecomMrchntSrvcApiRestReqResp) {

		return getService().updateEcomMrchntSrvcApiRestReqResp(
			ecomMrchntSrvcApiRestReqResp);
	}

	public static EcomMrchntSrvcApiRestReqRespLocalService getService() {
		return _service;
	}

	private static volatile EcomMrchntSrvcApiRestReqRespLocalService _service;

}