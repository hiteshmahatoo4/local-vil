/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.vil.ecom.db.exception.NoSuchEcomSrvcConfigCnstntsException;
import com.vil.ecom.db.model.EcomSrvcConfigCnstnts;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the ecom srvc config cnstnts service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSrvcConfigCnstntsUtil
 * @generated
 */
@ProviderType
public interface EcomSrvcConfigCnstntsPersistence
	extends BasePersistence<EcomSrvcConfigCnstnts> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EcomSrvcConfigCnstntsUtil} to access the ecom srvc config cnstnts persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @return the matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findBySrvcType(
		String srvc_type);

	/**
	 * Returns a range of all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_type the srvc_type
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @return the range of matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findBySrvcType(
		String srvc_type, int start, int end);

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_type the srvc_type
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findBySrvcType(
		String srvc_type, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_type the srvc_type
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findBySrvcType(
		String srvc_type, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts findBySrvcType_First(
			String srvc_type,
			com.liferay.portal.kernel.util.OrderByComparator
				<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException;

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts fetchBySrvcType_First(
		String srvc_type,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator);

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts findBySrvcType_Last(
			String srvc_type,
			com.liferay.portal.kernel.util.OrderByComparator
				<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException;

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts fetchBySrvcType_Last(
		String srvc_type,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator);

	/**
	 * Returns the ecom srvc config cnstntses before and after the current ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param id the primary key of the current ecom srvc config cnstnts
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	public EcomSrvcConfigCnstnts[] findBySrvcType_PrevAndNext(
			long id, String srvc_type,
			com.liferay.portal.kernel.util.OrderByComparator
				<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException;

	/**
	 * Removes all the ecom srvc config cnstntses where srvc_type = &#63; from the database.
	 *
	 * @param srvc_type the srvc_type
	 */
	public void removeBySrvcType(String srvc_type);

	/**
	 * Returns the number of ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @return the number of matching ecom srvc config cnstntses
	 */
	public int countBySrvcType(String srvc_type);

	/**
	 * Returns all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findByKey(String srvc_key);

	/**
	 * Returns a range of all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @return the range of matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findByKey(
		String srvc_key, int start, int end);

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findByKey(
		String srvc_key, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findByKey(
		String srvc_key, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts findByKey_First(
			String srvc_key,
			com.liferay.portal.kernel.util.OrderByComparator
				<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException;

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts fetchByKey_First(
		String srvc_key,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator);

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts findByKey_Last(
			String srvc_key,
			com.liferay.portal.kernel.util.OrderByComparator
				<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException;

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	public EcomSrvcConfigCnstnts fetchByKey_Last(
		String srvc_key,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator);

	/**
	 * Returns the ecom srvc config cnstntses before and after the current ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param id the primary key of the current ecom srvc config cnstnts
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	public EcomSrvcConfigCnstnts[] findByKey_PrevAndNext(
			long id, String srvc_key,
			com.liferay.portal.kernel.util.OrderByComparator
				<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException;

	/**
	 * Removes all the ecom srvc config cnstntses where srvc_key = &#63; from the database.
	 *
	 * @param srvc_key the srvc_key
	 */
	public void removeByKey(String srvc_key);

	/**
	 * Returns the number of ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the number of matching ecom srvc config cnstntses
	 */
	public int countByKey(String srvc_key);

	/**
	 * Caches the ecom srvc config cnstnts in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcConfigCnstnts the ecom srvc config cnstnts
	 */
	public void cacheResult(EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts);

	/**
	 * Caches the ecom srvc config cnstntses in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcConfigCnstntses the ecom srvc config cnstntses
	 */
	public void cacheResult(
		java.util.List<EcomSrvcConfigCnstnts> ecomSrvcConfigCnstntses);

	/**
	 * Creates a new ecom srvc config cnstnts with the primary key. Does not add the ecom srvc config cnstnts to the database.
	 *
	 * @param id the primary key for the new ecom srvc config cnstnts
	 * @return the new ecom srvc config cnstnts
	 */
	public EcomSrvcConfigCnstnts create(long id);

	/**
	 * Removes the ecom srvc config cnstnts with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts that was removed
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	public EcomSrvcConfigCnstnts remove(long id)
		throws NoSuchEcomSrvcConfigCnstntsException;

	public EcomSrvcConfigCnstnts updateImpl(
		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts);

	/**
	 * Returns the ecom srvc config cnstnts with the primary key or throws a <code>NoSuchEcomSrvcConfigCnstntsException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	public EcomSrvcConfigCnstnts findByPrimaryKey(long id)
		throws NoSuchEcomSrvcConfigCnstntsException;

	/**
	 * Returns the ecom srvc config cnstnts with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts, or <code>null</code> if a ecom srvc config cnstnts with the primary key could not be found
	 */
	public EcomSrvcConfigCnstnts fetchByPrimaryKey(long id);

	/**
	 * Returns all the ecom srvc config cnstntses.
	 *
	 * @return the ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findAll();

	/**
	 * Returns a range of all the ecom srvc config cnstntses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @return the range of ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom srvc config cnstntses
	 */
	public java.util.List<EcomSrvcConfigCnstnts> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcConfigCnstnts>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the ecom srvc config cnstntses from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of ecom srvc config cnstntses.
	 *
	 * @return the number of ecom srvc config cnstntses
	 */
	public int countAll();

}