/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;ecom_crcle_mstr&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see EcomCrcleMstr
 * @generated
 */
public class EcomCrcleMstrTable extends BaseTable<EcomCrcleMstrTable> {

	public static final EcomCrcleMstrTable INSTANCE = new EcomCrcleMstrTable();

	public final Column<EcomCrcleMstrTable, Long> id = createColumn(
		"id_", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<EcomCrcleMstrTable, String> circle_id = createColumn(
		"circle_id", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> circle_cde = createColumn(
		"circle_cde", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> circle_nme = createColumn(
		"circle_nme", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> eai_circle_id =
		createColumn(
			"eai_circle_id", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> upss_circle_id =
		createColumn(
			"upss_circle_id", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> msdp_circle_cde =
		createColumn(
			"msdp_circle_cde", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> msdp_circle_nme =
		createColumn(
			"msdp_circle_nme", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> msdp_content_provider =
		createColumn(
			"msdp_content_provider", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, String> crtd_by = createColumn(
		"crtd_by", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomCrcleMstrTable, Date> crtn_on = createColumn(
		"crtn_on", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);

	private EcomCrcleMstrTable() {
		super("ecom_crcle_mstr", EcomCrcleMstrTable::new);
	}

}