/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;ecom_srvc_api_req_resp&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see EcomMrchntSrvcApiRestReqResp
 * @generated
 */
public class EcomMrchntSrvcApiRestReqRespTable
	extends BaseTable<EcomMrchntSrvcApiRestReqRespTable> {

	public static final EcomMrchntSrvcApiRestReqRespTable INSTANCE =
		new EcomMrchntSrvcApiRestReqRespTable();

	public final Column<EcomMrchntSrvcApiRestReqRespTable, Long> id =
		createColumn("id_", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> service_nme =
		createColumn(
			"service_nme", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> msisdn =
		createColumn(
			"msisdn", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> amt =
		createColumn("amt", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> stts =
		createColumn("stts", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> error_code =
		createColumn(
			"error_code", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> error_msg =
		createColumn(
			"error_msg", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> user_id =
		createColumn(
			"user_id", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> chnnl_id =
		createColumn(
			"chnnl_id", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> req_id =
		createColumn(
			"req_id", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> ip_addr =
		createColumn(
			"ip_addr", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rqst_type =
		createColumn(
			"rqst_type", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> srce_systm =
		createColumn(
			"srce_systm", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_req1 =
		createColumn(
			"rest_req1", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_req2 =
		createColumn(
			"rest_req2", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_req3 =
		createColumn(
			"rest_req3", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_req4 =
		createColumn(
			"rest_req4", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_resp1 =
		createColumn(
			"rest_resp1", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_resp2 =
		createColumn(
			"rest_resp2", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_resp3 =
		createColumn(
			"rest_resp3", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> rest_resp4 =
		createColumn(
			"rest_resp4", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> filler1 =
		createColumn(
			"filler1", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> filler2 =
		createColumn(
			"filler2", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> filler3 =
		createColumn(
			"filler3", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> filler4 =
		createColumn(
			"filler4", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> filler5 =
		createColumn(
			"filler5", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, String> filler6 =
		createColumn(
			"filler6", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, Date> req_timestamp =
		createColumn(
			"req_timestamp", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<EcomMrchntSrvcApiRestReqRespTable, Date>
		resp_timestamp = createColumn(
			"resp_timestamp", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);

	private EcomMrchntSrvcApiRestReqRespTable() {
		super("ecom_srvc_api_req_resp", EcomMrchntSrvcApiRestReqRespTable::new);
	}

}