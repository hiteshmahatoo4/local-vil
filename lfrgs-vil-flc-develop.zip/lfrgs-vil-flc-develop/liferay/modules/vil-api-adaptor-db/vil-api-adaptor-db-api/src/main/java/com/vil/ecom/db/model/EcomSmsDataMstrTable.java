/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;ecom_sms_data_mstr&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see EcomSmsDataMstr
 * @generated
 */
public class EcomSmsDataMstrTable extends BaseTable<EcomSmsDataMstrTable> {

	public static final EcomSmsDataMstrTable INSTANCE =
		new EcomSmsDataMstrTable();

	public final Column<EcomSmsDataMstrTable, Long> id = createColumn(
		"id_", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<EcomSmsDataMstrTable, String> msisdn = createColumn(
		"msisdn", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> event_nme = createColumn(
		"event_nme", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> text_desc = createColumn(
		"text_desc", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> stts = createColumn(
		"stts", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> circle_nme = createColumn(
		"circle_nme", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> sender_id = createColumn(
		"sender_id", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> filler1 = createColumn(
		"filler1", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> filler2 = createColumn(
		"filler2", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> filler3 = createColumn(
		"filler3", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> filler4 = createColumn(
		"filler4", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> filler5 = createColumn(
		"filler5", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, String> crtd_by = createColumn(
		"crtd_by", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<EcomSmsDataMstrTable, Date> crtn_on = createColumn(
		"crtn_on", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);

	private EcomSmsDataMstrTable() {
		super("ecom_sms_data_mstr", EcomSmsDataMstrTable::new);
	}

}