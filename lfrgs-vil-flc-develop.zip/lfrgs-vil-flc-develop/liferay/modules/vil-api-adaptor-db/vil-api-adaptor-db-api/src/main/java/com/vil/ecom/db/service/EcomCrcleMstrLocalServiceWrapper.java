/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link EcomCrcleMstrLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see EcomCrcleMstrLocalService
 * @generated
 */
public class EcomCrcleMstrLocalServiceWrapper
	implements EcomCrcleMstrLocalService,
			   ServiceWrapper<EcomCrcleMstrLocalService> {

	public EcomCrcleMstrLocalServiceWrapper() {
		this(null);
	}

	public EcomCrcleMstrLocalServiceWrapper(
		EcomCrcleMstrLocalService ecomCrcleMstrLocalService) {

		_ecomCrcleMstrLocalService = ecomCrcleMstrLocalService;
	}

	/**
	 * Adds the ecom crcle mstr to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomCrcleMstrLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomCrcleMstr the ecom crcle mstr
	 * @return the ecom crcle mstr that was added
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr addEcomCrcleMstr(
		com.vil.ecom.db.model.EcomCrcleMstr ecomCrcleMstr) {

		return _ecomCrcleMstrLocalService.addEcomCrcleMstr(ecomCrcleMstr);
	}

	/**
	 * Creates a new ecom crcle mstr with the primary key. Does not add the ecom crcle mstr to the database.
	 *
	 * @param id the primary key for the new ecom crcle mstr
	 * @return the new ecom crcle mstr
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr createEcomCrcleMstr(long id) {
		return _ecomCrcleMstrLocalService.createEcomCrcleMstr(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomCrcleMstrLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Deletes the ecom crcle mstr from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomCrcleMstrLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomCrcleMstr the ecom crcle mstr
	 * @return the ecom crcle mstr that was removed
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr deleteEcomCrcleMstr(
		com.vil.ecom.db.model.EcomCrcleMstr ecomCrcleMstr) {

		return _ecomCrcleMstrLocalService.deleteEcomCrcleMstr(ecomCrcleMstr);
	}

	/**
	 * Deletes the ecom crcle mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomCrcleMstrLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr that was removed
	 * @throws PortalException if a ecom crcle mstr with the primary key could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr deleteEcomCrcleMstr(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomCrcleMstrLocalService.deleteEcomCrcleMstr(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomCrcleMstrLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _ecomCrcleMstrLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _ecomCrcleMstrLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _ecomCrcleMstrLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _ecomCrcleMstrLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _ecomCrcleMstrLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _ecomCrcleMstrLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _ecomCrcleMstrLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _ecomCrcleMstrLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr fetchEcomCrcleMstr(long id) {
		return _ecomCrcleMstrLocalService.fetchEcomCrcleMstr(id);
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr findBycircleCde(
			String circle_cde)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return _ecomCrcleMstrLocalService.findBycircleCde(circle_cde);
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr findByEaiCircleId(
			String eai_circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return _ecomCrcleMstrLocalService.findByEaiCircleId(eai_circle_id);
	}

	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr findByUpssCircleId(
			String upss_circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return _ecomCrcleMstrLocalService.findByUpssCircleId(upss_circle_id);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _ecomCrcleMstrLocalService.getActionableDynamicQuery();
	}

	/**
	 * Returns the ecom crcle mstr with the primary key.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr
	 * @throws PortalException if a ecom crcle mstr with the primary key could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr getEcomCrcleMstr(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomCrcleMstrLocalService.getEcomCrcleMstr(id);
	}

	/**
	 * Returns a range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @return the range of ecom crcle mstrs
	 */
	@Override
	public java.util.List<com.vil.ecom.db.model.EcomCrcleMstr>
		getEcomCrcleMstrs(int start, int end) {

		return _ecomCrcleMstrLocalService.getEcomCrcleMstrs(start, end);
	}

	/**
	 * Returns the number of ecom crcle mstrs.
	 *
	 * @return the number of ecom crcle mstrs
	 */
	@Override
	public int getEcomCrcleMstrsCount() {
		return _ecomCrcleMstrLocalService.getEcomCrcleMstrsCount();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _ecomCrcleMstrLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _ecomCrcleMstrLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomCrcleMstrLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the ecom crcle mstr in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomCrcleMstrLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomCrcleMstr the ecom crcle mstr
	 * @return the ecom crcle mstr that was updated
	 */
	@Override
	public com.vil.ecom.db.model.EcomCrcleMstr updateEcomCrcleMstr(
		com.vil.ecom.db.model.EcomCrcleMstr ecomCrcleMstr) {

		return _ecomCrcleMstrLocalService.updateEcomCrcleMstr(ecomCrcleMstr);
	}

	@Override
	public EcomCrcleMstrLocalService getWrappedService() {
		return _ecomCrcleMstrLocalService;
	}

	@Override
	public void setWrappedService(
		EcomCrcleMstrLocalService ecomCrcleMstrLocalService) {

		_ecomCrcleMstrLocalService = ecomCrcleMstrLocalService;
	}

	private EcomCrcleMstrLocalService _ecomCrcleMstrLocalService;

}