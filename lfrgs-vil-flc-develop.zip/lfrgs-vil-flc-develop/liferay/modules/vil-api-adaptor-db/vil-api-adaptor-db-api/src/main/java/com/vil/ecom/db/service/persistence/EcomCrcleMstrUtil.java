/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.vil.ecom.db.model.EcomCrcleMstr;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the ecom crcle mstr service. This utility wraps <code>com.vil.ecom.db.service.persistence.impl.EcomCrcleMstrPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomCrcleMstrPersistence
 * @generated
 */
public class EcomCrcleMstrUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(EcomCrcleMstr ecomCrcleMstr) {
		getPersistence().clearCache(ecomCrcleMstr);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, EcomCrcleMstr> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<EcomCrcleMstr> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<EcomCrcleMstr> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<EcomCrcleMstr> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<EcomCrcleMstr> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static EcomCrcleMstr update(EcomCrcleMstr ecomCrcleMstr) {
		return getPersistence().update(ecomCrcleMstr);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static EcomCrcleMstr update(
		EcomCrcleMstr ecomCrcleMstr, ServiceContext serviceContext) {

		return getPersistence().update(ecomCrcleMstr, serviceContext);
	}

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr findByUpssCircleId(String upss_circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().findByUpssCircleId(upss_circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByUpssCircleId(String upss_circle_id) {
		return getPersistence().fetchByUpssCircleId(upss_circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByUpssCircleId(
		String upss_circle_id, boolean useFinderCache) {

		return getPersistence().fetchByUpssCircleId(
			upss_circle_id, useFinderCache);
	}

	/**
	 * Removes the ecom crcle mstr where upss_circle_id = &#63; from the database.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	public static EcomCrcleMstr removeByUpssCircleId(String upss_circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().removeByUpssCircleId(upss_circle_id);
	}

	/**
	 * Returns the number of ecom crcle mstrs where upss_circle_id = &#63;.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	public static int countByUpssCircleId(String upss_circle_id) {
		return getPersistence().countByUpssCircleId(upss_circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr findByEaiCircleId(String eai_circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().findByEaiCircleId(eai_circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByEaiCircleId(String eai_circle_id) {
		return getPersistence().fetchByEaiCircleId(eai_circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByEaiCircleId(
		String eai_circle_id, boolean useFinderCache) {

		return getPersistence().fetchByEaiCircleId(
			eai_circle_id, useFinderCache);
	}

	/**
	 * Removes the ecom crcle mstr where eai_circle_id = &#63; from the database.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	public static EcomCrcleMstr removeByEaiCircleId(String eai_circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().removeByEaiCircleId(eai_circle_id);
	}

	/**
	 * Returns the number of ecom crcle mstrs where eai_circle_id = &#63;.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	public static int countByEaiCircleId(String eai_circle_id) {
		return getPersistence().countByEaiCircleId(eai_circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_cde the circle_cde
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr findBycircleCde(String circle_cde)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().findBycircleCde(circle_cde);
	}

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_cde the circle_cde
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchBycircleCde(String circle_cde) {
		return getPersistence().fetchBycircleCde(circle_cde);
	}

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_cde the circle_cde
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchBycircleCde(
		String circle_cde, boolean useFinderCache) {

		return getPersistence().fetchBycircleCde(circle_cde, useFinderCache);
	}

	/**
	 * Removes the ecom crcle mstr where circle_cde = &#63; from the database.
	 *
	 * @param circle_cde the circle_cde
	 * @return the ecom crcle mstr that was removed
	 */
	public static EcomCrcleMstr removeBycircleCde(String circle_cde)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().removeBycircleCde(circle_cde);
	}

	/**
	 * Returns the number of ecom crcle mstrs where circle_cde = &#63;.
	 *
	 * @param circle_cde the circle_cde
	 * @return the number of matching ecom crcle mstrs
	 */
	public static int countBycircleCde(String circle_cde) {
		return getPersistence().countBycircleCde(circle_cde);
	}

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_id the circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr findByCircleId(String circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().findByCircleId(circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_id the circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByCircleId(String circle_id) {
		return getPersistence().fetchByCircleId(circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_id the circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByCircleId(
		String circle_id, boolean useFinderCache) {

		return getPersistence().fetchByCircleId(circle_id, useFinderCache);
	}

	/**
	 * Removes the ecom crcle mstr where circle_id = &#63; from the database.
	 *
	 * @param circle_id the circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	public static EcomCrcleMstr removeByCircleId(String circle_id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().removeByCircleId(circle_id);
	}

	/**
	 * Returns the number of ecom crcle mstrs where circle_id = &#63;.
	 *
	 * @param circle_id the circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	public static int countByCircleId(String circle_id) {
		return getPersistence().countByCircleId(circle_id);
	}

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_nme the circle_nme
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr findByCircleNme(String circle_nme)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().findByCircleNme(circle_nme);
	}

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_nme the circle_nme
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByCircleNme(String circle_nme) {
		return getPersistence().fetchByCircleNme(circle_nme);
	}

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_nme the circle_nme
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public static EcomCrcleMstr fetchByCircleNme(
		String circle_nme, boolean useFinderCache) {

		return getPersistence().fetchByCircleNme(circle_nme, useFinderCache);
	}

	/**
	 * Removes the ecom crcle mstr where circle_nme = &#63; from the database.
	 *
	 * @param circle_nme the circle_nme
	 * @return the ecom crcle mstr that was removed
	 */
	public static EcomCrcleMstr removeByCircleNme(String circle_nme)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().removeByCircleNme(circle_nme);
	}

	/**
	 * Returns the number of ecom crcle mstrs where circle_nme = &#63;.
	 *
	 * @param circle_nme the circle_nme
	 * @return the number of matching ecom crcle mstrs
	 */
	public static int countByCircleNme(String circle_nme) {
		return getPersistence().countByCircleNme(circle_nme);
	}

	/**
	 * Caches the ecom crcle mstr in the entity cache if it is enabled.
	 *
	 * @param ecomCrcleMstr the ecom crcle mstr
	 */
	public static void cacheResult(EcomCrcleMstr ecomCrcleMstr) {
		getPersistence().cacheResult(ecomCrcleMstr);
	}

	/**
	 * Caches the ecom crcle mstrs in the entity cache if it is enabled.
	 *
	 * @param ecomCrcleMstrs the ecom crcle mstrs
	 */
	public static void cacheResult(List<EcomCrcleMstr> ecomCrcleMstrs) {
		getPersistence().cacheResult(ecomCrcleMstrs);
	}

	/**
	 * Creates a new ecom crcle mstr with the primary key. Does not add the ecom crcle mstr to the database.
	 *
	 * @param id the primary key for the new ecom crcle mstr
	 * @return the new ecom crcle mstr
	 */
	public static EcomCrcleMstr create(long id) {
		return getPersistence().create(id);
	}

	/**
	 * Removes the ecom crcle mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr that was removed
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	public static EcomCrcleMstr remove(long id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().remove(id);
	}

	public static EcomCrcleMstr updateImpl(EcomCrcleMstr ecomCrcleMstr) {
		return getPersistence().updateImpl(ecomCrcleMstr);
	}

	/**
	 * Returns the ecom crcle mstr with the primary key or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	public static EcomCrcleMstr findByPrimaryKey(long id)
		throws com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException {

		return getPersistence().findByPrimaryKey(id);
	}

	/**
	 * Returns the ecom crcle mstr with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr, or <code>null</code> if a ecom crcle mstr with the primary key could not be found
	 */
	public static EcomCrcleMstr fetchByPrimaryKey(long id) {
		return getPersistence().fetchByPrimaryKey(id);
	}

	/**
	 * Returns all the ecom crcle mstrs.
	 *
	 * @return the ecom crcle mstrs
	 */
	public static List<EcomCrcleMstr> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @return the range of ecom crcle mstrs
	 */
	public static List<EcomCrcleMstr> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom crcle mstrs
	 */
	public static List<EcomCrcleMstr> findAll(
		int start, int end,
		OrderByComparator<EcomCrcleMstr> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom crcle mstrs
	 */
	public static List<EcomCrcleMstr> findAll(
		int start, int end, OrderByComparator<EcomCrcleMstr> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the ecom crcle mstrs from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of ecom crcle mstrs.
	 *
	 * @return the number of ecom crcle mstrs
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static EcomCrcleMstrPersistence getPersistence() {
		return _persistence;
	}

	private static volatile EcomCrcleMstrPersistence _persistence;

}