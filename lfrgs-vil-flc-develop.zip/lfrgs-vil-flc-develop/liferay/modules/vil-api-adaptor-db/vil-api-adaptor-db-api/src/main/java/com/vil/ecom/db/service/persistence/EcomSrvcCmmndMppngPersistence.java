/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.vil.ecom.db.exception.NoSuchEcomSrvcCmmndMppngException;
import com.vil.ecom.db.model.EcomSrvcCmmndMppng;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the ecom srvc cmmnd mppng service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSrvcCmmndMppngUtil
 * @generated
 */
@ProviderType
public interface EcomSrvcCmmndMppngPersistence
	extends BasePersistence<EcomSrvcCmmndMppng> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EcomSrvcCmmndMppngUtil} to access the ecom srvc cmmnd mppng persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the matching ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findBySrvcKey(String srvc_key);

	/**
	 * Returns a range of all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @return the range of matching ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findBySrvcKey(
		String srvc_key, int start, int end);

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findBySrvcKey(
		String srvc_key, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findBySrvcKey(
		String srvc_key, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a matching ecom srvc cmmnd mppng could not be found
	 */
	public EcomSrvcCmmndMppng findBySrvcKey_First(
			String srvc_key,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
				orderByComparator)
		throws NoSuchEcomSrvcCmmndMppngException;

	/**
	 * Returns the first ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc cmmnd mppng, or <code>null</code> if a matching ecom srvc cmmnd mppng could not be found
	 */
	public EcomSrvcCmmndMppng fetchBySrvcKey_First(
		String srvc_key,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
			orderByComparator);

	/**
	 * Returns the last ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a matching ecom srvc cmmnd mppng could not be found
	 */
	public EcomSrvcCmmndMppng findBySrvcKey_Last(
			String srvc_key,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
				orderByComparator)
		throws NoSuchEcomSrvcCmmndMppngException;

	/**
	 * Returns the last ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc cmmnd mppng, or <code>null</code> if a matching ecom srvc cmmnd mppng could not be found
	 */
	public EcomSrvcCmmndMppng fetchBySrvcKey_Last(
		String srvc_key,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
			orderByComparator);

	/**
	 * Returns the ecom srvc cmmnd mppngs before and after the current ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param id the primary key of the current ecom srvc cmmnd mppng
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public EcomSrvcCmmndMppng[] findBySrvcKey_PrevAndNext(
			long id, String srvc_key,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
				orderByComparator)
		throws NoSuchEcomSrvcCmmndMppngException;

	/**
	 * Removes all the ecom srvc cmmnd mppngs where srvc_key = &#63; from the database.
	 *
	 * @param srvc_key the srvc_key
	 */
	public void removeBySrvcKey(String srvc_key);

	/**
	 * Returns the number of ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the number of matching ecom srvc cmmnd mppngs
	 */
	public int countBySrvcKey(String srvc_key);

	/**
	 * Caches the ecom srvc cmmnd mppng in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcCmmndMppng the ecom srvc cmmnd mppng
	 */
	public void cacheResult(EcomSrvcCmmndMppng ecomSrvcCmmndMppng);

	/**
	 * Caches the ecom srvc cmmnd mppngs in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcCmmndMppngs the ecom srvc cmmnd mppngs
	 */
	public void cacheResult(
		java.util.List<EcomSrvcCmmndMppng> ecomSrvcCmmndMppngs);

	/**
	 * Creates a new ecom srvc cmmnd mppng with the primary key. Does not add the ecom srvc cmmnd mppng to the database.
	 *
	 * @param id the primary key for the new ecom srvc cmmnd mppng
	 * @return the new ecom srvc cmmnd mppng
	 */
	public EcomSrvcCmmndMppng create(long id);

	/**
	 * Removes the ecom srvc cmmnd mppng with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng that was removed
	 * @throws NoSuchEcomSrvcCmmndMppngException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public EcomSrvcCmmndMppng remove(long id)
		throws NoSuchEcomSrvcCmmndMppngException;

	public EcomSrvcCmmndMppng updateImpl(EcomSrvcCmmndMppng ecomSrvcCmmndMppng);

	/**
	 * Returns the ecom srvc cmmnd mppng with the primary key or throws a <code>NoSuchEcomSrvcCmmndMppngException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public EcomSrvcCmmndMppng findByPrimaryKey(long id)
		throws NoSuchEcomSrvcCmmndMppngException;

	/**
	 * Returns the ecom srvc cmmnd mppng with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng, or <code>null</code> if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public EcomSrvcCmmndMppng fetchByPrimaryKey(long id);

	/**
	 * Returns all the ecom srvc cmmnd mppngs.
	 *
	 * @return the ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findAll();

	/**
	 * Returns a range of all the ecom srvc cmmnd mppngs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @return the range of ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom srvc cmmnd mppngs
	 */
	public java.util.List<EcomSrvcCmmndMppng> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSrvcCmmndMppng>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the ecom srvc cmmnd mppngs from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of ecom srvc cmmnd mppngs.
	 *
	 * @return the number of ecom srvc cmmnd mppngs
	 */
	public int countAll();

}