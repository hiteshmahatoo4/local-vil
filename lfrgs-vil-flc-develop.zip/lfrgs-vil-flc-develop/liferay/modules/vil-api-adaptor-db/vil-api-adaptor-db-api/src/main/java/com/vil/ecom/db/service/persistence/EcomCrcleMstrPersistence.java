/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException;
import com.vil.ecom.db.model.EcomCrcleMstr;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the ecom crcle mstr service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomCrcleMstrUtil
 * @generated
 */
@ProviderType
public interface EcomCrcleMstrPersistence
	extends BasePersistence<EcomCrcleMstr> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EcomCrcleMstrUtil} to access the ecom crcle mstr persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr findByUpssCircleId(String upss_circle_id)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByUpssCircleId(String upss_circle_id);

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByUpssCircleId(
		String upss_circle_id, boolean useFinderCache);

	/**
	 * Removes the ecom crcle mstr where upss_circle_id = &#63; from the database.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	public EcomCrcleMstr removeByUpssCircleId(String upss_circle_id)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the number of ecom crcle mstrs where upss_circle_id = &#63;.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	public int countByUpssCircleId(String upss_circle_id);

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr findByEaiCircleId(String eai_circle_id)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByEaiCircleId(String eai_circle_id);

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByEaiCircleId(
		String eai_circle_id, boolean useFinderCache);

	/**
	 * Removes the ecom crcle mstr where eai_circle_id = &#63; from the database.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	public EcomCrcleMstr removeByEaiCircleId(String eai_circle_id)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the number of ecom crcle mstrs where eai_circle_id = &#63;.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	public int countByEaiCircleId(String eai_circle_id);

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_cde the circle_cde
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr findBycircleCde(String circle_cde)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_cde the circle_cde
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchBycircleCde(String circle_cde);

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_cde the circle_cde
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchBycircleCde(
		String circle_cde, boolean useFinderCache);

	/**
	 * Removes the ecom crcle mstr where circle_cde = &#63; from the database.
	 *
	 * @param circle_cde the circle_cde
	 * @return the ecom crcle mstr that was removed
	 */
	public EcomCrcleMstr removeBycircleCde(String circle_cde)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the number of ecom crcle mstrs where circle_cde = &#63;.
	 *
	 * @param circle_cde the circle_cde
	 * @return the number of matching ecom crcle mstrs
	 */
	public int countBycircleCde(String circle_cde);

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_id the circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr findByCircleId(String circle_id)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_id the circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByCircleId(String circle_id);

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_id the circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByCircleId(
		String circle_id, boolean useFinderCache);

	/**
	 * Removes the ecom crcle mstr where circle_id = &#63; from the database.
	 *
	 * @param circle_id the circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	public EcomCrcleMstr removeByCircleId(String circle_id)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the number of ecom crcle mstrs where circle_id = &#63;.
	 *
	 * @param circle_id the circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	public int countByCircleId(String circle_id);

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_nme the circle_nme
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr findByCircleNme(String circle_nme)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_nme the circle_nme
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByCircleNme(String circle_nme);

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_nme the circle_nme
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr fetchByCircleNme(
		String circle_nme, boolean useFinderCache);

	/**
	 * Removes the ecom crcle mstr where circle_nme = &#63; from the database.
	 *
	 * @param circle_nme the circle_nme
	 * @return the ecom crcle mstr that was removed
	 */
	public EcomCrcleMstr removeByCircleNme(String circle_nme)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the number of ecom crcle mstrs where circle_nme = &#63;.
	 *
	 * @param circle_nme the circle_nme
	 * @return the number of matching ecom crcle mstrs
	 */
	public int countByCircleNme(String circle_nme);

	/**
	 * Caches the ecom crcle mstr in the entity cache if it is enabled.
	 *
	 * @param ecomCrcleMstr the ecom crcle mstr
	 */
	public void cacheResult(EcomCrcleMstr ecomCrcleMstr);

	/**
	 * Caches the ecom crcle mstrs in the entity cache if it is enabled.
	 *
	 * @param ecomCrcleMstrs the ecom crcle mstrs
	 */
	public void cacheResult(java.util.List<EcomCrcleMstr> ecomCrcleMstrs);

	/**
	 * Creates a new ecom crcle mstr with the primary key. Does not add the ecom crcle mstr to the database.
	 *
	 * @param id the primary key for the new ecom crcle mstr
	 * @return the new ecom crcle mstr
	 */
	public EcomCrcleMstr create(long id);

	/**
	 * Removes the ecom crcle mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr that was removed
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	public EcomCrcleMstr remove(long id) throws NoSuchEcomCrcleMstrException;

	public EcomCrcleMstr updateImpl(EcomCrcleMstr ecomCrcleMstr);

	/**
	 * Returns the ecom crcle mstr with the primary key or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	public EcomCrcleMstr findByPrimaryKey(long id)
		throws NoSuchEcomCrcleMstrException;

	/**
	 * Returns the ecom crcle mstr with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr, or <code>null</code> if a ecom crcle mstr with the primary key could not be found
	 */
	public EcomCrcleMstr fetchByPrimaryKey(long id);

	/**
	 * Returns all the ecom crcle mstrs.
	 *
	 * @return the ecom crcle mstrs
	 */
	public java.util.List<EcomCrcleMstr> findAll();

	/**
	 * Returns a range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @return the range of ecom crcle mstrs
	 */
	public java.util.List<EcomCrcleMstr> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom crcle mstrs
	 */
	public java.util.List<EcomCrcleMstr> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomCrcleMstr>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom crcle mstrs
	 */
	public java.util.List<EcomCrcleMstr> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomCrcleMstr>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the ecom crcle mstrs from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of ecom crcle mstrs.
	 *
	 * @return the number of ecom crcle mstrs
	 */
	public int countAll();

}