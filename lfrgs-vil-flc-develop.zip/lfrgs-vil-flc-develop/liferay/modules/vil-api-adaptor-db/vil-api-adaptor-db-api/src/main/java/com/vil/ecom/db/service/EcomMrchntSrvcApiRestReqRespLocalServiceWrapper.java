/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link EcomMrchntSrvcApiRestReqRespLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see EcomMrchntSrvcApiRestReqRespLocalService
 * @generated
 */
public class EcomMrchntSrvcApiRestReqRespLocalServiceWrapper
	implements EcomMrchntSrvcApiRestReqRespLocalService,
			   ServiceWrapper<EcomMrchntSrvcApiRestReqRespLocalService> {

	public EcomMrchntSrvcApiRestReqRespLocalServiceWrapper() {
		this(null);
	}

	public EcomMrchntSrvcApiRestReqRespLocalServiceWrapper(
		EcomMrchntSrvcApiRestReqRespLocalService
			ecomMrchntSrvcApiRestReqRespLocalService) {

		_ecomMrchntSrvcApiRestReqRespLocalService =
			ecomMrchntSrvcApiRestReqRespLocalService;
	}

	/**
	 * Adds the ecom mrchnt srvc api rest req resp to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomMrchntSrvcApiRestReqResp the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was added
	 */
	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
		addEcomMrchntSrvcApiRestReqResp(
			com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
				ecomMrchntSrvcApiRestReqResp) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			addEcomMrchntSrvcApiRestReqResp(ecomMrchntSrvcApiRestReqResp);
	}

	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
		addMrchntLogRecord(
			com.vil.ecom.db.custommodel.EcomMrchntSrvcApiRestReqRespCustomModel
				model) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.addMrchntLogRecord(
			model);
	}

	/**
	 * Creates a new ecom mrchnt srvc api rest req resp with the primary key. Does not add the ecom mrchnt srvc api rest req resp to the database.
	 *
	 * @param id the primary key for the new ecom mrchnt srvc api rest req resp
	 * @return the new ecom mrchnt srvc api rest req resp
	 */
	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
		createEcomMrchntSrvcApiRestReqResp(long id) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			createEcomMrchntSrvcApiRestReqResp(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomMrchntSrvcApiRestReqRespLocalService.createPersistedModel(
			primaryKeyObj);
	}

	/**
	 * Deletes the ecom mrchnt srvc api rest req resp from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomMrchntSrvcApiRestReqResp the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was removed
	 */
	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
		deleteEcomMrchntSrvcApiRestReqResp(
			com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
				ecomMrchntSrvcApiRestReqResp) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			deleteEcomMrchntSrvcApiRestReqResp(ecomMrchntSrvcApiRestReqResp);
	}

	/**
	 * Deletes the ecom mrchnt srvc api rest req resp with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param id the primary key of the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was removed
	 * @throws PortalException if a ecom mrchnt srvc api rest req resp with the primary key could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
			deleteEcomMrchntSrvcApiRestReqResp(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			deleteEcomMrchntSrvcApiRestReqResp(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomMrchntSrvcApiRestReqRespLocalService.deletePersistedModel(
			persistedModel);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _ecomMrchntSrvcApiRestReqRespLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.dslQueryCount(
			dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _ecomMrchntSrvcApiRestReqRespLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.dynamicQuery(
			dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomMrchntSrvcApiRestReqRespModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.dynamicQuery(
			dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomMrchntSrvcApiRestReqRespModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.dynamicQueryCount(
			dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
		fetchEcomMrchntSrvcApiRestReqResp(long id) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			fetchEcomMrchntSrvcApiRestReqResp(id);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			getActionableDynamicQuery();
	}

	/**
	 * Returns the ecom mrchnt srvc api rest req resp with the primary key.
	 *
	 * @param id the primary key of the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp
	 * @throws PortalException if a ecom mrchnt srvc api rest req resp with the primary key could not be found
	 */
	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
			getEcomMrchntSrvcApiRestReqResp(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			getEcomMrchntSrvcApiRestReqResp(id);
	}

	/**
	 * Returns a range of all the ecom mrchnt srvc api rest req resps.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.ecom.db.model.impl.EcomMrchntSrvcApiRestReqRespModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom mrchnt srvc api rest req resps
	 * @param end the upper bound of the range of ecom mrchnt srvc api rest req resps (not inclusive)
	 * @return the range of ecom mrchnt srvc api rest req resps
	 */
	@Override
	public java.util.List<com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp>
		getEcomMrchntSrvcApiRestReqResps(int start, int end) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			getEcomMrchntSrvcApiRestReqResps(start, end);
	}

	/**
	 * Returns the number of ecom mrchnt srvc api rest req resps.
	 *
	 * @return the number of ecom mrchnt srvc api rest req resps
	 */
	@Override
	public int getEcomMrchntSrvcApiRestReqRespsCount() {
		return _ecomMrchntSrvcApiRestReqRespLocalService.
			getEcomMrchntSrvcApiRestReqRespsCount();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _ecomMrchntSrvcApiRestReqRespLocalService.
			getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _ecomMrchntSrvcApiRestReqRespLocalService.getPersistedModel(
			primaryKeyObj);
	}

	/**
	 * Updates the ecom mrchnt srvc api rest req resp in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect EcomMrchntSrvcApiRestReqRespLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param ecomMrchntSrvcApiRestReqResp the ecom mrchnt srvc api rest req resp
	 * @return the ecom mrchnt srvc api rest req resp that was updated
	 */
	@Override
	public com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
		updateEcomMrchntSrvcApiRestReqResp(
			com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp
				ecomMrchntSrvcApiRestReqResp) {

		return _ecomMrchntSrvcApiRestReqRespLocalService.
			updateEcomMrchntSrvcApiRestReqResp(ecomMrchntSrvcApiRestReqResp);
	}

	@Override
	public EcomMrchntSrvcApiRestReqRespLocalService getWrappedService() {
		return _ecomMrchntSrvcApiRestReqRespLocalService;
	}

	@Override
	public void setWrappedService(
		EcomMrchntSrvcApiRestReqRespLocalService
			ecomMrchntSrvcApiRestReqRespLocalService) {

		_ecomMrchntSrvcApiRestReqRespLocalService =
			ecomMrchntSrvcApiRestReqRespLocalService;
	}

	private EcomMrchntSrvcApiRestReqRespLocalService
		_ecomMrchntSrvcApiRestReqRespLocalService;

}