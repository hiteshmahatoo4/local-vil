/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EcomMrchntSrvcApiRestReqResp}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomMrchntSrvcApiRestReqResp
 * @generated
 */
public class EcomMrchntSrvcApiRestReqRespWrapper
	extends BaseModelWrapper<EcomMrchntSrvcApiRestReqResp>
	implements EcomMrchntSrvcApiRestReqResp,
			   ModelWrapper<EcomMrchntSrvcApiRestReqResp> {

	public EcomMrchntSrvcApiRestReqRespWrapper(
		EcomMrchntSrvcApiRestReqResp ecomMrchntSrvcApiRestReqResp) {

		super(ecomMrchntSrvcApiRestReqResp);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("id", getId());
		attributes.put("service_nme", getService_nme());
		attributes.put("msisdn", getMsisdn());
		attributes.put("amt", getAmt());
		attributes.put("stts", getStts());
		attributes.put("error_code", getError_code());
		attributes.put("error_msg", getError_msg());
		attributes.put("user_id", getUser_id());
		attributes.put("chnnl_id", getChnnl_id());
		attributes.put("req_id", getReq_id());
		attributes.put("ip_addr", getIp_addr());
		attributes.put("rqst_type", getRqst_type());
		attributes.put("srce_systm", getSrce_systm());
		attributes.put("rest_req1", getRest_req1());
		attributes.put("rest_req2", getRest_req2());
		attributes.put("rest_req3", getRest_req3());
		attributes.put("rest_req4", getRest_req4());
		attributes.put("rest_resp1", getRest_resp1());
		attributes.put("rest_resp2", getRest_resp2());
		attributes.put("rest_resp3", getRest_resp3());
		attributes.put("rest_resp4", getRest_resp4());
		attributes.put("filler1", getFiller1());
		attributes.put("filler2", getFiller2());
		attributes.put("filler3", getFiller3());
		attributes.put("filler4", getFiller4());
		attributes.put("filler5", getFiller5());
		attributes.put("filler6", getFiller6());
		attributes.put("req_timestamp", getReq_timestamp());
		attributes.put("resp_timestamp", getResp_timestamp());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String service_nme = (String)attributes.get("service_nme");

		if (service_nme != null) {
			setService_nme(service_nme);
		}

		String msisdn = (String)attributes.get("msisdn");

		if (msisdn != null) {
			setMsisdn(msisdn);
		}

		String amt = (String)attributes.get("amt");

		if (amt != null) {
			setAmt(amt);
		}

		String stts = (String)attributes.get("stts");

		if (stts != null) {
			setStts(stts);
		}

		String error_code = (String)attributes.get("error_code");

		if (error_code != null) {
			setError_code(error_code);
		}

		String error_msg = (String)attributes.get("error_msg");

		if (error_msg != null) {
			setError_msg(error_msg);
		}

		String user_id = (String)attributes.get("user_id");

		if (user_id != null) {
			setUser_id(user_id);
		}

		String chnnl_id = (String)attributes.get("chnnl_id");

		if (chnnl_id != null) {
			setChnnl_id(chnnl_id);
		}

		String req_id = (String)attributes.get("req_id");

		if (req_id != null) {
			setReq_id(req_id);
		}

		String ip_addr = (String)attributes.get("ip_addr");

		if (ip_addr != null) {
			setIp_addr(ip_addr);
		}

		String rqst_type = (String)attributes.get("rqst_type");

		if (rqst_type != null) {
			setRqst_type(rqst_type);
		}

		String srce_systm = (String)attributes.get("srce_systm");

		if (srce_systm != null) {
			setSrce_systm(srce_systm);
		}

		String rest_req1 = (String)attributes.get("rest_req1");

		if (rest_req1 != null) {
			setRest_req1(rest_req1);
		}

		String rest_req2 = (String)attributes.get("rest_req2");

		if (rest_req2 != null) {
			setRest_req2(rest_req2);
		}

		String rest_req3 = (String)attributes.get("rest_req3");

		if (rest_req3 != null) {
			setRest_req3(rest_req3);
		}

		String rest_req4 = (String)attributes.get("rest_req4");

		if (rest_req4 != null) {
			setRest_req4(rest_req4);
		}

		String rest_resp1 = (String)attributes.get("rest_resp1");

		if (rest_resp1 != null) {
			setRest_resp1(rest_resp1);
		}

		String rest_resp2 = (String)attributes.get("rest_resp2");

		if (rest_resp2 != null) {
			setRest_resp2(rest_resp2);
		}

		String rest_resp3 = (String)attributes.get("rest_resp3");

		if (rest_resp3 != null) {
			setRest_resp3(rest_resp3);
		}

		String rest_resp4 = (String)attributes.get("rest_resp4");

		if (rest_resp4 != null) {
			setRest_resp4(rest_resp4);
		}

		String filler1 = (String)attributes.get("filler1");

		if (filler1 != null) {
			setFiller1(filler1);
		}

		String filler2 = (String)attributes.get("filler2");

		if (filler2 != null) {
			setFiller2(filler2);
		}

		String filler3 = (String)attributes.get("filler3");

		if (filler3 != null) {
			setFiller3(filler3);
		}

		String filler4 = (String)attributes.get("filler4");

		if (filler4 != null) {
			setFiller4(filler4);
		}

		String filler5 = (String)attributes.get("filler5");

		if (filler5 != null) {
			setFiller5(filler5);
		}

		String filler6 = (String)attributes.get("filler6");

		if (filler6 != null) {
			setFiller6(filler6);
		}

		Date req_timestamp = (Date)attributes.get("req_timestamp");

		if (req_timestamp != null) {
			setReq_timestamp(req_timestamp);
		}

		Date resp_timestamp = (Date)attributes.get("resp_timestamp");

		if (resp_timestamp != null) {
			setResp_timestamp(resp_timestamp);
		}
	}

	@Override
	public EcomMrchntSrvcApiRestReqResp cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the amt of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the amt of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getAmt() {
		return model.getAmt();
	}

	/**
	 * Returns the chnnl_id of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the chnnl_id of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getChnnl_id() {
		return model.getChnnl_id();
	}

	/**
	 * Returns the error_code of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the error_code of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getError_code() {
		return model.getError_code();
	}

	/**
	 * Returns the error_msg of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the error_msg of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getError_msg() {
		return model.getError_msg();
	}

	/**
	 * Returns the filler1 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the filler1 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getFiller1() {
		return model.getFiller1();
	}

	/**
	 * Returns the filler2 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the filler2 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getFiller2() {
		return model.getFiller2();
	}

	/**
	 * Returns the filler3 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the filler3 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getFiller3() {
		return model.getFiller3();
	}

	/**
	 * Returns the filler4 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the filler4 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getFiller4() {
		return model.getFiller4();
	}

	/**
	 * Returns the filler5 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the filler5 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getFiller5() {
		return model.getFiller5();
	}

	/**
	 * Returns the filler6 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the filler6 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getFiller6() {
		return model.getFiller6();
	}

	/**
	 * Returns the ID of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the ID of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the ip_addr of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the ip_addr of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getIp_addr() {
		return model.getIp_addr();
	}

	/**
	 * Returns the msisdn of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the msisdn of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getMsisdn() {
		return model.getMsisdn();
	}

	/**
	 * Returns the primary key of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the primary key of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the req_id of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the req_id of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getReq_id() {
		return model.getReq_id();
	}

	/**
	 * Returns the req_timestamp of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the req_timestamp of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public Date getReq_timestamp() {
		return model.getReq_timestamp();
	}

	/**
	 * Returns the resp_timestamp of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the resp_timestamp of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public Date getResp_timestamp() {
		return model.getResp_timestamp();
	}

	/**
	 * Returns the rest_req1 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_req1 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_req1() {
		return model.getRest_req1();
	}

	/**
	 * Returns the rest_req2 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_req2 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_req2() {
		return model.getRest_req2();
	}

	/**
	 * Returns the rest_req3 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_req3 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_req3() {
		return model.getRest_req3();
	}

	/**
	 * Returns the rest_req4 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_req4 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_req4() {
		return model.getRest_req4();
	}

	/**
	 * Returns the rest_resp1 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_resp1 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_resp1() {
		return model.getRest_resp1();
	}

	/**
	 * Returns the rest_resp2 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_resp2 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_resp2() {
		return model.getRest_resp2();
	}

	/**
	 * Returns the rest_resp3 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_resp3 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_resp3() {
		return model.getRest_resp3();
	}

	/**
	 * Returns the rest_resp4 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rest_resp4 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRest_resp4() {
		return model.getRest_resp4();
	}

	/**
	 * Returns the rqst_type of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the rqst_type of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getRqst_type() {
		return model.getRqst_type();
	}

	/**
	 * Returns the service_nme of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the service_nme of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getService_nme() {
		return model.getService_nme();
	}

	/**
	 * Returns the srce_systm of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the srce_systm of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getSrce_systm() {
		return model.getSrce_systm();
	}

	/**
	 * Returns the stts of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the stts of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getStts() {
		return model.getStts();
	}

	/**
	 * Returns the user_id of this ecom mrchnt srvc api rest req resp.
	 *
	 * @return the user_id of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public String getUser_id() {
		return model.getUser_id();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the amt of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param amt the amt of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setAmt(String amt) {
		model.setAmt(amt);
	}

	/**
	 * Sets the chnnl_id of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param chnnl_id the chnnl_id of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setChnnl_id(String chnnl_id) {
		model.setChnnl_id(chnnl_id);
	}

	/**
	 * Sets the error_code of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param error_code the error_code of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setError_code(String error_code) {
		model.setError_code(error_code);
	}

	/**
	 * Sets the error_msg of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param error_msg the error_msg of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setError_msg(String error_msg) {
		model.setError_msg(error_msg);
	}

	/**
	 * Sets the filler1 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param filler1 the filler1 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setFiller1(String filler1) {
		model.setFiller1(filler1);
	}

	/**
	 * Sets the filler2 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param filler2 the filler2 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setFiller2(String filler2) {
		model.setFiller2(filler2);
	}

	/**
	 * Sets the filler3 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param filler3 the filler3 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setFiller3(String filler3) {
		model.setFiller3(filler3);
	}

	/**
	 * Sets the filler4 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param filler4 the filler4 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setFiller4(String filler4) {
		model.setFiller4(filler4);
	}

	/**
	 * Sets the filler5 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param filler5 the filler5 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setFiller5(String filler5) {
		model.setFiller5(filler5);
	}

	/**
	 * Sets the filler6 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param filler6 the filler6 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setFiller6(String filler6) {
		model.setFiller6(filler6);
	}

	/**
	 * Sets the ID of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param id the ID of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the ip_addr of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param ip_addr the ip_addr of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setIp_addr(String ip_addr) {
		model.setIp_addr(ip_addr);
	}

	/**
	 * Sets the msisdn of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param msisdn the msisdn of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setMsisdn(String msisdn) {
		model.setMsisdn(msisdn);
	}

	/**
	 * Sets the primary key of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param primaryKey the primary key of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the req_id of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param req_id the req_id of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setReq_id(String req_id) {
		model.setReq_id(req_id);
	}

	/**
	 * Sets the req_timestamp of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param req_timestamp the req_timestamp of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setReq_timestamp(Date req_timestamp) {
		model.setReq_timestamp(req_timestamp);
	}

	/**
	 * Sets the resp_timestamp of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param resp_timestamp the resp_timestamp of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setResp_timestamp(Date resp_timestamp) {
		model.setResp_timestamp(resp_timestamp);
	}

	/**
	 * Sets the rest_req1 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_req1 the rest_req1 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_req1(String rest_req1) {
		model.setRest_req1(rest_req1);
	}

	/**
	 * Sets the rest_req2 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_req2 the rest_req2 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_req2(String rest_req2) {
		model.setRest_req2(rest_req2);
	}

	/**
	 * Sets the rest_req3 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_req3 the rest_req3 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_req3(String rest_req3) {
		model.setRest_req3(rest_req3);
	}

	/**
	 * Sets the rest_req4 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_req4 the rest_req4 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_req4(String rest_req4) {
		model.setRest_req4(rest_req4);
	}

	/**
	 * Sets the rest_resp1 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_resp1 the rest_resp1 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_resp1(String rest_resp1) {
		model.setRest_resp1(rest_resp1);
	}

	/**
	 * Sets the rest_resp2 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_resp2 the rest_resp2 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_resp2(String rest_resp2) {
		model.setRest_resp2(rest_resp2);
	}

	/**
	 * Sets the rest_resp3 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_resp3 the rest_resp3 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_resp3(String rest_resp3) {
		model.setRest_resp3(rest_resp3);
	}

	/**
	 * Sets the rest_resp4 of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rest_resp4 the rest_resp4 of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRest_resp4(String rest_resp4) {
		model.setRest_resp4(rest_resp4);
	}

	/**
	 * Sets the rqst_type of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param rqst_type the rqst_type of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setRqst_type(String rqst_type) {
		model.setRqst_type(rqst_type);
	}

	/**
	 * Sets the service_nme of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param service_nme the service_nme of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setService_nme(String service_nme) {
		model.setService_nme(service_nme);
	}

	/**
	 * Sets the srce_systm of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param srce_systm the srce_systm of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setSrce_systm(String srce_systm) {
		model.setSrce_systm(srce_systm);
	}

	/**
	 * Sets the stts of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param stts the stts of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setStts(String stts) {
		model.setStts(stts);
	}

	/**
	 * Sets the user_id of this ecom mrchnt srvc api rest req resp.
	 *
	 * @param user_id the user_id of this ecom mrchnt srvc api rest req resp
	 */
	@Override
	public void setUser_id(String user_id) {
		model.setUser_id(user_id);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected EcomMrchntSrvcApiRestReqRespWrapper wrap(
		EcomMrchntSrvcApiRestReqResp ecomMrchntSrvcApiRestReqResp) {

		return new EcomMrchntSrvcApiRestReqRespWrapper(
			ecomMrchntSrvcApiRestReqResp);
	}

}