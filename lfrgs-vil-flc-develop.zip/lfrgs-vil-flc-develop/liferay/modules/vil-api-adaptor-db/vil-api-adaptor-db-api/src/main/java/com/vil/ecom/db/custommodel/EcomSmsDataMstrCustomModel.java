package com.vil.ecom.db.custommodel;

import java.util.Date;

public class EcomSmsDataMstrCustomModel {
	
private Long id;
	
	private String msisdn;
	
	private String event_nme;
		
	private String text_desc;
	
	private String stts;
	
	private String circle_nme;
	
	private String sender_id;	
	
	private String filler1;
	
	private String filler2;
	
	private String filler3;
	
	private String filler4;
	
	private String filler5;
	
	private String crtd_by;
	
	private Date crtn_on;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the event_nme
	 */
	public String getEvent_nme() {
		return event_nme;
	}

	/**
	 * @param event_nme the event_nme to set
	 */
	public void setEvent_nme(String event_nme) {
		this.event_nme = event_nme;
	}

	/**
	 * @return the text_desc
	 */
	public String getText_desc() {
		return text_desc;
	}

	/**
	 * @param text_desc the text_desc to set
	 */
	public void setText_desc(String text_desc) {
		this.text_desc = text_desc;
	}

	/**
	 * @return the stts
	 */
	public String getStts() {
		return stts;
	}

	/**
	 * @param stts the stts to set
	 */
	public void setStts(String stts) {
		this.stts = stts;
	}

	/**
	 * @return the circle_nme
	 */
	public String getCircle_nme() {
		return circle_nme;
	}

	/**
	 * @param circle_nme the circle_nme to set
	 */
	public void setCircle_nme(String circle_nme) {
		this.circle_nme = circle_nme;
	}

	/**
	 * @return the sender_id
	 */
	public String getSender_id() {
		return sender_id;
	}

	/**
	 * @param sender_id the sender_id to set
	 */
	public void setSender_id(String sender_id) {
		this.sender_id = sender_id;
	}

	/**
	 * @return the filler1
	 */
	public String getFiller1() {
		return filler1;
	}

	/**
	 * @param filler1 the filler1 to set
	 */
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

	/**
	 * @return the filler2
	 */
	public String getFiller2() {
		return filler2;
	}

	/**
	 * @param filler2 the filler2 to set
	 */
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	/**
	 * @return the filler3
	 */
	public String getFiller3() {
		return filler3;
	}

	/**
	 * @param filler3 the filler3 to set
	 */
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}

	/**
	 * @return the filler4
	 */
	public String getFiller4() {
		return filler4;
	}

	/**
	 * @param filler4 the filler4 to set
	 */
	public void setFiller4(String filler4) {
		this.filler4 = filler4;
	}

	/**
	 * @return the filler5
	 */
	public String getFiller5() {
		return filler5;
	}

	/**
	 * @param filler5 the filler5 to set
	 */
	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}

	/**
	 * @return the crtd_by
	 */
	public String getCrtd_by() {
		return crtd_by;
	}

	/**
	 * @param crtd_by the crtd_by to set
	 */
	public void setCrtd_by(String crtd_by) {
		this.crtd_by = crtd_by;
	}

	/**
	 * @return the crtn_on
	 */
	public Date getCrtn_on() {
		return crtn_on;
	}

	/**
	 * @param crtn_on the crtn_on to set
	 */
	public void setCrtn_on(Date crtn_on) {
		this.crtn_on = crtn_on;
	}
	
	

}
