/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.vil.ecom.db.model.EcomSrvcCmmndMppng;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the ecom srvc cmmnd mppng service. This utility wraps <code>com.vil.ecom.db.service.persistence.impl.EcomSrvcCmmndMppngPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSrvcCmmndMppngPersistence
 * @generated
 */
public class EcomSrvcCmmndMppngUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {
		getPersistence().clearCache(ecomSrvcCmmndMppng);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, EcomSrvcCmmndMppng> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<EcomSrvcCmmndMppng> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<EcomSrvcCmmndMppng> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<EcomSrvcCmmndMppng> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<EcomSrvcCmmndMppng> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static EcomSrvcCmmndMppng update(
		EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {

		return getPersistence().update(ecomSrvcCmmndMppng);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static EcomSrvcCmmndMppng update(
		EcomSrvcCmmndMppng ecomSrvcCmmndMppng, ServiceContext serviceContext) {

		return getPersistence().update(ecomSrvcCmmndMppng, serviceContext);
	}

	/**
	 * Returns all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the matching ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findBySrvcKey(String srvc_key) {
		return getPersistence().findBySrvcKey(srvc_key);
	}

	/**
	 * Returns a range of all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @return the range of matching ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findBySrvcKey(
		String srvc_key, int start, int end) {

		return getPersistence().findBySrvcKey(srvc_key, start, end);
	}

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findBySrvcKey(
		String srvc_key, int start, int end,
		OrderByComparator<EcomSrvcCmmndMppng> orderByComparator) {

		return getPersistence().findBySrvcKey(
			srvc_key, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findBySrvcKey(
		String srvc_key, int start, int end,
		OrderByComparator<EcomSrvcCmmndMppng> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findBySrvcKey(
			srvc_key, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a matching ecom srvc cmmnd mppng could not be found
	 */
	public static EcomSrvcCmmndMppng findBySrvcKey_First(
			String srvc_key,
			OrderByComparator<EcomSrvcCmmndMppng> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSrvcCmmndMppngException {

		return getPersistence().findBySrvcKey_First(
			srvc_key, orderByComparator);
	}

	/**
	 * Returns the first ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc cmmnd mppng, or <code>null</code> if a matching ecom srvc cmmnd mppng could not be found
	 */
	public static EcomSrvcCmmndMppng fetchBySrvcKey_First(
		String srvc_key,
		OrderByComparator<EcomSrvcCmmndMppng> orderByComparator) {

		return getPersistence().fetchBySrvcKey_First(
			srvc_key, orderByComparator);
	}

	/**
	 * Returns the last ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a matching ecom srvc cmmnd mppng could not be found
	 */
	public static EcomSrvcCmmndMppng findBySrvcKey_Last(
			String srvc_key,
			OrderByComparator<EcomSrvcCmmndMppng> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSrvcCmmndMppngException {

		return getPersistence().findBySrvcKey_Last(srvc_key, orderByComparator);
	}

	/**
	 * Returns the last ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc cmmnd mppng, or <code>null</code> if a matching ecom srvc cmmnd mppng could not be found
	 */
	public static EcomSrvcCmmndMppng fetchBySrvcKey_Last(
		String srvc_key,
		OrderByComparator<EcomSrvcCmmndMppng> orderByComparator) {

		return getPersistence().fetchBySrvcKey_Last(
			srvc_key, orderByComparator);
	}

	/**
	 * Returns the ecom srvc cmmnd mppngs before and after the current ecom srvc cmmnd mppng in the ordered set where srvc_key = &#63;.
	 *
	 * @param id the primary key of the current ecom srvc cmmnd mppng
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public static EcomSrvcCmmndMppng[] findBySrvcKey_PrevAndNext(
			long id, String srvc_key,
			OrderByComparator<EcomSrvcCmmndMppng> orderByComparator)
		throws com.vil.ecom.db.exception.NoSuchEcomSrvcCmmndMppngException {

		return getPersistence().findBySrvcKey_PrevAndNext(
			id, srvc_key, orderByComparator);
	}

	/**
	 * Removes all the ecom srvc cmmnd mppngs where srvc_key = &#63; from the database.
	 *
	 * @param srvc_key the srvc_key
	 */
	public static void removeBySrvcKey(String srvc_key) {
		getPersistence().removeBySrvcKey(srvc_key);
	}

	/**
	 * Returns the number of ecom srvc cmmnd mppngs where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the number of matching ecom srvc cmmnd mppngs
	 */
	public static int countBySrvcKey(String srvc_key) {
		return getPersistence().countBySrvcKey(srvc_key);
	}

	/**
	 * Caches the ecom srvc cmmnd mppng in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcCmmndMppng the ecom srvc cmmnd mppng
	 */
	public static void cacheResult(EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {
		getPersistence().cacheResult(ecomSrvcCmmndMppng);
	}

	/**
	 * Caches the ecom srvc cmmnd mppngs in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcCmmndMppngs the ecom srvc cmmnd mppngs
	 */
	public static void cacheResult(
		List<EcomSrvcCmmndMppng> ecomSrvcCmmndMppngs) {

		getPersistence().cacheResult(ecomSrvcCmmndMppngs);
	}

	/**
	 * Creates a new ecom srvc cmmnd mppng with the primary key. Does not add the ecom srvc cmmnd mppng to the database.
	 *
	 * @param id the primary key for the new ecom srvc cmmnd mppng
	 * @return the new ecom srvc cmmnd mppng
	 */
	public static EcomSrvcCmmndMppng create(long id) {
		return getPersistence().create(id);
	}

	/**
	 * Removes the ecom srvc cmmnd mppng with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng that was removed
	 * @throws NoSuchEcomSrvcCmmndMppngException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public static EcomSrvcCmmndMppng remove(long id)
		throws com.vil.ecom.db.exception.NoSuchEcomSrvcCmmndMppngException {

		return getPersistence().remove(id);
	}

	public static EcomSrvcCmmndMppng updateImpl(
		EcomSrvcCmmndMppng ecomSrvcCmmndMppng) {

		return getPersistence().updateImpl(ecomSrvcCmmndMppng);
	}

	/**
	 * Returns the ecom srvc cmmnd mppng with the primary key or throws a <code>NoSuchEcomSrvcCmmndMppngException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng
	 * @throws NoSuchEcomSrvcCmmndMppngException if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public static EcomSrvcCmmndMppng findByPrimaryKey(long id)
		throws com.vil.ecom.db.exception.NoSuchEcomSrvcCmmndMppngException {

		return getPersistence().findByPrimaryKey(id);
	}

	/**
	 * Returns the ecom srvc cmmnd mppng with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc cmmnd mppng
	 * @return the ecom srvc cmmnd mppng, or <code>null</code> if a ecom srvc cmmnd mppng with the primary key could not be found
	 */
	public static EcomSrvcCmmndMppng fetchByPrimaryKey(long id) {
		return getPersistence().fetchByPrimaryKey(id);
	}

	/**
	 * Returns all the ecom srvc cmmnd mppngs.
	 *
	 * @return the ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the ecom srvc cmmnd mppngs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @return the range of ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findAll(
		int start, int end,
		OrderByComparator<EcomSrvcCmmndMppng> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the ecom srvc cmmnd mppngs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcCmmndMppngModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc cmmnd mppngs
	 * @param end the upper bound of the range of ecom srvc cmmnd mppngs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom srvc cmmnd mppngs
	 */
	public static List<EcomSrvcCmmndMppng> findAll(
		int start, int end,
		OrderByComparator<EcomSrvcCmmndMppng> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the ecom srvc cmmnd mppngs from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of ecom srvc cmmnd mppngs.
	 *
	 * @return the number of ecom srvc cmmnd mppngs
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static EcomSrvcCmmndMppngPersistence getPersistence() {
		return _persistence;
	}

	private static volatile EcomSrvcCmmndMppngPersistence _persistence;

}