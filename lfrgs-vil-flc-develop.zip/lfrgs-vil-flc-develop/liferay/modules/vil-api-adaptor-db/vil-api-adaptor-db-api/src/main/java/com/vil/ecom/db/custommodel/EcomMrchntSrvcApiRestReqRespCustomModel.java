package com.vil.ecom.db.custommodel;

import java.util.Date;

public class EcomMrchntSrvcApiRestReqRespCustomModel {
	
	private long id;
	private String service_nme;
	private String msisdn;
	private String amt;
	private String stts;
	private String error_code;
	private String error_msg;
	private String user_id;
	private String chnnl_id;
	private String req_id;
	private String ip_addr;
	private String rqst_type;
	private String srce_systm;

	private String rest_req1;
	private String rest_req2;
	private String rest_req3;
	private String rest_req4;
	private String rest_resp1;
	private String rest_resp2;
	private String rest_resp3;
	private String rest_resp4;
	
	private String filler1;
	private String filler2;
	private String filler3;
	private String filler4;
	private String filler5;
	private String filler6;
	
	private Date req_timestamp;
	private Date resp_timestamp;
	
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the service_nme
	 */
	public String getService_nme() {
		return service_nme;
	}
	/**
	 * @param service_nme the service_nme to set
	 */
	public void setService_nme(String service_nme) {
		this.service_nme = service_nme;
	}
	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}
	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	/**
	 * @return the amt
	 */
	public String getAmt() {
		return amt;
	}
	/**
	 * @param amt the amt to set
	 */
	public void setAmt(String amt) {
		this.amt = amt;
	}
	/**
	 * @return the stts
	 */
	public String getStts() {
		return stts;
	}
	/**
	 * @param stts the stts to set
	 */
	public void setStts(String stts) {
		this.stts = stts;
	}
	/**
	 * @return the error_code
	 */
	public String getError_code() {
		return error_code;
	}
	/**
	 * @param error_code the error_code to set
	 */
	public void setError_code(String error_code) {
		this.error_code = error_code;
	}
	/**
	 * @return the error_msg
	 */
	public String getError_msg() {
		return error_msg;
	}
	/**
	 * @param error_msg the error_msg to set
	 */
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}
	/**
	 * @return the user_id
	 */
	public String getUser_id() {
		return user_id;
	}
	/**
	 * @param user_id the user_id to set
	 */
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	/**
	 * @return the chnnl_id
	 */
	public String getChnnl_id() {
		return chnnl_id;
	}
	/**
	 * @param chnnl_id the chnnl_id to set
	 */
	public void setChnnl_id(String chnnl_id) {
		this.chnnl_id = chnnl_id;
	}
	/**
	 * @return the req_id
	 */
	public String getReq_id() {
		return req_id;
	}
	/**
	 * @param req_id the req_id to set
	 */
	public void setReq_id(String req_id) {
		this.req_id = req_id;
	}
	/**
	 * @return the ip_addr
	 */
	public String getIp_addr() {
		return ip_addr;
	}
	/**
	 * @param ip_addr the ip_addr to set
	 */
	public void setIp_addr(String ip_addr) {
		this.ip_addr = ip_addr;
	}
	/**
	 * @return the rqst_type
	 */
	public String getRqst_type() {
		return rqst_type;
	}
	/**
	 * @param rqst_type the rqst_type to set
	 */
	public void setRqst_type(String rqst_type) {
		this.rqst_type = rqst_type;
	}
	/**
	 * @return the srce_systm
	 */
	public String getSrce_systm() {
		return srce_systm;
	}
	/**
	 * @param srce_systm the srce_systm to set
	 */
	public void setSrce_systm(String srce_systm) {
		this.srce_systm = srce_systm;
	}
	/**
	 * @return the rest_req1
	 */
	public String getRest_req1() {
		return rest_req1;
	}
	/**
	 * @param rest_req1 the rest_req1 to set
	 */
	public void setRest_req1(String rest_req1) {
		this.rest_req1 = rest_req1;
	}
	/**
	 * @return the rest_req2
	 */
	public String getRest_req2() {
		return rest_req2;
	}
	/**
	 * @param rest_req2 the rest_req2 to set
	 */
	public void setRest_req2(String rest_req2) {
		this.rest_req2 = rest_req2;
	}
	/**
	 * @return the rest_req3
	 */
	public String getRest_req3() {
		return rest_req3;
	}
	/**
	 * @param rest_req3 the rest_req3 to set
	 */
	public void setRest_req3(String rest_req3) {
		this.rest_req3 = rest_req3;
	}
	/**
	 * @return the rest_req4
	 */
	public String getRest_req4() {
		return rest_req4;
	}
	/**
	 * @param rest_req4 the rest_req4 to set
	 */
	public void setRest_req4(String rest_req4) {
		this.rest_req4 = rest_req4;
	}
	/**
	 * @return the rest_resp1
	 */
	public String getRest_resp1() {
		return rest_resp1;
	}
	/**
	 * @param rest_resp1 the rest_resp1 to set
	 */
	public void setRest_resp1(String rest_resp1) {
		this.rest_resp1 = rest_resp1;
	}
	/**
	 * @return the rest_resp2
	 */
	public String getRest_resp2() {
		return rest_resp2;
	}
	/**
	 * @param rest_resp2 the rest_resp2 to set
	 */
	public void setRest_resp2(String rest_resp2) {
		this.rest_resp2 = rest_resp2;
	}
	/**
	 * @return the rest_resp3
	 */
	public String getRest_resp3() {
		return rest_resp3;
	}
	/**
	 * @param rest_resp3 the rest_resp3 to set
	 */
	public void setRest_resp3(String rest_resp3) {
		this.rest_resp3 = rest_resp3;
	}
	/**
	 * @return the rest_resp4
	 */
	public String getRest_resp4() {
		return rest_resp4;
	}
	/**
	 * @param rest_resp4 the rest_resp4 to set
	 */
	public void setRest_resp4(String rest_resp4) {
		this.rest_resp4 = rest_resp4;
	}
	/**
	 * @return the filler1
	 */
	public String getFiller1() {
		return filler1;
	}
	/**
	 * @param filler1 the filler1 to set
	 */
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	/**
	 * @return the filler2
	 */
	public String getFiller2() {
		return filler2;
	}
	/**
	 * @param filler2 the filler2 to set
	 */
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
	/**
	 * @return the filler3
	 */
	public String getFiller3() {
		return filler3;
	}
	/**
	 * @param filler3 the filler3 to set
	 */
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}
	/**
	 * @return the filler4
	 */
	public String getFiller4() {
		return filler4;
	}
	/**
	 * @param filler4 the filler4 to set
	 */
	public void setFiller4(String filler4) {
		this.filler4 = filler4;
	}
	/**
	 * @return the filler5
	 */
	public String getFiller5() {
		return filler5;
	}
	/**
	 * @param filler5 the filler5 to set
	 */
	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}
	/**
	 * @return the filler6
	 */
	public String getFiller6() {
		return filler6;
	}
	/**
	 * @param filler6 the filler6 to set
	 */
	public void setFiller6(String filler6) {
		this.filler6 = filler6;
	}
	/**
	 * @return the req_timestamp
	 */
	public Date getReq_timestamp() {
		return req_timestamp;
	}
	/**
	 * @param req_timestamp the req_timestamp to set
	 */
	public void setReq_timestamp(Date req_timestamp) {
		this.req_timestamp = req_timestamp;
	}
	/**
	 * @return the resp_timestamp
	 */
	public Date getResp_timestamp() {
		return resp_timestamp;
	}
	/**
	 * @param resp_timestamp the resp_timestamp to set
	 */
	public void setResp_timestamp(Date resp_timestamp) {
		this.resp_timestamp = resp_timestamp;
	}
	
	
}
