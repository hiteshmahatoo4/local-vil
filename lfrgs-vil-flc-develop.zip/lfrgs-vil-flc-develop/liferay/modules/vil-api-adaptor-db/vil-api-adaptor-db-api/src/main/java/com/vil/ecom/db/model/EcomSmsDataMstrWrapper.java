/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EcomSmsDataMstr}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSmsDataMstr
 * @generated
 */
public class EcomSmsDataMstrWrapper
	extends BaseModelWrapper<EcomSmsDataMstr>
	implements EcomSmsDataMstr, ModelWrapper<EcomSmsDataMstr> {

	public EcomSmsDataMstrWrapper(EcomSmsDataMstr ecomSmsDataMstr) {
		super(ecomSmsDataMstr);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("id", getId());
		attributes.put("msisdn", getMsisdn());
		attributes.put("event_nme", getEvent_nme());
		attributes.put("text_desc", getText_desc());
		attributes.put("stts", getStts());
		attributes.put("circle_nme", getCircle_nme());
		attributes.put("sender_id", getSender_id());
		attributes.put("filler1", getFiller1());
		attributes.put("filler2", getFiller2());
		attributes.put("filler3", getFiller3());
		attributes.put("filler4", getFiller4());
		attributes.put("filler5", getFiller5());
		attributes.put("crtd_by", getCrtd_by());
		attributes.put("crtn_on", getCrtn_on());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String msisdn = (String)attributes.get("msisdn");

		if (msisdn != null) {
			setMsisdn(msisdn);
		}

		String event_nme = (String)attributes.get("event_nme");

		if (event_nme != null) {
			setEvent_nme(event_nme);
		}

		String text_desc = (String)attributes.get("text_desc");

		if (text_desc != null) {
			setText_desc(text_desc);
		}

		String stts = (String)attributes.get("stts");

		if (stts != null) {
			setStts(stts);
		}

		String circle_nme = (String)attributes.get("circle_nme");

		if (circle_nme != null) {
			setCircle_nme(circle_nme);
		}

		String sender_id = (String)attributes.get("sender_id");

		if (sender_id != null) {
			setSender_id(sender_id);
		}

		String filler1 = (String)attributes.get("filler1");

		if (filler1 != null) {
			setFiller1(filler1);
		}

		String filler2 = (String)attributes.get("filler2");

		if (filler2 != null) {
			setFiller2(filler2);
		}

		String filler3 = (String)attributes.get("filler3");

		if (filler3 != null) {
			setFiller3(filler3);
		}

		String filler4 = (String)attributes.get("filler4");

		if (filler4 != null) {
			setFiller4(filler4);
		}

		String filler5 = (String)attributes.get("filler5");

		if (filler5 != null) {
			setFiller5(filler5);
		}

		String crtd_by = (String)attributes.get("crtd_by");

		if (crtd_by != null) {
			setCrtd_by(crtd_by);
		}

		Date crtn_on = (Date)attributes.get("crtn_on");

		if (crtn_on != null) {
			setCrtn_on(crtn_on);
		}
	}

	@Override
	public EcomSmsDataMstr cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the circle_nme of this ecom sms data mstr.
	 *
	 * @return the circle_nme of this ecom sms data mstr
	 */
	@Override
	public String getCircle_nme() {
		return model.getCircle_nme();
	}

	/**
	 * Returns the crtd_by of this ecom sms data mstr.
	 *
	 * @return the crtd_by of this ecom sms data mstr
	 */
	@Override
	public String getCrtd_by() {
		return model.getCrtd_by();
	}

	/**
	 * Returns the crtn_on of this ecom sms data mstr.
	 *
	 * @return the crtn_on of this ecom sms data mstr
	 */
	@Override
	public Date getCrtn_on() {
		return model.getCrtn_on();
	}

	/**
	 * Returns the event_nme of this ecom sms data mstr.
	 *
	 * @return the event_nme of this ecom sms data mstr
	 */
	@Override
	public String getEvent_nme() {
		return model.getEvent_nme();
	}

	/**
	 * Returns the filler1 of this ecom sms data mstr.
	 *
	 * @return the filler1 of this ecom sms data mstr
	 */
	@Override
	public String getFiller1() {
		return model.getFiller1();
	}

	/**
	 * Returns the filler2 of this ecom sms data mstr.
	 *
	 * @return the filler2 of this ecom sms data mstr
	 */
	@Override
	public String getFiller2() {
		return model.getFiller2();
	}

	/**
	 * Returns the filler3 of this ecom sms data mstr.
	 *
	 * @return the filler3 of this ecom sms data mstr
	 */
	@Override
	public String getFiller3() {
		return model.getFiller3();
	}

	/**
	 * Returns the filler4 of this ecom sms data mstr.
	 *
	 * @return the filler4 of this ecom sms data mstr
	 */
	@Override
	public String getFiller4() {
		return model.getFiller4();
	}

	/**
	 * Returns the filler5 of this ecom sms data mstr.
	 *
	 * @return the filler5 of this ecom sms data mstr
	 */
	@Override
	public String getFiller5() {
		return model.getFiller5();
	}

	/**
	 * Returns the ID of this ecom sms data mstr.
	 *
	 * @return the ID of this ecom sms data mstr
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the msisdn of this ecom sms data mstr.
	 *
	 * @return the msisdn of this ecom sms data mstr
	 */
	@Override
	public String getMsisdn() {
		return model.getMsisdn();
	}

	/**
	 * Returns the primary key of this ecom sms data mstr.
	 *
	 * @return the primary key of this ecom sms data mstr
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the sender_id of this ecom sms data mstr.
	 *
	 * @return the sender_id of this ecom sms data mstr
	 */
	@Override
	public String getSender_id() {
		return model.getSender_id();
	}

	/**
	 * Returns the stts of this ecom sms data mstr.
	 *
	 * @return the stts of this ecom sms data mstr
	 */
	@Override
	public String getStts() {
		return model.getStts();
	}

	/**
	 * Returns the text_desc of this ecom sms data mstr.
	 *
	 * @return the text_desc of this ecom sms data mstr
	 */
	@Override
	public String getText_desc() {
		return model.getText_desc();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the circle_nme of this ecom sms data mstr.
	 *
	 * @param circle_nme the circle_nme of this ecom sms data mstr
	 */
	@Override
	public void setCircle_nme(String circle_nme) {
		model.setCircle_nme(circle_nme);
	}

	/**
	 * Sets the crtd_by of this ecom sms data mstr.
	 *
	 * @param crtd_by the crtd_by of this ecom sms data mstr
	 */
	@Override
	public void setCrtd_by(String crtd_by) {
		model.setCrtd_by(crtd_by);
	}

	/**
	 * Sets the crtn_on of this ecom sms data mstr.
	 *
	 * @param crtn_on the crtn_on of this ecom sms data mstr
	 */
	@Override
	public void setCrtn_on(Date crtn_on) {
		model.setCrtn_on(crtn_on);
	}

	/**
	 * Sets the event_nme of this ecom sms data mstr.
	 *
	 * @param event_nme the event_nme of this ecom sms data mstr
	 */
	@Override
	public void setEvent_nme(String event_nme) {
		model.setEvent_nme(event_nme);
	}

	/**
	 * Sets the filler1 of this ecom sms data mstr.
	 *
	 * @param filler1 the filler1 of this ecom sms data mstr
	 */
	@Override
	public void setFiller1(String filler1) {
		model.setFiller1(filler1);
	}

	/**
	 * Sets the filler2 of this ecom sms data mstr.
	 *
	 * @param filler2 the filler2 of this ecom sms data mstr
	 */
	@Override
	public void setFiller2(String filler2) {
		model.setFiller2(filler2);
	}

	/**
	 * Sets the filler3 of this ecom sms data mstr.
	 *
	 * @param filler3 the filler3 of this ecom sms data mstr
	 */
	@Override
	public void setFiller3(String filler3) {
		model.setFiller3(filler3);
	}

	/**
	 * Sets the filler4 of this ecom sms data mstr.
	 *
	 * @param filler4 the filler4 of this ecom sms data mstr
	 */
	@Override
	public void setFiller4(String filler4) {
		model.setFiller4(filler4);
	}

	/**
	 * Sets the filler5 of this ecom sms data mstr.
	 *
	 * @param filler5 the filler5 of this ecom sms data mstr
	 */
	@Override
	public void setFiller5(String filler5) {
		model.setFiller5(filler5);
	}

	/**
	 * Sets the ID of this ecom sms data mstr.
	 *
	 * @param id the ID of this ecom sms data mstr
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the msisdn of this ecom sms data mstr.
	 *
	 * @param msisdn the msisdn of this ecom sms data mstr
	 */
	@Override
	public void setMsisdn(String msisdn) {
		model.setMsisdn(msisdn);
	}

	/**
	 * Sets the primary key of this ecom sms data mstr.
	 *
	 * @param primaryKey the primary key of this ecom sms data mstr
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the sender_id of this ecom sms data mstr.
	 *
	 * @param sender_id the sender_id of this ecom sms data mstr
	 */
	@Override
	public void setSender_id(String sender_id) {
		model.setSender_id(sender_id);
	}

	/**
	 * Sets the stts of this ecom sms data mstr.
	 *
	 * @param stts the stts of this ecom sms data mstr
	 */
	@Override
	public void setStts(String stts) {
		model.setStts(stts);
	}

	/**
	 * Sets the text_desc of this ecom sms data mstr.
	 *
	 * @param text_desc the text_desc of this ecom sms data mstr
	 */
	@Override
	public void setText_desc(String text_desc) {
		model.setText_desc(text_desc);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected EcomSmsDataMstrWrapper wrap(EcomSmsDataMstr ecomSmsDataMstr) {
		return new EcomSmsDataMstrWrapper(ecomSmsDataMstr);
	}

}