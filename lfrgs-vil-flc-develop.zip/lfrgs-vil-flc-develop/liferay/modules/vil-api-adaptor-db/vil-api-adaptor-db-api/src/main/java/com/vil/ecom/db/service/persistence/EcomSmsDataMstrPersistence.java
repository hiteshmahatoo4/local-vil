/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

import com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException;
import com.vil.ecom.db.model.EcomSmsDataMstr;

import java.util.Date;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the ecom sms data mstr service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomSmsDataMstrUtil
 * @generated
 */
@ProviderType
public interface EcomSmsDataMstrPersistence
	extends BasePersistence<EcomSmsDataMstr> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EcomSmsDataMstrUtil} to access the ecom sms data mstr persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Returns all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @return the matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByMsisdn(String msisdn);

	/**
	 * Returns a range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end);

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr findByMsisdn_First(
			String msisdn,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
				orderByComparator)
		throws NoSuchEcomSmsDataMstrException;

	/**
	 * Returns the first ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr fetchByMsisdn_First(
		String msisdn,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator);

	/**
	 * Returns the last ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr findByMsisdn_Last(
			String msisdn,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
				orderByComparator)
		throws NoSuchEcomSmsDataMstrException;

	/**
	 * Returns the last ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr fetchByMsisdn_Last(
		String msisdn,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator);

	/**
	 * Returns the ecom sms data mstrs before and after the current ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param id the primary key of the current ecom sms data mstr
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public EcomSmsDataMstr[] findByMsisdn_PrevAndNext(
			long id, String msisdn,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
				orderByComparator)
		throws NoSuchEcomSmsDataMstrException;

	/**
	 * Removes all the ecom sms data mstrs where msisdn = &#63; from the database.
	 *
	 * @param msisdn the msisdn
	 */
	public void removeByMsisdn(String msisdn);

	/**
	 * Returns the number of ecom sms data mstrs where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @return the number of matching ecom sms data mstrs
	 */
	public int countByMsisdn(String msisdn);

	/**
	 * Returns all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @return the matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByCrtnOn(Date crtn_on);

	/**
	 * Returns a range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end);

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Returns the first ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr findByCrtnOn_First(
			Date crtn_on,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
				orderByComparator)
		throws NoSuchEcomSmsDataMstrException;

	/**
	 * Returns the first ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr fetchByCrtnOn_First(
		Date crtn_on,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator);

	/**
	 * Returns the last ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr findByCrtnOn_Last(
			Date crtn_on,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
				orderByComparator)
		throws NoSuchEcomSmsDataMstrException;

	/**
	 * Returns the last ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	public EcomSmsDataMstr fetchByCrtnOn_Last(
		Date crtn_on,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator);

	/**
	 * Returns the ecom sms data mstrs before and after the current ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param id the primary key of the current ecom sms data mstr
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public EcomSmsDataMstr[] findByCrtnOn_PrevAndNext(
			long id, Date crtn_on,
			com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
				orderByComparator)
		throws NoSuchEcomSmsDataMstrException;

	/**
	 * Removes all the ecom sms data mstrs where crtn_on = &#63; from the database.
	 *
	 * @param crtn_on the crtn_on
	 */
	public void removeByCrtnOn(Date crtn_on);

	/**
	 * Returns the number of ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @return the number of matching ecom sms data mstrs
	 */
	public int countByCrtnOn(Date crtn_on);

	/**
	 * Caches the ecom sms data mstr in the entity cache if it is enabled.
	 *
	 * @param ecomSmsDataMstr the ecom sms data mstr
	 */
	public void cacheResult(EcomSmsDataMstr ecomSmsDataMstr);

	/**
	 * Caches the ecom sms data mstrs in the entity cache if it is enabled.
	 *
	 * @param ecomSmsDataMstrs the ecom sms data mstrs
	 */
	public void cacheResult(java.util.List<EcomSmsDataMstr> ecomSmsDataMstrs);

	/**
	 * Creates a new ecom sms data mstr with the primary key. Does not add the ecom sms data mstr to the database.
	 *
	 * @param id the primary key for the new ecom sms data mstr
	 * @return the new ecom sms data mstr
	 */
	public EcomSmsDataMstr create(long id);

	/**
	 * Removes the ecom sms data mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr that was removed
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public EcomSmsDataMstr remove(long id)
		throws NoSuchEcomSmsDataMstrException;

	public EcomSmsDataMstr updateImpl(EcomSmsDataMstr ecomSmsDataMstr);

	/**
	 * Returns the ecom sms data mstr with the primary key or throws a <code>NoSuchEcomSmsDataMstrException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	public EcomSmsDataMstr findByPrimaryKey(long id)
		throws NoSuchEcomSmsDataMstrException;

	/**
	 * Returns the ecom sms data mstr with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr, or <code>null</code> if a ecom sms data mstr with the primary key could not be found
	 */
	public EcomSmsDataMstr fetchByPrimaryKey(long id);

	/**
	 * Returns all the ecom sms data mstrs.
	 *
	 * @return the ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findAll();

	/**
	 * Returns a range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator);

	/**
	 * Returns an ordered range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom sms data mstrs
	 */
	public java.util.List<EcomSmsDataMstr> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<EcomSmsDataMstr>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the ecom sms data mstrs from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of ecom sms data mstrs.
	 *
	 * @return the number of ecom sms data mstrs
	 */
	public int countAll();

}