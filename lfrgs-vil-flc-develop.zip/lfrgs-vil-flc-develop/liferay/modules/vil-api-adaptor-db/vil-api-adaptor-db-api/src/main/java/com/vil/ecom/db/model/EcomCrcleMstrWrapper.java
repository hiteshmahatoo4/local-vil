/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EcomCrcleMstr}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see EcomCrcleMstr
 * @generated
 */
public class EcomCrcleMstrWrapper
	extends BaseModelWrapper<EcomCrcleMstr>
	implements EcomCrcleMstr, ModelWrapper<EcomCrcleMstr> {

	public EcomCrcleMstrWrapper(EcomCrcleMstr ecomCrcleMstr) {
		super(ecomCrcleMstr);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("id", getId());
		attributes.put("circle_id", getCircle_id());
		attributes.put("circle_cde", getCircle_cde());
		attributes.put("circle_nme", getCircle_nme());
		attributes.put("eai_circle_id", getEai_circle_id());
		attributes.put("upss_circle_id", getUpss_circle_id());
		attributes.put("msdp_circle_cde", getMsdp_circle_cde());
		attributes.put("msdp_circle_nme", getMsdp_circle_nme());
		attributes.put("msdp_content_provider", getMsdp_content_provider());
		attributes.put("crtd_by", getCrtd_by());
		attributes.put("crtn_on", getCrtn_on());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String circle_id = (String)attributes.get("circle_id");

		if (circle_id != null) {
			setCircle_id(circle_id);
		}

		String circle_cde = (String)attributes.get("circle_cde");

		if (circle_cde != null) {
			setCircle_cde(circle_cde);
		}

		String circle_nme = (String)attributes.get("circle_nme");

		if (circle_nme != null) {
			setCircle_nme(circle_nme);
		}

		String eai_circle_id = (String)attributes.get("eai_circle_id");

		if (eai_circle_id != null) {
			setEai_circle_id(eai_circle_id);
		}

		String upss_circle_id = (String)attributes.get("upss_circle_id");

		if (upss_circle_id != null) {
			setUpss_circle_id(upss_circle_id);
		}

		String msdp_circle_cde = (String)attributes.get("msdp_circle_cde");

		if (msdp_circle_cde != null) {
			setMsdp_circle_cde(msdp_circle_cde);
		}

		String msdp_circle_nme = (String)attributes.get("msdp_circle_nme");

		if (msdp_circle_nme != null) {
			setMsdp_circle_nme(msdp_circle_nme);
		}

		String msdp_content_provider = (String)attributes.get(
			"msdp_content_provider");

		if (msdp_content_provider != null) {
			setMsdp_content_provider(msdp_content_provider);
		}

		String crtd_by = (String)attributes.get("crtd_by");

		if (crtd_by != null) {
			setCrtd_by(crtd_by);
		}

		Date crtn_on = (Date)attributes.get("crtn_on");

		if (crtn_on != null) {
			setCrtn_on(crtn_on);
		}
	}

	@Override
	public EcomCrcleMstr cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the circle_cde of this ecom crcle mstr.
	 *
	 * @return the circle_cde of this ecom crcle mstr
	 */
	@Override
	public String getCircle_cde() {
		return model.getCircle_cde();
	}

	/**
	 * Returns the circle_id of this ecom crcle mstr.
	 *
	 * @return the circle_id of this ecom crcle mstr
	 */
	@Override
	public String getCircle_id() {
		return model.getCircle_id();
	}

	/**
	 * Returns the circle_nme of this ecom crcle mstr.
	 *
	 * @return the circle_nme of this ecom crcle mstr
	 */
	@Override
	public String getCircle_nme() {
		return model.getCircle_nme();
	}

	/**
	 * Returns the crtd_by of this ecom crcle mstr.
	 *
	 * @return the crtd_by of this ecom crcle mstr
	 */
	@Override
	public String getCrtd_by() {
		return model.getCrtd_by();
	}

	/**
	 * Returns the crtn_on of this ecom crcle mstr.
	 *
	 * @return the crtn_on of this ecom crcle mstr
	 */
	@Override
	public Date getCrtn_on() {
		return model.getCrtn_on();
	}

	/**
	 * Returns the eai_circle_id of this ecom crcle mstr.
	 *
	 * @return the eai_circle_id of this ecom crcle mstr
	 */
	@Override
	public String getEai_circle_id() {
		return model.getEai_circle_id();
	}

	/**
	 * Returns the ID of this ecom crcle mstr.
	 *
	 * @return the ID of this ecom crcle mstr
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the msdp_circle_cde of this ecom crcle mstr.
	 *
	 * @return the msdp_circle_cde of this ecom crcle mstr
	 */
	@Override
	public String getMsdp_circle_cde() {
		return model.getMsdp_circle_cde();
	}

	/**
	 * Returns the msdp_circle_nme of this ecom crcle mstr.
	 *
	 * @return the msdp_circle_nme of this ecom crcle mstr
	 */
	@Override
	public String getMsdp_circle_nme() {
		return model.getMsdp_circle_nme();
	}

	/**
	 * Returns the msdp_content_provider of this ecom crcle mstr.
	 *
	 * @return the msdp_content_provider of this ecom crcle mstr
	 */
	@Override
	public String getMsdp_content_provider() {
		return model.getMsdp_content_provider();
	}

	/**
	 * Returns the primary key of this ecom crcle mstr.
	 *
	 * @return the primary key of this ecom crcle mstr
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the upss_circle_id of this ecom crcle mstr.
	 *
	 * @return the upss_circle_id of this ecom crcle mstr
	 */
	@Override
	public String getUpss_circle_id() {
		return model.getUpss_circle_id();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the circle_cde of this ecom crcle mstr.
	 *
	 * @param circle_cde the circle_cde of this ecom crcle mstr
	 */
	@Override
	public void setCircle_cde(String circle_cde) {
		model.setCircle_cde(circle_cde);
	}

	/**
	 * Sets the circle_id of this ecom crcle mstr.
	 *
	 * @param circle_id the circle_id of this ecom crcle mstr
	 */
	@Override
	public void setCircle_id(String circle_id) {
		model.setCircle_id(circle_id);
	}

	/**
	 * Sets the circle_nme of this ecom crcle mstr.
	 *
	 * @param circle_nme the circle_nme of this ecom crcle mstr
	 */
	@Override
	public void setCircle_nme(String circle_nme) {
		model.setCircle_nme(circle_nme);
	}

	/**
	 * Sets the crtd_by of this ecom crcle mstr.
	 *
	 * @param crtd_by the crtd_by of this ecom crcle mstr
	 */
	@Override
	public void setCrtd_by(String crtd_by) {
		model.setCrtd_by(crtd_by);
	}

	/**
	 * Sets the crtn_on of this ecom crcle mstr.
	 *
	 * @param crtn_on the crtn_on of this ecom crcle mstr
	 */
	@Override
	public void setCrtn_on(Date crtn_on) {
		model.setCrtn_on(crtn_on);
	}

	/**
	 * Sets the eai_circle_id of this ecom crcle mstr.
	 *
	 * @param eai_circle_id the eai_circle_id of this ecom crcle mstr
	 */
	@Override
	public void setEai_circle_id(String eai_circle_id) {
		model.setEai_circle_id(eai_circle_id);
	}

	/**
	 * Sets the ID of this ecom crcle mstr.
	 *
	 * @param id the ID of this ecom crcle mstr
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the msdp_circle_cde of this ecom crcle mstr.
	 *
	 * @param msdp_circle_cde the msdp_circle_cde of this ecom crcle mstr
	 */
	@Override
	public void setMsdp_circle_cde(String msdp_circle_cde) {
		model.setMsdp_circle_cde(msdp_circle_cde);
	}

	/**
	 * Sets the msdp_circle_nme of this ecom crcle mstr.
	 *
	 * @param msdp_circle_nme the msdp_circle_nme of this ecom crcle mstr
	 */
	@Override
	public void setMsdp_circle_nme(String msdp_circle_nme) {
		model.setMsdp_circle_nme(msdp_circle_nme);
	}

	/**
	 * Sets the msdp_content_provider of this ecom crcle mstr.
	 *
	 * @param msdp_content_provider the msdp_content_provider of this ecom crcle mstr
	 */
	@Override
	public void setMsdp_content_provider(String msdp_content_provider) {
		model.setMsdp_content_provider(msdp_content_provider);
	}

	/**
	 * Sets the primary key of this ecom crcle mstr.
	 *
	 * @param primaryKey the primary key of this ecom crcle mstr
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the upss_circle_id of this ecom crcle mstr.
	 *
	 * @param upss_circle_id the upss_circle_id of this ecom crcle mstr
	 */
	@Override
	public void setUpss_circle_id(String upss_circle_id) {
		model.setUpss_circle_id(upss_circle_id);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected EcomCrcleMstrWrapper wrap(EcomCrcleMstr ecomCrcleMstr) {
		return new EcomCrcleMstrWrapper(ecomCrcleMstr);
	}

}