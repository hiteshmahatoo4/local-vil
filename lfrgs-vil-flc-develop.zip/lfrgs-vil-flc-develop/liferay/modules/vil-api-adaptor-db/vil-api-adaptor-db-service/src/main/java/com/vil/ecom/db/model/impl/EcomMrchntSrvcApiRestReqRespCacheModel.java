/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EcomMrchntSrvcApiRestReqResp in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class EcomMrchntSrvcApiRestReqRespCacheModel
	implements CacheModel<EcomMrchntSrvcApiRestReqResp>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof EcomMrchntSrvcApiRestReqRespCacheModel)) {
			return false;
		}

		EcomMrchntSrvcApiRestReqRespCacheModel
			ecomMrchntSrvcApiRestReqRespCacheModel =
				(EcomMrchntSrvcApiRestReqRespCacheModel)object;

		if (id == ecomMrchntSrvcApiRestReqRespCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(59);

		sb.append("{id=");
		sb.append(id);
		sb.append(", service_nme=");
		sb.append(service_nme);
		sb.append(", msisdn=");
		sb.append(msisdn);
		sb.append(", amt=");
		sb.append(amt);
		sb.append(", stts=");
		sb.append(stts);
		sb.append(", error_code=");
		sb.append(error_code);
		sb.append(", error_msg=");
		sb.append(error_msg);
		sb.append(", user_id=");
		sb.append(user_id);
		sb.append(", chnnl_id=");
		sb.append(chnnl_id);
		sb.append(", req_id=");
		sb.append(req_id);
		sb.append(", ip_addr=");
		sb.append(ip_addr);
		sb.append(", rqst_type=");
		sb.append(rqst_type);
		sb.append(", srce_systm=");
		sb.append(srce_systm);
		sb.append(", rest_req1=");
		sb.append(rest_req1);
		sb.append(", rest_req2=");
		sb.append(rest_req2);
		sb.append(", rest_req3=");
		sb.append(rest_req3);
		sb.append(", rest_req4=");
		sb.append(rest_req4);
		sb.append(", rest_resp1=");
		sb.append(rest_resp1);
		sb.append(", rest_resp2=");
		sb.append(rest_resp2);
		sb.append(", rest_resp3=");
		sb.append(rest_resp3);
		sb.append(", rest_resp4=");
		sb.append(rest_resp4);
		sb.append(", filler1=");
		sb.append(filler1);
		sb.append(", filler2=");
		sb.append(filler2);
		sb.append(", filler3=");
		sb.append(filler3);
		sb.append(", filler4=");
		sb.append(filler4);
		sb.append(", filler5=");
		sb.append(filler5);
		sb.append(", filler6=");
		sb.append(filler6);
		sb.append(", req_timestamp=");
		sb.append(req_timestamp);
		sb.append(", resp_timestamp=");
		sb.append(resp_timestamp);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EcomMrchntSrvcApiRestReqResp toEntityModel() {
		EcomMrchntSrvcApiRestReqRespImpl ecomMrchntSrvcApiRestReqRespImpl =
			new EcomMrchntSrvcApiRestReqRespImpl();

		ecomMrchntSrvcApiRestReqRespImpl.setId(id);

		if (service_nme == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setService_nme("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setService_nme(service_nme);
		}

		if (msisdn == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setMsisdn("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setMsisdn(msisdn);
		}

		if (amt == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setAmt("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setAmt(amt);
		}

		if (stts == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setStts("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setStts(stts);
		}

		if (error_code == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setError_code("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setError_code(error_code);
		}

		if (error_msg == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setError_msg("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setError_msg(error_msg);
		}

		if (user_id == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setUser_id("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setUser_id(user_id);
		}

		if (chnnl_id == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setChnnl_id("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setChnnl_id(chnnl_id);
		}

		if (req_id == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setReq_id("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setReq_id(req_id);
		}

		if (ip_addr == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setIp_addr("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setIp_addr(ip_addr);
		}

		if (rqst_type == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRqst_type("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRqst_type(rqst_type);
		}

		if (srce_systm == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setSrce_systm("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setSrce_systm(srce_systm);
		}

		if (rest_req1 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req1("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req1(rest_req1);
		}

		if (rest_req2 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req2("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req2(rest_req2);
		}

		if (rest_req3 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req3("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req3(rest_req3);
		}

		if (rest_req4 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req4("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_req4(rest_req4);
		}

		if (rest_resp1 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp1("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp1(rest_resp1);
		}

		if (rest_resp2 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp2("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp2(rest_resp2);
		}

		if (rest_resp3 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp3("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp3(rest_resp3);
		}

		if (rest_resp4 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp4("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setRest_resp4(rest_resp4);
		}

		if (filler1 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller1("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller1(filler1);
		}

		if (filler2 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller2("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller2(filler2);
		}

		if (filler3 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller3("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller3(filler3);
		}

		if (filler4 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller4("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller4(filler4);
		}

		if (filler5 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller5("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller5(filler5);
		}

		if (filler6 == null) {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller6("");
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setFiller6(filler6);
		}

		if (req_timestamp == Long.MIN_VALUE) {
			ecomMrchntSrvcApiRestReqRespImpl.setReq_timestamp(null);
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setReq_timestamp(
				new Date(req_timestamp));
		}

		if (resp_timestamp == Long.MIN_VALUE) {
			ecomMrchntSrvcApiRestReqRespImpl.setResp_timestamp(null);
		}
		else {
			ecomMrchntSrvcApiRestReqRespImpl.setResp_timestamp(
				new Date(resp_timestamp));
		}

		ecomMrchntSrvcApiRestReqRespImpl.resetOriginalValues();

		return ecomMrchntSrvcApiRestReqRespImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		id = objectInput.readLong();
		service_nme = objectInput.readUTF();
		msisdn = objectInput.readUTF();
		amt = objectInput.readUTF();
		stts = objectInput.readUTF();
		error_code = objectInput.readUTF();
		error_msg = objectInput.readUTF();
		user_id = objectInput.readUTF();
		chnnl_id = objectInput.readUTF();
		req_id = objectInput.readUTF();
		ip_addr = objectInput.readUTF();
		rqst_type = objectInput.readUTF();
		srce_systm = objectInput.readUTF();
		rest_req1 = objectInput.readUTF();
		rest_req2 = objectInput.readUTF();
		rest_req3 = objectInput.readUTF();
		rest_req4 = objectInput.readUTF();
		rest_resp1 = objectInput.readUTF();
		rest_resp2 = objectInput.readUTF();
		rest_resp3 = objectInput.readUTF();
		rest_resp4 = objectInput.readUTF();
		filler1 = objectInput.readUTF();
		filler2 = objectInput.readUTF();
		filler3 = objectInput.readUTF();
		filler4 = objectInput.readUTF();
		filler5 = objectInput.readUTF();
		filler6 = objectInput.readUTF();
		req_timestamp = objectInput.readLong();
		resp_timestamp = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(id);

		if (service_nme == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(service_nme);
		}

		if (msisdn == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(msisdn);
		}

		if (amt == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(amt);
		}

		if (stts == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(stts);
		}

		if (error_code == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(error_code);
		}

		if (error_msg == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(error_msg);
		}

		if (user_id == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(user_id);
		}

		if (chnnl_id == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(chnnl_id);
		}

		if (req_id == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(req_id);
		}

		if (ip_addr == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(ip_addr);
		}

		if (rqst_type == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rqst_type);
		}

		if (srce_systm == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(srce_systm);
		}

		if (rest_req1 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_req1);
		}

		if (rest_req2 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_req2);
		}

		if (rest_req3 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_req3);
		}

		if (rest_req4 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_req4);
		}

		if (rest_resp1 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_resp1);
		}

		if (rest_resp2 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_resp2);
		}

		if (rest_resp3 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_resp3);
		}

		if (rest_resp4 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(rest_resp4);
		}

		if (filler1 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler1);
		}

		if (filler2 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler2);
		}

		if (filler3 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler3);
		}

		if (filler4 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler4);
		}

		if (filler5 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler5);
		}

		if (filler6 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler6);
		}

		objectOutput.writeLong(req_timestamp);
		objectOutput.writeLong(resp_timestamp);
	}

	public long id;
	public String service_nme;
	public String msisdn;
	public String amt;
	public String stts;
	public String error_code;
	public String error_msg;
	public String user_id;
	public String chnnl_id;
	public String req_id;
	public String ip_addr;
	public String rqst_type;
	public String srce_systm;
	public String rest_req1;
	public String rest_req2;
	public String rest_req3;
	public String rest_req4;
	public String rest_resp1;
	public String rest_resp2;
	public String rest_resp3;
	public String rest_resp4;
	public String filler1;
	public String filler2;
	public String filler3;
	public String filler4;
	public String filler5;
	public String filler6;
	public long req_timestamp;
	public long resp_timestamp;

}