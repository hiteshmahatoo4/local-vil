create table ecom_crcle_mstr (
	id_ LONG not null primary key,
	circle_id VARCHAR(75) null,
	circle_cde VARCHAR(75) null,
	circle_nme VARCHAR(75) null,
	eai_circle_id VARCHAR(75) null,
	upss_circle_id VARCHAR(75) null,
	msdp_circle_cde VARCHAR(75) null,
	msdp_circle_nme VARCHAR(75) null,
	msdp_content_provider VARCHAR(75) null,
	crtd_by VARCHAR(75) null,
	crtn_on DATE null
);

create table ecom_sms_data_mstr (
	id_ LONG not null primary key,
	msisdn VARCHAR(75) null,
	event_nme VARCHAR(75) null,
	text_desc VARCHAR(75) null,
	stts VARCHAR(75) null,
	circle_nme VARCHAR(75) null,
	sender_id VARCHAR(75) null,
	filler1 VARCHAR(75) null,
	filler2 VARCHAR(75) null,
	filler3 VARCHAR(75) null,
	filler4 VARCHAR(75) null,
	filler5 VARCHAR(75) null,
	crtd_by VARCHAR(75) null,
	crtn_on DATE null
);

create table ecom_srvc_api_req_resp (
	id_ LONG not null primary key,
	service_nme VARCHAR(75) null,
	msisdn VARCHAR(75) null,
	amt VARCHAR(75) null,
	stts VARCHAR(75) null,
	error_code VARCHAR(75) null,
	error_msg VARCHAR(75) null,
	user_id VARCHAR(75) null,
	chnnl_id VARCHAR(75) null,
	req_id VARCHAR(75) null,
	ip_addr VARCHAR(75) null,
	rqst_type VARCHAR(75) null,
	srce_systm VARCHAR(75) null,
	rest_req1 VARCHAR(75) null,
	rest_req2 VARCHAR(75) null,
	rest_req3 VARCHAR(75) null,
	rest_req4 VARCHAR(75) null,
	rest_resp1 VARCHAR(75) null,
	rest_resp2 VARCHAR(75) null,
	rest_resp3 VARCHAR(75) null,
	rest_resp4 VARCHAR(75) null,
	filler1 VARCHAR(75) null,
	filler2 VARCHAR(75) null,
	filler3 VARCHAR(75) null,
	filler4 VARCHAR(75) null,
	filler5 VARCHAR(75) null,
	filler6 VARCHAR(75) null,
	req_timestamp DATE null,
	resp_timestamp DATE null
);

create table ecom_srvc_cmmnd_mppng (
	id_ LONG not null primary key,
	srvc_key VARCHAR(75) null,
	srvc_req VARCHAR(75) null,
	srvc_util_class VARCHAR(75) null,
	util_signature VARCHAR(75) null,
	event VARCHAR(75) null,
	filler1 VARCHAR(75) null,
	filler2 VARCHAR(75) null,
	filler3 VARCHAR(75) null,
	crtd_on DATE null
);

create table ecom_srvc_config_cnstnts (
	id_ LONG not null primary key,
	srvc_type VARCHAR(75) null,
	srvc_key VARCHAR(75) null,
	value VARCHAR(75) null,
	description VARCHAR(75) null,
	crtn_on DATE null
);