create index IX_D5A3B6E8 on ecom_crcle_mstr (circle_cde[$COLUMN_LENGTH:75$]);
create index IX_6E6F2BB on ecom_crcle_mstr (circle_id[$COLUMN_LENGTH:75$]);
create index IX_D642D0CA on ecom_crcle_mstr (circle_nme[$COLUMN_LENGTH:75$]);
create index IX_DA79A549 on ecom_crcle_mstr (eai_circle_id[$COLUMN_LENGTH:75$]);
create index IX_98F993D9 on ecom_crcle_mstr (upss_circle_id[$COLUMN_LENGTH:75$]);

create index IX_19C95EEF on ecom_sms_data_mstr (crtn_on);
create index IX_B62B5744 on ecom_sms_data_mstr (msisdn[$COLUMN_LENGTH:75$]);

create index IX_3458F979 on ecom_srvc_api_req_resp (req_timestamp);

create index IX_AF5A9DB6 on ecom_srvc_cmmnd_mppng (srvc_key[$COLUMN_LENGTH:75$]);

create index IX_67589A on ecom_srvc_config_cnstnts (srvc_key[$COLUMN_LENGTH:75$]);
create index IX_1CF5F643 on ecom_srvc_config_cnstnts (srvc_type[$COLUMN_LENGTH:75$]);