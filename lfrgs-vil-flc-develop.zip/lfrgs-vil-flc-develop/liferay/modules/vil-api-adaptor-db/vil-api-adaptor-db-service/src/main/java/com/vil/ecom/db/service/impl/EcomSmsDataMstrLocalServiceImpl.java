/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.bean.BeanPropertiesUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.db.custommodel.EcomSmsDataMstrCustomModel;
import com.vil.ecom.db.model.EcomSmsDataMstr;
import com.vil.ecom.db.service.base.EcomSmsDataMstrLocalServiceBaseImpl;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.vil.ecom.db.model.EcomSmsDataMstr",
	service = AopService.class
)
public class EcomSmsDataMstrLocalServiceImpl
	extends EcomSmsDataMstrLocalServiceBaseImpl {
	
	public EcomSmsDataMstr addMrchntSmsLogRecord(EcomSmsDataMstrCustomModel model) {
			
			EcomSmsDataMstr record = null;
	
			try {
				
				_log.debug("inside method ");
				
				long id = counterLocalService.increment(EcomSmsDataMstr.class.getName());
				record = ecomSmsDataMstrPersistence.create(id);     
				model.setId(id);
				
				BeanPropertiesUtil.copyProperties(model, record);
				ecomSmsDataMstrPersistence.update(record);
	
			} catch (Exception e) {
				_log.error("Error while adding data to table EcomMrchntSrvcApiRestReqResp :" + e);
			}
			
			return record;
	}

	private static final Log _log = LogFactoryUtil.getLog(EcomSmsDataMstrLocalServiceImpl.class.getName());
}