/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;

import com.vil.ecom.db.exception.NoSuchEcomSmsDataMstrException;
import com.vil.ecom.db.model.EcomSmsDataMstr;
import com.vil.ecom.db.model.EcomSmsDataMstrTable;
import com.vil.ecom.db.model.impl.EcomSmsDataMstrImpl;
import com.vil.ecom.db.model.impl.EcomSmsDataMstrModelImpl;
import com.vil.ecom.db.service.persistence.EcomSmsDataMstrPersistence;
import com.vil.ecom.db.service.persistence.EcomSmsDataMstrUtil;
import com.vil.ecom.db.service.persistence.impl.constants.LRPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;

import java.sql.Timestamp;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the ecom sms data mstr service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = EcomSmsDataMstrPersistence.class)
public class EcomSmsDataMstrPersistenceImpl
	extends BasePersistenceImpl<EcomSmsDataMstr>
	implements EcomSmsDataMstrPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>EcomSmsDataMstrUtil</code> to access the ecom sms data mstr persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		EcomSmsDataMstrImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByMsisdn;
	private FinderPath _finderPathWithoutPaginationFindByMsisdn;
	private FinderPath _finderPathCountByMsisdn;

	/**
	 * Returns all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @return the matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByMsisdn(String msisdn) {
		return findByMsisdn(msisdn, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end) {

		return findByMsisdn(msisdn, start, end, null);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return findByMsisdn(msisdn, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where msisdn = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param msisdn the msisdn
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByMsisdn(
		String msisdn, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean useFinderCache) {

		msisdn = Objects.toString(msisdn, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByMsisdn;
				finderArgs = new Object[] {msisdn};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByMsisdn;
			finderArgs = new Object[] {msisdn, start, end, orderByComparator};
		}

		List<EcomSmsDataMstr> list = null;

		if (useFinderCache) {
			list = (List<EcomSmsDataMstr>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (EcomSmsDataMstr ecomSmsDataMstr : list) {
					if (!msisdn.equals(ecomSmsDataMstr.getMsisdn())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_ECOMSMSDATAMSTR_WHERE);

			boolean bindMsisdn = false;

			if (msisdn.isEmpty()) {
				sb.append(_FINDER_COLUMN_MSISDN_MSISDN_3);
			}
			else {
				bindMsisdn = true;

				sb.append(_FINDER_COLUMN_MSISDN_MSISDN_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(EcomSmsDataMstrModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindMsisdn) {
					queryPos.add(msisdn);
				}

				list = (List<EcomSmsDataMstr>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr findByMsisdn_First(
			String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws NoSuchEcomSmsDataMstrException {

		EcomSmsDataMstr ecomSmsDataMstr = fetchByMsisdn_First(
			msisdn, orderByComparator);

		if (ecomSmsDataMstr != null) {
			return ecomSmsDataMstr;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("msisdn=");
		sb.append(msisdn);

		sb.append("}");

		throw new NoSuchEcomSmsDataMstrException(sb.toString());
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr fetchByMsisdn_First(
		String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		List<EcomSmsDataMstr> list = findByMsisdn(
			msisdn, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr findByMsisdn_Last(
			String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws NoSuchEcomSmsDataMstrException {

		EcomSmsDataMstr ecomSmsDataMstr = fetchByMsisdn_Last(
			msisdn, orderByComparator);

		if (ecomSmsDataMstr != null) {
			return ecomSmsDataMstr;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("msisdn=");
		sb.append(msisdn);

		sb.append("}");

		throw new NoSuchEcomSmsDataMstrException(sb.toString());
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr fetchByMsisdn_Last(
		String msisdn, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		int count = countByMsisdn(msisdn);

		if (count == 0) {
			return null;
		}

		List<EcomSmsDataMstr> list = findByMsisdn(
			msisdn, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the ecom sms data mstrs before and after the current ecom sms data mstr in the ordered set where msisdn = &#63;.
	 *
	 * @param id the primary key of the current ecom sms data mstr
	 * @param msisdn the msisdn
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	@Override
	public EcomSmsDataMstr[] findByMsisdn_PrevAndNext(
			long id, String msisdn,
			OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws NoSuchEcomSmsDataMstrException {

		msisdn = Objects.toString(msisdn, "");

		EcomSmsDataMstr ecomSmsDataMstr = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			EcomSmsDataMstr[] array = new EcomSmsDataMstrImpl[3];

			array[0] = getByMsisdn_PrevAndNext(
				session, ecomSmsDataMstr, msisdn, orderByComparator, true);

			array[1] = ecomSmsDataMstr;

			array[2] = getByMsisdn_PrevAndNext(
				session, ecomSmsDataMstr, msisdn, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected EcomSmsDataMstr getByMsisdn_PrevAndNext(
		Session session, EcomSmsDataMstr ecomSmsDataMstr, String msisdn,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_ECOMSMSDATAMSTR_WHERE);

		boolean bindMsisdn = false;

		if (msisdn.isEmpty()) {
			sb.append(_FINDER_COLUMN_MSISDN_MSISDN_3);
		}
		else {
			bindMsisdn = true;

			sb.append(_FINDER_COLUMN_MSISDN_MSISDN_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(EcomSmsDataMstrModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindMsisdn) {
			queryPos.add(msisdn);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						ecomSmsDataMstr)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<EcomSmsDataMstr> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the ecom sms data mstrs where msisdn = &#63; from the database.
	 *
	 * @param msisdn the msisdn
	 */
	@Override
	public void removeByMsisdn(String msisdn) {
		for (EcomSmsDataMstr ecomSmsDataMstr :
				findByMsisdn(
					msisdn, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(ecomSmsDataMstr);
		}
	}

	/**
	 * Returns the number of ecom sms data mstrs where msisdn = &#63;.
	 *
	 * @param msisdn the msisdn
	 * @return the number of matching ecom sms data mstrs
	 */
	@Override
	public int countByMsisdn(String msisdn) {
		msisdn = Objects.toString(msisdn, "");

		FinderPath finderPath = _finderPathCountByMsisdn;

		Object[] finderArgs = new Object[] {msisdn};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMSMSDATAMSTR_WHERE);

			boolean bindMsisdn = false;

			if (msisdn.isEmpty()) {
				sb.append(_FINDER_COLUMN_MSISDN_MSISDN_3);
			}
			else {
				bindMsisdn = true;

				sb.append(_FINDER_COLUMN_MSISDN_MSISDN_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindMsisdn) {
					queryPos.add(msisdn);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_MSISDN_MSISDN_2 =
		"ecomSmsDataMstr.msisdn = ?";

	private static final String _FINDER_COLUMN_MSISDN_MSISDN_3 =
		"(ecomSmsDataMstr.msisdn IS NULL OR ecomSmsDataMstr.msisdn = '')";

	private FinderPath _finderPathWithPaginationFindByCrtnOn;
	private FinderPath _finderPathWithoutPaginationFindByCrtnOn;
	private FinderPath _finderPathCountByCrtnOn;

	/**
	 * Returns all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @return the matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByCrtnOn(Date crtn_on) {
		return findByCrtnOn(
			crtn_on, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end) {

		return findByCrtnOn(crtn_on, start, end, null);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return findByCrtnOn(crtn_on, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param crtn_on the crtn_on
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findByCrtnOn(
		Date crtn_on, int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByCrtnOn;
				finderArgs = new Object[] {_getTime(crtn_on)};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByCrtnOn;
			finderArgs = new Object[] {
				_getTime(crtn_on), start, end, orderByComparator
			};
		}

		List<EcomSmsDataMstr> list = null;

		if (useFinderCache) {
			list = (List<EcomSmsDataMstr>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (EcomSmsDataMstr ecomSmsDataMstr : list) {
					if (!Objects.equals(
							crtn_on, ecomSmsDataMstr.getCrtn_on())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_ECOMSMSDATAMSTR_WHERE);

			boolean bindCrtn_on = false;

			if (crtn_on == null) {
				sb.append(_FINDER_COLUMN_CRTNON_CRTN_ON_1);
			}
			else {
				bindCrtn_on = true;

				sb.append(_FINDER_COLUMN_CRTNON_CRTN_ON_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(EcomSmsDataMstrModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCrtn_on) {
					queryPos.add(new Timestamp(crtn_on.getTime()));
				}

				list = (List<EcomSmsDataMstr>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr findByCrtnOn_First(
			Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws NoSuchEcomSmsDataMstrException {

		EcomSmsDataMstr ecomSmsDataMstr = fetchByCrtnOn_First(
			crtn_on, orderByComparator);

		if (ecomSmsDataMstr != null) {
			return ecomSmsDataMstr;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("crtn_on=");
		sb.append(crtn_on);

		sb.append("}");

		throw new NoSuchEcomSmsDataMstrException(sb.toString());
	}

	/**
	 * Returns the first ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr fetchByCrtnOn_First(
		Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		List<EcomSmsDataMstr> list = findByCrtnOn(
			crtn_on, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr findByCrtnOn_Last(
			Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws NoSuchEcomSmsDataMstrException {

		EcomSmsDataMstr ecomSmsDataMstr = fetchByCrtnOn_Last(
			crtn_on, orderByComparator);

		if (ecomSmsDataMstr != null) {
			return ecomSmsDataMstr;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("crtn_on=");
		sb.append(crtn_on);

		sb.append("}");

		throw new NoSuchEcomSmsDataMstrException(sb.toString());
	}

	/**
	 * Returns the last ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom sms data mstr, or <code>null</code> if a matching ecom sms data mstr could not be found
	 */
	@Override
	public EcomSmsDataMstr fetchByCrtnOn_Last(
		Date crtn_on, OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		int count = countByCrtnOn(crtn_on);

		if (count == 0) {
			return null;
		}

		List<EcomSmsDataMstr> list = findByCrtnOn(
			crtn_on, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the ecom sms data mstrs before and after the current ecom sms data mstr in the ordered set where crtn_on = &#63;.
	 *
	 * @param id the primary key of the current ecom sms data mstr
	 * @param crtn_on the crtn_on
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	@Override
	public EcomSmsDataMstr[] findByCrtnOn_PrevAndNext(
			long id, Date crtn_on,
			OrderByComparator<EcomSmsDataMstr> orderByComparator)
		throws NoSuchEcomSmsDataMstrException {

		EcomSmsDataMstr ecomSmsDataMstr = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			EcomSmsDataMstr[] array = new EcomSmsDataMstrImpl[3];

			array[0] = getByCrtnOn_PrevAndNext(
				session, ecomSmsDataMstr, crtn_on, orderByComparator, true);

			array[1] = ecomSmsDataMstr;

			array[2] = getByCrtnOn_PrevAndNext(
				session, ecomSmsDataMstr, crtn_on, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected EcomSmsDataMstr getByCrtnOn_PrevAndNext(
		Session session, EcomSmsDataMstr ecomSmsDataMstr, Date crtn_on,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_ECOMSMSDATAMSTR_WHERE);

		boolean bindCrtn_on = false;

		if (crtn_on == null) {
			sb.append(_FINDER_COLUMN_CRTNON_CRTN_ON_1);
		}
		else {
			bindCrtn_on = true;

			sb.append(_FINDER_COLUMN_CRTNON_CRTN_ON_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(EcomSmsDataMstrModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindCrtn_on) {
			queryPos.add(new Timestamp(crtn_on.getTime()));
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						ecomSmsDataMstr)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<EcomSmsDataMstr> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the ecom sms data mstrs where crtn_on = &#63; from the database.
	 *
	 * @param crtn_on the crtn_on
	 */
	@Override
	public void removeByCrtnOn(Date crtn_on) {
		for (EcomSmsDataMstr ecomSmsDataMstr :
				findByCrtnOn(
					crtn_on, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(ecomSmsDataMstr);
		}
	}

	/**
	 * Returns the number of ecom sms data mstrs where crtn_on = &#63;.
	 *
	 * @param crtn_on the crtn_on
	 * @return the number of matching ecom sms data mstrs
	 */
	@Override
	public int countByCrtnOn(Date crtn_on) {
		FinderPath finderPath = _finderPathCountByCrtnOn;

		Object[] finderArgs = new Object[] {_getTime(crtn_on)};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMSMSDATAMSTR_WHERE);

			boolean bindCrtn_on = false;

			if (crtn_on == null) {
				sb.append(_FINDER_COLUMN_CRTNON_CRTN_ON_1);
			}
			else {
				bindCrtn_on = true;

				sb.append(_FINDER_COLUMN_CRTNON_CRTN_ON_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCrtn_on) {
					queryPos.add(new Timestamp(crtn_on.getTime()));
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CRTNON_CRTN_ON_1 =
		"ecomSmsDataMstr.crtn_on IS NULL";

	private static final String _FINDER_COLUMN_CRTNON_CRTN_ON_2 =
		"ecomSmsDataMstr.crtn_on = ?";

	public EcomSmsDataMstrPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("id", "id_");

		setDBColumnNames(dbColumnNames);

		setModelClass(EcomSmsDataMstr.class);

		setModelImplClass(EcomSmsDataMstrImpl.class);
		setModelPKClass(long.class);

		setTable(EcomSmsDataMstrTable.INSTANCE);
	}

	/**
	 * Caches the ecom sms data mstr in the entity cache if it is enabled.
	 *
	 * @param ecomSmsDataMstr the ecom sms data mstr
	 */
	@Override
	public void cacheResult(EcomSmsDataMstr ecomSmsDataMstr) {
		entityCache.putResult(
			EcomSmsDataMstrImpl.class, ecomSmsDataMstr.getPrimaryKey(),
			ecomSmsDataMstr);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the ecom sms data mstrs in the entity cache if it is enabled.
	 *
	 * @param ecomSmsDataMstrs the ecom sms data mstrs
	 */
	@Override
	public void cacheResult(List<EcomSmsDataMstr> ecomSmsDataMstrs) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (ecomSmsDataMstrs.size() >
				 _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (EcomSmsDataMstr ecomSmsDataMstr : ecomSmsDataMstrs) {
			if (entityCache.getResult(
					EcomSmsDataMstrImpl.class,
					ecomSmsDataMstr.getPrimaryKey()) == null) {

				cacheResult(ecomSmsDataMstr);
			}
		}
	}

	/**
	 * Clears the cache for all ecom sms data mstrs.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(EcomSmsDataMstrImpl.class);

		finderCache.clearCache(EcomSmsDataMstrImpl.class);
	}

	/**
	 * Clears the cache for the ecom sms data mstr.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(EcomSmsDataMstr ecomSmsDataMstr) {
		entityCache.removeResult(EcomSmsDataMstrImpl.class, ecomSmsDataMstr);
	}

	@Override
	public void clearCache(List<EcomSmsDataMstr> ecomSmsDataMstrs) {
		for (EcomSmsDataMstr ecomSmsDataMstr : ecomSmsDataMstrs) {
			entityCache.removeResult(
				EcomSmsDataMstrImpl.class, ecomSmsDataMstr);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(EcomSmsDataMstrImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(EcomSmsDataMstrImpl.class, primaryKey);
		}
	}

	/**
	 * Creates a new ecom sms data mstr with the primary key. Does not add the ecom sms data mstr to the database.
	 *
	 * @param id the primary key for the new ecom sms data mstr
	 * @return the new ecom sms data mstr
	 */
	@Override
	public EcomSmsDataMstr create(long id) {
		EcomSmsDataMstr ecomSmsDataMstr = new EcomSmsDataMstrImpl();

		ecomSmsDataMstr.setNew(true);
		ecomSmsDataMstr.setPrimaryKey(id);

		return ecomSmsDataMstr;
	}

	/**
	 * Removes the ecom sms data mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr that was removed
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	@Override
	public EcomSmsDataMstr remove(long id)
		throws NoSuchEcomSmsDataMstrException {

		return remove((Serializable)id);
	}

	/**
	 * Removes the ecom sms data mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr that was removed
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	@Override
	public EcomSmsDataMstr remove(Serializable primaryKey)
		throws NoSuchEcomSmsDataMstrException {

		Session session = null;

		try {
			session = openSession();

			EcomSmsDataMstr ecomSmsDataMstr = (EcomSmsDataMstr)session.get(
				EcomSmsDataMstrImpl.class, primaryKey);

			if (ecomSmsDataMstr == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchEcomSmsDataMstrException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(ecomSmsDataMstr);
		}
		catch (NoSuchEcomSmsDataMstrException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected EcomSmsDataMstr removeImpl(EcomSmsDataMstr ecomSmsDataMstr) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(ecomSmsDataMstr)) {
				ecomSmsDataMstr = (EcomSmsDataMstr)session.get(
					EcomSmsDataMstrImpl.class,
					ecomSmsDataMstr.getPrimaryKeyObj());
			}

			if (ecomSmsDataMstr != null) {
				session.delete(ecomSmsDataMstr);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (ecomSmsDataMstr != null) {
			clearCache(ecomSmsDataMstr);
		}

		return ecomSmsDataMstr;
	}

	@Override
	public EcomSmsDataMstr updateImpl(EcomSmsDataMstr ecomSmsDataMstr) {
		boolean isNew = ecomSmsDataMstr.isNew();

		if (!(ecomSmsDataMstr instanceof EcomSmsDataMstrModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(ecomSmsDataMstr.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					ecomSmsDataMstr);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in ecomSmsDataMstr proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom EcomSmsDataMstr implementation " +
					ecomSmsDataMstr.getClass());
		}

		EcomSmsDataMstrModelImpl ecomSmsDataMstrModelImpl =
			(EcomSmsDataMstrModelImpl)ecomSmsDataMstr;

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(ecomSmsDataMstr);
			}
			else {
				ecomSmsDataMstr = (EcomSmsDataMstr)session.merge(
					ecomSmsDataMstr);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			EcomSmsDataMstrImpl.class, ecomSmsDataMstrModelImpl, false, true);

		if (isNew) {
			ecomSmsDataMstr.setNew(false);
		}

		ecomSmsDataMstr.resetOriginalValues();

		return ecomSmsDataMstr;
	}

	/**
	 * Returns the ecom sms data mstr with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	@Override
	public EcomSmsDataMstr findByPrimaryKey(Serializable primaryKey)
		throws NoSuchEcomSmsDataMstrException {

		EcomSmsDataMstr ecomSmsDataMstr = fetchByPrimaryKey(primaryKey);

		if (ecomSmsDataMstr == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchEcomSmsDataMstrException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return ecomSmsDataMstr;
	}

	/**
	 * Returns the ecom sms data mstr with the primary key or throws a <code>NoSuchEcomSmsDataMstrException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr
	 * @throws NoSuchEcomSmsDataMstrException if a ecom sms data mstr with the primary key could not be found
	 */
	@Override
	public EcomSmsDataMstr findByPrimaryKey(long id)
		throws NoSuchEcomSmsDataMstrException {

		return findByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns the ecom sms data mstr with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom sms data mstr
	 * @return the ecom sms data mstr, or <code>null</code> if a ecom sms data mstr with the primary key could not be found
	 */
	@Override
	public EcomSmsDataMstr fetchByPrimaryKey(long id) {
		return fetchByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns all the ecom sms data mstrs.
	 *
	 * @return the ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @return the range of ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findAll(
		int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the ecom sms data mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSmsDataMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom sms data mstrs
	 * @param end the upper bound of the range of ecom sms data mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom sms data mstrs
	 */
	@Override
	public List<EcomSmsDataMstr> findAll(
		int start, int end,
		OrderByComparator<EcomSmsDataMstr> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<EcomSmsDataMstr> list = null;

		if (useFinderCache) {
			list = (List<EcomSmsDataMstr>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_ECOMSMSDATAMSTR);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_ECOMSMSDATAMSTR;

				sql = sql.concat(EcomSmsDataMstrModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<EcomSmsDataMstr>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the ecom sms data mstrs from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (EcomSmsDataMstr ecomSmsDataMstr : findAll()) {
			remove(ecomSmsDataMstr);
		}
	}

	/**
	 * Returns the number of ecom sms data mstrs.
	 *
	 * @return the number of ecom sms data mstrs
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_ECOMSMSDATAMSTR);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "id_";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_ECOMSMSDATAMSTR;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return EcomSmsDataMstrModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the ecom sms data mstr persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathWithPaginationFindByMsisdn = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByMsisdn",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"msisdn"}, true);

		_finderPathWithoutPaginationFindByMsisdn = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByMsisdn",
			new String[] {String.class.getName()}, new String[] {"msisdn"},
			true);

		_finderPathCountByMsisdn = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByMsisdn",
			new String[] {String.class.getName()}, new String[] {"msisdn"},
			false);

		_finderPathWithPaginationFindByCrtnOn = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCrtnOn",
			new String[] {
				Date.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"crtn_on"}, true);

		_finderPathWithoutPaginationFindByCrtnOn = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCrtnOn",
			new String[] {Date.class.getName()}, new String[] {"crtn_on"},
			true);

		_finderPathCountByCrtnOn = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCrtnOn",
			new String[] {Date.class.getName()}, new String[] {"crtn_on"},
			false);

		_setEcomSmsDataMstrUtilPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		_setEcomSmsDataMstrUtilPersistence(null);

		entityCache.removeCache(EcomSmsDataMstrImpl.class.getName());
	}

	private void _setEcomSmsDataMstrUtilPersistence(
		EcomSmsDataMstrPersistence ecomSmsDataMstrPersistence) {

		try {
			Field field = EcomSmsDataMstrUtil.class.getDeclaredField(
				"_persistence");

			field.setAccessible(true);

			field.set(null, ecomSmsDataMstrPersistence);
		}
		catch (ReflectiveOperationException reflectiveOperationException) {
			throw new RuntimeException(reflectiveOperationException);
		}
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static Long _getTime(Date date) {
		if (date == null) {
			return null;
		}

		return date.getTime();
	}

	private static final String _SQL_SELECT_ECOMSMSDATAMSTR =
		"SELECT ecomSmsDataMstr FROM EcomSmsDataMstr ecomSmsDataMstr";

	private static final String _SQL_SELECT_ECOMSMSDATAMSTR_WHERE =
		"SELECT ecomSmsDataMstr FROM EcomSmsDataMstr ecomSmsDataMstr WHERE ";

	private static final String _SQL_COUNT_ECOMSMSDATAMSTR =
		"SELECT COUNT(ecomSmsDataMstr) FROM EcomSmsDataMstr ecomSmsDataMstr";

	private static final String _SQL_COUNT_ECOMSMSDATAMSTR_WHERE =
		"SELECT COUNT(ecomSmsDataMstr) FROM EcomSmsDataMstr ecomSmsDataMstr WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "ecomSmsDataMstr.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No EcomSmsDataMstr exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No EcomSmsDataMstr exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		EcomSmsDataMstrPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"id"});

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

}