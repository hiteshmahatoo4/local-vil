/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.vil.ecom.db.model.EcomCrcleMstr;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EcomCrcleMstr in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class EcomCrcleMstrCacheModel
	implements CacheModel<EcomCrcleMstr>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof EcomCrcleMstrCacheModel)) {
			return false;
		}

		EcomCrcleMstrCacheModel ecomCrcleMstrCacheModel =
			(EcomCrcleMstrCacheModel)object;

		if (id == ecomCrcleMstrCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{id=");
		sb.append(id);
		sb.append(", circle_id=");
		sb.append(circle_id);
		sb.append(", circle_cde=");
		sb.append(circle_cde);
		sb.append(", circle_nme=");
		sb.append(circle_nme);
		sb.append(", eai_circle_id=");
		sb.append(eai_circle_id);
		sb.append(", upss_circle_id=");
		sb.append(upss_circle_id);
		sb.append(", msdp_circle_cde=");
		sb.append(msdp_circle_cde);
		sb.append(", msdp_circle_nme=");
		sb.append(msdp_circle_nme);
		sb.append(", msdp_content_provider=");
		sb.append(msdp_content_provider);
		sb.append(", crtd_by=");
		sb.append(crtd_by);
		sb.append(", crtn_on=");
		sb.append(crtn_on);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EcomCrcleMstr toEntityModel() {
		EcomCrcleMstrImpl ecomCrcleMstrImpl = new EcomCrcleMstrImpl();

		ecomCrcleMstrImpl.setId(id);

		if (circle_id == null) {
			ecomCrcleMstrImpl.setCircle_id("");
		}
		else {
			ecomCrcleMstrImpl.setCircle_id(circle_id);
		}

		if (circle_cde == null) {
			ecomCrcleMstrImpl.setCircle_cde("");
		}
		else {
			ecomCrcleMstrImpl.setCircle_cde(circle_cde);
		}

		if (circle_nme == null) {
			ecomCrcleMstrImpl.setCircle_nme("");
		}
		else {
			ecomCrcleMstrImpl.setCircle_nme(circle_nme);
		}

		if (eai_circle_id == null) {
			ecomCrcleMstrImpl.setEai_circle_id("");
		}
		else {
			ecomCrcleMstrImpl.setEai_circle_id(eai_circle_id);
		}

		if (upss_circle_id == null) {
			ecomCrcleMstrImpl.setUpss_circle_id("");
		}
		else {
			ecomCrcleMstrImpl.setUpss_circle_id(upss_circle_id);
		}

		if (msdp_circle_cde == null) {
			ecomCrcleMstrImpl.setMsdp_circle_cde("");
		}
		else {
			ecomCrcleMstrImpl.setMsdp_circle_cde(msdp_circle_cde);
		}

		if (msdp_circle_nme == null) {
			ecomCrcleMstrImpl.setMsdp_circle_nme("");
		}
		else {
			ecomCrcleMstrImpl.setMsdp_circle_nme(msdp_circle_nme);
		}

		if (msdp_content_provider == null) {
			ecomCrcleMstrImpl.setMsdp_content_provider("");
		}
		else {
			ecomCrcleMstrImpl.setMsdp_content_provider(msdp_content_provider);
		}

		if (crtd_by == null) {
			ecomCrcleMstrImpl.setCrtd_by("");
		}
		else {
			ecomCrcleMstrImpl.setCrtd_by(crtd_by);
		}

		if (crtn_on == Long.MIN_VALUE) {
			ecomCrcleMstrImpl.setCrtn_on(null);
		}
		else {
			ecomCrcleMstrImpl.setCrtn_on(new Date(crtn_on));
		}

		ecomCrcleMstrImpl.resetOriginalValues();

		return ecomCrcleMstrImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		id = objectInput.readLong();
		circle_id = objectInput.readUTF();
		circle_cde = objectInput.readUTF();
		circle_nme = objectInput.readUTF();
		eai_circle_id = objectInput.readUTF();
		upss_circle_id = objectInput.readUTF();
		msdp_circle_cde = objectInput.readUTF();
		msdp_circle_nme = objectInput.readUTF();
		msdp_content_provider = objectInput.readUTF();
		crtd_by = objectInput.readUTF();
		crtn_on = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(id);

		if (circle_id == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(circle_id);
		}

		if (circle_cde == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(circle_cde);
		}

		if (circle_nme == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(circle_nme);
		}

		if (eai_circle_id == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(eai_circle_id);
		}

		if (upss_circle_id == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(upss_circle_id);
		}

		if (msdp_circle_cde == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(msdp_circle_cde);
		}

		if (msdp_circle_nme == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(msdp_circle_nme);
		}

		if (msdp_content_provider == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(msdp_content_provider);
		}

		if (crtd_by == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(crtd_by);
		}

		objectOutput.writeLong(crtn_on);
	}

	public long id;
	public String circle_id;
	public String circle_cde;
	public String circle_nme;
	public String eai_circle_id;
	public String upss_circle_id;
	public String msdp_circle_cde;
	public String msdp_circle_nme;
	public String msdp_content_provider;
	public String crtd_by;
	public long crtn_on;

}