/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringUtil;

import com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException;
import com.vil.ecom.db.model.EcomCrcleMstr;
import com.vil.ecom.db.model.EcomCrcleMstrTable;
import com.vil.ecom.db.model.impl.EcomCrcleMstrImpl;
import com.vil.ecom.db.model.impl.EcomCrcleMstrModelImpl;
import com.vil.ecom.db.service.persistence.EcomCrcleMstrPersistence;
import com.vil.ecom.db.service.persistence.EcomCrcleMstrUtil;
import com.vil.ecom.db.service.persistence.impl.constants.LRPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the ecom crcle mstr service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = EcomCrcleMstrPersistence.class)
public class EcomCrcleMstrPersistenceImpl
	extends BasePersistenceImpl<EcomCrcleMstr>
	implements EcomCrcleMstrPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>EcomCrcleMstrUtil</code> to access the ecom crcle mstr persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		EcomCrcleMstrImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathFetchByUpssCircleId;
	private FinderPath _finderPathCountByUpssCircleId;

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr findByUpssCircleId(String upss_circle_id)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = fetchByUpssCircleId(upss_circle_id);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("upss_circle_id=");
			sb.append(upss_circle_id);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByUpssCircleId(String upss_circle_id) {
		return fetchByUpssCircleId(upss_circle_id, true);
	}

	/**
	 * Returns the ecom crcle mstr where upss_circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByUpssCircleId(
		String upss_circle_id, boolean useFinderCache) {

		upss_circle_id = Objects.toString(upss_circle_id, "");

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {upss_circle_id};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchByUpssCircleId, finderArgs, this);
		}

		if (result instanceof EcomCrcleMstr) {
			EcomCrcleMstr ecomCrcleMstr = (EcomCrcleMstr)result;

			if (!Objects.equals(
					upss_circle_id, ecomCrcleMstr.getUpss_circle_id())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_ECOMCRCLEMSTR_WHERE);

			boolean bindUpss_circle_id = false;

			if (upss_circle_id.isEmpty()) {
				sb.append(_FINDER_COLUMN_UPSSCIRCLEID_UPSS_CIRCLE_ID_3);
			}
			else {
				bindUpss_circle_id = true;

				sb.append(_FINDER_COLUMN_UPSSCIRCLEID_UPSS_CIRCLE_ID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindUpss_circle_id) {
					queryPos.add(upss_circle_id);
				}

				List<EcomCrcleMstr> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchByUpssCircleId, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {upss_circle_id};
							}

							_log.warn(
								"EcomCrcleMstrPersistenceImpl.fetchByUpssCircleId(String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					EcomCrcleMstr ecomCrcleMstr = list.get(0);

					result = ecomCrcleMstr;

					cacheResult(ecomCrcleMstr);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (EcomCrcleMstr)result;
		}
	}

	/**
	 * Removes the ecom crcle mstr where upss_circle_id = &#63; from the database.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	@Override
	public EcomCrcleMstr removeByUpssCircleId(String upss_circle_id)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = findByUpssCircleId(upss_circle_id);

		return remove(ecomCrcleMstr);
	}

	/**
	 * Returns the number of ecom crcle mstrs where upss_circle_id = &#63;.
	 *
	 * @param upss_circle_id the upss_circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	@Override
	public int countByUpssCircleId(String upss_circle_id) {
		upss_circle_id = Objects.toString(upss_circle_id, "");

		FinderPath finderPath = _finderPathCountByUpssCircleId;

		Object[] finderArgs = new Object[] {upss_circle_id};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMCRCLEMSTR_WHERE);

			boolean bindUpss_circle_id = false;

			if (upss_circle_id.isEmpty()) {
				sb.append(_FINDER_COLUMN_UPSSCIRCLEID_UPSS_CIRCLE_ID_3);
			}
			else {
				bindUpss_circle_id = true;

				sb.append(_FINDER_COLUMN_UPSSCIRCLEID_UPSS_CIRCLE_ID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindUpss_circle_id) {
					queryPos.add(upss_circle_id);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UPSSCIRCLEID_UPSS_CIRCLE_ID_2 =
		"ecomCrcleMstr.upss_circle_id = ?";

	private static final String _FINDER_COLUMN_UPSSCIRCLEID_UPSS_CIRCLE_ID_3 =
		"(ecomCrcleMstr.upss_circle_id IS NULL OR ecomCrcleMstr.upss_circle_id = '')";

	private FinderPath _finderPathFetchByEaiCircleId;
	private FinderPath _finderPathCountByEaiCircleId;

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr findByEaiCircleId(String eai_circle_id)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = fetchByEaiCircleId(eai_circle_id);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("eai_circle_id=");
			sb.append(eai_circle_id);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByEaiCircleId(String eai_circle_id) {
		return fetchByEaiCircleId(eai_circle_id, true);
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByEaiCircleId(
		String eai_circle_id, boolean useFinderCache) {

		eai_circle_id = Objects.toString(eai_circle_id, "");

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {eai_circle_id};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchByEaiCircleId, finderArgs, this);
		}

		if (result instanceof EcomCrcleMstr) {
			EcomCrcleMstr ecomCrcleMstr = (EcomCrcleMstr)result;

			if (!Objects.equals(
					eai_circle_id, ecomCrcleMstr.getEai_circle_id())) {

				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_ECOMCRCLEMSTR_WHERE);

			boolean bindEai_circle_id = false;

			if (eai_circle_id.isEmpty()) {
				sb.append(_FINDER_COLUMN_EAICIRCLEID_EAI_CIRCLE_ID_3);
			}
			else {
				bindEai_circle_id = true;

				sb.append(_FINDER_COLUMN_EAICIRCLEID_EAI_CIRCLE_ID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindEai_circle_id) {
					queryPos.add(eai_circle_id);
				}

				List<EcomCrcleMstr> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchByEaiCircleId, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {eai_circle_id};
							}

							_log.warn(
								"EcomCrcleMstrPersistenceImpl.fetchByEaiCircleId(String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					EcomCrcleMstr ecomCrcleMstr = list.get(0);

					result = ecomCrcleMstr;

					cacheResult(ecomCrcleMstr);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (EcomCrcleMstr)result;
		}
	}

	/**
	 * Removes the ecom crcle mstr where eai_circle_id = &#63; from the database.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	@Override
	public EcomCrcleMstr removeByEaiCircleId(String eai_circle_id)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = findByEaiCircleId(eai_circle_id);

		return remove(ecomCrcleMstr);
	}

	/**
	 * Returns the number of ecom crcle mstrs where eai_circle_id = &#63;.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	@Override
	public int countByEaiCircleId(String eai_circle_id) {
		eai_circle_id = Objects.toString(eai_circle_id, "");

		FinderPath finderPath = _finderPathCountByEaiCircleId;

		Object[] finderArgs = new Object[] {eai_circle_id};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMCRCLEMSTR_WHERE);

			boolean bindEai_circle_id = false;

			if (eai_circle_id.isEmpty()) {
				sb.append(_FINDER_COLUMN_EAICIRCLEID_EAI_CIRCLE_ID_3);
			}
			else {
				bindEai_circle_id = true;

				sb.append(_FINDER_COLUMN_EAICIRCLEID_EAI_CIRCLE_ID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindEai_circle_id) {
					queryPos.add(eai_circle_id);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_EAICIRCLEID_EAI_CIRCLE_ID_2 =
		"ecomCrcleMstr.eai_circle_id = ?";

	private static final String _FINDER_COLUMN_EAICIRCLEID_EAI_CIRCLE_ID_3 =
		"(ecomCrcleMstr.eai_circle_id IS NULL OR ecomCrcleMstr.eai_circle_id = '')";

	private FinderPath _finderPathFetchBycircleCde;
	private FinderPath _finderPathCountBycircleCde;

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_cde the circle_cde
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr findBycircleCde(String circle_cde)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = fetchBycircleCde(circle_cde);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("circle_cde=");
			sb.append(circle_cde);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_cde the circle_cde
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchBycircleCde(String circle_cde) {
		return fetchBycircleCde(circle_cde, true);
	}

	/**
	 * Returns the ecom crcle mstr where circle_cde = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_cde the circle_cde
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchBycircleCde(
		String circle_cde, boolean useFinderCache) {

		circle_cde = Objects.toString(circle_cde, "");

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {circle_cde};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchBycircleCde, finderArgs, this);
		}

		if (result instanceof EcomCrcleMstr) {
			EcomCrcleMstr ecomCrcleMstr = (EcomCrcleMstr)result;

			if (!Objects.equals(circle_cde, ecomCrcleMstr.getCircle_cde())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_ECOMCRCLEMSTR_WHERE);

			boolean bindCircle_cde = false;

			if (circle_cde.isEmpty()) {
				sb.append(_FINDER_COLUMN_CIRCLECDE_CIRCLE_CDE_3);
			}
			else {
				bindCircle_cde = true;

				sb.append(_FINDER_COLUMN_CIRCLECDE_CIRCLE_CDE_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCircle_cde) {
					queryPos.add(circle_cde);
				}

				List<EcomCrcleMstr> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchBycircleCde, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {circle_cde};
							}

							_log.warn(
								"EcomCrcleMstrPersistenceImpl.fetchBycircleCde(String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					EcomCrcleMstr ecomCrcleMstr = list.get(0);

					result = ecomCrcleMstr;

					cacheResult(ecomCrcleMstr);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (EcomCrcleMstr)result;
		}
	}

	/**
	 * Removes the ecom crcle mstr where circle_cde = &#63; from the database.
	 *
	 * @param circle_cde the circle_cde
	 * @return the ecom crcle mstr that was removed
	 */
	@Override
	public EcomCrcleMstr removeBycircleCde(String circle_cde)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = findBycircleCde(circle_cde);

		return remove(ecomCrcleMstr);
	}

	/**
	 * Returns the number of ecom crcle mstrs where circle_cde = &#63;.
	 *
	 * @param circle_cde the circle_cde
	 * @return the number of matching ecom crcle mstrs
	 */
	@Override
	public int countBycircleCde(String circle_cde) {
		circle_cde = Objects.toString(circle_cde, "");

		FinderPath finderPath = _finderPathCountBycircleCde;

		Object[] finderArgs = new Object[] {circle_cde};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMCRCLEMSTR_WHERE);

			boolean bindCircle_cde = false;

			if (circle_cde.isEmpty()) {
				sb.append(_FINDER_COLUMN_CIRCLECDE_CIRCLE_CDE_3);
			}
			else {
				bindCircle_cde = true;

				sb.append(_FINDER_COLUMN_CIRCLECDE_CIRCLE_CDE_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCircle_cde) {
					queryPos.add(circle_cde);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CIRCLECDE_CIRCLE_CDE_2 =
		"ecomCrcleMstr.circle_cde = ?";

	private static final String _FINDER_COLUMN_CIRCLECDE_CIRCLE_CDE_3 =
		"(ecomCrcleMstr.circle_cde IS NULL OR ecomCrcleMstr.circle_cde = '')";

	private FinderPath _finderPathFetchByCircleId;
	private FinderPath _finderPathCountByCircleId;

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_id the circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr findByCircleId(String circle_id)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = fetchByCircleId(circle_id);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("circle_id=");
			sb.append(circle_id);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_id the circle_id
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByCircleId(String circle_id) {
		return fetchByCircleId(circle_id, true);
	}

	/**
	 * Returns the ecom crcle mstr where circle_id = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_id the circle_id
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByCircleId(
		String circle_id, boolean useFinderCache) {

		circle_id = Objects.toString(circle_id, "");

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {circle_id};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchByCircleId, finderArgs, this);
		}

		if (result instanceof EcomCrcleMstr) {
			EcomCrcleMstr ecomCrcleMstr = (EcomCrcleMstr)result;

			if (!Objects.equals(circle_id, ecomCrcleMstr.getCircle_id())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_ECOMCRCLEMSTR_WHERE);

			boolean bindCircle_id = false;

			if (circle_id.isEmpty()) {
				sb.append(_FINDER_COLUMN_CIRCLEID_CIRCLE_ID_3);
			}
			else {
				bindCircle_id = true;

				sb.append(_FINDER_COLUMN_CIRCLEID_CIRCLE_ID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCircle_id) {
					queryPos.add(circle_id);
				}

				List<EcomCrcleMstr> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchByCircleId, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {circle_id};
							}

							_log.warn(
								"EcomCrcleMstrPersistenceImpl.fetchByCircleId(String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					EcomCrcleMstr ecomCrcleMstr = list.get(0);

					result = ecomCrcleMstr;

					cacheResult(ecomCrcleMstr);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (EcomCrcleMstr)result;
		}
	}

	/**
	 * Removes the ecom crcle mstr where circle_id = &#63; from the database.
	 *
	 * @param circle_id the circle_id
	 * @return the ecom crcle mstr that was removed
	 */
	@Override
	public EcomCrcleMstr removeByCircleId(String circle_id)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = findByCircleId(circle_id);

		return remove(ecomCrcleMstr);
	}

	/**
	 * Returns the number of ecom crcle mstrs where circle_id = &#63;.
	 *
	 * @param circle_id the circle_id
	 * @return the number of matching ecom crcle mstrs
	 */
	@Override
	public int countByCircleId(String circle_id) {
		circle_id = Objects.toString(circle_id, "");

		FinderPath finderPath = _finderPathCountByCircleId;

		Object[] finderArgs = new Object[] {circle_id};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMCRCLEMSTR_WHERE);

			boolean bindCircle_id = false;

			if (circle_id.isEmpty()) {
				sb.append(_FINDER_COLUMN_CIRCLEID_CIRCLE_ID_3);
			}
			else {
				bindCircle_id = true;

				sb.append(_FINDER_COLUMN_CIRCLEID_CIRCLE_ID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCircle_id) {
					queryPos.add(circle_id);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CIRCLEID_CIRCLE_ID_2 =
		"ecomCrcleMstr.circle_id = ?";

	private static final String _FINDER_COLUMN_CIRCLEID_CIRCLE_ID_3 =
		"(ecomCrcleMstr.circle_id IS NULL OR ecomCrcleMstr.circle_id = '')";

	private FinderPath _finderPathFetchByCircleNme;
	private FinderPath _finderPathCountByCircleNme;

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param circle_nme the circle_nme
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr findByCircleNme(String circle_nme)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = fetchByCircleNme(circle_nme);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("circle_nme=");
			sb.append(circle_nme);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param circle_nme the circle_nme
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByCircleNme(String circle_nme) {
		return fetchByCircleNme(circle_nme, true);
	}

	/**
	 * Returns the ecom crcle mstr where circle_nme = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param circle_nme the circle_nme
	 * @param useFinderCache whether to use the finder cache
	 * @return the matching ecom crcle mstr, or <code>null</code> if a matching ecom crcle mstr could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByCircleNme(
		String circle_nme, boolean useFinderCache) {

		circle_nme = Objects.toString(circle_nme, "");

		Object[] finderArgs = null;

		if (useFinderCache) {
			finderArgs = new Object[] {circle_nme};
		}

		Object result = null;

		if (useFinderCache) {
			result = finderCache.getResult(
				_finderPathFetchByCircleNme, finderArgs, this);
		}

		if (result instanceof EcomCrcleMstr) {
			EcomCrcleMstr ecomCrcleMstr = (EcomCrcleMstr)result;

			if (!Objects.equals(circle_nme, ecomCrcleMstr.getCircle_nme())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler sb = new StringBundler(3);

			sb.append(_SQL_SELECT_ECOMCRCLEMSTR_WHERE);

			boolean bindCircle_nme = false;

			if (circle_nme.isEmpty()) {
				sb.append(_FINDER_COLUMN_CIRCLENME_CIRCLE_NME_3);
			}
			else {
				bindCircle_nme = true;

				sb.append(_FINDER_COLUMN_CIRCLENME_CIRCLE_NME_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCircle_nme) {
					queryPos.add(circle_nme);
				}

				List<EcomCrcleMstr> list = query.list();

				if (list.isEmpty()) {
					if (useFinderCache) {
						finderCache.putResult(
							_finderPathFetchByCircleNme, finderArgs, list);
					}
				}
				else {
					if (list.size() > 1) {
						Collections.sort(list, Collections.reverseOrder());

						if (_log.isWarnEnabled()) {
							if (!useFinderCache) {
								finderArgs = new Object[] {circle_nme};
							}

							_log.warn(
								"EcomCrcleMstrPersistenceImpl.fetchByCircleNme(String, boolean) with parameters (" +
									StringUtil.merge(finderArgs) +
										") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
						}
					}

					EcomCrcleMstr ecomCrcleMstr = list.get(0);

					result = ecomCrcleMstr;

					cacheResult(ecomCrcleMstr);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (EcomCrcleMstr)result;
		}
	}

	/**
	 * Removes the ecom crcle mstr where circle_nme = &#63; from the database.
	 *
	 * @param circle_nme the circle_nme
	 * @return the ecom crcle mstr that was removed
	 */
	@Override
	public EcomCrcleMstr removeByCircleNme(String circle_nme)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = findByCircleNme(circle_nme);

		return remove(ecomCrcleMstr);
	}

	/**
	 * Returns the number of ecom crcle mstrs where circle_nme = &#63;.
	 *
	 * @param circle_nme the circle_nme
	 * @return the number of matching ecom crcle mstrs
	 */
	@Override
	public int countByCircleNme(String circle_nme) {
		circle_nme = Objects.toString(circle_nme, "");

		FinderPath finderPath = _finderPathCountByCircleNme;

		Object[] finderArgs = new Object[] {circle_nme};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMCRCLEMSTR_WHERE);

			boolean bindCircle_nme = false;

			if (circle_nme.isEmpty()) {
				sb.append(_FINDER_COLUMN_CIRCLENME_CIRCLE_NME_3);
			}
			else {
				bindCircle_nme = true;

				sb.append(_FINDER_COLUMN_CIRCLENME_CIRCLE_NME_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindCircle_nme) {
					queryPos.add(circle_nme);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CIRCLENME_CIRCLE_NME_2 =
		"ecomCrcleMstr.circle_nme = ?";

	private static final String _FINDER_COLUMN_CIRCLENME_CIRCLE_NME_3 =
		"(ecomCrcleMstr.circle_nme IS NULL OR ecomCrcleMstr.circle_nme = '')";

	public EcomCrcleMstrPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("id", "id_");

		setDBColumnNames(dbColumnNames);

		setModelClass(EcomCrcleMstr.class);

		setModelImplClass(EcomCrcleMstrImpl.class);
		setModelPKClass(long.class);

		setTable(EcomCrcleMstrTable.INSTANCE);
	}

	/**
	 * Caches the ecom crcle mstr in the entity cache if it is enabled.
	 *
	 * @param ecomCrcleMstr the ecom crcle mstr
	 */
	@Override
	public void cacheResult(EcomCrcleMstr ecomCrcleMstr) {
		entityCache.putResult(
			EcomCrcleMstrImpl.class, ecomCrcleMstr.getPrimaryKey(),
			ecomCrcleMstr);

		finderCache.putResult(
			_finderPathFetchByUpssCircleId,
			new Object[] {ecomCrcleMstr.getUpss_circle_id()}, ecomCrcleMstr);

		finderCache.putResult(
			_finderPathFetchByEaiCircleId,
			new Object[] {ecomCrcleMstr.getEai_circle_id()}, ecomCrcleMstr);

		finderCache.putResult(
			_finderPathFetchBycircleCde,
			new Object[] {ecomCrcleMstr.getCircle_cde()}, ecomCrcleMstr);

		finderCache.putResult(
			_finderPathFetchByCircleId,
			new Object[] {ecomCrcleMstr.getCircle_id()}, ecomCrcleMstr);

		finderCache.putResult(
			_finderPathFetchByCircleNme,
			new Object[] {ecomCrcleMstr.getCircle_nme()}, ecomCrcleMstr);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the ecom crcle mstrs in the entity cache if it is enabled.
	 *
	 * @param ecomCrcleMstrs the ecom crcle mstrs
	 */
	@Override
	public void cacheResult(List<EcomCrcleMstr> ecomCrcleMstrs) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (ecomCrcleMstrs.size() > _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (EcomCrcleMstr ecomCrcleMstr : ecomCrcleMstrs) {
			if (entityCache.getResult(
					EcomCrcleMstrImpl.class, ecomCrcleMstr.getPrimaryKey()) ==
						null) {

				cacheResult(ecomCrcleMstr);
			}
		}
	}

	/**
	 * Clears the cache for all ecom crcle mstrs.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(EcomCrcleMstrImpl.class);

		finderCache.clearCache(EcomCrcleMstrImpl.class);
	}

	/**
	 * Clears the cache for the ecom crcle mstr.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(EcomCrcleMstr ecomCrcleMstr) {
		entityCache.removeResult(EcomCrcleMstrImpl.class, ecomCrcleMstr);
	}

	@Override
	public void clearCache(List<EcomCrcleMstr> ecomCrcleMstrs) {
		for (EcomCrcleMstr ecomCrcleMstr : ecomCrcleMstrs) {
			entityCache.removeResult(EcomCrcleMstrImpl.class, ecomCrcleMstr);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(EcomCrcleMstrImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(EcomCrcleMstrImpl.class, primaryKey);
		}
	}

	protected void cacheUniqueFindersCache(
		EcomCrcleMstrModelImpl ecomCrcleMstrModelImpl) {

		Object[] args = new Object[] {
			ecomCrcleMstrModelImpl.getUpss_circle_id()
		};

		finderCache.putResult(
			_finderPathCountByUpssCircleId, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchByUpssCircleId, args, ecomCrcleMstrModelImpl);

		args = new Object[] {ecomCrcleMstrModelImpl.getEai_circle_id()};

		finderCache.putResult(
			_finderPathCountByEaiCircleId, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchByEaiCircleId, args, ecomCrcleMstrModelImpl);

		args = new Object[] {ecomCrcleMstrModelImpl.getCircle_cde()};

		finderCache.putResult(
			_finderPathCountBycircleCde, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchBycircleCde, args, ecomCrcleMstrModelImpl);

		args = new Object[] {ecomCrcleMstrModelImpl.getCircle_id()};

		finderCache.putResult(
			_finderPathCountByCircleId, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchByCircleId, args, ecomCrcleMstrModelImpl);

		args = new Object[] {ecomCrcleMstrModelImpl.getCircle_nme()};

		finderCache.putResult(
			_finderPathCountByCircleNme, args, Long.valueOf(1));
		finderCache.putResult(
			_finderPathFetchByCircleNme, args, ecomCrcleMstrModelImpl);
	}

	/**
	 * Creates a new ecom crcle mstr with the primary key. Does not add the ecom crcle mstr to the database.
	 *
	 * @param id the primary key for the new ecom crcle mstr
	 * @return the new ecom crcle mstr
	 */
	@Override
	public EcomCrcleMstr create(long id) {
		EcomCrcleMstr ecomCrcleMstr = new EcomCrcleMstrImpl();

		ecomCrcleMstr.setNew(true);
		ecomCrcleMstr.setPrimaryKey(id);

		return ecomCrcleMstr;
	}

	/**
	 * Removes the ecom crcle mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr that was removed
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	@Override
	public EcomCrcleMstr remove(long id) throws NoSuchEcomCrcleMstrException {
		return remove((Serializable)id);
	}

	/**
	 * Removes the ecom crcle mstr with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr that was removed
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	@Override
	public EcomCrcleMstr remove(Serializable primaryKey)
		throws NoSuchEcomCrcleMstrException {

		Session session = null;

		try {
			session = openSession();

			EcomCrcleMstr ecomCrcleMstr = (EcomCrcleMstr)session.get(
				EcomCrcleMstrImpl.class, primaryKey);

			if (ecomCrcleMstr == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchEcomCrcleMstrException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(ecomCrcleMstr);
		}
		catch (NoSuchEcomCrcleMstrException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected EcomCrcleMstr removeImpl(EcomCrcleMstr ecomCrcleMstr) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(ecomCrcleMstr)) {
				ecomCrcleMstr = (EcomCrcleMstr)session.get(
					EcomCrcleMstrImpl.class, ecomCrcleMstr.getPrimaryKeyObj());
			}

			if (ecomCrcleMstr != null) {
				session.delete(ecomCrcleMstr);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (ecomCrcleMstr != null) {
			clearCache(ecomCrcleMstr);
		}

		return ecomCrcleMstr;
	}

	@Override
	public EcomCrcleMstr updateImpl(EcomCrcleMstr ecomCrcleMstr) {
		boolean isNew = ecomCrcleMstr.isNew();

		if (!(ecomCrcleMstr instanceof EcomCrcleMstrModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(ecomCrcleMstr.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					ecomCrcleMstr);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in ecomCrcleMstr proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom EcomCrcleMstr implementation " +
					ecomCrcleMstr.getClass());
		}

		EcomCrcleMstrModelImpl ecomCrcleMstrModelImpl =
			(EcomCrcleMstrModelImpl)ecomCrcleMstr;

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(ecomCrcleMstr);
			}
			else {
				ecomCrcleMstr = (EcomCrcleMstr)session.merge(ecomCrcleMstr);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			EcomCrcleMstrImpl.class, ecomCrcleMstrModelImpl, false, true);

		cacheUniqueFindersCache(ecomCrcleMstrModelImpl);

		if (isNew) {
			ecomCrcleMstr.setNew(false);
		}

		ecomCrcleMstr.resetOriginalValues();

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	@Override
	public EcomCrcleMstr findByPrimaryKey(Serializable primaryKey)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = fetchByPrimaryKey(primaryKey);

		if (ecomCrcleMstr == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchEcomCrcleMstrException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr with the primary key or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a ecom crcle mstr with the primary key could not be found
	 */
	@Override
	public EcomCrcleMstr findByPrimaryKey(long id)
		throws NoSuchEcomCrcleMstrException {

		return findByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns the ecom crcle mstr with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom crcle mstr
	 * @return the ecom crcle mstr, or <code>null</code> if a ecom crcle mstr with the primary key could not be found
	 */
	@Override
	public EcomCrcleMstr fetchByPrimaryKey(long id) {
		return fetchByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns all the ecom crcle mstrs.
	 *
	 * @return the ecom crcle mstrs
	 */
	@Override
	public List<EcomCrcleMstr> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @return the range of ecom crcle mstrs
	 */
	@Override
	public List<EcomCrcleMstr> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom crcle mstrs
	 */
	@Override
	public List<EcomCrcleMstr> findAll(
		int start, int end,
		OrderByComparator<EcomCrcleMstr> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the ecom crcle mstrs.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomCrcleMstrModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom crcle mstrs
	 * @param end the upper bound of the range of ecom crcle mstrs (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom crcle mstrs
	 */
	@Override
	public List<EcomCrcleMstr> findAll(
		int start, int end, OrderByComparator<EcomCrcleMstr> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<EcomCrcleMstr> list = null;

		if (useFinderCache) {
			list = (List<EcomCrcleMstr>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_ECOMCRCLEMSTR);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_ECOMCRCLEMSTR;

				sql = sql.concat(EcomCrcleMstrModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<EcomCrcleMstr>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the ecom crcle mstrs from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (EcomCrcleMstr ecomCrcleMstr : findAll()) {
			remove(ecomCrcleMstr);
		}
	}

	/**
	 * Returns the number of ecom crcle mstrs.
	 *
	 * @return the number of ecom crcle mstrs
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_ECOMCRCLEMSTR);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "id_";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_ECOMCRCLEMSTR;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return EcomCrcleMstrModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the ecom crcle mstr persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathFetchByUpssCircleId = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchByUpssCircleId",
			new String[] {String.class.getName()},
			new String[] {"upss_circle_id"}, true);

		_finderPathCountByUpssCircleId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUpssCircleId",
			new String[] {String.class.getName()},
			new String[] {"upss_circle_id"}, false);

		_finderPathFetchByEaiCircleId = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchByEaiCircleId",
			new String[] {String.class.getName()},
			new String[] {"eai_circle_id"}, true);

		_finderPathCountByEaiCircleId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByEaiCircleId",
			new String[] {String.class.getName()},
			new String[] {"eai_circle_id"}, false);

		_finderPathFetchBycircleCde = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchBycircleCde",
			new String[] {String.class.getName()}, new String[] {"circle_cde"},
			true);

		_finderPathCountBycircleCde = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBycircleCde",
			new String[] {String.class.getName()}, new String[] {"circle_cde"},
			false);

		_finderPathFetchByCircleId = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchByCircleId",
			new String[] {String.class.getName()}, new String[] {"circle_id"},
			true);

		_finderPathCountByCircleId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCircleId",
			new String[] {String.class.getName()}, new String[] {"circle_id"},
			false);

		_finderPathFetchByCircleNme = new FinderPath(
			FINDER_CLASS_NAME_ENTITY, "fetchByCircleNme",
			new String[] {String.class.getName()}, new String[] {"circle_nme"},
			true);

		_finderPathCountByCircleNme = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCircleNme",
			new String[] {String.class.getName()}, new String[] {"circle_nme"},
			false);

		_setEcomCrcleMstrUtilPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		_setEcomCrcleMstrUtilPersistence(null);

		entityCache.removeCache(EcomCrcleMstrImpl.class.getName());
	}

	private void _setEcomCrcleMstrUtilPersistence(
		EcomCrcleMstrPersistence ecomCrcleMstrPersistence) {

		try {
			Field field = EcomCrcleMstrUtil.class.getDeclaredField(
				"_persistence");

			field.setAccessible(true);

			field.set(null, ecomCrcleMstrPersistence);
		}
		catch (ReflectiveOperationException reflectiveOperationException) {
			throw new RuntimeException(reflectiveOperationException);
		}
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_ECOMCRCLEMSTR =
		"SELECT ecomCrcleMstr FROM EcomCrcleMstr ecomCrcleMstr";

	private static final String _SQL_SELECT_ECOMCRCLEMSTR_WHERE =
		"SELECT ecomCrcleMstr FROM EcomCrcleMstr ecomCrcleMstr WHERE ";

	private static final String _SQL_COUNT_ECOMCRCLEMSTR =
		"SELECT COUNT(ecomCrcleMstr) FROM EcomCrcleMstr ecomCrcleMstr";

	private static final String _SQL_COUNT_ECOMCRCLEMSTR_WHERE =
		"SELECT COUNT(ecomCrcleMstr) FROM EcomCrcleMstr ecomCrcleMstr WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "ecomCrcleMstr.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No EcomCrcleMstr exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No EcomCrcleMstr exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		EcomCrcleMstrPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"id"});

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

}