/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.vil.ecom.db.model.EcomSrvcConfigCnstnts;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EcomSrvcConfigCnstnts in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class EcomSrvcConfigCnstntsCacheModel
	implements CacheModel<EcomSrvcConfigCnstnts>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof EcomSrvcConfigCnstntsCacheModel)) {
			return false;
		}

		EcomSrvcConfigCnstntsCacheModel ecomSrvcConfigCnstntsCacheModel =
			(EcomSrvcConfigCnstntsCacheModel)object;

		if (id == ecomSrvcConfigCnstntsCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(13);

		sb.append("{id=");
		sb.append(id);
		sb.append(", srvc_type=");
		sb.append(srvc_type);
		sb.append(", srvc_key=");
		sb.append(srvc_key);
		sb.append(", value=");
		sb.append(value);
		sb.append(", description=");
		sb.append(description);
		sb.append(", crtn_on=");
		sb.append(crtn_on);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EcomSrvcConfigCnstnts toEntityModel() {
		EcomSrvcConfigCnstntsImpl ecomSrvcConfigCnstntsImpl =
			new EcomSrvcConfigCnstntsImpl();

		ecomSrvcConfigCnstntsImpl.setId(id);

		if (srvc_type == null) {
			ecomSrvcConfigCnstntsImpl.setSrvc_type("");
		}
		else {
			ecomSrvcConfigCnstntsImpl.setSrvc_type(srvc_type);
		}

		if (srvc_key == null) {
			ecomSrvcConfigCnstntsImpl.setSrvc_key("");
		}
		else {
			ecomSrvcConfigCnstntsImpl.setSrvc_key(srvc_key);
		}

		if (value == null) {
			ecomSrvcConfigCnstntsImpl.setValue("");
		}
		else {
			ecomSrvcConfigCnstntsImpl.setValue(value);
		}

		if (description == null) {
			ecomSrvcConfigCnstntsImpl.setDescription("");
		}
		else {
			ecomSrvcConfigCnstntsImpl.setDescription(description);
		}

		if (crtn_on == Long.MIN_VALUE) {
			ecomSrvcConfigCnstntsImpl.setCrtn_on(null);
		}
		else {
			ecomSrvcConfigCnstntsImpl.setCrtn_on(new Date(crtn_on));
		}

		ecomSrvcConfigCnstntsImpl.resetOriginalValues();

		return ecomSrvcConfigCnstntsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		id = objectInput.readLong();
		srvc_type = objectInput.readUTF();
		srvc_key = objectInput.readUTF();
		value = objectInput.readUTF();
		description = objectInput.readUTF();
		crtn_on = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(id);

		if (srvc_type == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(srvc_type);
		}

		if (srvc_key == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(srvc_key);
		}

		if (value == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(value);
		}

		if (description == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(description);
		}

		objectOutput.writeLong(crtn_on);
	}

	public long id;
	public String srvc_type;
	public String srvc_key;
	public String value;
	public String description;
	public long crtn_on;

}