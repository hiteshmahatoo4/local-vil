/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.vil.ecom.db.model.EcomSmsDataMstr;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EcomSmsDataMstr in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class EcomSmsDataMstrCacheModel
	implements CacheModel<EcomSmsDataMstr>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof EcomSmsDataMstrCacheModel)) {
			return false;
		}

		EcomSmsDataMstrCacheModel ecomSmsDataMstrCacheModel =
			(EcomSmsDataMstrCacheModel)object;

		if (id == ecomSmsDataMstrCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{id=");
		sb.append(id);
		sb.append(", msisdn=");
		sb.append(msisdn);
		sb.append(", event_nme=");
		sb.append(event_nme);
		sb.append(", text_desc=");
		sb.append(text_desc);
		sb.append(", stts=");
		sb.append(stts);
		sb.append(", circle_nme=");
		sb.append(circle_nme);
		sb.append(", sender_id=");
		sb.append(sender_id);
		sb.append(", filler1=");
		sb.append(filler1);
		sb.append(", filler2=");
		sb.append(filler2);
		sb.append(", filler3=");
		sb.append(filler3);
		sb.append(", filler4=");
		sb.append(filler4);
		sb.append(", filler5=");
		sb.append(filler5);
		sb.append(", crtd_by=");
		sb.append(crtd_by);
		sb.append(", crtn_on=");
		sb.append(crtn_on);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EcomSmsDataMstr toEntityModel() {
		EcomSmsDataMstrImpl ecomSmsDataMstrImpl = new EcomSmsDataMstrImpl();

		ecomSmsDataMstrImpl.setId(id);

		if (msisdn == null) {
			ecomSmsDataMstrImpl.setMsisdn("");
		}
		else {
			ecomSmsDataMstrImpl.setMsisdn(msisdn);
		}

		if (event_nme == null) {
			ecomSmsDataMstrImpl.setEvent_nme("");
		}
		else {
			ecomSmsDataMstrImpl.setEvent_nme(event_nme);
		}

		if (text_desc == null) {
			ecomSmsDataMstrImpl.setText_desc("");
		}
		else {
			ecomSmsDataMstrImpl.setText_desc(text_desc);
		}

		if (stts == null) {
			ecomSmsDataMstrImpl.setStts("");
		}
		else {
			ecomSmsDataMstrImpl.setStts(stts);
		}

		if (circle_nme == null) {
			ecomSmsDataMstrImpl.setCircle_nme("");
		}
		else {
			ecomSmsDataMstrImpl.setCircle_nme(circle_nme);
		}

		if (sender_id == null) {
			ecomSmsDataMstrImpl.setSender_id("");
		}
		else {
			ecomSmsDataMstrImpl.setSender_id(sender_id);
		}

		if (filler1 == null) {
			ecomSmsDataMstrImpl.setFiller1("");
		}
		else {
			ecomSmsDataMstrImpl.setFiller1(filler1);
		}

		if (filler2 == null) {
			ecomSmsDataMstrImpl.setFiller2("");
		}
		else {
			ecomSmsDataMstrImpl.setFiller2(filler2);
		}

		if (filler3 == null) {
			ecomSmsDataMstrImpl.setFiller3("");
		}
		else {
			ecomSmsDataMstrImpl.setFiller3(filler3);
		}

		if (filler4 == null) {
			ecomSmsDataMstrImpl.setFiller4("");
		}
		else {
			ecomSmsDataMstrImpl.setFiller4(filler4);
		}

		if (filler5 == null) {
			ecomSmsDataMstrImpl.setFiller5("");
		}
		else {
			ecomSmsDataMstrImpl.setFiller5(filler5);
		}

		if (crtd_by == null) {
			ecomSmsDataMstrImpl.setCrtd_by("");
		}
		else {
			ecomSmsDataMstrImpl.setCrtd_by(crtd_by);
		}

		if (crtn_on == Long.MIN_VALUE) {
			ecomSmsDataMstrImpl.setCrtn_on(null);
		}
		else {
			ecomSmsDataMstrImpl.setCrtn_on(new Date(crtn_on));
		}

		ecomSmsDataMstrImpl.resetOriginalValues();

		return ecomSmsDataMstrImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		id = objectInput.readLong();
		msisdn = objectInput.readUTF();
		event_nme = objectInput.readUTF();
		text_desc = objectInput.readUTF();
		stts = objectInput.readUTF();
		circle_nme = objectInput.readUTF();
		sender_id = objectInput.readUTF();
		filler1 = objectInput.readUTF();
		filler2 = objectInput.readUTF();
		filler3 = objectInput.readUTF();
		filler4 = objectInput.readUTF();
		filler5 = objectInput.readUTF();
		crtd_by = objectInput.readUTF();
		crtn_on = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(id);

		if (msisdn == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(msisdn);
		}

		if (event_nme == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(event_nme);
		}

		if (text_desc == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(text_desc);
		}

		if (stts == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(stts);
		}

		if (circle_nme == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(circle_nme);
		}

		if (sender_id == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(sender_id);
		}

		if (filler1 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler1);
		}

		if (filler2 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler2);
		}

		if (filler3 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler3);
		}

		if (filler4 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler4);
		}

		if (filler5 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler5);
		}

		if (crtd_by == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(crtd_by);
		}

		objectOutput.writeLong(crtn_on);
	}

	public long id;
	public String msisdn;
	public String event_nme;
	public String text_desc;
	public String stts;
	public String circle_nme;
	public String sender_id;
	public String filler1;
	public String filler2;
	public String filler3;
	public String filler4;
	public String filler5;
	public String crtd_by;
	public long crtn_on;

}