/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;

import com.vil.ecom.db.exception.NoSuchEcomSrvcConfigCnstntsException;
import com.vil.ecom.db.model.EcomSrvcConfigCnstnts;
import com.vil.ecom.db.model.EcomSrvcConfigCnstntsTable;
import com.vil.ecom.db.model.impl.EcomSrvcConfigCnstntsImpl;
import com.vil.ecom.db.model.impl.EcomSrvcConfigCnstntsModelImpl;
import com.vil.ecom.db.service.persistence.EcomSrvcConfigCnstntsPersistence;
import com.vil.ecom.db.service.persistence.EcomSrvcConfigCnstntsUtil;
import com.vil.ecom.db.service.persistence.impl.constants.LRPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the ecom srvc config cnstnts service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = EcomSrvcConfigCnstntsPersistence.class)
public class EcomSrvcConfigCnstntsPersistenceImpl
	extends BasePersistenceImpl<EcomSrvcConfigCnstnts>
	implements EcomSrvcConfigCnstntsPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>EcomSrvcConfigCnstntsUtil</code> to access the ecom srvc config cnstnts persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		EcomSrvcConfigCnstntsImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindBySrvcType;
	private FinderPath _finderPathWithoutPaginationFindBySrvcType;
	private FinderPath _finderPathCountBySrvcType;

	/**
	 * Returns all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @return the matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findBySrvcType(String srvc_type) {
		return findBySrvcType(
			srvc_type, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_type the srvc_type
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @return the range of matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findBySrvcType(
		String srvc_type, int start, int end) {

		return findBySrvcType(srvc_type, start, end, null);
	}

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_type the srvc_type
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findBySrvcType(
		String srvc_type, int start, int end,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator) {

		return findBySrvcType(srvc_type, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_type the srvc_type
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findBySrvcType(
		String srvc_type, int start, int end,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator,
		boolean useFinderCache) {

		srvc_type = Objects.toString(srvc_type, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindBySrvcType;
				finderArgs = new Object[] {srvc_type};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindBySrvcType;
			finderArgs = new Object[] {
				srvc_type, start, end, orderByComparator
			};
		}

		List<EcomSrvcConfigCnstnts> list = null;

		if (useFinderCache) {
			list = (List<EcomSrvcConfigCnstnts>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts : list) {
					if (!srvc_type.equals(
							ecomSrvcConfigCnstnts.getSrvc_type())) {

						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_ECOMSRVCCONFIGCNSTNTS_WHERE);

			boolean bindSrvc_type = false;

			if (srvc_type.isEmpty()) {
				sb.append(_FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_3);
			}
			else {
				bindSrvc_type = true;

				sb.append(_FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(EcomSrvcConfigCnstntsModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindSrvc_type) {
					queryPos.add(srvc_type);
				}

				list = (List<EcomSrvcConfigCnstnts>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts findBySrvcType_First(
			String srvc_type,
			OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException {

		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts = fetchBySrvcType_First(
			srvc_type, orderByComparator);

		if (ecomSrvcConfigCnstnts != null) {
			return ecomSrvcConfigCnstnts;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("srvc_type=");
		sb.append(srvc_type);

		sb.append("}");

		throw new NoSuchEcomSrvcConfigCnstntsException(sb.toString());
	}

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts fetchBySrvcType_First(
		String srvc_type,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator) {

		List<EcomSrvcConfigCnstnts> list = findBySrvcType(
			srvc_type, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts findBySrvcType_Last(
			String srvc_type,
			OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException {

		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts = fetchBySrvcType_Last(
			srvc_type, orderByComparator);

		if (ecomSrvcConfigCnstnts != null) {
			return ecomSrvcConfigCnstnts;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("srvc_type=");
		sb.append(srvc_type);

		sb.append("}");

		throw new NoSuchEcomSrvcConfigCnstntsException(sb.toString());
	}

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts fetchBySrvcType_Last(
		String srvc_type,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator) {

		int count = countBySrvcType(srvc_type);

		if (count == 0) {
			return null;
		}

		List<EcomSrvcConfigCnstnts> list = findBySrvcType(
			srvc_type, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the ecom srvc config cnstntses before and after the current ecom srvc config cnstnts in the ordered set where srvc_type = &#63;.
	 *
	 * @param id the primary key of the current ecom srvc config cnstnts
	 * @param srvc_type the srvc_type
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts[] findBySrvcType_PrevAndNext(
			long id, String srvc_type,
			OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException {

		srvc_type = Objects.toString(srvc_type, "");

		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			EcomSrvcConfigCnstnts[] array = new EcomSrvcConfigCnstntsImpl[3];

			array[0] = getBySrvcType_PrevAndNext(
				session, ecomSrvcConfigCnstnts, srvc_type, orderByComparator,
				true);

			array[1] = ecomSrvcConfigCnstnts;

			array[2] = getBySrvcType_PrevAndNext(
				session, ecomSrvcConfigCnstnts, srvc_type, orderByComparator,
				false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected EcomSrvcConfigCnstnts getBySrvcType_PrevAndNext(
		Session session, EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts,
		String srvc_type,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_ECOMSRVCCONFIGCNSTNTS_WHERE);

		boolean bindSrvc_type = false;

		if (srvc_type.isEmpty()) {
			sb.append(_FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_3);
		}
		else {
			bindSrvc_type = true;

			sb.append(_FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(EcomSrvcConfigCnstntsModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindSrvc_type) {
			queryPos.add(srvc_type);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						ecomSrvcConfigCnstnts)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<EcomSrvcConfigCnstnts> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the ecom srvc config cnstntses where srvc_type = &#63; from the database.
	 *
	 * @param srvc_type the srvc_type
	 */
	@Override
	public void removeBySrvcType(String srvc_type) {
		for (EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts :
				findBySrvcType(
					srvc_type, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(ecomSrvcConfigCnstnts);
		}
	}

	/**
	 * Returns the number of ecom srvc config cnstntses where srvc_type = &#63;.
	 *
	 * @param srvc_type the srvc_type
	 * @return the number of matching ecom srvc config cnstntses
	 */
	@Override
	public int countBySrvcType(String srvc_type) {
		srvc_type = Objects.toString(srvc_type, "");

		FinderPath finderPath = _finderPathCountBySrvcType;

		Object[] finderArgs = new Object[] {srvc_type};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMSRVCCONFIGCNSTNTS_WHERE);

			boolean bindSrvc_type = false;

			if (srvc_type.isEmpty()) {
				sb.append(_FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_3);
			}
			else {
				bindSrvc_type = true;

				sb.append(_FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindSrvc_type) {
					queryPos.add(srvc_type);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_2 =
		"ecomSrvcConfigCnstnts.srvc_type = ?";

	private static final String _FINDER_COLUMN_SRVCTYPE_SRVC_TYPE_3 =
		"(ecomSrvcConfigCnstnts.srvc_type IS NULL OR ecomSrvcConfigCnstnts.srvc_type = '')";

	private FinderPath _finderPathWithPaginationFindByKey;
	private FinderPath _finderPathWithoutPaginationFindByKey;
	private FinderPath _finderPathCountByKey;

	/**
	 * Returns all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findByKey(String srvc_key) {
		return findByKey(srvc_key, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @return the range of matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findByKey(
		String srvc_key, int start, int end) {

		return findByKey(srvc_key, start, end, null);
	}

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findByKey(
		String srvc_key, int start, int end,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator) {

		return findByKey(srvc_key, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param srvc_key the srvc_key
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findByKey(
		String srvc_key, int start, int end,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator,
		boolean useFinderCache) {

		srvc_key = Objects.toString(srvc_key, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByKey;
				finderArgs = new Object[] {srvc_key};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByKey;
			finderArgs = new Object[] {srvc_key, start, end, orderByComparator};
		}

		List<EcomSrvcConfigCnstnts> list = null;

		if (useFinderCache) {
			list = (List<EcomSrvcConfigCnstnts>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts : list) {
					if (!srvc_key.equals(ecomSrvcConfigCnstnts.getSrvc_key())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_ECOMSRVCCONFIGCNSTNTS_WHERE);

			boolean bindSrvc_key = false;

			if (srvc_key.isEmpty()) {
				sb.append(_FINDER_COLUMN_KEY_SRVC_KEY_3);
			}
			else {
				bindSrvc_key = true;

				sb.append(_FINDER_COLUMN_KEY_SRVC_KEY_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(EcomSrvcConfigCnstntsModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindSrvc_key) {
					queryPos.add(srvc_key);
				}

				list = (List<EcomSrvcConfigCnstnts>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts findByKey_First(
			String srvc_key,
			OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException {

		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts = fetchByKey_First(
			srvc_key, orderByComparator);

		if (ecomSrvcConfigCnstnts != null) {
			return ecomSrvcConfigCnstnts;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("srvc_key=");
		sb.append(srvc_key);

		sb.append("}");

		throw new NoSuchEcomSrvcConfigCnstntsException(sb.toString());
	}

	/**
	 * Returns the first ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts fetchByKey_First(
		String srvc_key,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator) {

		List<EcomSrvcConfigCnstnts> list = findByKey(
			srvc_key, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts findByKey_Last(
			String srvc_key,
			OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException {

		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts = fetchByKey_Last(
			srvc_key, orderByComparator);

		if (ecomSrvcConfigCnstnts != null) {
			return ecomSrvcConfigCnstnts;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("srvc_key=");
		sb.append(srvc_key);

		sb.append("}");

		throw new NoSuchEcomSrvcConfigCnstntsException(sb.toString());
	}

	/**
	 * Returns the last ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching ecom srvc config cnstnts, or <code>null</code> if a matching ecom srvc config cnstnts could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts fetchByKey_Last(
		String srvc_key,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator) {

		int count = countByKey(srvc_key);

		if (count == 0) {
			return null;
		}

		List<EcomSrvcConfigCnstnts> list = findByKey(
			srvc_key, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the ecom srvc config cnstntses before and after the current ecom srvc config cnstnts in the ordered set where srvc_key = &#63;.
	 *
	 * @param id the primary key of the current ecom srvc config cnstnts
	 * @param srvc_key the srvc_key
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts[] findByKey_PrevAndNext(
			long id, String srvc_key,
			OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator)
		throws NoSuchEcomSrvcConfigCnstntsException {

		srvc_key = Objects.toString(srvc_key, "");

		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			EcomSrvcConfigCnstnts[] array = new EcomSrvcConfigCnstntsImpl[3];

			array[0] = getByKey_PrevAndNext(
				session, ecomSrvcConfigCnstnts, srvc_key, orderByComparator,
				true);

			array[1] = ecomSrvcConfigCnstnts;

			array[2] = getByKey_PrevAndNext(
				session, ecomSrvcConfigCnstnts, srvc_key, orderByComparator,
				false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected EcomSrvcConfigCnstnts getByKey_PrevAndNext(
		Session session, EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts,
		String srvc_key,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator,
		boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_ECOMSRVCCONFIGCNSTNTS_WHERE);

		boolean bindSrvc_key = false;

		if (srvc_key.isEmpty()) {
			sb.append(_FINDER_COLUMN_KEY_SRVC_KEY_3);
		}
		else {
			bindSrvc_key = true;

			sb.append(_FINDER_COLUMN_KEY_SRVC_KEY_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(EcomSrvcConfigCnstntsModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindSrvc_key) {
			queryPos.add(srvc_key);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(
						ecomSrvcConfigCnstnts)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<EcomSrvcConfigCnstnts> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the ecom srvc config cnstntses where srvc_key = &#63; from the database.
	 *
	 * @param srvc_key the srvc_key
	 */
	@Override
	public void removeByKey(String srvc_key) {
		for (EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts :
				findByKey(
					srvc_key, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(ecomSrvcConfigCnstnts);
		}
	}

	/**
	 * Returns the number of ecom srvc config cnstntses where srvc_key = &#63;.
	 *
	 * @param srvc_key the srvc_key
	 * @return the number of matching ecom srvc config cnstntses
	 */
	@Override
	public int countByKey(String srvc_key) {
		srvc_key = Objects.toString(srvc_key, "");

		FinderPath finderPath = _finderPathCountByKey;

		Object[] finderArgs = new Object[] {srvc_key};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_ECOMSRVCCONFIGCNSTNTS_WHERE);

			boolean bindSrvc_key = false;

			if (srvc_key.isEmpty()) {
				sb.append(_FINDER_COLUMN_KEY_SRVC_KEY_3);
			}
			else {
				bindSrvc_key = true;

				sb.append(_FINDER_COLUMN_KEY_SRVC_KEY_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindSrvc_key) {
					queryPos.add(srvc_key);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_KEY_SRVC_KEY_2 =
		"ecomSrvcConfigCnstnts.srvc_key = ?";

	private static final String _FINDER_COLUMN_KEY_SRVC_KEY_3 =
		"(ecomSrvcConfigCnstnts.srvc_key IS NULL OR ecomSrvcConfigCnstnts.srvc_key = '')";

	public EcomSrvcConfigCnstntsPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("id", "id_");

		setDBColumnNames(dbColumnNames);

		setModelClass(EcomSrvcConfigCnstnts.class);

		setModelImplClass(EcomSrvcConfigCnstntsImpl.class);
		setModelPKClass(long.class);

		setTable(EcomSrvcConfigCnstntsTable.INSTANCE);
	}

	/**
	 * Caches the ecom srvc config cnstnts in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcConfigCnstnts the ecom srvc config cnstnts
	 */
	@Override
	public void cacheResult(EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts) {
		entityCache.putResult(
			EcomSrvcConfigCnstntsImpl.class,
			ecomSrvcConfigCnstnts.getPrimaryKey(), ecomSrvcConfigCnstnts);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the ecom srvc config cnstntses in the entity cache if it is enabled.
	 *
	 * @param ecomSrvcConfigCnstntses the ecom srvc config cnstntses
	 */
	@Override
	public void cacheResult(
		List<EcomSrvcConfigCnstnts> ecomSrvcConfigCnstntses) {

		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (ecomSrvcConfigCnstntses.size() >
				 _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts :
				ecomSrvcConfigCnstntses) {

			if (entityCache.getResult(
					EcomSrvcConfigCnstntsImpl.class,
					ecomSrvcConfigCnstnts.getPrimaryKey()) == null) {

				cacheResult(ecomSrvcConfigCnstnts);
			}
		}
	}

	/**
	 * Clears the cache for all ecom srvc config cnstntses.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(EcomSrvcConfigCnstntsImpl.class);

		finderCache.clearCache(EcomSrvcConfigCnstntsImpl.class);
	}

	/**
	 * Clears the cache for the ecom srvc config cnstnts.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts) {
		entityCache.removeResult(
			EcomSrvcConfigCnstntsImpl.class, ecomSrvcConfigCnstnts);
	}

	@Override
	public void clearCache(
		List<EcomSrvcConfigCnstnts> ecomSrvcConfigCnstntses) {

		for (EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts :
				ecomSrvcConfigCnstntses) {

			entityCache.removeResult(
				EcomSrvcConfigCnstntsImpl.class, ecomSrvcConfigCnstnts);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(EcomSrvcConfigCnstntsImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(
				EcomSrvcConfigCnstntsImpl.class, primaryKey);
		}
	}

	/**
	 * Creates a new ecom srvc config cnstnts with the primary key. Does not add the ecom srvc config cnstnts to the database.
	 *
	 * @param id the primary key for the new ecom srvc config cnstnts
	 * @return the new ecom srvc config cnstnts
	 */
	@Override
	public EcomSrvcConfigCnstnts create(long id) {
		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts =
			new EcomSrvcConfigCnstntsImpl();

		ecomSrvcConfigCnstnts.setNew(true);
		ecomSrvcConfigCnstnts.setPrimaryKey(id);

		return ecomSrvcConfigCnstnts;
	}

	/**
	 * Removes the ecom srvc config cnstnts with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts that was removed
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts remove(long id)
		throws NoSuchEcomSrvcConfigCnstntsException {

		return remove((Serializable)id);
	}

	/**
	 * Removes the ecom srvc config cnstnts with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts that was removed
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts remove(Serializable primaryKey)
		throws NoSuchEcomSrvcConfigCnstntsException {

		Session session = null;

		try {
			session = openSession();

			EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts =
				(EcomSrvcConfigCnstnts)session.get(
					EcomSrvcConfigCnstntsImpl.class, primaryKey);

			if (ecomSrvcConfigCnstnts == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchEcomSrvcConfigCnstntsException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(ecomSrvcConfigCnstnts);
		}
		catch (NoSuchEcomSrvcConfigCnstntsException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected EcomSrvcConfigCnstnts removeImpl(
		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts) {

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(ecomSrvcConfigCnstnts)) {
				ecomSrvcConfigCnstnts = (EcomSrvcConfigCnstnts)session.get(
					EcomSrvcConfigCnstntsImpl.class,
					ecomSrvcConfigCnstnts.getPrimaryKeyObj());
			}

			if (ecomSrvcConfigCnstnts != null) {
				session.delete(ecomSrvcConfigCnstnts);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (ecomSrvcConfigCnstnts != null) {
			clearCache(ecomSrvcConfigCnstnts);
		}

		return ecomSrvcConfigCnstnts;
	}

	@Override
	public EcomSrvcConfigCnstnts updateImpl(
		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts) {

		boolean isNew = ecomSrvcConfigCnstnts.isNew();

		if (!(ecomSrvcConfigCnstnts instanceof
				EcomSrvcConfigCnstntsModelImpl)) {

			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(ecomSrvcConfigCnstnts.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(
					ecomSrvcConfigCnstnts);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in ecomSrvcConfigCnstnts proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom EcomSrvcConfigCnstnts implementation " +
					ecomSrvcConfigCnstnts.getClass());
		}

		EcomSrvcConfigCnstntsModelImpl ecomSrvcConfigCnstntsModelImpl =
			(EcomSrvcConfigCnstntsModelImpl)ecomSrvcConfigCnstnts;

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(ecomSrvcConfigCnstnts);
			}
			else {
				ecomSrvcConfigCnstnts = (EcomSrvcConfigCnstnts)session.merge(
					ecomSrvcConfigCnstnts);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			EcomSrvcConfigCnstntsImpl.class, ecomSrvcConfigCnstntsModelImpl,
			false, true);

		if (isNew) {
			ecomSrvcConfigCnstnts.setNew(false);
		}

		ecomSrvcConfigCnstnts.resetOriginalValues();

		return ecomSrvcConfigCnstnts;
	}

	/**
	 * Returns the ecom srvc config cnstnts with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts findByPrimaryKey(Serializable primaryKey)
		throws NoSuchEcomSrvcConfigCnstntsException {

		EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts = fetchByPrimaryKey(
			primaryKey);

		if (ecomSrvcConfigCnstnts == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchEcomSrvcConfigCnstntsException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return ecomSrvcConfigCnstnts;
	}

	/**
	 * Returns the ecom srvc config cnstnts with the primary key or throws a <code>NoSuchEcomSrvcConfigCnstntsException</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts
	 * @throws NoSuchEcomSrvcConfigCnstntsException if a ecom srvc config cnstnts with the primary key could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts findByPrimaryKey(long id)
		throws NoSuchEcomSrvcConfigCnstntsException {

		return findByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns the ecom srvc config cnstnts with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the ecom srvc config cnstnts
	 * @return the ecom srvc config cnstnts, or <code>null</code> if a ecom srvc config cnstnts with the primary key could not be found
	 */
	@Override
	public EcomSrvcConfigCnstnts fetchByPrimaryKey(long id) {
		return fetchByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns all the ecom srvc config cnstntses.
	 *
	 * @return the ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the ecom srvc config cnstntses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @return the range of ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findAll(
		int start, int end,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the ecom srvc config cnstntses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>EcomSrvcConfigCnstntsModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of ecom srvc config cnstntses
	 * @param end the upper bound of the range of ecom srvc config cnstntses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of ecom srvc config cnstntses
	 */
	@Override
	public List<EcomSrvcConfigCnstnts> findAll(
		int start, int end,
		OrderByComparator<EcomSrvcConfigCnstnts> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<EcomSrvcConfigCnstnts> list = null;

		if (useFinderCache) {
			list = (List<EcomSrvcConfigCnstnts>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_ECOMSRVCCONFIGCNSTNTS);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_ECOMSRVCCONFIGCNSTNTS;

				sql = sql.concat(EcomSrvcConfigCnstntsModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<EcomSrvcConfigCnstnts>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the ecom srvc config cnstntses from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts : findAll()) {
			remove(ecomSrvcConfigCnstnts);
		}
	}

	/**
	 * Returns the number of ecom srvc config cnstntses.
	 *
	 * @return the number of ecom srvc config cnstntses
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(
					_SQL_COUNT_ECOMSRVCCONFIGCNSTNTS);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "id_";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_ECOMSRVCCONFIGCNSTNTS;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return EcomSrvcConfigCnstntsModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the ecom srvc config cnstnts persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathWithPaginationFindBySrvcType = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findBySrvcType",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"srvc_type"}, true);

		_finderPathWithoutPaginationFindBySrvcType = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findBySrvcType",
			new String[] {String.class.getName()}, new String[] {"srvc_type"},
			true);

		_finderPathCountBySrvcType = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countBySrvcType",
			new String[] {String.class.getName()}, new String[] {"srvc_type"},
			false);

		_finderPathWithPaginationFindByKey = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByKey",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"srvc_key"}, true);

		_finderPathWithoutPaginationFindByKey = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByKey",
			new String[] {String.class.getName()}, new String[] {"srvc_key"},
			true);

		_finderPathCountByKey = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByKey",
			new String[] {String.class.getName()}, new String[] {"srvc_key"},
			false);

		_setEcomSrvcConfigCnstntsUtilPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		_setEcomSrvcConfigCnstntsUtilPersistence(null);

		entityCache.removeCache(EcomSrvcConfigCnstntsImpl.class.getName());
	}

	private void _setEcomSrvcConfigCnstntsUtilPersistence(
		EcomSrvcConfigCnstntsPersistence ecomSrvcConfigCnstntsPersistence) {

		try {
			Field field = EcomSrvcConfigCnstntsUtil.class.getDeclaredField(
				"_persistence");

			field.setAccessible(true);

			field.set(null, ecomSrvcConfigCnstntsPersistence);
		}
		catch (ReflectiveOperationException reflectiveOperationException) {
			throw new RuntimeException(reflectiveOperationException);
		}
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = LRPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_ECOMSRVCCONFIGCNSTNTS =
		"SELECT ecomSrvcConfigCnstnts FROM EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts";

	private static final String _SQL_SELECT_ECOMSRVCCONFIGCNSTNTS_WHERE =
		"SELECT ecomSrvcConfigCnstnts FROM EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts WHERE ";

	private static final String _SQL_COUNT_ECOMSRVCCONFIGCNSTNTS =
		"SELECT COUNT(ecomSrvcConfigCnstnts) FROM EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts";

	private static final String _SQL_COUNT_ECOMSRVCCONFIGCNSTNTS_WHERE =
		"SELECT COUNT(ecomSrvcConfigCnstnts) FROM EcomSrvcConfigCnstnts ecomSrvcConfigCnstnts WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS =
		"ecomSrvcConfigCnstnts.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No EcomSrvcConfigCnstnts exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No EcomSrvcConfigCnstnts exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		EcomSrvcConfigCnstntsPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"id"});

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

}