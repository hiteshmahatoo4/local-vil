/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.vil.ecom.db.model.EcomSrvcCmmndMppng;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EcomSrvcCmmndMppng in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class EcomSrvcCmmndMppngCacheModel
	implements CacheModel<EcomSrvcCmmndMppng>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof EcomSrvcCmmndMppngCacheModel)) {
			return false;
		}

		EcomSrvcCmmndMppngCacheModel ecomSrvcCmmndMppngCacheModel =
			(EcomSrvcCmmndMppngCacheModel)object;

		if (id == ecomSrvcCmmndMppngCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{id=");
		sb.append(id);
		sb.append(", srvc_key=");
		sb.append(srvc_key);
		sb.append(", srvc_req=");
		sb.append(srvc_req);
		sb.append(", srvc_util_class=");
		sb.append(srvc_util_class);
		sb.append(", util_signature=");
		sb.append(util_signature);
		sb.append(", event=");
		sb.append(event);
		sb.append(", filler1=");
		sb.append(filler1);
		sb.append(", filler2=");
		sb.append(filler2);
		sb.append(", filler3=");
		sb.append(filler3);
		sb.append(", crtd_on=");
		sb.append(crtd_on);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EcomSrvcCmmndMppng toEntityModel() {
		EcomSrvcCmmndMppngImpl ecomSrvcCmmndMppngImpl =
			new EcomSrvcCmmndMppngImpl();

		ecomSrvcCmmndMppngImpl.setId(id);

		if (srvc_key == null) {
			ecomSrvcCmmndMppngImpl.setSrvc_key("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setSrvc_key(srvc_key);
		}

		if (srvc_req == null) {
			ecomSrvcCmmndMppngImpl.setSrvc_req("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setSrvc_req(srvc_req);
		}

		if (srvc_util_class == null) {
			ecomSrvcCmmndMppngImpl.setSrvc_util_class("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setSrvc_util_class(srvc_util_class);
		}

		if (util_signature == null) {
			ecomSrvcCmmndMppngImpl.setUtil_signature("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setUtil_signature(util_signature);
		}

		if (event == null) {
			ecomSrvcCmmndMppngImpl.setEvent("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setEvent(event);
		}

		if (filler1 == null) {
			ecomSrvcCmmndMppngImpl.setFiller1("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setFiller1(filler1);
		}

		if (filler2 == null) {
			ecomSrvcCmmndMppngImpl.setFiller2("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setFiller2(filler2);
		}

		if (filler3 == null) {
			ecomSrvcCmmndMppngImpl.setFiller3("");
		}
		else {
			ecomSrvcCmmndMppngImpl.setFiller3(filler3);
		}

		if (crtd_on == Long.MIN_VALUE) {
			ecomSrvcCmmndMppngImpl.setCrtd_on(null);
		}
		else {
			ecomSrvcCmmndMppngImpl.setCrtd_on(new Date(crtd_on));
		}

		ecomSrvcCmmndMppngImpl.resetOriginalValues();

		return ecomSrvcCmmndMppngImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		id = objectInput.readLong();
		srvc_key = objectInput.readUTF();
		srvc_req = objectInput.readUTF();
		srvc_util_class = objectInput.readUTF();
		util_signature = objectInput.readUTF();
		event = objectInput.readUTF();
		filler1 = objectInput.readUTF();
		filler2 = objectInput.readUTF();
		filler3 = objectInput.readUTF();
		crtd_on = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(id);

		if (srvc_key == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(srvc_key);
		}

		if (srvc_req == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(srvc_req);
		}

		if (srvc_util_class == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(srvc_util_class);
		}

		if (util_signature == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(util_signature);
		}

		if (event == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(event);
		}

		if (filler1 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler1);
		}

		if (filler2 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler2);
		}

		if (filler3 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(filler3);
		}

		objectOutput.writeLong(crtd_on);
	}

	public long id;
	public String srvc_key;
	public String srvc_req;
	public String srvc_util_class;
	public String util_signature;
	public String event;
	public String filler1;
	public String filler2;
	public String filler3;
	public long crtd_on;

}