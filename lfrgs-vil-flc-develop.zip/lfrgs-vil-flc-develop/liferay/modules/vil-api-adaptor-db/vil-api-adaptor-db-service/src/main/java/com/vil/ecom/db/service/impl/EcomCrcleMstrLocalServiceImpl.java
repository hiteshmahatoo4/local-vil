/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.ecom.db.service.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.db.exception.NoSuchEcomCrcleMstrException;
import com.vil.ecom.db.model.EcomCrcleMstr;
import com.vil.ecom.db.service.base.EcomCrcleMstrLocalServiceBaseImpl;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.vil.ecom.db.model.EcomCrcleMstr",
	service = AopService.class
)
public class EcomCrcleMstrLocalServiceImpl
		extends EcomCrcleMstrLocalServiceBaseImpl {

	private static final Log _log = LogFactoryUtil.getLog(EcomCrcleMstrLocalServiceImpl.class);
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No EcomCrcleMstr exists with the key {";

	public EcomCrcleMstr findByUpssCircleId(String upss_circle_id) throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = ecomCrcleMstrPersistence.fetchByUpssCircleId(upss_circle_id);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("upss_circle_id=");
			sb.append(upss_circle_id);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}


	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr findByEaiCircleId(String eai_circle_id)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = ecomCrcleMstrPersistence.fetchByEaiCircleId(eai_circle_id);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("eai_circle_id=");
			sb.append(eai_circle_id);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}

	/**
	 * Returns the ecom crcle mstr where eai_circle_id = &#63; or throws a <code>NoSuchEcomCrcleMstrException</code> if it could not be found.
	 *
	 * @param eai_circle_id the eai_circle_id
	 * @return the matching ecom crcle mstr
	 * @throws NoSuchEcomCrcleMstrException if a matching ecom crcle mstr could not be found
	 */
	public EcomCrcleMstr findBycircleCde(String circle_cde)
		throws NoSuchEcomCrcleMstrException {

		EcomCrcleMstr ecomCrcleMstr = ecomCrcleMstrPersistence.findBycircleCde(circle_cde);

		if (ecomCrcleMstr == null) {
			StringBundler sb = new StringBundler(4);

			sb.append(_NO_SUCH_ENTITY_WITH_KEY);

			sb.append("circle_cde=");
			sb.append(circle_cde);

			sb.append("}");

			if (_log.isDebugEnabled()) {
				_log.debug(sb.toString());
			}

			throw new NoSuchEcomCrcleMstrException(sb.toString());
		}

		return ecomCrcleMstr;
	}

}