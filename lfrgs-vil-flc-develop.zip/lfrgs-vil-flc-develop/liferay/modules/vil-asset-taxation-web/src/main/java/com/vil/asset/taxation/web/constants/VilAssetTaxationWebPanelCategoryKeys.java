package com.vil.asset.taxation.web.constants;

/**
 * @author vaibhav
 */
public class VilAssetTaxationWebPanelCategoryKeys {

	public static final String CONTROL_PANEL_CATEGORY = "VilAssetTaxationWeb";

}