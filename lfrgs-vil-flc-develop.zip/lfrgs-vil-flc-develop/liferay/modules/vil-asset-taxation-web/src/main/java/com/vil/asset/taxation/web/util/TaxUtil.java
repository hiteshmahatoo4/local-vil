package com.vil.asset.taxation.web.util;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.vil.common.util.VILCommonUtil;
import com.vil.common.util.VilCategoryUtil;
import com.vil.common.util.VilRoleUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * The purpose of this class is to provide various utility public methods
 * 
 * 
 * @author Prakash
 *
 */
public class TaxUtil {
	private static final Log log = LogFactoryUtil.getLog(TaxUtil.class.getName());

	/**
	 * This method is used to get category map
	 * 
	 * @param themeDisplay
	 * @return
	 */
	public static List<AssetCategory> getCategoryList(ThemeDisplay themeDisplay) {
		List<AssetCategory> categories = new ArrayList<>();
		try {
			boolean isPartnerKAM = UserLocalServiceUtil.hasRoleUser(themeDisplay.getCompanyId(),
					VilRoleUtil.VIL_PARTNER_ROLES.ROLE_PARTNER_KAM.name, themeDisplay.getUserId(), false);

			boolean isAdmin = VilRoleUtil.isAdmin(themeDisplay.getUserId());

			if (isPartnerKAM) {
				categories = VilCategoryUtil.getCategoryListByPartner(themeDisplay.getUserId());
			} else if (isAdmin) {
				categories = VILCommonUtil.getPartnerAssetCategories(themeDisplay.getCompanyGroupId());
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return categories;
	}

}
