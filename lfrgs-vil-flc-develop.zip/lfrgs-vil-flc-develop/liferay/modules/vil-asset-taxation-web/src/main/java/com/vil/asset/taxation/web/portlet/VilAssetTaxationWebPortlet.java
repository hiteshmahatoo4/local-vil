package com.vil.asset.taxation.web.portlet;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetVocabularyLocalServiceUtil;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Portal;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.vil.asset.taxation.displaycontext.CategoryManagementToolbarDisplayContext;
import com.vil.asset.taxation.web.constants.VilAssetTaxationWebPortletKeys;
import com.vil.common.util.VILCommonUtil;
import com.vil.tax.based.value.mapping.model.TaxBasedValueMapping;
import com.vil.tax.based.value.mapping.service.TaxBasedValueMappingLocalServiceUtil;
import com.vil.tax.category.mapping.model.TaxCategoryMapping;
import com.vil.tax.category.mapping.service.TaxCategoryMappingLocalServiceUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author vaibhav
 */
@Component(immediate = true, property = { "com.liferay.portlet.add-default-resource=true",
		"com.liferay.portlet.display-category=category.hidden", "com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.layout-cacheable=true", "com.liferay.portlet.private-request-attributes=false",
		"com.liferay.portlet.private-session-attributes=false", "com.liferay.portlet.render-weight=50",
		"com.liferay.portlet.use-default-template=true", "javax.portlet.display-name=VilAssetTaxationWeb",
		"javax.portlet.expiration-cache=0", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + VilAssetTaxationWebPortletKeys.VILASSETTAXATIONWEB,
		"javax.portlet.resource-bundle=content.Language", "javax.portlet.security-role-ref=power-user,user",

}, service = Portlet.class)
public class VilAssetTaxationWebPortlet extends MVCPortlet {

	/**
	 * This method is used to display deleted categories list.
	 *
	 * @param renderRequest  : holds and sets the attributes and renders when page
	 *                       is loading
	 * 
	 * @param renderResponse : holds the html and displays it to the end users
	 * 
	 * @throws IOException
	 * @throws PortletException : Hold detail of exception if there is problem while
	 *                          fetching the logs
	 */

	private static final Log log = LogFactoryUtil.getLog(VilAssetTaxationWebPortlet.class);

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		String addTax = ParamUtil.getString(renderRequest, "addTax");

		if (addTax.equals("addTax")) {
			categoryListAttributes(renderRequest);
			include("/list.jsp", renderRequest, renderResponse);
			return;
		} else {
			categoryTaxListAttributes(renderRequest);
		}
		addtToolbarAttributes(renderRequest, renderResponse);

		super.render(renderRequest, renderResponse);
	}

	/**
	 * This method is used to add the liferay toolbar
	 * 
	 */
	private void addtToolbarAttributes(RenderRequest renderRequest, RenderResponse renderResponse) {
		try {
			LiferayPortletRequest liferayPortletRequest = portal.getLiferayPortletRequest(renderRequest);
			LiferayPortletResponse liferayPortletResponse = portal.getLiferayPortletResponse(renderResponse);
			HttpServletRequest httpServletRequest = portal.getHttpServletRequest(renderRequest);

			CategoryManagementToolbarDisplayContext categoryManagementToolbarDisplayContext = new CategoryManagementToolbarDisplayContext(
					liferayPortletRequest, liferayPortletResponse, httpServletRequest);

			renderRequest.setAttribute("categoryManagementToolbarDisplayContext",
					categoryManagementToolbarDisplayContext);
		} catch (Exception e) {
			_log.error(e);
		}
	}

	/**
	 * 
	 * This method is used to get categories Tax list
	 *
	 * @param renderRequest : request param
	 */
	private void categoryTaxListAttributes(RenderRequest renderRequest) {
		List<TaxCategoryMapping> sortedList = new ArrayList<TaxCategoryMapping>();
		List<TaxCategoryMapping> taxCategoryMappings = TaxCategoryMappingLocalServiceUtil
				.getTaxCategoryMappings(QueryUtil.ALL_POS, QueryUtil.ALL_POS).stream()
				.filter(x -> x.getCatagoryId() != 0).collect(Collectors.toList());
		TaxCategoryMapping defaultTaxCategoryMapping = TaxCategoryMappingLocalServiceUtil.fetchByCatagoryId(0);

		Collections.sort(taxCategoryMappings,
				(TaxCategoryMapping o1, TaxCategoryMapping o2) -> o2.getModifiedDate().compareTo(o1.getModifiedDate()));

		if (Validator.isNotNull(defaultTaxCategoryMapping)) {
			sortedList.add(defaultTaxCategoryMapping);
		}

		if (ListUtil.isNotEmpty(taxCategoryMappings)) {
			sortedList.addAll(taxCategoryMappings);
		}

		renderRequest.setAttribute("taxCategoryMappings", sortedList);
		renderRequest.setAttribute("totaltaxCategory", sortedList.size());

	}

	/**
	 * 
	 * This method is used to get categories list
	 *
	 * @param renderRequest : request param
	 */
	private List<AssetCategory> categoryListAttributes(RenderRequest renderRequest) {
		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long globalGroupId = themeDisplay.getCompanyGroupId();
		List<AssetCategory> assetcategories = null;
		boolean isTaxPageDisplay = false;
		String categoryId = ParamUtil.getString(renderRequest, "categoryId");
		assetcategories = AssetCategoryLocalServiceUtil.getVocabularyCategories(0, getVocabId(globalGroupId),
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);

		if (ListUtil.isNotEmpty(assetcategories)) {
			renderRequest.setAttribute("assetcategories", assetcategories);
			renderRequest.setAttribute("totalcategories", assetcategories.size());
		} else if (Validator.isNotNull(categoryId)) {
			isTaxPageDisplay = true;
		}
		return assetcategories;
	}

	/**
	 * 
	 * This method is used to get Vocabulary Id
	 *
	 * @param renderRequest : request param
	 */
	private long getVocabId(Long id) {

		try {

			long globalGroupId = id;
			String vocabName = VILCommonUtil.getGenericVocabName();
			return AssetVocabularyLocalServiceUtil.fetchGroupVocabulary(globalGroupId, vocabName.toLowerCase())
					.getVocabularyId();
		} catch (Exception e) {
			log.info(e.getMessage());
		}
		return 0;
	}

	/**
	 * 
	 * This method is used to add or update category's tax values
	 * 
	 *
	 * @param actionRequest
	 * @param actionResponse
	 * @return
	 */
	@ProcessAction(name = "categoryTaxation")
	public void categoryTaxation(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {
		int level = 0;
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		User user = UserLocalServiceUtil.fetchUser(themeDisplay.getUserId());
		long categoryId = ParamUtil.getLong(actionRequest, "categoryId");
		String categoryLabel = ParamUtil.getString(actionRequest, "categoryLabel");
		List<Role> roles = user.getRoles();
		StringBuilder sb = new StringBuilder();
		for (Role role : roles) {
			sb.append(role.getName());
			sb.append(StringPool.COMMA_AND_SPACE);
		}

		double sgstRatio = Double.valueOf(ParamUtil.getString(actionRequest, "sgstRatio"));
		double cgstRatio = Double.valueOf(ParamUtil.getString(actionRequest, "cgstRatio"));
		double taxrate = Double.valueOf(ParamUtil.getString(actionRequest, "taxrate"));
		double cess = Double.valueOf(ParamUtil.getString(actionRequest, "cess"));
		boolean taxBasedOnAmountRange = Boolean.valueOf(ParamUtil.getString(actionRequest, "taxBasedOnAmountRange"));
		if (taxBasedOnAmountRange) {
			List<TaxBasedValueMapping> taxBasedValueMapping = TaxBasedValueMappingLocalServiceUtil
					.findByCatagoryId(categoryId);

			if (Validator.isNotNull(taxBasedValueMapping)) {

				for (TaxBasedValueMapping taxBasedValueMapping2 : taxBasedValueMapping) {
					TaxBasedValueMappingLocalServiceUtil.deleteTaxBasedValueMapping(taxBasedValueMapping2.getId());
				}

			}

			while (Validator.isNotNull(ParamUtil.getString(actionRequest, "startPrice" + level))) {
				long id = CounterLocalServiceUtil.increment(TaxBasedValueMapping.class.getName());
				TaxBasedValueMapping createTaxBasedValueMapping = TaxBasedValueMappingLocalServiceUtil
						.createTaxBasedValueMapping(id);
				Double startPrice = Double.valueOf(ParamUtil.getString(actionRequest, "startPrice" + level));
				Double endPrice = Double.valueOf(ParamUtil.getString(actionRequest, "endPrice" + level));
				Double taxBasedIgstRate = Double
						.valueOf(ParamUtil.getString(actionRequest, "taxBasedIgstRate" + level));
				Double taxBasedSgstRate = Double
						.valueOf(ParamUtil.getString(actionRequest, "taxBasedSgstRatio" + level));
				Double taxBasedCgstRate = Double
						.valueOf(ParamUtil.getString(actionRequest, "taxBasedCgstRatio" + level));
				Double taxBasedCessRate = Double
						.valueOf(ParamUtil.getString(actionRequest, "taxBasedCessRate" + level));
				createTaxBasedValueMapping.setCatagoryId(categoryId);
				createTaxBasedValueMapping.setStartRate(startPrice);
				createTaxBasedValueMapping.setEndRate(endPrice);
				createTaxBasedValueMapping.setIgstRate(taxBasedIgstRate);
				createTaxBasedValueMapping.setCgstRate(taxBasedCgstRate);
				createTaxBasedValueMapping.setSgstRate(taxBasedSgstRate);
				createTaxBasedValueMapping.setCessRate(taxBasedCessRate);
				TaxBasedValueMappingLocalServiceUtil.addTaxBasedValueMapping(createTaxBasedValueMapping);
				level++;

			}
		}
		long id = CounterLocalServiceUtil.increment(TaxCategoryMapping.class.getName());
		TaxCategoryMapping taxCategoryMapping = TaxCategoryMappingLocalServiceUtil.fetchByCatagoryId(categoryId);

		if (Validator.isNotNull(taxCategoryMapping)) {
			taxCategoryMapping.setCategoryLabel(categoryLabel);
			taxCategoryMapping.setSgstPercent(sgstRatio);
			taxCategoryMapping.setCgstPercent(cgstRatio);
			taxCategoryMapping.setCessPercent(cess);
			taxCategoryMapping.setTaxratePercent(taxrate);
			taxCategoryMapping.setTaxBasedOnAmountRange(taxBasedOnAmountRange);
			taxCategoryMapping.setCatagoryId(categoryId);
			TaxCategoryMappingLocalServiceUtil.updateTaxCategoryMapping(taxCategoryMapping);
		} else {
			TaxCategoryMapping categoryMapping = TaxCategoryMappingLocalServiceUtil.createTaxCategoryMapping(id);
			categoryMapping.setCategoryLabel(categoryLabel);
			categoryMapping.setSgstPercent(sgstRatio);
			categoryMapping.setCgstPercent(cgstRatio);
			categoryMapping.setCessPercent(cess);
			categoryMapping.setTaxratePercent(taxrate);
			categoryMapping.setTaxBasedOnAmountRange(taxBasedOnAmountRange);
			categoryMapping.setCatagoryId(categoryId);
			TaxCategoryMappingLocalServiceUtil.addTaxCategoryMapping(categoryMapping);
		}
		String updatedFields = StringUtil.removeLast(sb.toString(), StringPool.COMMA_AND_SPACE);
		VILCommonUtil.addFieldsAudit(categoryId, themeDisplay.getUserId(), "Category Tax", "", "", updatedFields);

	}

	@Reference
	private Portal portal;

	private static final Log _log = LogFactoryUtil.getLog(VilAssetTaxationWebPortlet.class.getName());
}