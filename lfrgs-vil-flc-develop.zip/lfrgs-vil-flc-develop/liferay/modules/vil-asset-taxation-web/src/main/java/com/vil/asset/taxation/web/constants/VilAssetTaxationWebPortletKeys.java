package com.vil.asset.taxation.web.constants;

/**
 * @author vaibhav
 */
public class VilAssetTaxationWebPortletKeys {

	public static final String VILASSETTAXATIONWEB =
		"vil_asset_taxation_web_VilAssetTaxationWebPortlet";

}