package com.vil.admin.report.web.Util;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.commerce.discount.model.CommerceDiscount;
import com.liferay.commerce.discount.service.CommerceDiscountLocalServiceUtil;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.common.util.VilRoleUtil;
import com.vil.partner.model.PartnerAddresses;
import com.vil.partner.model.PartnerBankDetails;
import com.vil.partner.model.PartnerCategories;
import com.vil.partner.model.PartnerDetails;
import com.vil.partner.model.PartnerLeads;
import com.vil.partner.model.PartnerMaster;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerAddressesLocalServiceUtil;
import com.vil.partner.service.PartnerBankDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerCategoriesLocalServiceUtil;
import com.vil.partner.service.PartnerDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerLeadsLocalServiceUtil;
import com.vil.partner.service.PartnerMasterLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PartnerSpecificReportGenerator {
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		PartnerSpecificReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		PartnerSpecificReportGenerator.endDate = endDate;
	}
	
	public static Workbook getPartnerExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		XSSFWorkbook workbook = new XSSFWorkbook();

		try {

			Sheet sheet = workbook.createSheet("partner Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			Font defaultFont = workbook.createFont();
			defaultCellStyle.setFont(defaultFont);
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);

			Row headRow = sheet.createRow(0);

			List<String> partnerColumns = getPartnerSpecificColumns();
			
			for (int header = 0; header < partnerColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(partnerColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}
			Date startDate = null;
			Date endDate = null;
			DynamicQuery partnerQuery = PartnerMasterLocalServiceUtil.dynamicQuery();
			List<PartnerMaster> partners = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			partnerQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			partners = PartnerMasterLocalServiceUtil.dynamicQuery(partnerQuery);
			int index = 1;
			for (PartnerMaster partner : partners) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				PartnerLeads partnerLead = PartnerLeadsLocalServiceUtil.getPartnerLeads(partner.getPartnerLeadId());
				Cell cell = row.createCell(colIndex);
				cell.setCellValue(partner.getCompanyLegalName());  // Company/ legal Entity Name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(partner.getOfficialEmailId());  // Official Email ID
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(partner.getMobileNo());  // Mobile Number
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(partner.getPartnerName());  // Partner Name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				String categories = getPartnerCategory(partner.getId());
				cell = row.createCell(colIndex);
				cell.setCellValue(categories);  // Category offerings
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				PartnerAddresses registeredAddress = PartnerAddressesLocalServiceUtil.findByAT_PID("registered", partner.getId());
				String registeredAds = "";
				if(registeredAddress!=null) {
					registeredAds = registeredAddress.getAddress1() + " " + 
							registeredAddress.getAddress2() + " " +
							registeredAddress.getCity() + " " +
							registeredAddress.getPin() + "  " +
							registeredAddress.getState() ;
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(registeredAds);   // Registered Office Address
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				PartnerAddresses businessAddress = PartnerAddressesLocalServiceUtil.findByAT_PID("registered", partner.getId());
				String businessAds = "";
				if(businessAddress != null) {
					 businessAds = businessAddress.getAddress1() + " " + 
						businessAddress.getAddress2() + " " +
						businessAddress.getCity() + " " +
						businessAddress.getPin() + "  " +
						businessAddress.getState() ;
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(businessAds);  // Business/ Head office address 
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				List<PartnerUsers> partnerUsers =  PartnerUsersLocalServiceUtil.findByPartnerId(partner.getId());
				
				long partnerKamRoleId = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),VilRoleUtil.VIL_PARTNER_ROLES.ROLE_PARTNER_KAM.name).getRoleId();
				PartnerUsers partnerKamuser = null;
				for(PartnerUsers partnerUser : partnerUsers) {
					if(partnerUser.getPartnerRoleType() == 0 || partnerUser.getPartnerRoleType() == partnerKamRoleId) {
						partnerKamuser = partnerUser;
					}
				}
				String kamFullName = "";
				String designation = "";
				String department = "";
				String mobileNumber = "";
				String alterMobile = "";
				String email = "";
				String alterEmail = "";
				if(Validator.isNotNull(partnerKamuser)) {
					kamFullName = partnerKamuser.getFullName();
					designation = partnerKamuser.getDesignation();
					department = partnerKamuser.getDepartment();
					mobileNumber = partnerKamuser.getMobile();
					alterMobile = partnerKamuser.getAlternateMobile();
					email = partnerKamuser.getEmailId();
					alterEmail = partnerKamuser.getAlternateEmailId();
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(kamFullName);   // Full Name of the partner KAM
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(designation);   // Designation
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				
				cell = row.createCell(colIndex);
				cell.setCellValue(department);   //Department
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(mobileNumber);   // Mobile Number
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(alterMobile);  // Alternate Mobile Number
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(email); // Email ID
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(alterEmail);  // Alternate Email Id
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				String companyType = "";
				String sapId = "";
				String panId = "";
				String tanId = "";
				String gstin = "";
				Date dateOfIncorporation = null;
				
				try {
					PartnerDetails partnerDetails = PartnerDetailsLocalServiceUtil.findByPartnerId(partner.getId());
					sapId = partnerDetails.getSapId();
					companyType = partnerDetails.getCompanyType();
					panId = partnerDetails.getPan();
					tanId = partnerDetails.getTan();
					gstin = partnerDetails.getGstin();
					dateOfIncorporation  = partnerDetails.getDateOfIncorporation();
				} catch(Exception e) {
					
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(companyType);  // Type of Company
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(sapId);   // SAP ID
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(panId);  // PAN
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(tanId);  // TAN
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(gstin); // GSTIN
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(dateOfIncorporation);  // Date of incorporation
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				String accountNumber = "";
				String accountName = "";
				String bank = "";
				String ifsc = "";
				String branch = "";
				try {
					PartnerBankDetails partnerbankDetails = PartnerBankDetailsLocalServiceUtil.findByPartnerId(partner.getId());
					accountName = partnerbankDetails.getAccountName();
					branch = partnerbankDetails.getBranch();
					ifsc = partnerbankDetails.getIfsc();
					bank = partnerbankDetails.getBank();
					accountNumber =partnerbankDetails.getAccountNumber();
				} catch(Exception e) {
					log.error("bank details not exists");
				}
				
				cell = row.createCell(colIndex);
				cell.setCellValue(accountName);  // Account Name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(accountNumber);  //  Account Number
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(bank);   // Bank
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(ifsc);   // IFSC code
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(branch);   // Branch
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(WorkflowConstants.getStatusLabel(partner.getStatus()));  // Current Partner Status
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// TODO: need to add column value
				cell = row.createCell(colIndex);
				cell.setCellValue("Onboarding Date");  // Onboarding Date
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(partner.getTier());   // Current Partner Tier
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				// TODO: need to add column value
				cell = row.createCell(colIndex);
				cell.setCellValue("Partner Commission"); 
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				// TODO: need to add column value
				cell = row.createCell(colIndex);
				cell.setCellValue("Partner commission start date"); 
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				// TODO: need to add column value
				cell = row.createCell(colIndex);
				cell.setCellValue("Partner commission end date"); 
				cell.setCellStyle(defaultCellStyle);				
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return workbook;
	}
	
	public static byte[] getPartnerCSVReportData(ResourceRequest resourceRequest) {

		byte[] outArray = null;

		try {
			StringBuffer data = new StringBuffer();
			List<String> partnerColumns = getPartnerSpecificColumns();
			ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

			String startingDate = getStartDate();
			String endingDate = getEndDate();
			for (int header = 0; header < partnerColumns.size(); header++) {
				data.append(partnerColumns.get(header));
				data.append(",");
			}
			data.append('\n');
			Date startDate = null;
			Date endDate = null;
			DynamicQuery partnerQuery = PartnerMasterLocalServiceUtil.dynamicQuery();
			List<PartnerMaster> partners = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			partnerQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			partners = PartnerMasterLocalServiceUtil.dynamicQuery(partnerQuery);
			int index = 1;
			for (PartnerMaster partner : partners) {
				

				PartnerLeads partnerLead = PartnerLeadsLocalServiceUtil.getPartnerLeads(partner.getPartnerLeadId());
				data.append(partner.getCompanyLegalName());  // Company/ legal Entity Name
				data.append(",");

				data.append(partner.getOfficialEmailId());  // Official Email ID
				data.append(",");

				data.append(String.valueOf(partner.getMobileNo()));  // Mobile Number
				data.append(",");

				data.append(partner.getPartnerName());  // Partner Name
				data.append(",");
				
				String categories = getPartnerCategory(partner.getId());
				data.append(categories);  // Category offerings
				data.append(",");

				PartnerAddresses registeredAddress = PartnerAddressesLocalServiceUtil.findByAT_PID("registered", partner.getId());
				String registeredAds = "";

				if(registeredAddress!=null) {
					registeredAds = registeredAddress.getAddress1() + " " + 
							registeredAddress.getAddress2() + " " +
							registeredAddress.getCity() + " " +
							registeredAddress.getPin() + "  " +
							registeredAddress.getState() ;
				}
				data.append(registeredAds);   // Registered Office Address
				data.append(",");
				PartnerAddresses businessAddress = PartnerAddressesLocalServiceUtil.findByAT_PID("registered", partner.getId());
				String businessAds = "";
				if(businessAddress != null) {
					 businessAds = businessAddress.getAddress1() + " " + 
						businessAddress.getAddress2() + " " +
						businessAddress.getCity() + " " +
						businessAddress.getPin() + "  " +
						businessAddress.getState() ;
				}
				
				data.append(businessAds);  // Business/ Head office address 
				data.append(",");

				List<PartnerUsers> partnerUsers =  PartnerUsersLocalServiceUtil.findByPartnerId(partner.getId());
				
				long partnerKamRoleId = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),VilRoleUtil.VIL_PARTNER_ROLES.ROLE_PARTNER_KAM.name).getRoleId();
				PartnerUsers partnerKamuser = null;
				for(PartnerUsers partnerUser : partnerUsers) {
					if(partnerUser.getPartnerRoleType() == 0 || partnerUser.getPartnerRoleType() == partnerKamRoleId) {
						partnerKamuser = partnerUser;
					}
				}
				String kamFullName = "";
				String designation = "";
				String department = "";
				String mobileNumber = "";
				String alterMobile = "";
				String email = "";
				String alterEmail = "";
				if(Validator.isNotNull(partnerKamuser)) {
					kamFullName = partnerKamuser.getFullName();
					designation = partnerKamuser.getDesignation();
					department = partnerKamuser.getDepartment();
					mobileNumber = partnerKamuser.getMobile();
					alterMobile = partnerKamuser.getAlternateMobile();
					email = partnerKamuser.getEmailId();
					alterEmail = partnerKamuser.getAlternateEmailId();
				}
				data.append(kamFullName);   // Full Name of the partner KAM
				data.append(",");
				
				data.append(designation);   // Designation
				data.append(",");
				
				data.append(department);   //Department
				data.append(",");
				
				data.append(mobileNumber);   // Mobile Number
				data.append(",");
				
				data.append(alterMobile);  // Alternate Mobile Number
				data.append(",");
				
				data.append(email); // Email ID
				data.append(",");
				
				data.append(alterEmail);  // Alternate Email Id
				data.append(",");
				
				String companyType = "";
				String sapId = "";
				String panId = "";
				String tanId = "";
				String gstin = "";
				Date dateOfIncorporation = null;
				
				try {
					PartnerDetails partnerDetails = PartnerDetailsLocalServiceUtil.findByPartnerId(partner.getId());
					if(partnerDetails != null ) {
						sapId = partnerDetails.getSapId();
						companyType = partnerDetails.getCompanyType();
						panId = partnerDetails.getPan();
						tanId = partnerDetails.getTan();
						gstin = partnerDetails.getGstin();
						dateOfIncorporation  = partnerDetails.getDateOfIncorporation();
					}
					
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(companyType);  // Type of Company
				data.append(",");
				
				data.append(sapId);   // SAP ID
				data.append(",");
				
				data.append(panId);  // PAN
				data.append(",");
				
				data.append(tanId);  // TAN
				data.append(",");
				
				data.append(gstin); // GSTIN
				data.append(",");
				
				data.append(dateOfIncorporation);  // Date of incorporation
				data.append(",");
				
				String accountNumber = "";
				String accountName = "";
				String bank = "";
				String ifsc = "";
				String branch = "";
				try {
					PartnerBankDetails partnerbankDetails = PartnerBankDetailsLocalServiceUtil.findByPartnerId(partner.getId());
					accountName = partnerbankDetails.getAccountName();
					branch = partnerbankDetails.getBranch();
					ifsc = partnerbankDetails.getIfsc();
					bank = partnerbankDetails.getBank();
					accountNumber =partnerbankDetails.getAccountNumber();
				} catch(Exception e) {
					log.error("bank details not exists");
				}
				
				data.append(accountName);  // Account Name
				data.append(",");
				
				data.append(accountNumber);  //  Account Number
				data.append(",");
				
				data.append(bank);   // Bank
				data.append(",");
				
				data.append(ifsc);   // IFSC code
				data.append(",");
				
				data.append(branch);   // Branch
				data.append(",");
				
				data.append(WorkflowConstants.getStatusLabel(partner.getStatus()));  // Current Partner Status
				data.append(",");

				data.append("Onboarding Date");  // Onboarding Date
				data.append(",");
				
				data.append(partner.getTier());   // Current Partner Tier
				data.append(",");
				
				data.append("Partner Commission"); 
				data.append(",");
				
				
				data.append("Partner commission start date"); 
				data.append(",");
				
				data.append("Partner commission end date"); 
				
				data.append('\n');
			}
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] generatePartnerPdf(ResourceRequest resourceRequest,String htmlContent) {
		String value = htmlContent;
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String body = replaceValue(value,themeDisplay);


		FileOutputStream fileOutputStream = null;
		try {
			String fileName = ""+new Date().getTime();
			File certificateFile = File.createTempFile(fileName, ".pdf");
			ConverterProperties properties = new ConverterProperties();
			fileOutputStream = new FileOutputStream(certificateFile);
			PdfDocument pdfDocument = new PdfDocument(new PdfWriter(certificateFile));
			pdfDocument.setDefaultPageSize(new PageSize(3370,2384));
			HtmlConverter.convertToPdf(body, pdfDocument, properties);
			FileInputStream fl = new FileInputStream(certificateFile);
	        byte[] arr = new byte[(int)certificateFile.length()];
	        fl.read(arr);
	        return arr;
		} catch (Exception e) {
			log.error(e);
			log.error("Exception during coupo pdf" + e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					log.error("Exception during coupon pdf" + e);
					return null;
				}
			}
		}
	}
	
	private static String replaceValue(String body,ThemeDisplay themeDisplay) {
		try {
				String htmlTable="";
				String startingDate = getStartDate();
				String endingDate = getEndDate();
				Date startDate = null;
				Date endDate = null;
				DynamicQuery partnerQuery = PartnerMasterLocalServiceUtil.dynamicQuery();
				List<PartnerMaster> partners = null;
				if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
					LocalDateTime localEndDate = LocalDateTime.now();
					LocalDateTime localStartDate = localEndDate.minusHours(24);
					Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
					endDate = Date.from(instant);
					instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
					startDate = Date.from(instant);
				} else {
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
					Date startDateTemp = dateFormatter.parse(startingDate);
					startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

					Date endDateTemp = dateFormatter.parse(endingDate);
					endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
				}
				
				partnerQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
				partners = PartnerMasterLocalServiceUtil.dynamicQuery(partnerQuery);
				int index = 1;
				
				
				List<String> partnerColumns = getPartnerSpecificColumns();
				htmlTable += "<table class=\"pdf-table\"><tr class=\"bg-clr1\">";
				for (int header = 0; header < partnerColumns.size(); header++) {
					htmlTable +=
							"<td><strong>"+partnerColumns.get(header)+"</strong></td>";
				}
				htmlTable += " </tr>";
				for (PartnerMaster partner : partners) {
					
					
					
					PartnerLeads partnerLead = PartnerLeadsLocalServiceUtil.getPartnerLeads(partner.getPartnerLeadId());
					// Company/ legal Entity Name
					htmlTable += " <td>"
							+ partner.getCompanyLegalName() + "</td>";

					// Official Email ID
					htmlTable += " <td>"
							+ partner.getOfficialEmailId() + "</td>";

					// Mobile Number
					htmlTable += " <td>"
							+ partner.getMobileNo() + "</td>";

					// Partner Name
					htmlTable += " <td>"
							+ partner.getPartnerName() + "</td>";
					
					String categories = getPartnerCategory(partner.getId());
					// Category offerings
					htmlTable += " <td>"
							+ categories + "</td>";

					PartnerAddresses registeredAddress = PartnerAddressesLocalServiceUtil.findByAT_PID("registered", partner.getId());
					String registeredAds = "";

					if(registeredAddress!=null) {
						registeredAds = registeredAddress.getAddress1() + " " + 
								registeredAddress.getAddress2() + " " +
								registeredAddress.getCity() + " " +
								registeredAddress.getPin() + "  " +
								registeredAddress.getState() ;
					}
					
					// Registered Office Address
					htmlTable += " <td>"
							+ registeredAds + "</td>";
					
					
					PartnerAddresses businessAddress = PartnerAddressesLocalServiceUtil.findByAT_PID("registered", partner.getId());
					String businessAds = "";
					if(businessAddress != null) {
						 businessAds = businessAddress.getAddress1() + " " + 
							businessAddress.getAddress2() + " " +
							businessAddress.getCity() + " " +
							businessAddress.getPin() + "  " +
							businessAddress.getState() ;
					}
					
					// Business/ Head office address 
					htmlTable +=" <td>"
							+ businessAds + "</td>";

					List<PartnerUsers> partnerUsers =  PartnerUsersLocalServiceUtil.findByPartnerId(partner.getId());
					
					long partnerKamRoleId = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),VilRoleUtil.VIL_PARTNER_ROLES.ROLE_PARTNER_KAM.name).getRoleId();
					PartnerUsers partnerKamuser = null;
					for(PartnerUsers partnerUser : partnerUsers) {
						if(partnerUser.getPartnerRoleType() == 0 || partnerUser.getPartnerRoleType() == partnerKamRoleId) {
							partnerKamuser = partnerUser;
						}
					}
					String kamFullName = "";
					String designation = "";
					String department = "";
					String mobileNumber = "";
					String alterMobile = "";
					String email = "";
					String alterEmail = "";
					if(Validator.isNotNull(partnerKamuser)) {
						kamFullName = partnerKamuser.getFullName();
						designation = partnerKamuser.getDesignation();
						department = partnerKamuser.getDepartment();
						mobileNumber = partnerKamuser.getMobile().toString();
						alterMobile = partnerKamuser.getAlternateMobile().toString();
						email = partnerKamuser.getEmailId();
						alterEmail = partnerKamuser.getAlternateEmailId();
					}
					// Full Name of the partner KAM
					htmlTable += " <td>"
							+ kamFullName + "</td>";
					
					// Designation
					htmlTable += " <td>"
							+ designation + "</td>";
					
					//Department
					htmlTable += " <td>"
							+ department + "</td>";
					
					// Mobile Number
					htmlTable += " <td>"
							+ mobileNumber + "</td>";
					
					// Alternate Mobile Number
					htmlTable += " <td>"
							+ alterMobile + "</td>";
					
					// Email ID
					htmlTable += " <td>"
							+ email + "</td>";
					
					// Alternate Email Id
					htmlTable += " <td>"
							+ alterEmail + "</td>";
					
					String companyType = "";
					String sapId = "";
					String panId = "";
					String tanId = "";
					String gstin = "";
					Date dateOfIncorporation = null;
					
					try {
						PartnerDetails partnerDetails = PartnerDetailsLocalServiceUtil.findByPartnerId(partner.getId());
						if(partnerDetails != null ) {
							sapId = partnerDetails.getSapId();
							companyType = partnerDetails.getCompanyType();
							panId = partnerDetails.getPan();
							tanId = partnerDetails.getTan();
							gstin = partnerDetails.getGstin();
							dateOfIncorporation  = partnerDetails.getDateOfIncorporation();
						}
						
					} catch(Exception e) {
						log.error(e.getMessage());
					}
					// Type of Company
					htmlTable += " <td>"
							+ companyType + "</td>";
					
					// SAP ID
					htmlTable += " <td>"
							+ sapId + "</td>";
					
					// PAN
					htmlTable += " <td>"
							+ panId + "</td>";
					
					// TAN
					htmlTable += " <td>"
							+ tanId + "</td>";
					
					// GSTIN
					htmlTable += " <td>"
							+ gstin + "</td>";
					
					// Date of incorporation
					htmlTable += " <td>"
							+ dateOfIncorporation + "</td>";
					
					String accountNumber = "";
					String accountName = "";
					String bank = "";
					String ifsc = "";
					String branch = "";
					try {
						PartnerBankDetails partnerbankDetails = PartnerBankDetailsLocalServiceUtil.findByPartnerId(partner.getId());
						accountName = partnerbankDetails.getAccountName();
						branch = partnerbankDetails.getBranch();
						ifsc = partnerbankDetails.getIfsc();
						bank = partnerbankDetails.getBank();
						accountNumber =partnerbankDetails.getAccountNumber();
					} catch(Exception e) {
						log.error("bank details not exists");
					}
					
					// Account Name
					htmlTable += " <td>"
							+ accountName + "</td>";
					
					//  Account Number
					htmlTable += " <td>"
							+ accountNumber + "</td>";
					
					// Bank
					htmlTable += " <td>"
							+ bank + "</td>";
					
					// IFSC code
					htmlTable += " <td>"
							+ ifsc + "</td>";
					
					// Branch
					htmlTable += " <td>"
							+ branch + "</td>";
					
					// Current Partner Status
					htmlTable += " <td>"
							+ WorkflowConstants.getStatusLabel(partner.getStatus()) + "</td>";

					// Onboarding Date
					htmlTable += " <td>"
							+ "Onboarding Date" + "</td>";;
					
				
					// Current Partner Tier
					htmlTable += " <td>"
							+ partner.getTier() + "</td>";;
					
					htmlTable += " <td>"
							+ "Partner Commissio" + "</td>";
					
					
					htmlTable += " <td>"
							+ "Partner commission start date" + "</td>";
					
					htmlTable += " <td>"
							+ "Partner commission end date" + "</td>";
					

					
					htmlTable += " </tr>";
				}
				htmlTable += " </table>";
				body = body.replace("[$ITEMDETAILS$]", htmlTable);
				Date today = new Date();
				body = body.replace("[$DATE$]", today.toString());
				body = body.replace("[$REPORTTYPE$]", "Partner Specific Report");

		} catch (

		Exception e) {
			log.error("Exception during invoice generation" + e);
		}
		return body;
	}
	
	public static String getPartnerCategory(Long partnerId) {
		try {
			List<PartnerCategories> categories = PartnerCategoriesLocalServiceUtil.findByPartnerMasterId(partnerId);
			StringBuilder categoriesStr = new StringBuilder();
			int counter=0;
			for(PartnerCategories category : categories) {
				AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(category.getCategoryId());

				if(counter!=0) {
					categoriesStr.append("/ ");
				}
				counter++;
				categoriesStr.append(assetCategory.getName());
			}
			return categoriesStr.toString();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return "";
	}
	
	public static List<String> getPartnerSpecificColumns() {
		List<String> partnerColumns = new ArrayList<>();

		partnerColumns.add("Company/ legal Entity Name");
		partnerColumns.add("Official Email ID");
		partnerColumns.add("Mobile Number");
		partnerColumns.add("Partner Name");
		partnerColumns.add("Category offerings");
		partnerColumns.add("Registered Office Address");
		partnerColumns.add("Business/ Head office address ");
		partnerColumns.add("Full Name of the partner KAM");
		partnerColumns.add("Designation");
		partnerColumns.add("Department");
		partnerColumns.add("Mobile Number");
		partnerColumns.add("Alternate Mobile Number");
		partnerColumns.add("Email ID");
		partnerColumns.add("Alternate Email Id");
		partnerColumns.add("Type of Company");
		partnerColumns.add("SAP ID");
		partnerColumns.add("PAN");
		partnerColumns.add("TAN");
		partnerColumns.add("GSTIN");
		partnerColumns.add("Date of incorporation");
		partnerColumns.add("Account Name");
		partnerColumns.add("Account Number");
		partnerColumns.add("Bank");
		partnerColumns.add("IFSC code");
		partnerColumns.add("Branch");
		partnerColumns.add("Current Partner Status");
		partnerColumns.add("Onboarding Date");
		partnerColumns.add("Current Partner Tier");
		partnerColumns.add("Partner Commission");
		partnerColumns.add("Partner commission start date");
		partnerColumns.add("Partner commission end date");
		
		return partnerColumns;
	}
	
	private static final Log log = LogFactoryUtil.getLog(PartnerSpecificReportGenerator.class);

}
