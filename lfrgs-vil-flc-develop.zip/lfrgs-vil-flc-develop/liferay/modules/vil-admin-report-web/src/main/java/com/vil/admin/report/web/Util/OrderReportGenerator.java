package com.vil.admin.report.web.Util;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Table;
import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.constants.CommerceOrderConstants;
import com.liferay.commerce.discount.model.CommerceDiscount;
import com.liferay.commerce.discount.service.CommerceDiscountLocalServiceUtil;
import com.liferay.commerce.model.CommerceAddress;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.model.CommerceOrderItem;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderItemLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderPaymentLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.cart.model.VilOrderDetails;
import com.vil.cart.service.VilOrderDetailsLocalServiceUtil;
import com.vil.common.util.GrievanceConstants;
import com.vil.common.util.VilRoleUtil;
import com.vil.customer.model.Customer;
import com.vil.customer.service.CustomerLocalServiceUtil;
import com.vil.grievance.management.model.GrievanceComments;
import com.vil.grievance.management.model.GrievanceMaster;
import com.vil.grievance.management.model.GrievanceTypeMaster;
import com.vil.grievance.management.service.GrievanceCommentsLocalServiceUtil;
import com.vil.grievance.management.service.GrievanceMasterLocalServiceUtil;
import com.vil.grievance.management.service.GrievanceTypeMasterLocalServiceUtil;
import com.vil.partner.model.PartnerAddresses;
import com.vil.partner.model.PartnerBankDetails;
import com.vil.partner.model.PartnerDetails;
import com.vil.partner.model.PartnerLeads;
import com.vil.partner.model.PartnerMaster;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerAddressesLocalServiceUtil;
import com.vil.partner.service.PartnerBankDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerLeadsLocalServiceUtil;
import com.vil.partner.service.PartnerMasterLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.inject.New;
import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class OrderReportGenerator {
	
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		OrderReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		OrderReportGenerator.endDate = endDate;
	}
	
	
	public static byte[] getOrderExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		try {

			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet sheet = workbook.createSheet("Order Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			Font defaultFont = workbook.createFont();
			defaultCellStyle.setFont(defaultFont);
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);
			

			Row headRow = sheet.createRow(0);

			List<String> orderColumns = getOrderColumns();
			
			String startingDate = getStartDate();
			String endingDate = getEndDate();
			

			for (int header = 0; header < orderColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(orderColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}

			Date startDate = null;
			Date endDate = null;
			DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
			List<CommerceOrder> commerceOrders = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			orderQuery.add(RestrictionsFactoryUtil.between("orderDate",startDate, endDate));
			orderQuery.add(RestrictionsFactoryUtil.ne("orderStatus", CommerceOrderConstants.ORDER_STATUS_OPEN));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					orderQuery.add(userRestriction);
					commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
					commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());

				} 
			} else {
				commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
				commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());
			}
			int index = 1;
			for (CommerceOrder commerceOrder : commerceOrders) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				try {
					// Customer customer = CustomerLocalServiceUtil.findByCustomerID(String.valueOf(commerceOrder.getCommerceAccount().getCommerceAccountId()));
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				double cgst = 0;
				double sgst = 0;
				double igst = 0;
				String mobileNumber = "";
				List<VilOrderDetails> vilOrderDetails =  VilOrderDetailsLocalServiceUtil.findByCommerceOrderId(commerceOrder.getCommerceOrderId());
				// need to check
				Date fullFillmentDate = null;
				int fullFillmentStatus = 0;
				String orderfullFillmentStatus = "NaN";
				if(vilOrderDetails.isEmpty()) {
					for(VilOrderDetails orderDetails : vilOrderDetails) {
						fullFillmentDate = orderDetails.getFulfilmentDate();
						orderfullFillmentStatus = orderDetails.getStatus();
						mobileNumber = orderDetails.getMobileNo();
						if(orderDetails.getCgstAmount()!=null) {
							cgst += orderDetails.getCgstAmount();
						}
						if(orderDetails.getSgstAmount()!=null) {
							igst += orderDetails.getSgstAmount();
						}
						if(orderDetails.getIgstAmount()!=null) {
							sgst += orderDetails.getIgstAmount();
						}
					}
				}
				
				// orderId
				Cell cell = row.createCell(colIndex);
				cell.setCellValue(commerceOrder.getCommerceOrderId());
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(commerceOrder.getOrderDate());
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(CommerceOrderConstants.getOrderStatusLabel(commerceOrder.getOrderStatus()));
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue(orderfullFillmentStatus);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue(fullFillmentDate);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				User user = UserLocalServiceUtil.getUser(commerceOrder.getUserId());
				cell = row.createCell(colIndex);
				cell.setCellValue(user.getFirstName() + " " + user.getLastName()); // customer name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(mobileNumber); // customer mobile number
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(user.getEmailAddress()); // Customer Email Address
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(String.valueOf(commerceOrder.getSubtotal())); // Order Subtotal
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				String discountAmount = "0";
				if(commerceOrder.getTotalDiscountAmount().compareTo(new BigDecimal(0)) != 0) {
					discountAmount = commerceOrder.getTotalDiscountAmount().toString();
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(discountAmount); // discount
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				
				cell = row.createCell(colIndex);
				cell.setCellValue(cgst);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(igst);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(sgst);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				String totalTaxes = "0";
				if(commerceOrder.getTaxAmount().compareTo(new BigDecimal(0)) != 0) {
					totalTaxes = commerceOrder.getTaxAmount().toString();
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(totalTaxes); // Total Taxes
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				String shippingAmount = "0";
				if(commerceOrder.getShippingAmount().compareTo(new BigDecimal(0)) != 0) {
					shippingAmount = commerceOrder.getShippingAmount().toString();
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(shippingAmount); // Order shipping charge
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(commerceOrder.getTotal().toString()); // order total
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(getAddress(commerceOrder.getBillingAddress())); // Billing Address
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Customer GSTIN Number");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Business Name");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Business Address");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment (Transaction) Status");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment Date");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment Time");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment Channel");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment Gateway");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Gateway Transaction Id");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment Mode");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment Method Type");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Card Issuer");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Payment Method");
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				// need to check
				cell = row.createCell(colIndex);
				cell.setCellValue("Card Type");
				cell.setCellStyle(defaultCellStyle);
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;

	}
	
	public static byte[] getOrderCSVReportData(ResourceRequest resourceRequest) {
		byte[] outArray = null;
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		try {
			StringBuffer data = new StringBuffer();
			List<String> orderColumns = getOrderColumns();
			
			String startingDate = getStartDate();
			String endingDate = getEndDate();
			

			for (int header = 0; header < orderColumns.size(); header++) {
				data.append(orderColumns.get(header));
				data.append(",");
			}
			
			data.append('\n');

			Date startDate = null;
			Date endDate = null;
			DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
			List<CommerceOrder> commerceOrders = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			orderQuery.add(RestrictionsFactoryUtil.between("orderDate",startDate, endDate));
			orderQuery.add(RestrictionsFactoryUtil.ne("orderStatus", CommerceOrderConstants.ORDER_STATUS_OPEN));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					orderQuery.add(userRestriction);
					commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
					commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());

				} 
			} else {
				commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
				commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());
			}
			for (CommerceOrder commerceOrder : commerceOrders) {
				
				double cgst = 0;
				double sgst = 0;
				double igst = 0;
				String mobileNumber = "";
				List<VilOrderDetails> vilOrderDetails =  VilOrderDetailsLocalServiceUtil.findByCommerceOrderId(commerceOrder.getCommerceOrderId());
				// need to check
				Date fullFillmentDate = null;
				String orderfullFillmentStatus = "NaN";
				if(vilOrderDetails.isEmpty()) {
					for(VilOrderDetails orderDetails : vilOrderDetails) {
						fullFillmentDate = orderDetails.getFulfilmentDate();
						orderfullFillmentStatus = orderDetails.getStatus();
						mobileNumber = orderDetails.getMobileNo();
						if(orderDetails.getCgstAmount()!=null) {
							cgst += orderDetails.getCgstAmount();
						}
						if(orderDetails.getSgstAmount()!=null) {
							igst += orderDetails.getSgstAmount();
						}
						if(orderDetails.getIgstAmount()!=null) {
							sgst += orderDetails.getIgstAmount();
						}
					}
				}
				
				// orderId
				data.append(commerceOrder.getCommerceOrderId());
				data.append(",");

				data.append(commerceOrder.getOrderDate());
				data.append(",");
				
				data.append(CommerceOrderConstants.getOrderStatusLabel(commerceOrder.getOrderStatus()));
				data.append(",");

				data.append(orderfullFillmentStatus);
				data.append(",");

				data.append(fullFillmentDate);
				data.append(",");

				User user = UserLocalServiceUtil.getUser(commerceOrder.getUserId());
				data.append(user.getFirstName() + " " + user.getLastName()); // customer name
				data.append(",");
				
				data.append(mobileNumber); // customer mobile number
				data.append(",");
				
				data.append(user.getEmailAddress()); // Customer Email Address
				data.append(",");
				
				data.append(String.valueOf(commerceOrder.getSubtotal())); // Order Subtotal
				data.append(",");

				String discountAmount = "0";
				if(commerceOrder.getTotalDiscountAmount().compareTo(new BigDecimal(0)) != 0) {
					discountAmount = commerceOrder.getTotalDiscountAmount().toString();
				}
				data.append(discountAmount); // discount
				data.append(",");

				data.append(cgst);
				data.append(",");

				data.append(igst);
				data.append(",");

				data.append(sgst);
				data.append(",");

				String totalTaxes = "0";
				if(commerceOrder.getTaxAmount().compareTo(new BigDecimal(0)) != 0) {
					totalTaxes = commerceOrder.getTaxAmount().toString();
				}
				data.append(totalTaxes); // Total Taxes
				data.append(",");

				String shippingAmount = "0";
				if(commerceOrder.getShippingAmount().compareTo(new BigDecimal(0)) != 0) {
					shippingAmount = commerceOrder.getShippingAmount().toString();
				}
				data.append(shippingAmount); // Order shipping charge
				data.append(",");

				data.append(commerceOrder.getTotal().toString()); // order total
				data.append(",");

				data.append(getAddress(commerceOrder.getBillingAddress())); // Billing Address
				data.append(",");

				// need to check
				data.append("Customer GSTIN Number");
				data.append(",");

				// need to check
				data.append("Business Name");
				data.append(",");

				// need to check
				data.append("Business Address");
				data.append(",");
				
				// need to check
				data.append("Payment (Transaction) Status");
				data.append(",");

				// need to check
				data.append("Payment Date");
				data.append(",");

				// need to check
				data.append("Payment Time");
				data.append(",");

				// need to check
				data.append("Payment Channel");
				data.append(",");

				// need to check
				data.append("Payment Gateway");
				data.append(",");

				// need to check
				data.append("Gateway Transaction Id");
				data.append(",");

				// need to check
				data.append("Payment Mode");
				data.append(",");

				// need to check
				data.append("Payment Method Type");
				data.append(",");

				// need to check
				data.append("Card Issuer");
				data.append(",");
				
				// need to check
				data.append("Payment Method");
				data.append(",");

				// need to check
				data.append("Card Type");
				data.append(",");
				
				data.append('\n');
			}
			
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] getOrderPdfReportData(String htmlContent,ResourceRequest resourceRequest) {
		String value = htmlContent;
		String body = replaceValue(value,resourceRequest);

		FileOutputStream fileOutputStream = null;
		try {
			String fileName = ""+new Date().getTime();
			File certificateFile = File.createTempFile(fileName, ".pdf");
			ConverterProperties properties = new ConverterProperties();
			fileOutputStream = new FileOutputStream(certificateFile);
			PdfDocument pdfDocument = new PdfDocument(new PdfWriter(certificateFile));
			pdfDocument.setDefaultPageSize(new PageSize(3500,2384));
			HtmlConverter.convertToPdf(body, pdfDocument, properties);
			FileInputStream fl = new FileInputStream(certificateFile);
	        byte[] arr = new byte[(int)certificateFile.length()];
	        fl.read(arr);
	        return arr;
		} catch (Exception e) {
			log.error(e);
			log.error("Exception during coupo pdf" + e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					log.error("Exception during coupon pdf" + e);
					return null;
				}
			}
		}
	}
	
	
	private static String replaceValue(String body,ResourceRequest resourceRequest) {
		try {
				ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

				String htmlTable="";
				String startingDate = getStartDate();
				String endingDate = getEndDate();
				Date startDate = null;
				Date endDate = null;
				DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
				List<CommerceOrder> commerceOrders = null;
				if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
					LocalDateTime localEndDate = LocalDateTime.now();
					LocalDateTime localStartDate = localEndDate.minusHours(24);
					Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
					endDate = Date.from(instant);
					instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
					startDate = Date.from(instant);
				} else {
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
					Date startDateTemp = dateFormatter.parse(startingDate);
					startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

					Date endDateTemp = dateFormatter.parse(endingDate);
					endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
				}
				
				orderQuery.add(RestrictionsFactoryUtil.between("orderDate",startDate, endDate));
				orderQuery.add(RestrictionsFactoryUtil.ne("orderStatus", CommerceOrderConstants.ORDER_STATUS_OPEN));

				if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
					PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
					DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
					userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
					List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
					
					if(!partnerUsers.isEmpty()) {
						Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
						for(int i=1;i<partnerUsers.size();i++) {
							userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
						}
						orderQuery.add(userRestriction);
						commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
						commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());

					} 
				} else {
					commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
					commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());
				}
				
				
				List<String> grievanceColumns = getOrderColumns();
				htmlTable += "<table class=\"pdf-table\"><tr class=\"bg-clr1\">";
				for (int header = 0; header < grievanceColumns.size(); header++) {
					htmlTable +=
							"<td><strong>"+grievanceColumns.get(header)+"</strong></td>";
				}
				htmlTable += " </tr>";
				for (CommerceOrder commerceOrder : commerceOrders) {
					
					double cgst = 0;
					double sgst = 0;
					double igst = 0;
					String mobileNumber = "";
					List<VilOrderDetails> vilOrderDetails =  VilOrderDetailsLocalServiceUtil.findByCommerceOrderId(commerceOrder.getCommerceOrderId());
					// need to check
					Date fullFillmentDate = null;
					String orderfullFillmentStatus = "";
					if(vilOrderDetails.isEmpty()) {
						for(VilOrderDetails orderDetails : vilOrderDetails) {
							fullFillmentDate = orderDetails.getFulfilmentDate();
							orderfullFillmentStatus = orderDetails.getStatus();
							mobileNumber = orderDetails.getMobileNo();
							if(orderDetails.getCgstAmount()!=null) {
								cgst += orderDetails.getCgstAmount();
							}
							if(orderDetails.getSgstAmount()!=null) {
								igst += orderDetails.getSgstAmount();
							}
							if(orderDetails.getIgstAmount()!=null) {
								sgst += orderDetails.getIgstAmount();
							}
						}
					}

					User user = UserLocalServiceUtil.getUser(commerceOrder.getUserId());
					

					String discountAmount = "0";
					if(commerceOrder.getTotalDiscountAmount().compareTo(new BigDecimal(0)) != 0) {
						discountAmount = commerceOrder.getTotalDiscountAmount().toString();
					}
					

					String totalTaxes = "0";
					if(commerceOrder.getTaxAmount().compareTo(new BigDecimal(0)) != 0) {
						totalTaxes = commerceOrder.getTaxAmount().toString();
					}
					

					String shippingAmount = "0";
					if(commerceOrder.getShippingAmount().compareTo(new BigDecimal(0)) != 0) {
						shippingAmount = commerceOrder.getShippingAmount().toString();
					}
					
					
					htmlTable += "<tr>"
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ commerceOrder.getCommerceOrderId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ commerceOrder.getOrderDate()+ "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ CommerceOrderConstants.getOrderStatusLabel(commerceOrder.getOrderStatus())+ "</td>"

					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ orderfullFillmentStatus + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ fullFillmentDate + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ user.getFirstName() + " " + user.getLastName() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ mobileNumber + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ user.getEmailAddress() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ String.valueOf(commerceOrder.getSubtotal()) + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ discountAmount + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ cgst + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ igst + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ sgst + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ totalTaxes + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ shippingAmount + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ commerceOrder.getTotal().toString() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ getAddress(commerceOrder.getBillingAddress()) + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Customer GSTIN Number" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Business Name" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "BusinessAddress" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment (Transaction) Status" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment Date" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment Time" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment Channel" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment Gateway" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Gateway Transaction Id" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment Mode" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment Method Type" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "card Issue" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "Payment Method" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "card type" + "</td>";

					htmlTable += " </tr>";
				}
				htmlTable += " </table>";
				body = body.replace("[$ITEMDETAILS$]", htmlTable);
				Date today = new Date();
				body = body.replace("[$DATE$]", today.toString());
				body = body.replace("[$REPORTTYPE$]", "Coupon Report");
				if(startingDate!=null) {
					body = body.replace("[$DATERANGE$]", startingDate +" to "+endingDate);

				} else {
					body = body.replace("[$DATERANGE$]","last 24 hours record");

				}

		} catch (

		Exception e) {
			log.error("Exception during invoice generation" + e);
		}
		return body;
	}
	
	private static String getAddress(CommerceAddress address) {
		if (Validator.isNotNull(address)) {
			return address.getStreet1() + " " + address.getStreet2() + " " + address.getStreet3() + " "
					+ address.getCity();
		}
		return null;
	}
	
	public static List<String> getOrderColumns() {
		List<String> orderColumns = new ArrayList<>();
		orderColumns.add("Order ID");
		orderColumns.add("Order Confirmation Date");
		orderColumns.add("Order Status");
		orderColumns.add("Order Fulfilment Status ");
		orderColumns.add("Order Fulfilment Date");
		orderColumns.add("Customer Name");
		orderColumns.add("Customer Mobile Number");
		orderColumns.add("Customer Email Address");
		orderColumns.add("Order Subtotal");
		orderColumns.add("Discount");
		orderColumns.add("CGST");
		orderColumns.add("SGST");
		orderColumns.add("IGST");
		orderColumns.add("Total Taxes");
		orderColumns.add("Order shipping charge");
		orderColumns.add("Order Total");
		orderColumns.add("Billing Address");
		orderColumns.add("Customer GSTIN Number");
		orderColumns.add("Business Name");
		orderColumns.add("Business Address");
		orderColumns.add("Payment (Transaction) Status");
		orderColumns.add("Payment Date");
		orderColumns.add("Payment Time");
		orderColumns.add("Payment Channel");
		orderColumns.add("Payment Gateway");
		orderColumns.add("Gateway Transaction Id");
		orderColumns.add("Payment Mode");
		orderColumns.add("Payment Method Type");
		orderColumns.add("Card Issuer");
		orderColumns.add("Payment Method");
		orderColumns.add("Card Type");
		
		return orderColumns;
	}
	
	private static final Log log = LogFactoryUtil.getLog(OrderReportGenerator.class);
}
