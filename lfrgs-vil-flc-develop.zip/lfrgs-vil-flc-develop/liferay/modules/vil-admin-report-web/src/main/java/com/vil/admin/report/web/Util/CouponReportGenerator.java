package com.vil.admin.report.web.Util;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Table;
import com.liferay.commerce.discount.model.CommerceDiscount;
import com.liferay.commerce.discount.service.CommerceDiscountLocalServiceUtil;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.model.CommerceOrderItem;
import com.liferay.commerce.service.CommerceOrderItemLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.Validator;
import com.vil.common.util.NumberToWords;
import com.vil.common.util.VILCommonUtil;
import com.vil.partner.model.PartnerDetails;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CouponReportGenerator {
	
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		CouponReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		CouponReportGenerator.endDate = endDate;
	}
	
	public static Workbook getCouponExcelReportData() {
		
		String startingDate = getStartDate();
		String endingDate = getEndDate();
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		XSSFWorkbook workbook = new XSSFWorkbook();

		try {

			Sheet sheet = workbook.createSheet("Coupon Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			// headerFont.setBoldweight((short) 700);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);

			Row headRow = sheet.createRow(0);

			List<String> couponColumns = getCouponColumn();

			for (int header = 0; header < couponColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(couponColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}
			Date startDate = null;
			Date endDate = null;
			DynamicQuery discountQuery = CommerceDiscountLocalServiceUtil.dynamicQuery();
			List<CommerceDiscount> discounts = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			discountQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			discounts = CommerceDiscountLocalServiceUtil.dynamicQuery(discountQuery);
			try {
			discounts = discounts.stream().sorted((o1, o2)->o1.getDisplayDate().compareTo(o2.getDisplayDate())).collect(Collectors.toList());
			} catch(Exception e) {
				log.error(e.getMessage());
			}
			int index = 1;
			for (CommerceDiscount discount : discounts) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				
				Cell cell = row.createCell(colIndex);
				cell.setCellValue(discount.getTitle());
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				String promoType = "Fixed Amount";
				if(discount.getUsePercentage()) {
					promoType = "percentage";
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(promoType);
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(discount.getTarget());
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(discount.getLimitationTimes());
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
				orderQuery.add(RestrictionsFactoryUtil.eq("couponCode", discount.getCouponCode()));
				List<CommerceOrder> ordersOfCoupon = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
				
				long totalCouponToday = 0;
				BigDecimal totalDiscountToday = new BigDecimal(0);
				BigDecimal totalDiscountTillDate = new BigDecimal(0);
				
				Date today = new Date();
				
				for(CommerceOrder order : ordersOfCoupon) {
					if(order.getOrderDate().getDay() == today.getDay() &&
						order.getOrderDate().getMonth() == today.getMonth()-1 &&
						order.getOrderDate().getYear() + 1900 == today.getYear()) {
						totalCouponToday += 1;
						totalDiscountToday = totalDiscountToday.add(order.getTotalDiscountAmount());
					}
					totalDiscountTillDate = totalDiscountTillDate.add(order.getTotalDiscountAmount());

				}
				
				cell = row.createCell(colIndex);
				cell.setCellValue(String.valueOf(totalCouponToday));
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(totalDiscountToday.toString()); 
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(discount.getNumberOfUse()); 
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(totalDiscountTillDate.toString()); 
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				CellStyle dateCellStyle = workbook.createCellStyle();
				CreationHelper createHelper = workbook.getCreationHelper();
				dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy h:mm"));
				
				cell = row.createCell(colIndex);
				cell.setCellValue(discount.getLastPublishDate()); 
				cell.setCellStyle(dateCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(discount.getExpirationDate()); 
				cell.setCellStyle(dateCellStyle);
				
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return workbook;
	}
	
	public static byte[] getCouponCSVReportData() {

		byte[] outArray = null;

		Workbook workbook = getCouponExcelReportData();
		try {
			StringBuffer data = new StringBuffer();
			Sheet sheet = workbook.getSheetAt(0);
			 
            Iterator<Row> rowIterator = sheet.iterator();
 
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
 
                    Cell cell = cellIterator.next();
                    switch (cell.getCellType()) {
	                    case BOOLEAN:
	                        data.append(cell.getBooleanCellValue() + ",");
	                        break;
	                    case NUMERIC:
	                        data.append(cell.getNumericCellValue() + ",");
	                        break;
	                    case STRING:
	                        data.append(cell.getStringCellValue() + ",");
	                        break;
	                    case BLANK:
	                        data.append("" + ",");
	                        break;
	                    default:
	                        data.append(cell + ",");
                    }
                }
                data.append('\n');
            }
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] generateCouponPdf(String htmlContent) {
		
		String value = htmlContent;
		String body = replaceValue(value);

		FileOutputStream fileOutputStream = null;
		try {
			String fileName = ""+new Date().getTime();
			File certificateFile = File.createTempFile(fileName, ".pdf");
			ConverterProperties properties = new ConverterProperties();
			fileOutputStream = new FileOutputStream(certificateFile);
			PdfDocument pdfDocument = new PdfDocument(new PdfWriter(certificateFile));
			pdfDocument.setDefaultPageSize(PageSize.A2);
			//pdfDocument.
			HtmlConverter.convertToPdf(body, pdfDocument, properties);
			FileInputStream fl = new FileInputStream(certificateFile);
	        byte[] arr = new byte[(int)certificateFile.length()];
	        fl.read(arr);
	        return arr;
		} catch (Exception e) {
			log.error(e);
			log.error("Exception during coupo pdf" + e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					log.error("Exception during coupon pdf" + e);
					return null;
				}
			}
		}
	}
	
	private static String replaceValue(String body) {
		try {
				String htmlTable="";
				String startingDate = getStartDate();
				String endingDate = getEndDate();
				Date startDate = null;
				Date endDate = null;
				DynamicQuery discountQuery = CommerceDiscountLocalServiceUtil.dynamicQuery();
				List<CommerceDiscount> discounts = null;
				if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
					LocalDateTime localEndDate = LocalDateTime.now();
					LocalDateTime localStartDate = localEndDate.minusHours(24);
					Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
					endDate = Date.from(instant);
					instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
					startDate = Date.from(instant);
				} else {
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
					Date startDateTemp = dateFormatter.parse(startingDate);
					startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

					Date endDateTemp = dateFormatter.parse(endingDate);
					endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
				}
				
				discountQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
				discounts = CommerceDiscountLocalServiceUtil.dynamicQuery(discountQuery);
				try {
				discounts = discounts.stream().sorted((o1, o2)->o1.getDisplayDate().compareTo(o2.getDisplayDate())).collect(Collectors.toList());
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				
				List<String> couponColumns = getCouponColumn();
				htmlTable += "<table class=\"pdf-table\"><tr class=\"bg-clr1\">";
				for (int header = 0; header < couponColumns.size(); header++) {
					htmlTable +=
							"<td><strong>"+couponColumns.get(header)+"</strong></td>";
				}
				htmlTable += " </tr>";
				for (CommerceDiscount discount : discounts) {
					String promoType = "Fixed Amount";
					if(discount.getUsePercentage()) {
						promoType = "percentage";
					}
					
					DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
					orderQuery.add(RestrictionsFactoryUtil.eq("couponCode", discount.getCouponCode()));
					List<CommerceOrder> ordersOfCoupon = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
					
					long totalCouponToday = 0;
					BigDecimal totalDiscountToday = new BigDecimal(0);
					BigDecimal totalDiscountTillDate = new BigDecimal(0);
					
					Date today = new Date();
					
					for(CommerceOrder order : ordersOfCoupon) {
						if(order.getOrderDate().getDay() == today.getDay() &&
							order.getOrderDate().getMonth() == today.getMonth()-1 &&
							order.getOrderDate().getYear() + 1900 == today.getYear()) {
							totalCouponToday += 1;
							totalDiscountToday = totalDiscountToday.add(order.getTotalDiscountAmount());
						}
						totalDiscountTillDate = totalDiscountTillDate.add(order.getTotalDiscountAmount());

					}
					
					htmlTable += "<tr>"
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ discount.getTitle() + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ promoType + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ discount.getTarget() + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ discount.getLimitationTimes() + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ totalCouponToday + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ discount.getNumberOfUse() + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ totalDiscountToday + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ totalDiscountTillDate + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ discount.getLastPublishDate() + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ discount.getExpirationDate() + "</td>";

					
					htmlTable += " </tr>";
				}
				htmlTable += " </table>";
				body = body.replace("[$ITEMDETAILS$]", htmlTable);
				Date today = new Date();
				body = body.replace("[$DATE$]", today.toString());
				body = body.replace("[$REPORTTYPE$]", "Coupon Report");

		} catch (

		Exception e) {
			log.error("Exception during invoice generation" + e);
		}
		return body;
	}
	public static List<String> getCouponColumn() {
		List<String> couponColumns = new ArrayList<>();
		couponColumns.add("Promotion Name");
		couponColumns.add("Type of Promo");
		couponColumns.add("Target");
		couponColumns.add("Total Coupons Allocated");
		couponColumns.add("Total Coupons given (today)");
		couponColumns.add("Total Discount given (today)");
		couponColumns.add("Total Coupons given (till date)");
		couponColumns.add("Total Discount given (till date)");
		couponColumns.add("Start Date");
		couponColumns.add("End Date");
		
		return couponColumns;
	}
	
	private static final Log log = LogFactoryUtil.getLog(CatalogReportGenerator.class);

}
