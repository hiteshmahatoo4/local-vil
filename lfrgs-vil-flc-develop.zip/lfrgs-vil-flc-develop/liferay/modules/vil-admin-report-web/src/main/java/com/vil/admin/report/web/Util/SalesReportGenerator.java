package com.vil.admin.report.web.Util;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.discount.model.CommerceDiscount;
import com.liferay.commerce.discount.service.CommerceDiscountLocalServiceUtil;
import com.liferay.commerce.inventory.model.CIWarehouseItem;
import com.liferay.commerce.inventory.model.CommerceInventoryWarehouseItem;
import com.liferay.commerce.inventory.service.CommerceInventoryBookedQuantityLocalServiceUtil;
import com.liferay.commerce.inventory.service.CommerceInventoryWarehouseItemLocalServiceUtil;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.model.CommerceOrderItem;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CPInstance;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.commerce.product.service.CPInstanceLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderItemLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.commission.model.OrderItemCommission;
import com.vil.commission.service.OrderItemCommissionLocalServiceUtil;
import com.vil.common.util.VilRoleUtil;
import com.vil.partner.model.PartnerAddresses;
import com.vil.partner.model.PartnerBankDetails;
import com.vil.partner.model.PartnerCategories;
import com.vil.partner.model.PartnerDetails;
import com.vil.partner.model.PartnerLeads;
import com.vil.partner.model.PartnerMaster;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerAddressesLocalServiceUtil;
import com.vil.partner.service.PartnerBankDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerCategoriesLocalServiceUtil;
import com.vil.partner.service.PartnerDetailsLocalServiceUtil;
import com.vil.partner.service.PartnerLeadsLocalServiceUtil;
import com.vil.partner.service.PartnerMasterLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bouncycastle.asn1.isismtt.x509.ProcurationSyntax;

public class SalesReportGenerator {
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		SalesReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		SalesReportGenerator.endDate = endDate;
	}
	
	public static byte[] getSalesExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		XSSFWorkbook workbook = new XSSFWorkbook();
		try {

			Sheet sheet = workbook.createSheet("Sales Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			Font defaultFont = workbook.createFont();
			defaultCellStyle.setFont(defaultFont);
			defaultCellStyle.setWrapText(true);
			
			
			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);

			Row headRow = sheet.createRow(0);

			List<String> partnerColumns = getSalesColumns();
			
			for (int header = 0; header < partnerColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(partnerColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}
			
			Date startDate = null;
			Date endDate = null;
			DynamicQuery instanceQuery = CPInstanceLocalServiceUtil.dynamicQuery();
			List<CPInstance> instances = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			instanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			
			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					instanceQuery.add(userRestriction);
					instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
					instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());

				} 
			} else {
				instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
				instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
			}
			
			int index = 1;
			for (CPInstance instance : instances) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				Cell cell = row.createCell(colIndex);
				cell.setCellValue(instance.getCPInstanceId());  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(instance.getLastPublishDate());  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				long userId = instance.getUserId();
				
				String sellerName = "";
				PartnerUsers partneruser = PartnerUsersLocalServiceUtil.findByLiferayUserId(userId);
				if(partneruser != null && Validator.isNotNull(partneruser.getPartnerId())) {
					PartnerMaster partnermaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partneruser.getPartnerId());
					if(partnermaster != null) {
						sellerName = partnermaster.getPartnerName();
					}
					
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(sellerName);  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				String productName = "";
				long productId = 0;
				String[] categories = null;
				CPDefinition cpdefinition = CPDefinitionLocalServiceUtil.getCPDefinition(instance.getCPDefinitionId());
				if(cpdefinition != null) {
					productId = cpdefinition.getCProductId();
					productName = cpdefinition.getName();
					categories = getCategories(cpdefinition);
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(productId);  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(productName);  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				String categorie = "";
				String subCategories="";
				String subsubCategories="";
				if(categories != null) {
					categorie = categories[0];
					subCategories = categories[1];
					subsubCategories = categories[2];
				}
				
				cell = row.createCell(colIndex);
				cell.setCellValue(categorie);  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(subCategories);  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(subsubCategories);  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				int totalQuantity = 0;
				List<CommerceInventoryWarehouseItem> warehouseItems = CommerceInventoryWarehouseItemLocalServiceUtil.getCommerceInventoryWarehouseItems(instance.getCompanyId(), instance.getSku(),-1,-1);
				if(warehouseItems != null && !warehouseItems.isEmpty()) {
					for(CommerceInventoryWarehouseItem warehouseItem : warehouseItems) {
						totalQuantity += warehouseItem.getQuantity();
					}
				}
				
				int bookedQuantity = CommerceInventoryBookedQuantityLocalServiceUtil.getCommerceBookedQuantity(instance.getCompanyId(), instance.getSku());
				
				int endQuantity = totalQuantity - bookedQuantity;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(totalQuantity);  // Starting Inventory
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(bookedQuantity);  // Quantity Sold
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(endQuantity);    // End Inventory
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				DynamicQuery orderItemCommissionQuery = OrderItemCommissionLocalServiceUtil.dynamicQuery();
				orderItemCommissionQuery.add(RestrictionsFactoryUtil.eq("skuId", instance.getCPInstanceId()));
				List<OrderItemCommission> orderCommsionItems = OrderItemCommissionLocalServiceUtil.dynamicQuery(orderItemCommissionQuery);
				
				BigDecimal totalCommission = new BigDecimal(0);
				BigDecimal finalAmountAfterCommission = new BigDecimal(0);
				BigDecimal settlementAmount = new BigDecimal(0);
				if(!orderCommsionItems.isEmpty()) {
					for(OrderItemCommission orderCommissionItem : orderCommsionItems) {
						totalCommission= totalCommission.add(orderCommissionItem.getTotalCommVal());
						finalAmountAfterCommission = finalAmountAfterCommission.add(orderCommissionItem.getFinalAmountAfterComm());
						settlementAmount = settlementAmount.add(orderCommissionItem.getSettlementAmount());
					}
				}
				
				
				cell = row.createCell(colIndex);
				cell.setCellValue(finalAmountAfterCommission.add(totalCommission).toString());   // Total Collection (INR)
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(totalCommission.toString());   // Vi Commission (INR)
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue("GST TCS @1%");  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue("TDS 194 (O) @1%");  
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlementAmount.toString());   // Net Partner Payout (INR)
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue("Order Date");  
				cell.setCellStyle(defaultCellStyle);
								
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] getSalesCSVReportData(ResourceRequest resourceRequest) {

		byte[] outArray = null;

		try {
			StringBuffer data = new StringBuffer();
			List<String> salesColumns = getSalesColumns();
			ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

			String startingDate = getStartDate();
			String endingDate = getEndDate();
			for (int header = 0; header < salesColumns.size(); header++) {
				data.append(salesColumns.get(header));
				data.append(",");
			}
			data.append('\n');
			Date startDate = null;
			Date endDate = null;
			DynamicQuery instanceQuery = CPInstanceLocalServiceUtil.dynamicQuery();
			List<CPInstance> instances = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			instanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			
			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					instanceQuery.add(userRestriction);
					instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
					instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());

				} 
			} else {
				instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
				instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
			}
			for (CPInstance instance : instances) {
				
				

				data.append(instance.getCPInstanceId());  
				data.append(",");
				
				data.append(instance.getLastPublishDate());  
				data.append(",");
				
				long userId = instance.getUserId();
				
				String sellerName = "";
				PartnerUsers partneruser = PartnerUsersLocalServiceUtil.findByLiferayUserId(userId);
				if(partneruser != null && Validator.isNotNull(partneruser.getPartnerId())) {
					PartnerMaster partnermaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partneruser.getPartnerId());
					if(partnermaster != null) {
						sellerName = partnermaster.getPartnerName();
					}
					
				}
				
				data.append(sellerName);  
				data.append(",");
				
				String productName = "";
				long productId = 0;
				String[] categories = null;
				CPDefinition cpdefinition = CPDefinitionLocalServiceUtil.getCPDefinition(instance.getCPDefinitionId());
				if(cpdefinition != null) {
					productId = cpdefinition.getCProductId();
					productName = cpdefinition.getName();
					categories = getCategories(cpdefinition);
				}
				data.append(productId);  
				data.append(",");
				
				data.append(productName);  
				data.append(",");
				
				String categorie = "";
				String subCategories="";
				String subsubCategories="";
				if(categories != null) {
					categorie = categories[0];
					subCategories = categories[1];
					subsubCategories = categories[2];
				}
				
				data.append(categorie);  
				data.append(",");
				
				data.append(subCategories);  
				data.append(",");
				
				data.append(subsubCategories);  
				data.append(",");
				
				int totalQuantity = 0;
				List<CommerceInventoryWarehouseItem> warehouseItems = CommerceInventoryWarehouseItemLocalServiceUtil.getCommerceInventoryWarehouseItems(instance.getCompanyId(), instance.getSku(),-1,-1);
				if(warehouseItems != null && warehouseItems.size() > 0) {
					for(CommerceInventoryWarehouseItem warehouseItem : warehouseItems) {
						totalQuantity += warehouseItem.getQuantity();
					}
				}
				
				int bookedQuantity = CommerceInventoryBookedQuantityLocalServiceUtil.getCommerceBookedQuantity(instance.getCompanyId(), instance.getSku());
				
				int endQuantity = totalQuantity - bookedQuantity;
				
				data.append(totalQuantity);  // Starting Inventory
				data.append(",");
				
				data.append(bookedQuantity);  // Quantity Sold
				data.append(",");
				
				data.append(endQuantity);    // End Inventory
				data.append(",");
				
				DynamicQuery orderItemCommissionQuery = OrderItemCommissionLocalServiceUtil.dynamicQuery();
				orderItemCommissionQuery.add(RestrictionsFactoryUtil.eq("skuId", instance.getCPInstanceId()));
				List<OrderItemCommission> orderCommsionItems = OrderItemCommissionLocalServiceUtil.dynamicQuery(orderItemCommissionQuery);
				
				BigDecimal totalCommission = new BigDecimal(0);
				BigDecimal finalAmountAfterCommission = new BigDecimal(0);
				BigDecimal settlementAmount = new BigDecimal(0);
				if(orderCommsionItems.size() > 0) {
					for(OrderItemCommission orderCommissionItem : orderCommsionItems) {
						totalCommission= totalCommission.add(orderCommissionItem.getTotalCommVal());
						finalAmountAfterCommission = finalAmountAfterCommission.add(orderCommissionItem.getFinalAmountAfterComm());
						settlementAmount = settlementAmount.add(orderCommissionItem.getSettlementAmount());
					}
				}
				
				
				data.append(finalAmountAfterCommission.add(totalCommission).toString());   // Total Collection (INR)
				data.append(",");
				
				data.append(totalCommission.toString());   // Vi Commission (INR)
				data.append(",");
				
				data.append("GST TCS @1%");  
				data.append(",");
				
				data.append("TDS 194 (O) @1%");  
				data.append(",");
				
				data.append(settlementAmount.toString());   // Net Partner Payout (INR)
				data.append(",");
				
				data.append("Order Date");  
				
				
				data.append('\n');
			}
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] generateSalesPdf(String htmlContent,ResourceRequest resourceRequest) {
		String value = htmlContent;
		String body = replaceValue(value,resourceRequest);
		
		FileOutputStream fileOutputStream = null;
		try {
			String fileName = ""+new Date().getTime();
			File certificateFile = File.createTempFile(fileName, ".pdf");
			ConverterProperties properties = new ConverterProperties();
			fileOutputStream = new FileOutputStream(certificateFile);
			PdfDocument pdfDocument = new PdfDocument(new PdfWriter(certificateFile));
			pdfDocument.setDefaultPageSize(PageSize.A1);
			//pdfDocument.
			HtmlConverter.convertToPdf(body, pdfDocument, properties);
			FileInputStream fl = new FileInputStream(certificateFile);
	        byte[] arr = new byte[(int)certificateFile.length()];
	        fl.read(arr);
	        return arr;
		} catch (Exception e) {
			log.error(e);
			log.error("Exception during coupo pdf" + e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					log.error("Exception during coupon pdf" + e);
					return null;
				}
			}
		}
	}
	
	private static String replaceValue(String body,ResourceRequest resourceRequest) {
		try {
				ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

				String htmlTable="";
				String startingDate = getStartDate();
				String endingDate = getEndDate();
				Date startDate = null;
				Date endDate = null;
				
				DynamicQuery instanceQuery = CPInstanceLocalServiceUtil.dynamicQuery();
				List<CPInstance> instances = null;
				if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
					LocalDateTime localEndDate = LocalDateTime.now();
					LocalDateTime localStartDate = localEndDate.minusHours(24);
					Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
					endDate = Date.from(instant);
					instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
					startDate = Date.from(instant);
				} else {
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
					Date startDateTemp = dateFormatter.parse(startingDate);
					startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

					Date endDateTemp = dateFormatter.parse(endingDate);
					endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
				}
				
				instanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
				
				if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
					PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
					DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
					userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
					List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
					
					if(!partnerUsers.isEmpty()) {
						Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
						for(int i=1;i<partnerUsers.size();i++) {
							userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
						}
						instanceQuery.add(userRestriction);
						instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
						instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());

					} 
				} else {
					instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
					instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
				}
				
				List<String> salesColumns = getSalesColumns();
				htmlTable += "<table class=\"pdf-table\"><tr class=\"bg-clr1\">";
				for (int header = 0; header < salesColumns.size(); header++) {
					htmlTable +=
							"<td><strong>"+salesColumns.get(header)+"</strong></td>";
				}
				htmlTable += " </tr>";
				for (CPInstance instance : instances) {
					
					long userId = instance.getUserId();
					
					String sellerName = "";
					PartnerUsers partneruser = PartnerUsersLocalServiceUtil.findByLiferayUserId(userId);
					if(partneruser != null && Validator.isNotNull(partneruser.getPartnerId())) {
						PartnerMaster partnermaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partneruser.getPartnerId());
						if(partnermaster != null) {
							sellerName = partnermaster.getPartnerName();
						}
						
					}
										
					String productName = "";
					long productId = 0;
					String[] categories = null;
					CPDefinition cpdefinition = CPDefinitionLocalServiceUtil.getCPDefinition(instance.getCPDefinitionId());
					if(cpdefinition != null) {
						productId = cpdefinition.getCProductId();
						productName = cpdefinition.getName();
						categories = getCategories(cpdefinition);
					} 
					
					String categorie = "";
					String subCategories="";
					String subsubCategories="";
					if(categories != null) {
						categorie = categories[0];
						subCategories = categories[1];
						subsubCategories = categories[2];
					}
					
					 
					
					int totalQuantity = 0;
					List<CommerceInventoryWarehouseItem> warehouseItems = CommerceInventoryWarehouseItemLocalServiceUtil.getCommerceInventoryWarehouseItems(instance.getCompanyId(), instance.getSku(),-1,-1);
					if(warehouseItems != null && warehouseItems.size() > 0) {
						for(CommerceInventoryWarehouseItem warehouseItem : warehouseItems) {
							totalQuantity += warehouseItem.getQuantity();
						}
					}
					
					int bookedQuantity = CommerceInventoryBookedQuantityLocalServiceUtil.getCommerceBookedQuantity(instance.getCompanyId(), instance.getSku());
					
					int endQuantity = totalQuantity - bookedQuantity;
					
					DynamicQuery orderItemCommissionQuery = OrderItemCommissionLocalServiceUtil.dynamicQuery();
					orderItemCommissionQuery.add(RestrictionsFactoryUtil.eq("skuId", instance.getCPInstanceId()));
					List<OrderItemCommission> orderCommsionItems = OrderItemCommissionLocalServiceUtil.dynamicQuery(orderItemCommissionQuery);
					
					BigDecimal totalCommission = new BigDecimal(0);
					BigDecimal finalAmountAfterCommission = new BigDecimal(0);
					BigDecimal settlementAmount = new BigDecimal(0);
					if(orderCommsionItems.size() > 0) {
						for(OrderItemCommission orderCommissionItem : orderCommsionItems) {
							totalCommission= totalCommission.add(orderCommissionItem.getTotalCommVal());
							finalAmountAfterCommission = finalAmountAfterCommission.add(orderCommissionItem.getFinalAmountAfterComm());
							settlementAmount = settlementAmount.add(orderCommissionItem.getSettlementAmount());
						}
					}
					
					htmlTable += "<tr>"
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ instance.getCPInstanceId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ instance.getLastPublishDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ sellerName + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ productId + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ productName + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ categorie + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ subCategories + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ subsubCategories + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ totalQuantity + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ bookedQuantity + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ endQuantity + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ finalAmountAfterCommission.add(totalCommission).toString() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ totalCommission.toString() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "GST TCS @1%" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "TDS 194 (O) @1%" + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlementAmount.toString() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ "OrderDate" + "</td>";

					htmlTable += " </tr>";
				}
				htmlTable += " </table>";
				body = body.replace("[$ITEMDETAILS$]", htmlTable);
				Date today = new Date();
				body = body.replace("[$DATE$]", today.toString());
				body = body.replace("[$REPORTTYPE$]", "Sales Report");
				if(startingDate!=null) {
					body = body.replace("[$DATERANGE$]", startingDate +" to "+endingDate);

				} else {
					body = body.replace("[$DATERANGE$]","last 24 hours record");

				}

		} catch (

		Exception e) {
			log.error("Exception during invoice generation" + e);
		}
		return body;
	}
	
	public static String getPartnerCategory(Long partnerId) {
		try {
			List<PartnerCategories> categories = PartnerCategoriesLocalServiceUtil.findByPartnerMasterId(partnerId);
			StringBuilder categoriesStr = new StringBuilder();
			int counter=0;
			for(PartnerCategories category : categories) {
				AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(category.getCategoryId());

				if(counter!=0) {
					categoriesStr.append("/ ");
				}
				counter++;
				categoriesStr.append(assetCategory.getName());
			}
			return categoriesStr.toString();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return "";
	}
	
	public static List<String> getSalesColumns() {
		List<String> salesColumns = new ArrayList<>();
		
		salesColumns.add("SKU ID");
		salesColumns.add("SKU Published Date");
		salesColumns.add("Seller Name");
		salesColumns.add("Product ID");
		salesColumns.add("Product Name");
		salesColumns.add("Category (L2");
		salesColumns.add("Sub-Category (L3)");
		salesColumns.add("Sub-Sub-Category (L4)");
		salesColumns.add("Starting Inventory");
		salesColumns.add("Quantity Sold");
		salesColumns.add("End Inventory");
		salesColumns.add("Total Collection (INR)");
		salesColumns.add("Vi Commission (INR)");
		salesColumns.add("GST TCS @1%");
		salesColumns.add("TDS 194 (O) @1% ");
		salesColumns.add("Net Partner Payout (INR)");
		salesColumns.add("Order Date");
		
		return salesColumns;
	}
	
	public static String[] getCategories(CPDefinition cpDefinition) {
		Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
		AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, cpDefinition.getCPDefinitionId());
		StringBuilder category = new StringBuilder();
		StringBuilder categorySub = new StringBuilder();
		StringBuilder categorySubSub = new StringBuilder();
		if(assetEntry!=null && assetEntry.getCategoryIds() != null) {
			for(int i=0;i<assetEntry.getCategoryIds().length;i++) {
				try {
					AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(assetEntry.getCategoryIds()[i]);
					
					if(assetCategory !=null) {
						String treepath = assetCategory.getTreePath();
						if(treepath !=null) {
							String[] categoryArr = treepath.split("/");
							if(categoryArr.length == 3) {
								categorySub.append(assetCategory.getName());	
								categorySub.append("/");
							}
							if(categoryArr.length == 4) {
								categorySubSub.append(assetCategory.getName());
								categorySub.append("/");
								
							}
							if(categoryArr.length == 2) {
								category.append(assetCategory.getName());
								categorySub.append("/");
							}
						}
					}
					
				} catch(Exception e) {
					log.error(e.getMessage());
				}
			}
			
		}
		String categoriesStr = category.toString();
		String categoriesSubStr = categorySub.toString();
		String categoriesSubSubStr = categorySubSub.toString();
		return new String[] {categoriesStr,categoriesSubStr,categoriesSubSubStr};
	}
	
	private static final Log log = LogFactoryUtil.getLog(SalesReportGenerator.class);

}
