package com.vil.admin.report.web.Util;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.vil.common.util.VilRoleUtil;

import java.util.List;

public class ReportViewAccessUtil {
	
	public static boolean isCategoryLead(ThemeDisplay themeDisplay) {
		long[] roleIds = themeDisplay.getUser().getRoleIds();
		List<Long> listRoleIds = ListUtil.fromArray(roleIds);
		long viCateoryLead;
		try {
			viCateoryLead = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),VilRoleUtil.VIL_PARTNER_ROLES.ROLE_CATEGORY_LEAD.name).getRoleId();
			if (listRoleIds.contains(viCateoryLead)) {
				return true;
			}
		} catch (PortalException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static boolean isCategoryManager(ThemeDisplay themeDisplay) {
		long[] roleIds = themeDisplay.getUser().getRoleIds();
		List<Long> listRoleIds = ListUtil.fromArray(roleIds);
		long viCateoryLead;
		try {
			viCateoryLead = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),VilRoleUtil.VIL_PARTNER_ROLES.ROLE_CATEGORY_MANAGER.name).getRoleId();
			if (listRoleIds.contains(viCateoryLead)) {
				return true;
			}
		} catch (PortalException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static boolean isGrievanceManager(ThemeDisplay themeDisplay) {
		long[] roleIds = themeDisplay.getUser().getRoleIds();
		List<Long> listRoleIds = ListUtil.fromArray(roleIds);
		String ROLE_VI_GRIEVANCE_MANAGER = "Vi Grievance Manager";
		long grievanceMgrId;
		try {
			grievanceMgrId = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),ROLE_VI_GRIEVANCE_MANAGER).getRoleId();
			if (listRoleIds.contains(grievanceMgrId)) {
				return true;
			}
		} catch (PortalException e) {
			e.printStackTrace();
		}
		
		return false;
	}

}
