package com.vil.admin.report.web.Util;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.liferay.commerce.constants.CommerceOrderConstants;
import com.liferay.commerce.model.CommerceAddress;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.vil.cart.model.VilOrderDetails;
import com.vil.cart.service.VilOrderDetailsLocalServiceUtil;
import com.vil.commission.model.CommissionSettlement;
import com.vil.commission.service.CommissionSettlementLocalServiceUtil;
import com.vil.common.util.VilRoleUtil;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class settlementReportGenerator {
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		settlementReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		settlementReportGenerator.endDate = endDate;
	}
	
	
	public static byte[] getSettlementExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		try {

			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet sheet = workbook.createSheet("Settlement Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			Font defaultFont = workbook.createFont();
			defaultCellStyle.setFont(defaultFont);
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);
			

			Row headRow = sheet.createRow(0);

			List<String> settlementColumns = getSettlementColumn();
			
			String startingDate = getStartDate();
			String endingDate = getEndDate();
			

			for (int header = 0; header < settlementColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(settlementColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}

			Date startDate = null;
			Date endDate = null;
			DynamicQuery settlementQuery = CommissionSettlementLocalServiceUtil.dynamicQuery();
			List<CommissionSettlement> settlements = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			settlementQuery.add(RestrictionsFactoryUtil.between("settlementDate",startDate, endDate));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					settlementQuery.add(userRestriction);
					settlements = CommissionSettlementLocalServiceUtil.dynamicQuery(settlementQuery);
					settlements = settlements.stream().sorted((o1, o2)->o2.getSettlementDate().compareTo(o1.getSettlementDate())).collect(Collectors.toList());

				} 
			} else {
				settlements = CommissionSettlementLocalServiceUtil.dynamicQuery(settlementQuery);
				settlements = settlements.stream().sorted((o1, o2)->o2.getSettlementDate().compareTo(o1.getSettlementDate())).collect(Collectors.toList());
			}
			int index = 1;
			for (CommissionSettlement settlement : settlements) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				Cell cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getPartnerName()); // Seller Name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getSapId());  // "Seller SAP ID"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getPartnerKAMName());  // "Partner KAM"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getPartnerKamEmail());  // "Partner KAM Email"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getPartnerKamMobile());  // "Partner KAM Phone Number"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getTotalCollection());  // "Total Collection (INR)"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getTotalVICommission());  // "Vi Commission (INR)"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getTotalGst());  // "GST TCS @1%"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getTotalTds());  // "TDS 194 (O) @1% "
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getNetPartnerPayout());  // "Net Partner Payout (INR)"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(settlement.getSettlementDate()); // "Settlement Date (Payment Collection Date)"
				cell.setCellStyle(defaultCellStyle);

			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;

	}
	
	public static byte[] getSettlementCSVReportData(ResourceRequest resourceRequest) {
		byte[] outArray = null;
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		try {
			StringBuffer data = new StringBuffer();
			List<String> settlementColumns = getSettlementColumn();
			
			String startingDate = getStartDate();
			String endingDate = getEndDate();
			

			for (int header = 0; header < settlementColumns.size(); header++) {
				data.append(settlementColumns.get(header));
				data.append(",");
			}
			
			data.append('\n');

			Date startDate = null;
			Date endDate = null;
			DynamicQuery settlementQuery = CommissionSettlementLocalServiceUtil.dynamicQuery();
			List<CommissionSettlement> settlements = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			settlementQuery.add(RestrictionsFactoryUtil.between("settlementDate",startDate, endDate));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					settlementQuery.add(userRestriction);
					settlements = CommissionSettlementLocalServiceUtil.dynamicQuery(settlementQuery);
					settlements = settlements.stream().sorted((o1, o2)->o2.getSettlementDate().compareTo(o1.getSettlementDate())).collect(Collectors.toList());

				} 
			} else {
				settlements = CommissionSettlementLocalServiceUtil.dynamicQuery(settlementQuery);
				settlements = settlements.stream().sorted((o1, o2)->o2.getSettlementDate().compareTo(o1.getSettlementDate())).collect(Collectors.toList());
			}
			for (CommissionSettlement settlement : settlements) {

				data.append(settlement.getPartnerName()); // Seller Name
				data.append(",");
				
				data.append(settlement.getSapId());  // "Seller SAP ID"
				data.append(",");
				
				data.append(settlement.getPartnerKAMName());  // "Partner KAM"
				data.append(",");
				
				data.append(settlement.getPartnerKamEmail());  // "Partner KAM Email"
				data.append(",");
				
				data.append(settlement.getPartnerKamMobile());  // "Partner KAM Phone Number"
				data.append(",");
				
				data.append(settlement.getTotalCollection());  // "Total Collection (INR)"
				data.append(",");
				
				data.append(settlement.getTotalVICommission());  // "Vi Commission (INR)"
				data.append(",");
				
				data.append(settlement.getTotalGst());  // "GST TCS @1%"
				data.append(",");
				
				data.append(settlement.getTotalTds());  // "TDS 194 (O) @1% "
				data.append(",");
				
				data.append(settlement.getNetPartnerPayout());  // "Net Partner Payout (INR)"
				data.append(",");
				
				data.append(settlement.getSettlementDate()); // "Settlement Date (Payment Collection Date)"
				data.append(",");
	            
                data.append('\n');
			}
			
			
			
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] getSettlementPdfReportData(String htmlContent,ResourceRequest resourceRequest) {
		String value = htmlContent;
		String body = replaceValue(value,resourceRequest);

		FileOutputStream fileOutputStream = null;
		try {
			String fileName = ""+new Date().getTime();
			File certificateFile = File.createTempFile(fileName, ".pdf");
			ConverterProperties properties = new ConverterProperties();
			fileOutputStream = new FileOutputStream(certificateFile);
			PdfDocument pdfDocument = new PdfDocument(new PdfWriter(certificateFile));
			pdfDocument.setDefaultPageSize(PageSize.A2);
			HtmlConverter.convertToPdf(body, pdfDocument, properties);
			FileInputStream fl = new FileInputStream(certificateFile);
	        byte[] arr = new byte[(int)certificateFile.length()];
	        fl.read(arr);
	        return arr;
		} catch (Exception e) {
			log.error(e);
			log.error("Exception during coupo pdf" + e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					log.error("Exception during coupon pdf" + e);
					return null;
				}
			}
		}
	}
	
	
	private static String replaceValue(String body,ResourceRequest resourceRequest) {
		try {
				ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

				String htmlTable="";
				String startingDate = getStartDate();
				String endingDate = getEndDate();
				Date startDate = null;
				Date endDate = null;
				DynamicQuery settlementQuery = CommissionSettlementLocalServiceUtil.dynamicQuery();
				List<CommissionSettlement> settlements = null;
				if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
					LocalDateTime localEndDate = LocalDateTime.now();
					LocalDateTime localStartDate = localEndDate.minusHours(24);
					Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
					endDate = Date.from(instant);
					instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
					startDate = Date.from(instant);
				} else {
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
					Date startDateTemp = dateFormatter.parse(startingDate);
					startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

					Date endDateTemp = dateFormatter.parse(endingDate);
					endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
				}
				
				settlementQuery.add(RestrictionsFactoryUtil.between("settlementDate",startDate, endDate));

				if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
					PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
					DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
					userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
					List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
					
					if(!partnerUsers.isEmpty()) {
						Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
						for(int i=1;i<partnerUsers.size();i++) {
							userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
						}
						settlementQuery.add(userRestriction);
						settlements = CommissionSettlementLocalServiceUtil.dynamicQuery(settlementQuery);
						settlements = settlements.stream().sorted((o1, o2)->o2.getSettlementDate().compareTo(o1.getSettlementDate())).collect(Collectors.toList());

					} 
				} else {
					settlements = CommissionSettlementLocalServiceUtil.dynamicQuery(settlementQuery);
					settlements = settlements.stream().sorted((o1, o2)->o2.getSettlementDate().compareTo(o1.getSettlementDate())).collect(Collectors.toList());
				}
				
				List<String> settlementColumns = getSettlementColumn();
				htmlTable += "<table class=\"pdf-table\"><tr class=\"bg-clr1\">";
				for (int header = 0; header < settlementColumns.size(); header++) {
					htmlTable +=
							"<td><strong>"+settlementColumns.get(header)+"</strong></td>";
				}
				htmlTable += " </tr>";
				for (CommissionSettlement settlement : settlements) {
					
					
					
					htmlTable += "<tr>"
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getPartnerName() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getSapId()+ "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getPartnerKAMName() + "</td>"

					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getPartnerKamEmail() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getPartnerKamMobile() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getTotalCollection() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getTotalVICommission() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getTotalGst() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getTotalTds() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getNetPartnerPayout() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ settlement.getSettlementDate() + "</td>";
					
					

					htmlTable += " </tr>";
				}
				htmlTable += " </table>";
				body = body.replace("[$ITEMDETAILS$]", htmlTable);
				Date today = new Date();
				body = body.replace("[$DATE$]", today.toString());
				body = body.replace("[$REPORTTYPE$]", "Settlement Report");
				if(startingDate!=null) {
					body = body.replace("[$DATERANGE$]", startingDate +" to "+endingDate);

				} else {
					body = body.replace("[$DATERANGE$]","last 24 hours record");

				}

		} catch (

		Exception e) {
			log.error("Exception during invoice generation" + e);
		}
		return body;
	}
	
	private static String getAddress(CommerceAddress address) {
		if (Validator.isNotNull(address)) {
			return address.getStreet1() + " " + address.getStreet2() + " " + address.getStreet3() + " "
					+ address.getCity();
		}
		return null;
	}
	
	public static List<String> getSettlementColumn() {
		List<String> settlementColumns = new ArrayList<>();
		
		settlementColumns.add("Seller Name");
		settlementColumns.add("Seller SAP ID");
		settlementColumns.add("Partner KAM");
		settlementColumns.add("Partner KAM Email");
		settlementColumns.add("Partner KAM Phone Number");
		settlementColumns.add("Total Collection (INR)");
		settlementColumns.add("Vi Commission (INR)");
		settlementColumns.add("GST TCS @1%");
		settlementColumns.add("TDS 194 (O) @1% ");
		settlementColumns.add("Net Partner Payout (INR)");
		settlementColumns.add("Settlement Date (Payment Collection Date)");

		return settlementColumns;
	}
	
	private static final Log log = LogFactoryUtil.getLog(settlementReportGenerator.class);
}
