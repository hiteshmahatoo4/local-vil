package com.vil.admin.report.web.Util;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.discount.model.CommerceDiscount;
import com.liferay.commerce.discount.service.CommerceDiscountLocalServiceUtil;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CPInstance;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.commerce.product.service.CPInstanceLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.common.util.VilRoleUtil;
import com.vil.partner.model.PartnerMaster;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerMasterLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class CatalogReportGenerator {
	
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		CatalogReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		CatalogReportGenerator.endDate = endDate;
	}

	public static byte[] getCatalogExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();
		
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		try {

			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet sheet = workbook.createSheet("Catalog Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			Font defaultFont = workbook.createFont();
			defaultCellStyle.setFont(defaultFont);
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);

			Row headRow = sheet.createRow(0);

			List<String> catalogColumns = getCatalogColumns();

			for (int header = 0; header < catalogColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(catalogColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}
			Date startDate = null;
			Date endDate = null;
			DynamicQuery instanceQuery = CPInstanceLocalServiceUtil.dynamicQuery();
			List<CPInstance> instances = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			instanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			
			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					instanceQuery.add(userRestriction);
					instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
					instances = instances.stream().sorted((o1, o2)->o2.getCreateDate().compareTo(o1.getCreateDate())).collect(Collectors.toList());

				} 
			} else {
				instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
				instances = instances.stream().sorted((o1, o2)->o2.getCreateDate().compareTo(o1.getCreateDate())).collect(Collectors.toList());
			}
			int index = 1;
			for (CPInstance instance : instances) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				
				Cell cell = row.createCell(colIndex);
				cell.setCellValue(instance.getCPInstanceId());
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(instance.getCreateDate().toGMTString());
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(WorkflowConstants.getStatusLabel(instance.getStatus()));
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(instance.getCreateDate().toGMTString());
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				String partnerName = "";
				try {
					PartnerUsers partnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
					if(partnerUser != null) {
						PartnerMaster partnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partnerUser.getPartnerId());
						partnerName = partnerMaster.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(partnerName);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				CPDefinition  cpDefinition = CPDefinitionLocalServiceUtil.getCPDefinition(instance.getCPDefinitionId());
				cell = row.createCell(colIndex);
				cell.setCellValue(cpDefinition.getCProductId()); 
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(cpDefinition.getName()); 
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(cpDefinition.getCreateDate().toGMTString()); 
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(WorkflowConstants.getStatusLabel(cpDefinition.getStatus())); // Order Subtotal
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(cpDefinition.getCreateDate().toGMTString()); 
				
				CellStyle productCreateCellStyle = workbook.createCellStyle();
				CreationHelper createHelper = workbook.getCreationHelper();
				productCreateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy h:mm"));
				cell.setCellStyle(productCreateCellStyle);
				colIndex++;


				PartnerMaster productPartnerMaster = null;
				String partnerNameProduct = "";
				try {
					PartnerUsers productPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
					if(productPartnerUser!=null) {
						productPartnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(productPartnerUser.getPartnerId());
					}
					
					if(productPartnerMaster!=null) {
						partnerNameProduct = productPartnerMaster.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(partnerNameProduct);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
				AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, cpDefinition.getCProductId());
				long[] categoryIds = new long[]{};
				if(assetEntry != null) {
					categoryIds = AssetEntryAssetCategoryRelLocalServiceUtil.getAssetCategoryPrimaryKeys(136108L);
				}

				List<Long> lisCategoryIds = ListUtil.fromArray(categoryIds);
				StringBuilder category = new StringBuilder();
				StringBuilder categorySub = new StringBuilder();
				StringBuilder categorySubSub = new StringBuilder();
				
				for(int i=0;i<lisCategoryIds.size();i++) {
					try {
						AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(lisCategoryIds.get(i));
						
						if(assetCategory !=null) {
							String treepath = assetCategory.getTreePath();
							if(treepath !=null) {
								String[] categoryArr = treepath.split("/");
								if(categoryArr.length == 3) {
									categorySub.append(assetCategory.getName());									
								}
								if(categoryArr.length == 4) {
									categorySubSub.append(assetCategory.getName());
									
								}
								if(categoryArr.length == 2) {
									category.append(assetCategory.getName());
								}
							}
						}
						
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				String categoriesStr = category.toString();
				String categoriesSubStr = categorySub.toString();
				String categoriesSubSubStr = categorySubSub.toString();
				
				String[] categories = getProductCategories(cpDefinition.getCPDefinitionId());

				cell = row.createCell(colIndex);
				cell.setCellValue(categories[0]);  // "Category (L2)"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(categories[1]);  // "Sub-Category (L3)"
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(categories[2]);  // "Sub-Sub-Category (L4)"
				cell.setCellStyle(defaultCellStyle);
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}

	public static byte[] getCatalogCSVReportData(ResourceRequest resourceRequest) {

		byte[] outArray = null;
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();

		try {
			StringBuffer data = new StringBuffer();
			List<String> catalogColumns = getCatalogColumns();

			for (int header = 0; header < catalogColumns.size(); header++) {
				data.append(catalogColumns.get(header));
				data.append(",");
				
				
			}
			data.append('\n');
			Date startDate = null;
			Date endDate = null;
			DynamicQuery instanceQuery = CPInstanceLocalServiceUtil.dynamicQuery();
			List<CPInstance> instances = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			instanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			
			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					instanceQuery.add(userRestriction);
					instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
					instances = instances.stream().sorted((o1, o2)->o2.getCreateDate().compareTo(o1.getCreateDate())).collect(Collectors.toList());

				} 
			} else {
				instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
				instances = instances.stream().sorted((o1, o2)->o2.getCreateDate().compareTo(o1.getCreateDate())).collect(Collectors.toList());
			}
			int index = 1;
			for (CPInstance instance : instances) {

				
				data.append(instance.getCPInstanceId());
				data.append(",");

				data.append(instance.getCreateDate().toGMTString());
				data.append(",");
				
				data.append(WorkflowConstants.getStatusLabel(instance.getStatus()));
				data.append(",");

				data.append(instance.getCreateDate().toGMTString());
				data.append(",");

				String partnerName = "";
				try {
					PartnerUsers partnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
					if(partnerUser != null) {
						PartnerMaster partnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partnerUser.getPartnerId());
						partnerName = partnerMaster.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(partnerName);
				data.append(",");

				CPDefinition  cpDefinition = CPDefinitionLocalServiceUtil.getCPDefinition(instance.getCPDefinitionId());
				data.append(cpDefinition.getCProductId()); 
				data.append(",");

				data.append(cpDefinition.getName()); 
				data.append(",");

				data.append(cpDefinition.getCreateDate().toGMTString()); 
				data.append(",");

				data.append(WorkflowConstants.getStatusLabel(cpDefinition.getStatus())); // Order Subtotal
				data.append(",");

				data.append(cpDefinition.getCreateDate().toGMTString()); 
				data.append(",");


				PartnerMaster productPartnerMaster = null;
				String partnerNameProduct = "";
				try {
					PartnerUsers productPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
					if(productPartnerUser!=null) {
						productPartnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(productPartnerUser.getPartnerId());
					}
					
					if(productPartnerMaster!=null) {
						partnerNameProduct = productPartnerMaster.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(partnerNameProduct);
				data.append(",");
				
				
				String[] categories = getProductCategories(cpDefinition.getCPDefinitionId());
				
				data.append(categories[0]);  // "Category (L2)"
				data.append(",");

				data.append(categories[1]);  // "Sub-Category (L3)"
				data.append(",");
				
				data.append(categories[2]);  // "Sub-Sub-Category (L4)"
				data.append(",");
				
                data.append('\n');
            }
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] generateCatalogPdf(String htmlContent,ResourceRequest resourceRequest) {
		String value = htmlContent;
		String body = replaceValue(value,resourceRequest);

		FileOutputStream fileOutputStream = null;
		try {
			String fileName = ""+new Date().getTime();
			File certificateFile = File.createTempFile(fileName, ".pdf");
			ConverterProperties properties = new ConverterProperties();
			fileOutputStream = new FileOutputStream(certificateFile);
			PdfDocument pdfDocument = new PdfDocument(new PdfWriter(certificateFile));
			pdfDocument.setDefaultPageSize(PageSize.A2);
			//pdfDocument.
			HtmlConverter.convertToPdf(body, pdfDocument, properties);
			FileInputStream fl = new FileInputStream(certificateFile);
	        byte[] arr = new byte[(int)certificateFile.length()];
	        fl.read(arr);
	        return arr;
		} catch (Exception e) {
			log.error(e);
			log.error("Exception during coupo pdf" + e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					log.error("Exception during coupon pdf" + e);
					return null;
				}
			}
		}
	}
	
	private static String replaceValue(String body,ResourceRequest resourceRequest) {
		try {
				ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

				String htmlTable="";
				String startingDate = getStartDate();
				String endingDate = getEndDate();
				Date startDate = null;
				Date endDate = null;
				DynamicQuery instanceQuery = CPInstanceLocalServiceUtil.dynamicQuery();
				List<CPInstance> instances = null;
				if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
					LocalDateTime localEndDate = LocalDateTime.now();
					LocalDateTime localStartDate = localEndDate.minusHours(24);
					Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
					endDate = Date.from(instant);
					instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
					startDate = Date.from(instant);
				} else {
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
					Date startDateTemp = dateFormatter.parse(startingDate);
					startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

					Date endDateTemp = dateFormatter.parse(endingDate);
					endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
				}
				
				instanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
				
				if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
					PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
					DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
					userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
					List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
					
					if(!partnerUsers.isEmpty()) {
						Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
						for(int i=1;i<partnerUsers.size();i++) {
							userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
						}
						instanceQuery.add(userRestriction);
						instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
						instances = instances.stream().sorted((o1, o2)->o2.getCreateDate().compareTo(o1.getCreateDate())).collect(Collectors.toList());

					} 
				} else {
					instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
					instances = instances.stream().sorted((o1, o2)->o2.getCreateDate().compareTo(o1.getCreateDate())).collect(Collectors.toList());
				}
				
				
				List<String> catalogColumns = getCatalogColumns();
				htmlTable += "<table class=\"pdf-table\"><tr class=\"bg-clr1\">";
				for (int header = 0; header < catalogColumns.size(); header++) {
					htmlTable +=
							"<td><strong>"+catalogColumns.get(header)+"</strong></td>";
				}
				htmlTable += " </tr>";
				for (CPInstance instance : instances) {

					String partnerName = "";
					try {
						PartnerUsers partnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
						if(partnerUser != null) {
							PartnerMaster partnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partnerUser.getPartnerId());
							partnerName = partnerMaster.getPartnerName();
						}
					} catch(Exception e) {
						log.error(e.getMessage());
					}

					CPDefinition  cpDefinition = CPDefinitionLocalServiceUtil.getCPDefinition(instance.getCPDefinitionId());
					
					PartnerMaster productPartnerMaster = null;
					String partnerNameProduct = "";
					try {
						PartnerUsers productPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
						if(productPartnerUser!=null) {
							productPartnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(productPartnerUser.getPartnerId());
						}
						
						if(productPartnerMaster!=null) {
							partnerNameProduct = productPartnerMaster.getPartnerName();
						}
					} catch(Exception e) {
						log.error(e.getMessage());
					}
					
					
					String[] categories = getProductCategories(cpDefinition.getCPDefinitionId());
					
					htmlTable += "<tr>"
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ instance.getCPInstanceId() + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ instance.getCreateDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ WorkflowConstants.getStatusLabel(instance.getStatus()) + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ instance.getCreateDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ partnerName + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ cpDefinition.getCProductId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ cpDefinition.getName() + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ cpDefinition.getCreateDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ WorkflowConstants.getStatusLabel(cpDefinition.getStatus()) + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ cpDefinition.getCreateDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ partnerNameProduct + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ categories[0] + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ categories[1] + "</td>"
					
					+ "  <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ categories[2] + "</td>";
					

					htmlTable += " </tr>";
				}
				htmlTable += " </table>";
				body = body.replace("[$ITEMDETAILS$]", htmlTable);
				Date today = new Date();
				body = body.replace("[$DATE$]", today.toString());
				body = body.replace("[$REPORTTYPE$]", "Coupon Report");
				if(startingDate!=null) {
					body = body.replace("[$DATERANGE$]", startingDate +" to "+endingDate);

				} else {
					body = body.replace("[$DATERANGE$]","last 24 hours record");

				}
		} catch (

		Exception e) {
			log.error("Exception during invoice generation" + e);
		}
		return body;
	}
	
	public static String[] getProductCategories(Long id) {
		Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
		AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, id);
		StringBuilder category = new StringBuilder();
		StringBuilder categorySub = new StringBuilder();
		StringBuilder categorySubSub = new StringBuilder();
		if(assetEntry!=null && assetEntry.getCategoryIds() != null) {
			for(int i=0;i<assetEntry.getCategoryIds().length;i++) {
				try {
					AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(assetEntry.getCategoryIds()[i]);
					
					if(assetCategory !=null) {
						String treepath = assetCategory.getTreePath();
						if(treepath !=null) {
							String[] categoryArr = treepath.split("/");
							if(categoryArr.length == 3) {
								categorySub.append(assetCategory.getName());	
								categorySub.append("/");
							}
							if(categoryArr.length == 4) {
								categorySubSub.append(assetCategory.getName());
								categorySub.append("/");
								
							}
							if(categoryArr.length == 2) {
								category.append(assetCategory.getName());
								categorySub.append("/");
							}
						}
					}
					
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			
		}
		String categoriesStr = category.toString();
		String categoriesSubStr = categorySub.toString();
		String categoriesSubSubStr = categorySubSub.toString();
		return new String[] {categoriesStr,categoriesSubStr,categoriesSubSubStr};
	}
	
	public static List<String> getCatalogColumns() {
		List<String> catalogColumns = new ArrayList<>();
		catalogColumns.add("SKU ID");
		catalogColumns.add("SKU Request Date");
		catalogColumns.add("SKU Status");
		catalogColumns.add("SKU Creation Date");
		catalogColumns.add("Seller Name");
		catalogColumns.add("Product ID");
		catalogColumns.add("Product Name");
		catalogColumns.add("Product Request Date");
		catalogColumns.add("Product Status");
		catalogColumns.add("Product Creation Date");
		catalogColumns.add("Product Created By");
		catalogColumns.add("Category (L2)");
		catalogColumns.add("Sub-Category (L3)");
		catalogColumns.add("Sub-Sub-Category (L4)");
		
		return catalogColumns;
	}
	private static final Log log = LogFactoryUtil.getLog(CatalogReportGenerator.class);

}
