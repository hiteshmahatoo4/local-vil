package com.vil.admin.report.web.Util;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.model.CommerceOrderItem;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CPInstance;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.commerce.product.service.CPInstanceLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderItemLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.cart.model.VilOrderDetails;
import com.vil.cart.service.VilOrderDetailsLocalServiceUtil;
import com.vil.common.util.GrievanceConstants;
import com.vil.common.util.VilRoleUtil;
import com.vil.customer.model.Customer;
import com.vil.customer.service.CustomerLocalServiceUtil;
import com.vil.grievance.management.model.GrievanceComments;
import com.vil.grievance.management.model.GrievanceMaster;
import com.vil.grievance.management.model.GrievanceTypeMaster;
import com.vil.grievance.management.service.GrievanceCommentsLocalServiceUtil;
import com.vil.grievance.management.service.GrievanceMasterLocalServiceUtil;
import com.vil.grievance.management.service.GrievanceTypeMasterLocalServiceUtil;
import com.vil.partner.model.PartnerMaster;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerMasterLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class GrievanceReportGenerator {
	
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		GrievanceReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		GrievanceReportGenerator.endDate = endDate;
	}
	
	public static byte[] getGrievanceExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		try {

			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet sheet = workbook.createSheet("Greivance Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			// headerFont.setBoldweight((short) 700);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);

			Row headRow = sheet.createRow(0);

			List<String> grievanceColumns = getGrievanceColumn();

			for (int header = 0; header < grievanceColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(grievanceColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}
			Date startDate = null;
			Date endDate = null;
			DynamicQuery grievanceQuery = GrievanceMasterLocalServiceUtil.dynamicQuery();
			List<GrievanceMaster> grievances = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			grievanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					grievanceQuery.add(userRestriction);
					grievances = GrievanceMasterLocalServiceUtil.dynamicQuery(grievanceQuery);
					grievances = grievances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());

				} 
			} else {
				grievances = GrievanceMasterLocalServiceUtil.dynamicQuery(grievanceQuery);
				grievances = grievances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
			}
			
			int index = 1;
			for (GrievanceMaster grievance : grievances) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				
				Cell cell = row.createCell(colIndex); 
				cell.setCellValue(grievance.getId());  // Grievance ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(GrievanceConstants.getStatus(grievance.getStatus()));  // Grievance Status
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getCustomerId());  // Customer ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				String customerName = "";
				try {
					Customer customer = CustomerLocalServiceUtil.findByCustomerID(String.valueOf(grievance.getCustomerId()));
					if(customer !=null) {
						customerName = customer.getFirstName() + " " + customer.getLastName() ;
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(customerName);  // Customer Name
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getCustomerMobileNo());  // Customer Mobile No
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getOrderId());  // Order ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getOrderLineItemId());  // Order Line-Item ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				VilOrderDetails vilOrderDetails = null;
				Date orderFullillmentDate = null;
				long orderItemId = grievance.getOrderLineItemId();
				if(Validator.isNotNull(orderItemId)) {
					try {
						vilOrderDetails = VilOrderDetailsLocalServiceUtil.findByCommerceOrderItemId(orderItemId);
					} catch(Exception e) {
						log.error(e.getMessage());
					}
						if(Validator.isNotNull(vilOrderDetails)) {
						orderFullillmentDate = vilOrderDetails.getFulfilmentDate();
					}
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(orderFullillmentDate);  // Order Fulfilment Date
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				long instanceId = 0,productId = 0;
				CommerceOrderItem commerceOrderItem = null;
				try {
					commerceOrderItem = CommerceOrderItemLocalServiceUtil.getCommerceOrderItem(orderItemId);
					instanceId = commerceOrderItem.getCPInstanceId();
					productId = commerceOrderItem.getCProductId();
				} catch ( Exception e) {
					log.error(e.getMessage());
				}

				Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
				AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, productId);
				long[] categoryIds = new long[]{};
				if(assetEntry != null) {
					categoryIds = AssetEntryAssetCategoryRelLocalServiceUtil.getAssetCategoryPrimaryKeys(assetEntry.getEntryId());
				}
				List<Long> lisCategoryIds = ListUtil.fromArray(categoryIds);
				StringBuilder category = new StringBuilder();
				StringBuilder categorySub = new StringBuilder();
				StringBuilder categorySubSub = new StringBuilder();
				
				for(int i=0;i<lisCategoryIds.size();i++) {
					try {
						AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(lisCategoryIds.get(i));
						if(assetCategory !=null) {
							String treepath = assetCategory.getTreePath();
							if(treepath !=null) {
								String[] categoryArr = treepath.split("/");
								if(categoryArr.length == 3) {
									categorySub.append(assetCategory.getName());									
								}
								if(categoryArr.length == 4) {
									categorySubSub.append(assetCategory.getName());
									
								}
								if(categoryArr.length == 2) {
									category.append(assetCategory.getName());
								}
							}
						}
						
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				
				cell = row.createCell(colIndex);
				cell.setCellValue(instanceId);  // SKU ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(productId);  // Product ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				String productName = "";
				if(commerceOrderItem != null) {
					CPDefinition cpdefinition = CPDefinitionLocalServiceUtil.getCPDefinition(commerceOrderItem.getCPDefinitionId());
					if(cpdefinition !=null) {
						productName = cpdefinition.getName();
					}
				}

				cell = row.createCell(colIndex);
				cell.setCellValue(productName);  // Product Name
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(category.toString());  // Category (L2)
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(categorySub.toString());  // Sub-Category (L3)
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(categorySubSub.toString());  // Sub-Sub-Category (L4)
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getOrderAmount());  // Order Amount
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getOrderLineItemAmount());  // Order Line-Item Amount
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getPartnerId());  // Partner ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				String partnerName = "";
				try {
					PartnerMaster partner = PartnerMasterLocalServiceUtil.getPartnerMaster(grievance.getPartnerId());
					if(partner != null) {
						partnerName = partner.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(partnerName);  // Partner Name
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getCurrentOwnerRoleName());  // Current Owner Role 
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getCurrentOwnerUserId());  // Current Owner User ID
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				String currntUserUsername = "";
				try {
					User currentUser  = UserLocalServiceUtil.getUser(grievance.getCurrentOwnerUserId());
					if(currentUser!=null) {
						currntUserUsername = currentUser.getFullName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(currntUserUsername);  // Current Owner Username
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				GrievanceTypeMaster grievanceParentType =  GrievanceTypeMasterLocalServiceUtil.getGrievanceTypeMaster(grievance.getParentTypeId());
				String grievanceType = "";
				if(grievanceParentType != null) {
					grievanceType = grievanceParentType.getGrievanceType();
				}
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievanceType);  // Grievance Type
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				String grievanceSubTypeValue = "";
				try {
					GrievanceTypeMaster grievanceSubType =  GrievanceTypeMasterLocalServiceUtil.getGrievanceTypeMaster(grievance.getParentTypeId());
					if(grievanceParentType != null) {
						grievanceSubTypeValue = grievanceSubType.getGrievanceType();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				cell = row.createCell(colIndex);
				cell.setCellValue(grievanceSubTypeValue);  // Grievance Sub Type
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				String resolutoinOwner = "";
				String resolutoinDetails = "";
				String resolutoinComment = "";
				String closureComment = "";
				boolean customerFeedback = true;
				try {
					List<GrievanceComments> grievenceComments = GrievanceCommentsLocalServiceUtil.findByGrievanceId(grievance.getId());
					if(grievenceComments != null && grievenceComments.size() > 0) {
						grievenceComments = grievenceComments.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
						GrievanceComments grievanceComment = grievenceComments.get(grievenceComments.size()-1);
						resolutoinDetails = grievanceComment.getResolutionComments();
						long resolutoinOwnerId = grievanceComment.getResolutionOwner();
						resolutoinOwner = String.valueOf(resolutoinOwnerId);
						resolutoinComment = grievanceComment.getResolutionComments();
						customerFeedback = grievanceComment.getCustomerFeedback();
					}

				} catch(Exception e) {
					log.error(e.getMessage());
				}
				
				// TODO: need to check the column value
				cell = row.createCell(colIndex);
				cell.setCellValue(resolutoinDetails);  // Resolution Details
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getCreateDate());  // Raised On
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getDueDate());  // Due Date
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(grievance.getClosureDate());  // Closure Date
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				String ageing = String.valueOf(getDayDiff(grievance.getCreateDate(), new Date()));
				cell = row.createCell(colIndex);
				cell.setCellValue(ageing);  // Ageing
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				
				cell = row.createCell(colIndex);
				cell.setCellValue(resolutoinOwner);  // Resolution Owner
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(resolutoinComment);  // Resolution Comments
				cell.setCellStyle(headerCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(closureComment);  //  Closure Comments  
				cell.setCellStyle(headerCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(customerFeedback);  //  Customer Feedback
				cell.setCellStyle(headerCellStyle);

				
				
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] getGrievanceCSVReportData(ResourceRequest resourceRequest) {

		byte[] outArray = null;
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();
		try {
			StringBuffer data = new StringBuffer();
			List<String> grievanceColumns = getGrievanceColumn();

			for (int header = 0; header < grievanceColumns.size(); header++) {
				data.append(grievanceColumns.get(header));
				data.append(",");
			}
			data.append('\n');
			Date startDate = null;
			Date endDate = null;
			DynamicQuery grievanceQuery = GrievanceMasterLocalServiceUtil.dynamicQuery();
			List<GrievanceMaster> grievances = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			grievanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					grievanceQuery.add(userRestriction);
					grievances = GrievanceMasterLocalServiceUtil.dynamicQuery(grievanceQuery);
					grievances = grievances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());

				} 
			} else {
				grievances = GrievanceMasterLocalServiceUtil.dynamicQuery(grievanceQuery);
				grievances = grievances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
			}
			
			for (GrievanceMaster grievance : grievances) {
				
				data.append(grievance.getId());  // Grievance ID
				data.append(",");
				
				data.append(GrievanceConstants.getStatus(grievance.getStatus()));  // Grievance Status
				data.append(",");
				
				data.append(grievance.getCustomerId());  // Customer ID
				data.append(",");
				
				String customerName = "";
				try {
					Customer customer = CustomerLocalServiceUtil.findByCustomerID(String.valueOf(grievance.getCustomerId()));
					if(customer !=null) {
						customerName = customer.getFirstName() + " " + customer.getLastName() ;
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(customerName);  // Customer Name
				data.append(",");
				
				data.append(grievance.getCustomerMobileNo());  // Customer Mobile No
				data.append(",");
				
				data.append(grievance.getOrderId());  // Order ID
				data.append(",");
				
				data.append(grievance.getOrderLineItemId());  // Order Line-Item ID
				data.append(",");
				
				VilOrderDetails vilOrderDetails = null;
				Date orderFullillmentDate = null;
				long orderItemId = grievance.getOrderLineItemId();
				if(Validator.isNotNull(orderItemId)) {
					try {
						vilOrderDetails = VilOrderDetailsLocalServiceUtil.findByCommerceOrderItemId(orderItemId);
					} catch(Exception e) {
						log.error(e.getMessage());
					}
						if(Validator.isNotNull(vilOrderDetails)) {
						orderFullillmentDate = vilOrderDetails.getFulfilmentDate();
					}
				}
				data.append(orderFullillmentDate);  // Order Fulfilment Date
				data.append(",");
				
				long instanceId = 0,productId = 0;
				CommerceOrderItem commerceOrderItem = null;
				try {
					commerceOrderItem = CommerceOrderItemLocalServiceUtil.getCommerceOrderItem(orderItemId);
					instanceId = commerceOrderItem.getCPInstanceId();
					productId = commerceOrderItem.getCProductId();
				} catch ( Exception e) {
					log.error(e.getMessage());
				}

				Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
				AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, productId);
				long[] categoryIds = new long[]{};
				if(assetEntry != null) {
					categoryIds = AssetEntryAssetCategoryRelLocalServiceUtil.getAssetCategoryPrimaryKeys(assetEntry.getEntryId());
				}
				List<Long> lisCategoryIds = ListUtil.fromArray(categoryIds);
				StringBuilder category = new StringBuilder();
				StringBuilder categorySub = new StringBuilder();
				StringBuilder categorySubSub = new StringBuilder();
				
				for(int i=0;i<lisCategoryIds.size();i++) {
					try {
						AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(lisCategoryIds.get(i));
						if(assetCategory !=null) {
							String treepath = assetCategory.getTreePath();
							if(treepath !=null) {
								String[] categoryArr = treepath.split("/");
								if(categoryArr.length == 3) {
									categorySub.append(assetCategory.getName());									
								}
								if(categoryArr.length == 4) {
									categorySubSub.append(assetCategory.getName());
									
								}
								if(categoryArr.length == 2) {
									category.append(assetCategory.getName());
								}
							}
						}
						
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				
				data.append(instanceId);  // SKU ID
				data.append(",");
				
				data.append(productId);  // Product ID
				data.append(",");
				
				String productName = "";
				if(commerceOrderItem != null) {
					CPDefinition cpdefinition = CPDefinitionLocalServiceUtil.getCPDefinition(commerceOrderItem.getCPDefinitionId());
					if(cpdefinition !=null) {
						productName = cpdefinition.getName();
					}
				}

				data.append(productName);  // Product Name
				data.append(",");
				
				data.append(category.toString());  // Category (L2)
				data.append(",");
				
				data.append(categorySub.toString());  // Sub-Category (L3)
				data.append(",");
				
				data.append(categorySubSub.toString());  // Sub-Sub-Category (L4)
				data.append(",");
				
				data.append(grievance.getOrderAmount());  // Order Amount
				data.append(",");
				
				data.append(grievance.getOrderLineItemAmount());  // Order Line-Item Amount
				data.append(",");
				
				data.append(grievance.getPartnerId());  // Partner ID
				data.append(",");
				
				String partnerName = "";
				try {
					PartnerMaster partner = PartnerMasterLocalServiceUtil.getPartnerMaster(grievance.getPartnerId());
					if(partner != null) {
						partnerName = partner.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(partnerName);  // Partner Name
				data.append(",");
				
				data.append(grievance.getCurrentOwnerRoleName());  // Current Owner Role 
				data.append(",");
				
				data.append(grievance.getCurrentOwnerUserId());  // Current Owner User ID
				data.append(",");
				
				String currntUserUsername = "";
				try {
					User currentUser  = UserLocalServiceUtil.getUser(grievance.getCurrentOwnerUserId());
					if(currentUser!=null) {
						currntUserUsername = currentUser.getFullName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(currntUserUsername);  // Current Owner Username
				data.append(",");
				
				GrievanceTypeMaster grievanceParentType =  GrievanceTypeMasterLocalServiceUtil.getGrievanceTypeMaster(grievance.getParentTypeId());
				String grievanceType = "";
				if(grievanceParentType != null) {
					grievanceType = grievanceParentType.getGrievanceType();
				}
				
				data.append(grievanceType);  // Grievance Type
				data.append(",");
				
				String grievanceSubTypeValue = "";
				try {
					GrievanceTypeMaster grievanceSubType =  GrievanceTypeMasterLocalServiceUtil.getGrievanceTypeMaster(grievance.getParentTypeId());
					if(grievanceParentType != null) {
						grievanceSubTypeValue = grievanceSubType.getGrievanceType();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(grievanceSubTypeValue);  // Grievance Sub Type
				data.append(",");
				
				String resolutoinOwner = "";
				String resolutoinDetails = "";
				String resolutoinComment = "";
				String closureComment = "";
				boolean customerFeedback = true;
				try {
					List<GrievanceComments> grievenceComments = GrievanceCommentsLocalServiceUtil.findByGrievanceId(grievance.getId());
					if(grievenceComments != null && grievenceComments.size() > 0) {
						grievenceComments = grievenceComments.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
						GrievanceComments grievanceComment = grievenceComments.get(grievenceComments.size()-1);
						resolutoinDetails = grievanceComment.getResolutionComments();
						long resolutoinOwnerId = grievanceComment.getResolutionOwner();
						resolutoinOwner = String.valueOf(resolutoinOwnerId);
						resolutoinComment = grievanceComment.getResolutionComments();
						customerFeedback = grievanceComment.getCustomerFeedback();
					}

				} catch(Exception e) {
					log.error(e.getMessage());
				}
				
				// TODO: need to check the column value
				data.append(resolutoinDetails);  // Resolution Details
				data.append(",");
				
				data.append(grievance.getCreateDate());  // Raised On
				data.append(",");
				
				data.append(grievance.getDueDate());  // Due Date
				data.append(",");
				
				data.append(grievance.getClosureDate());  // Closure Date
				data.append(",");
				
				String ageing = String.valueOf(getDayDiff(grievance.getCreateDate(), new Date()));
				data.append(ageing);  // Ageing
				data.append(",");
				
				
				data.append(resolutoinOwner);  // Resolution Owner
				data.append(",");
				
				data.append(resolutoinComment);  // Resolution Comments
				data.append(",");

				data.append(closureComment);  //  Closure Comments  
				data.append(",");
				
				data.append(customerFeedback);  //  Customer Feedback
				data.append(",");
            
                data.append('\n');
            }
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] generateGrievancePdf(String htmlContent,ResourceRequest resourceRequest) {
		String value = htmlContent;
		String body = replaceValue(value,resourceRequest);

		FileOutputStream fileOutputStream = null;
		try {
			String fileName = ""+new Date().getTime();
			File certificateFile = File.createTempFile(fileName, ".pdf");
			ConverterProperties properties = new ConverterProperties();
			fileOutputStream = new FileOutputStream(certificateFile);
			PdfDocument pdfDocument = new PdfDocument(new PdfWriter(certificateFile));
			pdfDocument.setDefaultPageSize(new PageSize(4500,2384));
			HtmlConverter.convertToPdf(body, pdfDocument, properties);
			FileInputStream fl = new FileInputStream(certificateFile);
	        byte[] arr = new byte[(int)certificateFile.length()];
	        fl.read(arr);
	        return arr;
		} catch (Exception e) {
			log.error(e);
			log.error("Exception during coupo pdf" + e);
			return null;
		} finally {
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					log.error("Exception during coupon pdf" + e);
					return null;
				}
			}
		}
	}
	
	private static String replaceValue(String body,ResourceRequest resourceRequest) {
		try {
				ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

				String htmlTable="";
				String startingDate = getStartDate();
				String endingDate = getEndDate();
				Date startDate = null;
				Date endDate = null;
				DynamicQuery grievanceQuery = GrievanceMasterLocalServiceUtil.dynamicQuery();
				List<GrievanceMaster> grievances = null;
				if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
					LocalDateTime localEndDate = LocalDateTime.now();
					LocalDateTime localStartDate = localEndDate.minusHours(24);
					Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
					endDate = Date.from(instant);
					instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
					startDate = Date.from(instant);
				} else {
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
					Date startDateTemp = dateFormatter.parse(startingDate);
					startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

					Date endDateTemp = dateFormatter.parse(endingDate);
					endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
				}
				
				grievanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));

				if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
					PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
					DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
					userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
					List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
					
					if(!partnerUsers.isEmpty()) {
						Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
						for(int i=1;i<partnerUsers.size();i++) {
							userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
						}
						grievanceQuery.add(userRestriction);
						grievances = GrievanceMasterLocalServiceUtil.dynamicQuery(grievanceQuery);
						grievances = grievances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());

					} 
				} else {
					grievances = GrievanceMasterLocalServiceUtil.dynamicQuery(grievanceQuery);
					grievances = grievances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
				}
				
				
				List<String> grievanceColumns = getGrievanceColumn();
				htmlTable += "<table class=\"pdf-table\"><tr class=\"bg-clr1\">";
				for (int header = 0; header < grievanceColumns.size(); header++) {
					htmlTable +=
							"<td><strong>"+grievanceColumns.get(header)+"</strong></td>";
				}
				htmlTable += " </tr>";
				for (GrievanceMaster grievance : grievances) {
					
					String customerName = "";
					try {
						Customer customer = CustomerLocalServiceUtil.findByCustomerID(String.valueOf(grievance.getCustomerId()));
						if(customer !=null) {
							customerName = customer.getFirstName() + " " + customer.getLastName() ;
						}
					} catch(Exception e) {
						log.error(e.getMessage());
					}
					
					VilOrderDetails vilOrderDetails = null;
					Date orderFullillmentDate = null;
					long orderItemId = grievance.getOrderLineItemId();
					if(Validator.isNotNull(orderItemId)) {
						try {
							vilOrderDetails = VilOrderDetailsLocalServiceUtil.findByCommerceOrderItemId(orderItemId);
						} catch(Exception e) {
							log.error(e.getMessage());
						}
							if(Validator.isNotNull(vilOrderDetails)) {
							orderFullillmentDate = vilOrderDetails.getFulfilmentDate();
						}
					}
					
					long instanceId = 0,productId = 0;
					CommerceOrderItem commerceOrderItem = null;
					try {
						commerceOrderItem = CommerceOrderItemLocalServiceUtil.getCommerceOrderItem(orderItemId);
						instanceId = commerceOrderItem.getCPInstanceId();
						productId = commerceOrderItem.getCProductId();
					} catch ( Exception e) {
						log.error(e.getMessage());
					}

					Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
					AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, productId);
					long[] categoryIds = new long[]{};
					if(assetEntry != null) {
						categoryIds = AssetEntryAssetCategoryRelLocalServiceUtil.getAssetCategoryPrimaryKeys(assetEntry.getEntryId());
					}
					List<Long> lisCategoryIds = ListUtil.fromArray(categoryIds);
					StringBuilder category = new StringBuilder();
					StringBuilder categorySub = new StringBuilder();
					StringBuilder categorySubSub = new StringBuilder();
					
					for(int i=0;i<lisCategoryIds.size();i++) {
						try {
							AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(lisCategoryIds.get(i));
							if(assetCategory !=null) {
								String treepath = assetCategory.getTreePath();
								if(treepath !=null) {
									String[] categoryArr = treepath.split("/");
									if(categoryArr.length == 3) {
										categorySub.append(assetCategory.getName());									
									}
									if(categoryArr.length == 4) {
										categorySubSub.append(assetCategory.getName());
										
									}
									if(categoryArr.length == 2) {
										category.append(assetCategory.getName());
									}
								}
							}
							
						} catch(Exception e) {
							e.printStackTrace();
						}
					}

					
					String productName = "";
					if(commerceOrderItem != null) {
						CPDefinition cpdefinition = CPDefinitionLocalServiceUtil.getCPDefinition(commerceOrderItem.getCPDefinitionId());
						if(cpdefinition !=null) {
							productName = cpdefinition.getName();
						}
					}

					String partnerName = "";
					try {
						PartnerMaster partner = PartnerMasterLocalServiceUtil.getPartnerMaster(grievance.getPartnerId());
						if(partner != null) {
							partnerName = partner.getPartnerName();
						}
					} catch(Exception e) {
						log.error(e.getMessage());
					}
				
					String currntUserUsername = "";
					try {
						User currentUser  = UserLocalServiceUtil.getUser(grievance.getCurrentOwnerUserId());
						if(currentUser!=null) {
							currntUserUsername = currentUser.getFullName();
						}
					} catch(Exception e) {
						log.error(e.getMessage());
					}
				
					
					GrievanceTypeMaster grievanceParentType =  GrievanceTypeMasterLocalServiceUtil.getGrievanceTypeMaster(grievance.getParentTypeId());
					String grievanceType = "";
					if(grievanceParentType != null) {
						grievanceType = grievanceParentType.getGrievanceType();
					}
					
					
					
					String grievanceSubTypeValue = "";
					try {
						GrievanceTypeMaster grievanceSubType =  GrievanceTypeMasterLocalServiceUtil.getGrievanceTypeMaster(grievance.getParentTypeId());
						if(grievanceParentType != null) {
							grievanceSubTypeValue = grievanceSubType.getGrievanceType();
						}
					} catch(Exception e) {
						log.error(e.getMessage());
					}
					
					
					String resolutoinOwner = "";
					String resolutoinDetails = "";
					String resolutoinComment = "";
					String closureComment = "";
					boolean customerFeedback = true;
					try {
						List<GrievanceComments> grievenceComments = GrievanceCommentsLocalServiceUtil.findByGrievanceId(grievance.getId());
						if(grievenceComments != null && grievenceComments.size() > 0) {
							grievenceComments = grievenceComments.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
							GrievanceComments grievanceComment = grievenceComments.get(grievenceComments.size()-1);
							resolutoinDetails = grievanceComment.getResolutionComments();
							long resolutoinOwnerId = grievanceComment.getResolutionOwner();
							resolutoinOwner = String.valueOf(resolutoinOwnerId);
							resolutoinComment = grievanceComment.getResolutionComments();
							customerFeedback = grievanceComment.getCustomerFeedback();
						}

					} catch(Exception e) {
						log.error(e.getMessage());
					}
					
					String ageing = String.valueOf(getDayDiff(grievance.getCreateDate(), new Date()));

					
					htmlTable += "<tr>"
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ GrievanceConstants.getStatus(grievance.getStatus()) + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getCustomerId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ customerName + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getCustomerMobileNo() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getOrderId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getOrderLineItemId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ orderFullillmentDate + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ instanceId + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ productId + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ productName + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ category + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ categorySub.toString() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ categorySubSub.toString() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getOrderAmount() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getOrderLineItemAmount() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getPartnerId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ partnerName + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getCurrentOwnerRoleName() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getCurrentOwnerUserId() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ currntUserUsername + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievanceType + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievanceSubTypeValue + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ resolutoinDetails + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getCreateDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getDueDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ grievance.getClosureDate() + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ ageing + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ resolutoinOwner + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ resolutoinComment + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ closureComment + "</td>"
					
					+ " <td style='border-bottom:1px solid #2f3043;text-align:left;padding: 15px 8px;font-size:16px;text-align:left;padding: 15px 8px;font-size:16px'>"
					+ customerFeedback + "</td>";

					htmlTable += " </tr>";
				}
				htmlTable += " </table>";
				body = body.replace("[$ITEMDETAILS$]", htmlTable);
				Date today = new Date();
				body = body.replace("[$DATE$]", today.toString());
				body = body.replace("[$REPORTTYPE$]", "Coupon Report");

		} catch (

		Exception e) {
			log.error("Exception during invoice generation" + e);
		}
		return body;
	}
	
	public static List<String> getGrievanceColumn() {
		List<String> grievanceColumns = new ArrayList<>();
		grievanceColumns.add("Grievance ID");
		grievanceColumns.add("Grievance Status");
		grievanceColumns.add("Customer ID");
		grievanceColumns.add("Customer Name");
		grievanceColumns.add("Customer Mobile No");
		grievanceColumns.add("Order ID");
		grievanceColumns.add("Order Line-Item ID");
		grievanceColumns.add("Order Fulfilment Date");
		grievanceColumns.add("SKU ID");
		grievanceColumns.add("Product ID");
		grievanceColumns.add("Product Name");
		grievanceColumns.add("Category (L2)");
		grievanceColumns.add("Sub-Category (L3)");
		grievanceColumns.add("Sub-Sub-Category (L4)");
		grievanceColumns.add("Order Amount");
		grievanceColumns.add("Order Line-Item Amount");
		grievanceColumns.add("Partner ID");
		grievanceColumns.add("Partner Name");
		grievanceColumns.add("Current Owner Role ");
		grievanceColumns.add("Current Owner User ID");
		grievanceColumns.add("Current Owner Username");
		grievanceColumns.add("Grievance Type");
		grievanceColumns.add("Grievance Sub Type");
		grievanceColumns.add("Resolution Details");
		grievanceColumns.add("Raised On");
		grievanceColumns.add("Due Date");
		grievanceColumns.add("Closure Date");
		grievanceColumns.add("Ageing");
		grievanceColumns.add("Resolution Owner");
		grievanceColumns.add("Resolution Comments ");
		grievanceColumns.add("Customer Closure Comments ");
		grievanceColumns.add("Customer Feedback ");
		
		
		return grievanceColumns;
	}
	
	public static long getDayDiff(Date beforeDate, Date afterDate) {
		LocalDate createDate = LocalDate.of(beforeDate.getYear(), beforeDate.getMonth()+1, beforeDate.getDate());
		LocalDate currentDate = LocalDate.of(afterDate.getYear(), afterDate.getMonth()+1, afterDate.getDate());
		Period period = Period.between(createDate, currentDate);
		
	    long years = period.getYears();
	    long months = period.getMonths();
	    long days = period.getDays();

	    return (years*365)+(months*30)+days;
	}

	private static final Log log = LogFactoryUtil.getLog(GrievanceReportGenerator.class);

}
