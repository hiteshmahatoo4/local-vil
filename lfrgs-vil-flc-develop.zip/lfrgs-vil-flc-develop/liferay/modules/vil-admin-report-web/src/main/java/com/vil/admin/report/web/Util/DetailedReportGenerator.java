package com.vil.admin.report.web.Util;

import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.constants.CommerceOrderConstants;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.model.CommerceOrderItem;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CPInstance;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.commerce.product.service.CPInstanceLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderItemLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Address;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.AddressLocalServiceUtil;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.cart.model.VilOrderDetails;
import com.vil.cart.service.VilOrderDetailsLocalServiceUtil;
import com.vil.common.util.VilRoleUtil;
import com.vil.partner.model.PartnerMaster;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerMasterLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class DetailedReportGenerator {
	
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		DetailedReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		DetailedReportGenerator.endDate = endDate;
	}

	public static byte[] getDetailExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();
		
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		try {

			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet sheet = workbook.createSheet("Catalog Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			// headerFont.setBoldweight((short) 700);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);

			Row headRow = sheet.createRow(0);

			List<String> catalogColumns = getDetailedReportColumns();

			for (int header = 0; header < catalogColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(catalogColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}
			Date startDate = null;
			Date endDate = null;
			DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
			List<CommerceOrder> commerceOrders = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			orderQuery.add(RestrictionsFactoryUtil.between("orderDate",startDate, endDate));
			orderQuery.add(RestrictionsFactoryUtil.ne("orderStatus", CommerceOrderConstants.ORDER_STATUS_OPEN));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					orderQuery.add(userRestriction);
					commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
					commerceOrders = commerceOrders.stream().sorted((o2, o1)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());

				} 
			} else {
				commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
				commerceOrders = commerceOrders.stream().sorted((o2, o1)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());
			}
			int index = 1;
			for (CommerceOrder commerceOrder : commerceOrders) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;
				List<VilOrderDetails> vilOrderDetails =  VilOrderDetailsLocalServiceUtil.findByCommerceOrderId(commerceOrder.getCommerceOrderId());
				// need to check
				Date fullFillmentDate = null;
				int fullFillmentStatus = 0;
				String orderfullFillmentStatus = "NaN";
				if(!vilOrderDetails.isEmpty()) {
					for(VilOrderDetails orderDetails : vilOrderDetails) {
						fullFillmentDate = orderDetails.getFulfilmentDate();
						orderfullFillmentStatus = orderDetails.getStatus();
						
						
						
						Cell cell = row.createCell(colIndex);
						cell.setCellValue(commerceOrder.getCommerceOrderId());
						cell.setCellStyle(defaultCellStyle);
						colIndex++;

						cell = row.createCell(colIndex);
						cell.setCellValue(commerceOrder.getOrderDate());
						cell.setCellStyle(defaultCellStyle);
						colIndex++;

						cell = row.createCell(colIndex);
						cell.setCellValue(CommerceOrderConstants.getOrderStatusLabel(commerceOrder.getOrderStatus()));
						cell.setCellStyle(defaultCellStyle);
						colIndex++;

						// need to check
						cell = row.createCell(colIndex);
						cell.setCellValue(orderfullFillmentStatus);
						cell.setCellStyle(defaultCellStyle);
						colIndex++;

						// need to check
						cell = row.createCell(colIndex);
						cell.setCellValue(fullFillmentDate);
						cell.setCellStyle(defaultCellStyle);
						colIndex++;

						User user = UserLocalServiceUtil.getUser(commerceOrder.getUserId());
						cell = row.createCell(colIndex);
						cell.setCellValue(user.getFirstName() + " " + user.getLastName()); // customer name
						cell.setCellStyle(defaultCellStyle);
						colIndex++;

						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getMobileNo()); // customer mobile number
						cell.setCellStyle(defaultCellStyle);
						colIndex++;

						cell = row.createCell(colIndex);
						cell.setCellValue(user.getEmailAddress()); // Customer Email Address
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getCommerceOrderItemId()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						String productName = "";
						Long productId = 0L;
						String sellerName = "";
						String skuId = "";
						int quantity = 0;
						String category = "";
						String subCategory = "";
						String subSubCategory = "";
						BigDecimal orderTotal = new BigDecimal(0);
						BigDecimal orderDiscount = new BigDecimal(0);
						BigDecimal orderTax = new BigDecimal(0);
						CommerceOrderItem orderItem = CommerceOrderItemLocalServiceUtil.getCommerceOrderItem(orderDetails.getCommerceOrderItemId());
						String itemShippingAddressStr = "";
						String offerApplied = "No";
						if(orderItem != null) {
							productName = orderItem.getCPDefinition().getName();
							productId = orderItem.getCPDefinition().getCProductId();
							CPInstance cpInstance = orderItem.getCPInstance();
							quantity = orderItem.getQuantity();
							orderTotal = orderItem.getFinalPrice();
							orderDiscount = orderItem.getDiscountAmount();
							orderTax = orderItem.getFinalPriceWithTaxAmount().subtract(orderItem.getFinalPrice());
							Long shippingAddressId = orderItem.getShippingAddressId();
							Address itemShippingAddress = AddressLocalServiceUtil.getAddress(shippingAddressId);
							itemShippingAddressStr = itemShippingAddress.getCity() + " " + itemShippingAddress.getZip() + " " + itemShippingAddress.getCountry();
							
							if(orderDiscount.compareTo(new BigDecimal(0)) !=0 ) {
								offerApplied = "Yes";
							}
							
							if(cpInstance != null ) {
								try {
									PartnerUsers partnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(cpInstance.getCPInstanceId());
									if(partnerUser != null) {
										PartnerMaster partnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partnerUser.getPartnerId());
										sellerName = partnerMaster.getPartnerName();
									}
								} catch(Exception e) {
									log.error(e.getMessage());
								}
								
								skuId = cpInstance.getSku();
								
								String[] categories = getProductCategories(cpInstance.getCPDefinitionId());
								category = categories[0];
								subCategory = categories[0];
								subSubCategory = categories[0];
							}
							
							
						}
						
						cell = row.createCell(colIndex);
						cell.setCellValue(productId); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(productName); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(skuId); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(sellerName); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(category); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(subCategory); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(subSubCategory); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						
						cell = row.createCell(colIndex);
						cell.setCellValue(quantity); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderTotal.toString()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDiscount.toString()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getCgstAmount()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getSgstAmount()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getIgstAmount()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getIgstAmount()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderTax.toString()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Vi Commission"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("GST TCS @1%"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("TDS 194 (O) @1%"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(commerceOrder.getShippingAmount().toString());  // Order shipping charge (if any)
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(commerceOrder.getTotal().toString());  // Order Total
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						

						cell = row.createCell(colIndex);
						cell.setCellValue(commerceOrder.getBillingAddress().toString()); // Billing Address (At order level)
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Customer GSTIN Number"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Business Name"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Business Address"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Beneficiary Name"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Beneficiary Mobile No"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Beneficiary Email Address"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(itemShippingAddressStr);  // Shipping Address (for each line item)
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(offerApplied);  // "Offers Applied (for individual line item)"
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Average Rating"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Total No of reviews"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Subscription End Date (for individual line item - if applicable)"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getCouponKey());  // "Reverse Coupon Code (if applicable)"
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Eligible Return Date (for individual line item - if applicable)"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getStatus()); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue(orderDetails.getFulfilmentDate());  // "Order Line-Item Fulfilment Date and Time"
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						
						// TODO: columns data needs to add
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment (Transaction) Status"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment Date"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment Time"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment Channel"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment Gateway"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Gateway Transaction Id"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment Mode"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment Method Type"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Card Issuer"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Payment Method"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
						
						cell = row.createCell(colIndex);
						cell.setCellValue("Card Type"); 
						cell.setCellStyle(defaultCellStyle);
						colIndex++;
					}
				}
				
				
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}

	public static byte[] getCatalogCSVReportData(ResourceRequest resourceRequest) {

		byte[] outArray = null;
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();

		try {
			StringBuffer data = new StringBuffer();
			List<String> catalogColumns = getDetailedReportColumns();

			for (int header = 0; header < catalogColumns.size(); header++) {
				data.append(catalogColumns.get(header));
				data.append(",");
				
				
			}
			data.append('\n');
			Date startDate = null;
			Date endDate = null;
			DynamicQuery instanceQuery = CPInstanceLocalServiceUtil.dynamicQuery();
			List<CPInstance> instances = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			instanceQuery.add(RestrictionsFactoryUtil.between("createDate",startDate, endDate));
			
			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					instanceQuery.add(userRestriction);
					instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
					instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());

				} 
			} else {
				instances = CPInstanceLocalServiceUtil.dynamicQuery(instanceQuery);
				instances = instances.stream().sorted((o1, o2)->o1.getCreateDate().compareTo(o2.getCreateDate())).collect(Collectors.toList());
			}
			int index = 1;
			for (CPInstance instance : instances) {

				
				data.append(instance.getCPInstanceId());
				data.append(",");

				data.append(instance.getCreateDate());
				data.append(",");
				
				data.append(WorkflowConstants.getStatusLabel(instance.getStatus()));
				data.append(",");

				data.append(instance.getCreateDate());
				data.append(",");

				String partnerName = "";
				try {
					PartnerUsers partnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
					if(partnerUser != null) {
						PartnerMaster partnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(partnerUser.getPartnerId());
						partnerName = partnerMaster.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(partnerName);
				data.append(",");

				CPDefinition  cpDefinition = CPDefinitionLocalServiceUtil.getCPDefinition(instance.getCPDefinitionId());
				data.append(cpDefinition.getCProductId()); 
				data.append(",");

				data.append(cpDefinition.getName()); 
				data.append(",");

				data.append(cpDefinition.getCreateDate()); 
				data.append(",");

				data.append(WorkflowConstants.getStatusLabel(cpDefinition.getStatus())); // Order Subtotal
				data.append(",");

				data.append(cpDefinition.getCreateDate()); 
				data.append(",");


				PartnerMaster productPartnerMaster = null;
				String partnerNameProduct = "";
				try {
					PartnerUsers productPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(instance.getUserId());
					if(productPartnerUser!=null) {
						productPartnerMaster = PartnerMasterLocalServiceUtil.getPartnerMaster(productPartnerUser.getPartnerId());
					}
					
					if(productPartnerMaster!=null) {
						partnerNameProduct = productPartnerMaster.getPartnerName();
					}
				} catch(Exception e) {
					log.error(e.getMessage());
				}
				data.append(partnerNameProduct);
				data.append(",");
				
				Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
				AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, cpDefinition.getCProductId());
				long[] categoryIds = new long[]{};
				if(assetEntry != null) {
					categoryIds = AssetEntryAssetCategoryRelLocalServiceUtil.getAssetCategoryPrimaryKeys(136108L);
				}

				List<Long> lisCategoryIds = ListUtil.fromArray(categoryIds);
				StringBuilder category = new StringBuilder();
				StringBuilder categorySub = new StringBuilder();
				StringBuilder categorySubSub = new StringBuilder();
				
				for(int i=0;i<lisCategoryIds.size();i++) {
					try {
						AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(lisCategoryIds.get(i));
						
						if(assetCategory !=null) {
							String treepath = assetCategory.getTreePath();
							if(treepath !=null) {
								String[] categoryArr = treepath.split("/");
								if(categoryArr.length == 3) {
									categorySub.append(assetCategory.getName());									
								}
								if(categoryArr.length == 4) {
									categorySubSub.append(assetCategory.getName());
									
								}
								if(categoryArr.length == 2) {
									category.append(assetCategory.getName());
								}
							}
						}
						
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				String categoriesStr = category.toString();
				String categoriesSubStr = categorySub.toString();
				String categoriesSubSubStr = categorySubSub.toString();
				data.append(categoriesStr);  // "Category (L2)"
				data.append(",");

				data.append(categoriesSubStr);  // "Sub-Category (L3)"
				data.append(",");
				
				data.append(categoriesSubSubStr);  // "Sub-Sub-Category (L4)"
				data.append(",");
				
                data.append('\n');
            }
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] generateCatalogPdf() {
		return null;
	}
	
	public static String[] getProductCategories(Long id) {
		Long classId = ClassNameLocalServiceUtil.getClassNameId(CPDefinition.class.getName());
		AssetEntry assetEntry = AssetEntryLocalServiceUtil.fetchEntry(classId, id);
		StringBuilder category = new StringBuilder();
		StringBuilder categorySub = new StringBuilder();
		StringBuilder categorySubSub = new StringBuilder();
		if(assetEntry!=null && assetEntry.getCategoryIds() != null) {
			for(int i=0;i<assetEntry.getCategoryIds().length;i++) {
				try {
					AssetCategory assetCategory = AssetCategoryLocalServiceUtil.getAssetCategory(assetEntry.getCategoryIds()[i]);
					
					if(assetCategory !=null) {
						String treepath = assetCategory.getTreePath();
						if(treepath !=null) {
							String[] categoryArr = treepath.split("/");
							if(categoryArr.length == 3) {
								categorySub.append(assetCategory.getName());	
								categorySub.append("/");
							}
							if(categoryArr.length == 4) {
								categorySubSub.append(assetCategory.getName());
								categorySub.append("/");
								
							}
							if(categoryArr.length == 2) {
								category.append(assetCategory.getName());
								categorySub.append("/");
							}
						}
					}
					
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			
		}
		String categoriesStr = category.toString();
		String categoriesSubStr = categorySub.toString();
		String categoriesSubSubStr = categorySubSub.toString();
		return new String[] {categoriesStr,categoriesSubStr,categoriesSubSubStr};
	}
	
	public static List<String> getDetailedReportColumns() {
		List<String> detailReportColumns = new ArrayList<>();


		detailReportColumns.add("Order ID");
		detailReportColumns.add("Order Date");
		detailReportColumns.add("Order Status");
		detailReportColumns.add("Order Fulfilment Status");
		detailReportColumns.add("Order Fulfilment Date and Time");
		detailReportColumns.add("Customer Name");
		detailReportColumns.add("Customer Mobile Number");
		detailReportColumns.add("Customer Email Address");
		detailReportColumns.add("Order Line-Item ID");		
		detailReportColumns.add("Product ID");
		detailReportColumns.add("Product Name");
		detailReportColumns.add("SKU ID");
		detailReportColumns.add("Seller Name");
		detailReportColumns.add("Category (L2)");
		detailReportColumns.add("Sub-Category (L3)");
		detailReportColumns.add("Sub-Sub-Category (L4)");
		detailReportColumns.add("Quantity");
		detailReportColumns.add("Listed Amount (MRP)");
		detailReportColumns.add("Order Line-Item Total");
		detailReportColumns.add("Order Line-Item Status");
		detailReportColumns.add("Order Subtotal");
		detailReportColumns.add("Discount");
		detailReportColumns.add("CGST");
		detailReportColumns.add("SGST");
		detailReportColumns.add("IGST");
		detailReportColumns.add("Total Taxes");
		detailReportColumns.add("Vi Commission");
		detailReportColumns.add("GST TCS @1%");
		detailReportColumns.add("TDS 194 (O) @1%");
		detailReportColumns.add("Order shipping charge (if any)");
		detailReportColumns.add("Order Total");
		detailReportColumns.add("Billing Address (At order level)");
		detailReportColumns.add("Customer GSTIN Number");
		detailReportColumns.add("Business Name");
		detailReportColumns.add("Business Address");
		detailReportColumns.add("Beneficiary Name");
		detailReportColumns.add("Beneficiary Mobile No");
		detailReportColumns.add("Beneficiary Email Address");
		detailReportColumns.add("Shipping Address (for each line item)");
		detailReportColumns.add("Offers Applied (for individual line item)");
		detailReportColumns.add("Average Rating");
		detailReportColumns.add("Total No of reviews");
		detailReportColumns.add("Subscription End Date (for individual line item - if applicable)");
		detailReportColumns.add("Reverse Coupon Code (if applicable)");
		detailReportColumns.add("Eligible Return Date (for individual line item - if applicable)");
		detailReportColumns.add("Order Line-Item Fulfilment Status");
		detailReportColumns.add("Order Line-Item Fulfilment Date and Time");
		detailReportColumns.add("Payment (Transaction) Status");
		detailReportColumns.add("Payment Date");
		detailReportColumns.add("Payment Time");
		detailReportColumns.add("Payment Channel");
		detailReportColumns.add("Payment Gateway");
		detailReportColumns.add("Gateway Transaction Id");
		detailReportColumns.add("Payment Mode");
		detailReportColumns.add("Payment Method Type");
		detailReportColumns.add("Card Issuer");
		detailReportColumns.add("Payment Method");
		detailReportColumns.add("Card Type");
		
		
		return detailReportColumns;
	}
	private static final Log log = LogFactoryUtil.getLog(DetailedReportGenerator.class);

}
