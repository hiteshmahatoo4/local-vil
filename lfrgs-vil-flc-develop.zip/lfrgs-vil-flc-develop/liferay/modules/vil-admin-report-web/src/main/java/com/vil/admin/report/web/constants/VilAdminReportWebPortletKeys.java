package com.vil.admin.report.web.constants;

/**
 * @author Deepak Patidar
 */
public class VilAdminReportWebPortletKeys {

	public static final String VILADMINREPORTWEB =
		"com_vil_admin_report_web_VilAdminReportWebPortlet";
	
	public static final String ORDER_EXCEL_FILE_NAME = "order-report.xlsx";
	public static final String ORDER_CSV_FILE_NAME = "order-report.csv";
	public static final String ORDER_PDF_FILE_NAME = "order-report.pdf";
	
	public static final String CATALOG_EXCEL_FILE_NAME = "catalog-report.xlsx";
	public static final String CATALOG_CSV_FILE_NAME = "catalog-report.csv";
	public static final String CATALOG_PDF_FILE_NAME = "catalog-report.pdf";
	
	public static final String COUPON_EXCEL_FILE_NAME = "coupon-report.xlsx";
	public static final String COUPON_CSV_FILE_NAME = "coupon-report.csv";
	public static final String COUPON_PDF_FILE_NAME = "coupon-report.pdf";
	
	public static final String PARTNER_EXCEL_FILE_NAME = "partner-report.xlsx";
	public static final String PARTNER_CSV_FILE_NAME = "partner-report.csv";
	public static final String PARTNER_PDF_FILE_NAME = "partner-report.pdf";
	
	public static final String GRIEVANCE_EXCEL_FILE_NAME = "grievance-report.xlsx";
	public static final String GRIEVANCE_CSV_FILE_NAME = "grievance-report.csv";
	public static final String GRIEVANCE_PDF_FILE_NAME = "grievance-report.pdf";
	
	public static final String SALES_EXCEL_FILE_NAME = "sales-report.xlsx";
	public static final String SALES_CSV_FILE_NAME = "sales-report.csv";
	public static final String SALES_PDF_FILE_NAME = "sales-report.pdf";
	
	public static final String RETURN_EXCEL_FILE_NAME = "return-report.xlsx";
	public static final String RETURN_CSV_FILE_NAME = "return-report.csv";
	public static final String RETURN_PDF_FILE_NAME = "return-report.pdf";
	
	public static final String DETAILED_EXCEL_FILE_NAME = "detailed-report.xlsx";
	public static final String DETAILED_CSV_FILE_NAME = "detailed-report.csv";
	public static final String DETAILED_PDF_FILE_NAME = "detailed-report.pdf";
	
	public static final String SETTLEMENT_EXCEL_FILE_NAME = "settlement-report.xlsx";
	public static final String SETTLEMENT_CSV_FILE_NAME = "settlement-report.csv";
	public static final String SETTLEMENT_PDF_FILE_NAME = "settlement-report.pdf";

}