package com.vil.admin.report.web.Util;

import com.liferay.asset.entry.rel.service.AssetEntryAssetCategoryRelLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.model.AssetEntry;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceUtil;
import com.liferay.asset.kernel.service.AssetEntryLocalServiceUtil;
import com.liferay.commerce.constants.CommerceOrderConstants;
import com.liferay.commerce.model.CommerceOrder;
import com.liferay.commerce.product.model.CPDefinition;
import com.liferay.commerce.product.model.CPInstance;
import com.liferay.commerce.product.service.CPDefinitionLocalServiceUtil;
import com.liferay.commerce.product.service.CPInstanceLocalServiceUtil;
import com.liferay.commerce.service.CommerceOrderLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ClassNameLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.vil.cart.model.VilOrderDetails;
import com.vil.cart.service.VilOrderDetailsLocalServiceUtil;
import com.vil.common.util.VilRoleUtil;
import com.vil.partner.model.PartnerMaster;
import com.vil.partner.model.PartnerUsers;
import com.vil.partner.service.PartnerMasterLocalServiceUtil;
import com.vil.partner.service.PartnerUsersLocalServiceUtil;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.portlet.ResourceRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class ReturnReportGenerator {
	private static String startDate=null;
	private static String endDate = null;
	
	

	public static String getStartDate() {
		return startDate;
	}

	public static void setStartDate(String startDate) {
		ReturnReportGenerator.startDate = startDate;
	}

	public static String getEndDate() {
		return endDate;
	}

	public static void setEndDate(String endDate) {
		ReturnReportGenerator.endDate = endDate;
	}

	public static byte[] getReturnExcelReportData(ResourceRequest resourceRequest) {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();
		
		ByteArrayOutputStream outByteStream = null;
		byte[] outArray = null;
		try {

			SXSSFWorkbook workbook = new SXSSFWorkbook();
			Sheet sheet = workbook.createSheet("Catalog Report");

			CellStyle defaultCellStyle = workbook.createCellStyle();
			Font defaultFont = workbook.createFont();
			defaultCellStyle.setFont(defaultFont);
			defaultCellStyle.setWrapText(true);

			CellStyle headerCellStyle = workbook.createCellStyle();
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerCellStyle.setFont(headerFont);
			headerCellStyle.setWrapText(true);

			Row headRow = sheet.createRow(0);

			List<String> catalogColumns = getReturnColumns();

			for (int header = 0; header < catalogColumns.size(); header++) {
				Cell cell = headRow.createCell(header);
				cell.setCellValue(catalogColumns.get(header));
				cell.setCellStyle(headerCellStyle);
			}
			Date startDate = null;
			Date endDate = null;
			DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
			List<CommerceOrder> commerceOrders = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			orderQuery.add(RestrictionsFactoryUtil.between("orderDate",startDate, endDate));
			orderQuery.add(RestrictionsFactoryUtil.ne("orderStatus", CommerceOrderConstants.ORDER_STATUS_OPEN));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					orderQuery.add(userRestriction);
					commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
					commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());

				} 
			} else {
				commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
				commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());
			}
			int index = 1;
			for (CommerceOrder commerceOrder : commerceOrders) {
				Row row = sheet.createRow(index);
				index++;
				int colIndex = 0;

				
				Cell cell = row.createCell(colIndex);
				cell.setCellValue(commerceOrder.getCommerceOrderId());
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				cell = row.createCell(colIndex);
				cell.setCellValue(commerceOrder.getOrderDate());
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				List<VilOrderDetails> vilOrderDetails =  VilOrderDetailsLocalServiceUtil.findByCommerceOrderId(commerceOrder.getCommerceOrderId());
				Date fullFillmentDate = null;
				String mobileNumber = "NaN";
				if(vilOrderDetails.isEmpty()) {
					for(VilOrderDetails orderDetails : vilOrderDetails) {
						mobileNumber = orderDetails.getMobileNo();
						fullFillmentDate = orderDetails.getFulfilmentDate();
					}
				}

				cell = row.createCell(colIndex);
				cell.setCellValue(fullFillmentDate);
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				User user = UserLocalServiceUtil.getUser(commerceOrder.getUserId());
				cell = row.createCell(colIndex);
				cell.setCellValue(user.getFirstName() + " " + user.getLastName()); // customer name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				cell = row.createCell(colIndex);
				cell.setCellValue(mobileNumber); // customer name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;
				
				
				cell = row.createCell(colIndex);
				cell.setCellValue(user.getEmailAddress()); // customer name
				cell.setCellStyle(defaultCellStyle);
				colIndex++;

				
			}

			outByteStream = new ByteArrayOutputStream();
			workbook.write(outByteStream);
			outArray = outByteStream.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}

	public static byte[] getReturnCSVReportData(ResourceRequest resourceRequest) {

		byte[] outArray = null;
		
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);

		String startingDate = getStartDate();
		String endingDate = getEndDate();

		try {
			StringBuffer data = new StringBuffer();
			List<String> catalogColumns = getReturnColumns();

			for (int header = 0; header < catalogColumns.size(); header++) {
				data.append(catalogColumns.get(header));
				data.append(",");
				
				
			}
			data.append('\n');
			Date startDate = null;
			Date endDate = null;
			DynamicQuery orderQuery = CommerceOrderLocalServiceUtil.dynamicQuery();
			List<CommerceOrder> commerceOrders = null;
			if(startingDate == null || endingDate == null || startingDate.isBlank() || endingDate.isBlank()) {
				LocalDateTime localEndDate = LocalDateTime.now();
				LocalDateTime localStartDate = localEndDate.minusHours(24);
				Instant instant = localEndDate.atZone(ZoneId.systemDefault()).toInstant();
				endDate = Date.from(instant);
				instant = localStartDate.atZone(ZoneId.systemDefault()).toInstant();
				startDate = Date.from(instant);
			} else {
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				Date startDateTemp = dateFormatter.parse(startingDate);
				startDate = new Date(startDateTemp.getYear(),startDateTemp.getMonth(),startDateTemp.getDate());

				Date endDateTemp = dateFormatter.parse(endingDate);
				endDate = new Date(endDateTemp.getYear(),endDateTemp.getMonth(),endDateTemp.getDate());
			}
			
			orderQuery.add(RestrictionsFactoryUtil.between("orderDate",startDate, endDate));
			orderQuery.add(RestrictionsFactoryUtil.ne("orderStatus", CommerceOrderConstants.ORDER_STATUS_OPEN));

			if(VilRoleUtil.isPartnerUser(themeDisplay.getUserId())) {
				PartnerUsers loginPartnerUser = PartnerUsersLocalServiceUtil.findByLiferayUserId(themeDisplay.getUserId());
				DynamicQuery userQuery = PartnerUsersLocalServiceUtil.dynamicQuery();
				userQuery.add(RestrictionsFactoryUtil.eq("partnerId", loginPartnerUser.getPartnerId()));
				List<PartnerUsers> partnerUsers = PartnerUsersLocalServiceUtil.dynamicQuery(userQuery);
				
				if(!partnerUsers.isEmpty()) {
					Criterion userRestriction = RestrictionsFactoryUtil.eq("userId", partnerUsers.get(0).getLiferayUserId());
					for(int i=1;i<partnerUsers.size();i++) {
						userRestriction =  RestrictionsFactoryUtil.or(userRestriction,RestrictionsFactoryUtil.eq("userId", partnerUsers.get(i).getLiferayUserId()));
					}
					orderQuery.add(userRestriction);
					commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
					commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());

				} 
			} else {
				commerceOrders = CommerceOrderLocalServiceUtil.dynamicQuery(orderQuery);
				commerceOrders = commerceOrders.stream().sorted((o1, o2)->o2.getOrderDate().compareTo(o1.getOrderDate())).collect(Collectors.toList());
			}
			
			for (CommerceOrder order : commerceOrders) {

            }
            outArray = data.toString().getBytes();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return outArray;
	}
	
	public static byte[] generateReturnPdf() {
		return null;
	}
	
	public static List<String> getReturnColumns() {
		List<String> returnColumns = new ArrayList<>();

		returnColumns.add("Order ID");
		returnColumns.add("Order Date");
		returnColumns.add("Order Fulfilment Date and Time");
		returnColumns.add("Customer Name");
		returnColumns.add("Customer Mobile Number");
		returnColumns.add("Customer Email Address");
		returnColumns.add("Order Line-Item ID");
		returnColumns.add("Product ID");
		returnColumns.add("Product Name");
		returnColumns.add("SKU ID");
		returnColumns.add("Return Request Date");
		returnColumns.add("Return Refund Status");
		returnColumns.add("Return Refund Success Date");
		returnColumns.add("Return Payment (Transaction) Status");
		returnColumns.add("Return Payment Date");
		returnColumns.add("Return Payment Time");
		returnColumns.add("Return Payment Channel");
		returnColumns.add("Return Payment Gateway");
		returnColumns.add("Return Gateway Transaction Id");
		returnColumns.add("Return Payment Mode");
		returnColumns.add("Return Payment Method Type");
		returnColumns.add("Return Card Issuer");
		returnColumns.add("Return Payment Method");
		returnColumns.add("Return Card Type");
		
		return returnColumns;
	}
	private static final Log log = LogFactoryUtil.getLog(ReturnReportGenerator.class);

}
