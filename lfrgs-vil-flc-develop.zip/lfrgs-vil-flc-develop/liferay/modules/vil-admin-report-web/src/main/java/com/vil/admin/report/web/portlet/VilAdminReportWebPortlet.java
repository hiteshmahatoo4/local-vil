package com.vil.admin.report.web.portlet;

import com.vil.admin.report.web.Util.CatalogReportGenerator;
import com.vil.admin.report.web.Util.CouponReportGenerator;
import com.vil.admin.report.web.Util.DetailedReportGenerator;
import com.vil.admin.report.web.Util.GrievanceReportGenerator;
import com.vil.admin.report.web.Util.OrderReportGenerator;
import com.vil.admin.report.web.Util.PartnerSpecificReportGenerator;
import com.vil.admin.report.web.Util.ReturnReportGenerator;
import com.vil.admin.report.web.Util.SalesReportGenerator;
import com.vil.admin.report.web.Util.settlementReportGenerator;
import com.vil.admin.report.web.constants.VilAdminReportWebPortletKeys;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;

import com.liferay.petra.string.StringUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.Portlet;
import javax.portlet.PortletContext;
import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.apache.poi.ss.usermodel.Workbook;
import org.osgi.service.component.annotations.Component;

/**
 * @author Deepak Patidar
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=VilAdminReportWeb",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + VilAdminReportWebPortletKeys.VILADMINREPORTWEB,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class VilAdminReportWebPortlet extends MVCPortlet {
	
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		
		String resourceId = resourceRequest.getResourceID();
				
	    if(resourceId.equals("getReportDate")) {
			
			String startDate = ParamUtil.getString(resourceRequest, "start");
			String endDate = ParamUtil.getString(resourceRequest, "end");
			String reportType = ParamUtil.getString(resourceRequest, "reportType");
			switch (reportType) {
				case "catalog-report" :{
					CatalogReportGenerator.setStartDate(startDate);
					CatalogReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "coupon-report" :{
					CouponReportGenerator.setStartDate(startDate);
					CouponReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "order-report" :{
					OrderReportGenerator.setStartDate(startDate);
					OrderReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "partner-report" :{
					PartnerSpecificReportGenerator.setStartDate(startDate);
					PartnerSpecificReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "grievance-report" :{
					GrievanceReportGenerator.setStartDate(startDate);
					GrievanceReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "sales-report" :{
					SalesReportGenerator.setStartDate(startDate);
					SalesReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "return-report" :{
					ReturnReportGenerator.setStartDate(startDate);
					ReturnReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "detail-report" :{
					DetailedReportGenerator.setStartDate(startDate);
					DetailedReportGenerator.setEndDate(endDate);
					
					break;
				}
				case "settlement-report" :{
					settlementReportGenerator.setStartDate(startDate);
					settlementReportGenerator.setEndDate(endDate);
					
					break;
				}
				default:
					break;
				
			}
		} else if(resourceId.equals("getReportFile")) {
			String reportType = ParamUtil.getString(resourceRequest, "reportType");
			switch (reportType) {
				case "catalog-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("catalog-report-excel")) {
						byte[] excelCatalog = CatalogReportGenerator.getCatalogExcelReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.CATALOG_EXCEL_FILE_NAME, excelCatalog,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("catalog-report-csv")) {
						byte[] csvCatalog = CatalogReportGenerator.getCatalogCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.CATALOG_CSV_FILE_NAME, csvCatalog,
			                    ContentTypes.TEXT_CSV);
					} else {
						String htmlContentString = StringUtil.read(getClass().getClassLoader(), "META-INF/resources/pdfTemplate.html", true);

						byte[] pdfCatalog = CatalogReportGenerator.generateCatalogPdf(htmlContentString,resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.CATALOG_PDF_FILE_NAME, pdfCatalog,
			                    ContentTypes.APPLICATION_PDF);
					}
					
					break;
				}
				case "coupon-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("coupon-report-excel")) {
						Workbook workbook = CouponReportGenerator.getCouponExcelReportData();
						ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
						workbook.write(outByteStream);
						byte[] excelCoupon = outByteStream.toByteArray();
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.COUPON_EXCEL_FILE_NAME, excelCoupon,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("coupon-report-csv")) {
						byte[] csvCoupon = CouponReportGenerator.getCouponCSVReportData();
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.COUPON_CSV_FILE_NAME, csvCoupon,
			                    ContentTypes.TEXT_CSV);
					} else {
						String htmlContentString = StringUtil.read(getClass().getClassLoader(), "META-INF/resources/pdfTemplate.html", true);
						byte[] excelOrder = CouponReportGenerator.generateCouponPdf(htmlContentString);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.COUPON_PDF_FILE_NAME, excelOrder,
			                    ContentTypes.APPLICATION_PDF);
					}
					
					break;
				}
				case "order-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("order-report-excel")) {
						byte[] excelOrder = OrderReportGenerator.getOrderExcelReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.ORDER_EXCEL_FILE_NAME, excelOrder,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("order-report-csv")) {
						byte[] csvOrder = OrderReportGenerator.getOrderCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.ORDER_CSV_FILE_NAME, csvOrder,
			                    ContentTypes.TEXT_CSV);
					} else {
						String htmlContentString = StringUtil.read(getClass().getClassLoader(), "META-INF/resources/pdfTemplate.html", true);

						byte[] pdfOrder = OrderReportGenerator.getOrderPdfReportData(htmlContentString,resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.ORDER_PDF_FILE_NAME, pdfOrder,
			                    ContentTypes.APPLICATION_PDF);
					}
					break;
				}
				case "partner-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("partner-report-excel")) {
						Workbook workbook = PartnerSpecificReportGenerator.getPartnerExcelReportData(resourceRequest);
						ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
						workbook.write(outByteStream);
						byte[] excelPartner = outByteStream.toByteArray();
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.PARTNER_EXCEL_FILE_NAME, excelPartner,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("partner-report-csv")) {
						byte[] csvPartner = PartnerSpecificReportGenerator.getPartnerCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.PARTNER_CSV_FILE_NAME, csvPartner,
			                    ContentTypes.TEXT_CSV);
					} else {
						String htmlContentString = StringUtil.read(getClass().getClassLoader(), "META-INF/resources/pdfTemplate.html", true);
						byte[] pdfPartner = PartnerSpecificReportGenerator.generatePartnerPdf(resourceRequest,htmlContentString);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.PARTNER_PDF_FILE_NAME, pdfPartner,
			                    ContentTypes.APPLICATION_PDF);
					}
					break;
				}
				case "grievance-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("grievance-report-excel")) {
						byte[] excelGrievance = GrievanceReportGenerator.getGrievanceExcelReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.GRIEVANCE_EXCEL_FILE_NAME, excelGrievance,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("grievance-report-csv")) {
						byte[] csvGrievance = GrievanceReportGenerator.getGrievanceCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.GRIEVANCE_CSV_FILE_NAME, csvGrievance,
			                    ContentTypes.TEXT_CSV_UTF8);
					} else {
						String htmlContentString = StringUtil.read(getClass().getClassLoader(), "META-INF/resources/pdfTemplate.html", true);

						byte[] excelGrievance = GrievanceReportGenerator.generateGrievancePdf(htmlContentString,resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.GRIEVANCE_PDF_FILE_NAME, excelGrievance,
			                    ContentTypes.APPLICATION_PDF);
					}
					break;
				}
				case "sales-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("sales-report-excel")) {
						byte[] excelSales = SalesReportGenerator.getSalesExcelReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.SALES_EXCEL_FILE_NAME, excelSales,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("sales-report-csv")) {
						byte[] csvSales = SalesReportGenerator.getSalesCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.SALES_CSV_FILE_NAME, csvSales,
			                    ContentTypes.TEXT_CSV_UTF8);
					} else {
						String htmlContentString = StringUtil.read(getClass().getClassLoader(), "META-INF/resources/pdfTemplate.html", true);

						byte[] pdfSales = SalesReportGenerator.generateSalesPdf(htmlContentString,resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.SALES_PDF_FILE_NAME, pdfSales,
			                    ContentTypes.APPLICATION_PDF);
					}
					break;
				}
				case "return-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("return-report-excel")) {
						byte[] excelReturn = ReturnReportGenerator.getReturnExcelReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.RETURN_EXCEL_FILE_NAME, excelReturn,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("return-report-csv")) {
						byte[] csvReturn = ReturnReportGenerator.getReturnCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.RETURN_CSV_FILE_NAME, csvReturn,
			                    ContentTypes.TEXT_CSV_UTF8);
					} else {
						byte[] excelReturn = ReturnReportGenerator.generateReturnPdf();
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.RETURN_PDF_FILE_NAME, excelReturn,
			                    ContentTypes.APPLICATION_PDF);
					}
					break;
				}
				case "detail-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("detail-report-excel")) {
						byte[] excelDetailed = DetailedReportGenerator.getDetailExcelReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.DETAILED_EXCEL_FILE_NAME, excelDetailed,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("detail-report-csv")) {
						byte[] csvDetailed = ReturnReportGenerator.getReturnCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.DETAILED_CSV_FILE_NAME, csvDetailed,
			                    ContentTypes.TEXT_CSV_UTF8);
					} else {
						byte[] excelDetailed = ReturnReportGenerator.generateReturnPdf();
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.DETAILED_PDF_FILE_NAME, excelDetailed,
			                    ContentTypes.APPLICATION_PDF);
					}
					break;
				}
				case "settlement-report" :{
					String reportFileType = ParamUtil.getString(resourceRequest, "reportFileType");
					if(reportFileType.equals("settlement-report-excel")) {
						byte[] excelSettlement = settlementReportGenerator.getSettlementExcelReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.SETTLEMENT_EXCEL_FILE_NAME, excelSettlement,
			                    ContentTypes.APPLICATION_VND_MS_EXCEL);
					} else if(reportFileType.equals("settlement-report-csv")) {
						byte[] csvSettlement = settlementReportGenerator.getSettlementCSVReportData(resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.SETTLEMENT_CSV_FILE_NAME, csvSettlement,
			                    ContentTypes.TEXT_CSV_UTF8);
					} else {
						String htmlContentString = StringUtil.read(getClass().getClassLoader(), "META-INF/resources/pdfTemplate.html", true);

						byte[] pdfSettlement = settlementReportGenerator.getSettlementPdfReportData(htmlContentString, resourceRequest);
						PortletResponseUtil.sendFile(resourceRequest, resourceResponse, VilAdminReportWebPortletKeys.SETTLEMENT_PDF_FILE_NAME, pdfSettlement,
			                    ContentTypes.APPLICATION_PDF);
					}
					break;
				}
				default:
					break;
				
			}
		}
	}
}