package com.vil.ecom.api.adaptor.testing.portlet;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;
import com.vil.ecom.api.adaptor.testing.constants.VilApiAdaptorTestingPortletKeys;
import com.vil.ecom.db.model.EcomSrvcCmmndMppng;
import com.vil.ecom.db.service.EcomSrvcCmmndMppngLocalServiceUtil;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomAdditionalBenefitsReq;
import com.vil.ecom.service.EcomAdditionalBenefitsUtil;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletSession;
import javax.portlet.ProcessAction;

import org.osgi.service.component.annotations.Component;

/**
 * @author Jeswanth
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=VilApiAdaptorTesting",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + VilApiAdaptorTestingPortletKeys.VILAPIADAPTORTESTING,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class VilApiAdaptorTestingPortlet extends MVCPortlet {
	
	private static final Log logger = LogFactoryUtil.getLog(VilApiAdaptorTestingPortlet.class);
	private static final String THIS_CLASS = VilApiAdaptorTestingPortlet.class.toString();
	
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	@ProcessAction(name="initiateProcessor")
	public void initiateProcessor(ActionRequest request,ActionResponse response) {
		
		String methodName = "initiateProcessor";
		String output = null;
		String srvcName = ParamUtil.getString(request,"srvcName");
		String payload = ParamUtil.getString(request, "payload");
		String proxy = ParamUtil.getString(request, "proxy");
		
		FLogger.debug(logger, THIS_CLASS, methodName, "Entered portlet method: "+methodName+" | for service name: "+srvcName+" | with payload: "+payload);
		
		FLogger.debug(logger, THIS_CLASS, methodName, "Proxy flag: "+proxy);
		
		List<EcomSrvcCmmndMppng> mp = EcomSrvcCmmndMppngLocalServiceUtil.findBySrvcKey(srvcName);
		
		PortletSession session = request.getPortletSession();
		
		
		try {
			
			
			if(proxy.equalsIgnoreCase("true")) {
					
				FLogger.info(logger, THIS_CLASS, methodName, "setting proxy");
				final String authUser = "INDIA\\21_______";  //emp id
				final String authPassword = "your password"; //global domain password
				System.setProperty("http.proxyHost", "proxy.tcs.com");
				System.setProperty("http.proxyPort", "8080");
				System.setProperty("https.proxyHost", "proxy.tcs.com");
				System.setProperty("https.proxyPort", "8080");
				Authenticator.setDefault(new Authenticator() {
				@Override
				public PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(authUser, authPassword.toCharArray());
				}
				});
			}else {
				
				FLogger.info(logger, THIS_CLASS, methodName, "proceeding as no proxy");
				System.setProperty("http.proxyHost", "");
				System.setProperty("http.proxyPort", "");
				System.setProperty("https.proxyHost", "");
				System.setProperty("https.proxyPort", "");
			}
			
			if(!mp.isEmpty()){
				
				Class dU = EcomAdditionalBenefitsUtil.class;
				Class dR = EcomAdditionalBenefitsReq.class;
				FLogger.info(logger, THIS_CLASS, methodName, "Processor is present with sevice name: "+srvcName);
				
				Class util = Class.forName(mp.get(0).getSrvc_util_class());
				Object obj = util.newInstance();
				
				
				if(!StringChecks.isFieldEmpty(mp.get(0).getSrvc_req())) {
					
					FLogger.debug(logger, THIS_CLASS, methodName, "request parameter is present");
					
					Class reqClass = Class.forName(mp.get(0).getSrvc_req());
					Method method = util.getDeclaredMethod(mp.get(0).getUtil_signature(), reqClass);
					output = StringChecks.convertObjectToJson(method.invoke(obj, StringChecks.convertJsonToObject(payload, reqClass)));
					
				} else {
					
					FLogger.debug(logger, THIS_CLASS, methodName, "request parameter is not present");
					
					Method method = util.getDeclaredMethod(mp.get(0).getUtil_signature());
					output = StringChecks.convertObjectToJson(method.invoke(obj));
				}		
				
				session.setAttribute("api_output",output, PortletSession.PORTLET_SCOPE);
				
				
			}else {
				FLogger.error(logger, THIS_CLASS, methodName,"Processor is present with sevice name: "+srvcName);
			}
		
		    
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException  e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}finally {
			FLogger.debug(logger, THIS_CLASS,methodName ,"Returning output from portlet: "+output);
		}
		
		
		
		
	}
}