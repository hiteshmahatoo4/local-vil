package com.vil.ecom.api.adaptor.testing.constants;

/**
 * @author Jeswanth
 */
public class VilApiAdaptorTestingPortletKeys {

	public static final String VILAPIADAPTORTESTING =
		"com_vil_ecom_api_adaptor_testing_VilApiAdaptorTestingPortlet";

}