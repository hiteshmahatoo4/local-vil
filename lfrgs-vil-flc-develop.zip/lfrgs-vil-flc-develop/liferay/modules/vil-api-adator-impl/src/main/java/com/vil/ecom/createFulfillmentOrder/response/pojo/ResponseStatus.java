
package com.vil.ecom.createFulfillmentOrder.response.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "code",
    "description",
    "status",
    "auditId"
})
public class ResponseStatus implements Serializable
{

    

	@JsonProperty("code")
    private String code;
    @JsonProperty("description")
    private String description;
    @JsonProperty("status")
    private String status;
    @JsonProperty("auditId")
    private String auditId;
    private final static long serialVersionUID = 751683985466442664L;

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }
    
    @JsonProperty("auditId")
    public String getAuditId() {
		return auditId;
	}

    @JsonProperty("auditId")
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

}
