package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomUploadEventsReq;
import com.vil.ecom.integration.pojo.EcomUploadEventsResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomUploadEventsProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomUploadEventsUtil {
	
	private static final Log logger = LogFactoryUtil.getLog(EcomUploadEventsUtil.class);
	private static final String THIS_CLASS = "EcomUpdateEventsUtil";
	
	
	/**
	 * @author Jeswanth
	 * 
	 * <p>Clevertop Upload Event API : sendEvent </p>
	 * 
	 * @param processorInput : EcomUploadEventsReq pojo to be set . Mandatory
	 * 
	 * <p>
	 * <h2>EcomUploadEventsReq pojo details</h2>
	 * @param customerMsisdn : customer msisdn for which event to be uploaded to be set. Mandatory
	 * @param eventName : event name for which notifications to be sent. Mandatory
	 * @param eventData : EvtData pojo (event details) to be set. Details are: 
	 * <ul>
	 * <li> Beneficiary_Name : (String) beneficiary name to be set</li>
	 * <li>Product_Name : (String) product name to be set</li>
	 * <li>Duration : (String) duration to be set</li>
	 * <li>Category : (String) category to be set</li>
	 * <li>Price : (Double) Price to be set</li>
	 * <li>start_date : (yyyy-MM-dd HH:mm:ss format) start date to be set. Mandatory</li>
	 * <li>end_date : (yyyy-MM-dd HH:mm:ss format) end date to be set. Mandatory</li>
	 * </ul>
	 * </p>		
	 * @return EcomUploadEventsResp : status of upload eventv
	 */
	public static EcomUploadEventsResp sendEvent(EcomUploadEventsReq processorInput) {
		
		String methodName =  "uploadEvent";
		StopWatch stopwatch = null;
		EcomUploadEventsResp response = null;
		MrchntRespStts respStts = null;
		
		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();
			
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.EAI_UPLOAD_EVENTS);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
			
			if(processorInput != null){
				
				FLogger.debug(logger, THIS_CLASS, methodName, "Entered method to upload events");
				
				respStts = validateInputs(processorInput);
				
				
				
				if(respStts == null) {
					
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.EAI_UPLOAD_EVENTS);
					srvcRequest.setUploadEventsReq(processorInput);
					
					EcomUploadEventsProcessor processor = new EcomUploadEventsProcessor(srvcRequest);
					
					EcomMrchntServiceResponse srvcResp = processor.execute();
					
					if(srvcResp != null) {
						
						if(srvcResp.getUploadEventsResp() != null) {
							
							FLogger.info(logger, THIS_CLASS, methodName, "Successful with auditId : "+srvcResp.getResponseStatus().getAuditId());
							response = srvcResp.getUploadEventsResp();
						}else {
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
							
							response = new EcomUploadEventsResp();
							response.setResponseStatus(respStts);
						}
						
					}else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
						
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
						
						response = new EcomUploadEventsResp();
						response.setResponseStatus(respStts);
					}
				}else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
					
					response = new EcomUploadEventsResp();
					response.setResponseStatus(respStts);
				}
				
			}else {

				FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
				
				response = new EcomUploadEventsResp();
				response.setResponseStatus(respStts);
			}
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);			
			
			response = new EcomUploadEventsResp();
			response.setResponseStatus(respStts);
			
		}finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		
		}
		
		return response;
	}
	
	private static MrchntRespStts validateInputs(EcomUploadEventsReq processorInput) {

		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName);
		
		try {
			
			FLogger.info(logger, THIS_CLASS, methodName, "Payload: "+StringChecks.convertObjectToJson(processorInput));
			
			if(processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}
			
			respStts = RsValiatorResponse.validateStrInput(processorInput.getEventName(), null, "Event Name");
			if(respStts != null) {
				return respStts;
			}
			
			if(!StringChecks.checkMsisdn(processorInput.getCustomerMsisdn())) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Msisdn");
				return respStts;
			}
			
			if(!(StringChecks.isFieldEmpty(processorInput.getEventData().getStartDate()) && StringChecks.isFieldEmpty(processorInput.getEventData().getEndDate()))){
				if(!StringChecks.dateCompare(processorInput.getEventData().getStartDate(), processorInput.getEventData().getEndDate(), BaseConstants.YYYYMMDDHHMMSS)) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Start Date / End Date");
					return respStts;
				}
			}
			
			
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
		}
		
		return respStts;
	}

}
