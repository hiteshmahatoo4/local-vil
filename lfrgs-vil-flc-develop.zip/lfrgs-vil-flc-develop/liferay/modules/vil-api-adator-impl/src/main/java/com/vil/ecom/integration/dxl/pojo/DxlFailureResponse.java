package com.vil.ecom.integration.dxl.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "errorCode",
    "errorType",
    "errorMessage",
    "errorDescription",
    "causingSystemName",
    "causingSystemErrorCode",
    "causingSystemErrorMessage"
})
public class DxlFailureResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("errorCode")
	private String errorCode;
	@JsonProperty("errorType")
	private String errorType;
	@JsonProperty("errorMessage")
	private String errorMessage;
	@JsonProperty("errorDescription")
	private String errorDescription;
	@JsonProperty("causingSystemName")
	private String causingSystemName;
	@JsonProperty("causingSystemErrorCode")
	private String causingSystemErrorCode;
	@JsonProperty("causingSystemErrorMessage")
	private String causingSystemErrorMessage;
	
	@JsonProperty("errorCode")
	public String getErrorCode() {
		return errorCode;
	}

	@JsonProperty("errorCode")
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@JsonProperty("errorType")
	public String getErrorType() {
		return errorType;
	}

	@JsonProperty("errorType")
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	@JsonProperty("errorMessage")
	public String getErrorMessage() {
		return errorMessage;
	}

	@JsonProperty("errorMessage")
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@JsonProperty("errorDescription")
	public String getErrorDescription() {
		return errorDescription;
	}

	@JsonProperty("errorDescription")
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	@JsonProperty("causingSystemName")
	public String getCausingSystemName() {
		return causingSystemName;
	}

	@JsonProperty("causingSystemName")
	public void setCausingSystemName(String causingSystemName) {
		this.causingSystemName = causingSystemName;
	}

	@JsonProperty("causingSystemErrorCode")
	public String getCausingSystemErrorCode() {
		return causingSystemErrorCode;
	}

	@JsonProperty("causingSystemErrorCode")
	public void setCausingSystemErrorCode(String causingSystemErrorCode) {
		this.causingSystemErrorCode = causingSystemErrorCode;
	}

	@JsonProperty("causingSystemErrorMessage")
	public String getCausingSystemErrorMessage() {
		return causingSystemErrorMessage;
	}

	@JsonProperty("causingSystemErrorMessage")
	public void setCausingSystemErrorMessage(String causingSystemErrorMessage) {
		this.causingSystemErrorMessage = causingSystemErrorMessage;
	}

	

}
