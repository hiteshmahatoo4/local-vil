
package com.vil.ecom.dxl.additionalBenefits.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"statusMessage",
"description",
"lastUpdate"
})
public class AdditionalBenefitsScssResp {

    @JsonProperty("statusMessage")
    private String statusMessage;
    @JsonProperty("description")
    private String description;
    @JsonProperty("lastUpdate")
    private String lastUpdate;

    @JsonProperty("statusMessage")
    public String getStatusMessage() {
        return statusMessage;
    }

    @JsonProperty("statusMessage")
    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    @JsonProperty("description")
    public String getDescription() {
    return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
    this.description = description;
    }

    @JsonProperty("lastUpdate")
    public String getLastUpdate() {
    return lastUpdate;
    }

    @JsonProperty("lastUpdate")
    public void setLastUpdate(String lastUpdate) {
    this.lastUpdate = lastUpdate;
    }

}
