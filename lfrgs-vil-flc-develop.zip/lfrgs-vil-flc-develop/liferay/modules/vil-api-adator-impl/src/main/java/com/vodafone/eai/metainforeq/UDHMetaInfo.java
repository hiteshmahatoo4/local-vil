
package com.vodafone.eai.metainforeq;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UDHMetaInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UDHMetaInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ConsumerReqInfo" type="{http://eai.vodafone.com/MetaInfoReq}CLSConsumerReqInfo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UDHMetaInfo", propOrder = {
    "consumerReqInfo"
})
public class UDHMetaInfo {

    @XmlElement(name = "ConsumerReqInfo", required = true)
    protected CLSConsumerReqInfo consumerReqInfo;

    /**
     * Gets the value of the consumerReqInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CLSConsumerReqInfo }
     *     
     */
    public CLSConsumerReqInfo getConsumerReqInfo() {
        return consumerReqInfo;
    }

    /**
     * Sets the value of the consumerReqInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CLSConsumerReqInfo }
     *     
     */
    public void setConsumerReqInfo(CLSConsumerReqInfo value) {
        this.consumerReqInfo = value;
    }

}
