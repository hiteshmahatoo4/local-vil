
package com.vodafone.eai.sendsmsmsdp;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.vodafone.eai.metainforeq.UDHMetaInfoReq;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MetaInfo" type="{http://eai.vodafone.com/MetaInfoReq}UDHMetaInfoReq"/>
 *         &lt;element name="SRVsendSmsMSDPReq" type="{http://eai.vodafone.com/sendSmsMSDP}sendSmsMSDPReq"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "metaInfo",
    "srVsendSmsMSDPReq"
})
@XmlRootElement(name = "SendSmsMSDPRequest")
public class SendSmsMSDPRequest {

    @XmlElement(name = "MetaInfo", required = true)
    protected UDHMetaInfoReq metaInfo;
    @XmlElement(name = "SRVsendSmsMSDPReq", required = true)
    protected SendSmsMSDPReq srVsendSmsMSDPReq;

    /**
     * Gets the value of the metaInfo property.
     * 
     * @return
     *     possible object is
     *     {@link UDHMetaInfoReq }
     *     
     */
    public UDHMetaInfoReq getMetaInfo() {
        return metaInfo;
    }

    /**
     * Sets the value of the metaInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link UDHMetaInfoReq }
     *     
     */
    public void setMetaInfo(UDHMetaInfoReq value) {
        this.metaInfo = value;
    }

    /**
     * Gets the value of the srVsendSmsMSDPReq property.
     * 
     * @return
     *     possible object is
     *     {@link SendSmsMSDPReq }
     *     
     */
    public SendSmsMSDPReq getSRVsendSmsMSDPReq() {
        return srVsendSmsMSDPReq;
    }

    /**
     * Sets the value of the srVsendSmsMSDPReq property.
     * 
     * @param value
     *     allowed object is
     *     {@link SendSmsMSDPReq }
     *     
     */
    public void setSRVsendSmsMSDPReq(SendSmsMSDPReq value) {
        this.srVsendSmsMSDPReq = value;
    }

}
