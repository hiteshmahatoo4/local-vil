package com.vil.ecom.integration.pojo;

import com.vil.ecom.dxl.refundStatus.pojo.RefundStatusRespDtls;

import java.io.Serializable;
import java.util.List;

public class EcomRefundStatusResp implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
	
	private List<RefundStatusRespDtls> refundStatus;

	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	public List<RefundStatusRespDtls> getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(List<RefundStatusRespDtls> refundStatus) {
		this.refundStatus = refundStatus;
	}

}
