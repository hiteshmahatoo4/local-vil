
package com.vil.ecom.fulfillmentOrderSttsQuery.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "message",
    "response_status"
})
public class EcomFulfillmentOrderSttsQueryResp implements Serializable
{

	@JsonProperty("message")
	private Message message;
	@JsonProperty("response_status")
	private ResponseStts responseStatus;
	private final static long serialVersionUID = 4993598613031920120L;

	@JsonProperty("message")
	public Message getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(Message message) {
		this.message = message;
	}

	public EcomFulfillmentOrderSttsQueryResp withMessage(Message message) {
		this.message = message;
		return this;
	}

	@JsonProperty("response_status")
	public ResponseStts getResponseStatus() {
		return responseStatus;
	}

	@JsonProperty("response_status")
	public void setResponseStatus(ResponseStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	public EcomFulfillmentOrderSttsQueryResp withResponseStatus(ResponseStts responseStatus) {
		this.responseStatus = responseStatus;
		return this;
	}

}
