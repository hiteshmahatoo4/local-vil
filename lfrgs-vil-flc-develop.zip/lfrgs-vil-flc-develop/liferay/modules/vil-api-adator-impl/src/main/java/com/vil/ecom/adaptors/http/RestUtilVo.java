package com.vil.ecom.adaptors.http;

import com.vil.ecom.integration.helper.EcomHelper;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class RestUtilVo  implements Serializable{

	private static final long serialVersionUID = 1L;

	private String pURL;

	private Map<String, String> headerParameters;

	private Map<String, String> urlParameters;

	private List<String> urlParamOrder;

	private int connectionTimeOut;

	private int connectReadTimeout;

	private String payload;

	// GET/POST
	private String requestType;

	private boolean proxyFlag;

	private boolean disableSslValidation;

	private boolean disableHostNmeVerification;

	private String tlsVersion;

	private String trustStorePath;

	private String trustStorePwd;

	private String serviceNme;

	private Map<String, Object> confMap;

	private String proxyIp;

	private int proxyPort;

	private String proxyUsrNme;

	private String proxyPwd;

	/**
	 * @return the pURL
	 */
	public String getpURL() {
		return pURL;
	}

	/**
	 * @param pURL the pURL to set
	 */
	public void setpURL(String pURL) {
		this.pURL = pURL;
	}

	/**
	 * @return the headerParameters
	 */
	public Map<String, String> getHeaderParameters() {
		return headerParameters;
	}

	/**
	 * @param headerParameters the headerParameters to set
	 */
	public void setHeaderParameters(Map<String, String> headerParameters) {
		this.headerParameters = headerParameters;
	}

	/**
	 * @return the urlParameters
	 */
	public Map<String, String> getUrlParameters() {
		return urlParameters;
	}

	/**
	 * @param urlParameters the urlParameters to set
	 */
	public void setUrlParameters(Map<String, String> urlParameters) {
		this.urlParameters = urlParameters;
	}

	/**
	 * @return the urlParamOrder
	 */
	public List<String> getUrlParamOrder() {
		return EcomHelper.cloneList(urlParamOrder);
	}

	/**
	 * @param urlParamOrder the urlParamOrder to set
	 */
	public void setUrlParamOrder(List<String> urlParamOrder) {
		this.urlParamOrder = EcomHelper.cloneList(urlParamOrder);
	}

	/**
	 * @return the connectionTimeOut
	 */
	public int getConnectionTimeOut() {
		return connectionTimeOut;
	}

	/**
	 * @param connectionTimeOut the connectionTimeOut to set
	 */
	public void setConnectionTimeOut(int connectionTimeOut) {
		this.connectionTimeOut = connectionTimeOut;
	}

	/**
	 * @return the connectReadTimeout
	 */
	public int getConnectReadTimeout() {
		return connectReadTimeout;
	}

	/**
	 * @param connectReadTimeout the connectReadTimeout to set
	 */
	public void setConnectReadTimeout(int connectReadTimeout) {
		this.connectReadTimeout = connectReadTimeout;
	}

	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}

	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	/**
	 * @return the proxyFlag
	 */
	public boolean isProxyFlag() {
		return proxyFlag;
	}

	/**
	 * @param proxyFlag the proxyFlag to set
	 */
	public void setProxyFlag(boolean proxyFlag) {
		this.proxyFlag = proxyFlag;
	}

	/**
	 * @return the disableSslValidation
	 */
	public boolean isDisableSslValidation() {
		return disableSslValidation;
	}

	/**
	 * @param disableSslValidation the disableSslValidation to set
	 */
	public void setDisableSslValidation(boolean disableSslValidation) {
		this.disableSslValidation = disableSslValidation;
	}

	/**
	 * @return the disableHostNmeVerification
	 */
	public boolean isDisableHostNmeVerification() {
		return disableHostNmeVerification;
	}

	/**
	 * @param disableHostNmeVerification the disableHostNmeVerification to set
	 */
	public void setDisableHostNmeVerification(boolean disableHostNmeVerification) {
		this.disableHostNmeVerification = disableHostNmeVerification;
	}

	/**
	 * @return the tlsVersion
	 */
	public String getTlsVersion() {
		return tlsVersion;
	}

	/**
	 * @param tlsVersion the tlsVersion to set
	 */
	public void setTlsVersion(String tlsVersion) {
		this.tlsVersion = tlsVersion;
	}

	/**
	 * @return the trustStorePath
	 */
	public String getTrustStorePath() {
		return trustStorePath;
	}

	/**
	 * @param trustStorePath the trustStorePath to set
	 */
	public void setTrustStorePath(String trustStorePath) {
		this.trustStorePath = trustStorePath;
	}

	/**
	 * @return the trustStorePwd
	 */
	public String getTrustStorePwd() {
		return trustStorePwd;
	}

	/**
	 * @param trustStorePwd the trustStorePwd to set
	 */
	public void setTrustStorePwd(String trustStorePwd) {
		this.trustStorePwd = trustStorePwd;
	}

	/**
	 * @return the confMap
	 */
	public Map<String, Object> getConfMap() {
		return confMap;
	}

	/**
	 * @param confMap the confMap to set
	 */
	public void setConfMap(Map<String, Object> confMap) {
		this.confMap = confMap;
	}

	/**
	 * @return the payload
	 */
	public String getPayload() {
		return payload;
	}

	/**
	 * @param payload the payload to set
	 */
	public void setPayload(String payload) {
		this.payload = payload;
	}

	/**
	 * @return the serviceNme
	 */
	public String getServiceNme() {
		return serviceNme;
	}

	/**
	 * @param serviceNme the serviceNme to set
	 */
	public void setServiceNme(String serviceNme) {
		this.serviceNme = serviceNme;
	}

	/**
	 * @return the proxyIp
	 */
	public String getProxyIp() {
		return proxyIp;
	}

	/**
	 * @param proxyIp the proxyIp to set
	 */
	public void setProxyIp(String proxyIp) {
		this.proxyIp = proxyIp;
	}

	/**
	 * @return the proxyPort
	 */
	public int getProxyPort() {
		return proxyPort;
	}

	/**
	 * @param proxyPort the proxyPort to set
	 */
	public void setProxyPort(int proxyPort) {
		this.proxyPort = proxyPort;
	}

	/**
	 * @return the proxyUsrNme
	 */
	public String getProxyUsrNme() {
		return proxyUsrNme;
	}

	/**
	 * @param proxyUsrNme the proxyUsrNme to set
	 */
	public void setProxyUsrNme(String proxyUsrNme) {
		this.proxyUsrNme = proxyUsrNme;
	}

	/**
	 * @return the proxyPwd
	 */
	public String getProxyPwd() {
		return proxyPwd;
	}

	/**
	 * @param proxyPwd the proxyPwd to set
	 */
	public void setProxyPwd(String proxyPwd) {
		this.proxyPwd = proxyPwd;
	}

}
