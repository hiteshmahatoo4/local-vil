package com.vil.ecom.adaptors.http;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class RestUtility {

	private static final Log logger = LogFactoryUtil.getLog(RestUtility.class);
	
	private static final String THIS_CLASS = RestUtility.class.toString();
	private static final String FLOW_WITH_URL = " Flow with Url : ";
	private static final String RESPCODE = "respCode";
	private static final String RESPMSG = "respMsg";
	private static final String STATUS = "status";
	private static final String STATUS_DESC = "statusDesc";
	private static final String EXISTING_METHOD = "Exiting Method ";
	private static final String ENTERED_METHOD = "Entered Method";
	private static final String UTF_8 = "UTF-8";
	private static final String VALUE = " | value : ";
	private static final String OUTPUT_ENCODED_STRING = "Output Encoded String :";
	private static final String GENERATE_GET_REQUEST_URL_PARAMS = "generateGetRequestUrlParams";

	private static final String TLSV_1_2 = "TLSv1.2";
	
	private RestUtility() {
		throw new IllegalStateException("Utility class");
	}

	/**
	 * <p>
	 * This method connects to the URL and get the response in Map for DISHTV
	 * Integration
	 * </p>
	 * 
	 * @param pURL
	 * @param headerParameters   : header Map containing header key value pairs to
	 *                           be sent over http conection.
	 * @param urlParameters      : url params Map containing value pairs to be sent
	 *                           over http conection.
	 * @param connectionTimeOut  : Connection timeout im milliseconds
	 * @param connectReadTimeout : Connection read timeout im milliseconds
	 * @param requestType        : GET/POST
	 * @param protocolType       : HTTP /HTTPS
	 * @param confMap            : configurations map
	 * @param proxyFlag          : flag to enable proxy connection or not.
	 * @return
	 */
	public static Map<String, String> doConnectUrl(RestUtilVo requestVo) {

		int respCode = 0;
		String lRespMesg = "";
		HashMap<String, String> valueMap = new HashMap<>();

		String methodName = "doConnectUrl";
		boolean disableSslValidation = false;
		boolean disableHostNmeVerification = false;
		boolean addProxyFlg = false;

		String trustStorePath = null;
		String trustStorePwd = null;

		SSLContext context = null;

		String proxyIp = null;
		int proxyPort = 0;
		String tlsVersion = null;

		URL url = null;
		URLConnection urlconn = null;

		String pURL = null;
		Map<String, String> headerParameters = null;
		Map<String, String> urlParameters = null;
		List<String> urlParamOrder = null;
		int connectionTimeOut = LoggerConstants.NUM_5000;
		int connectReadTimeout = LoggerConstants.NUM_15000;
		String requestType = null;
		String payload = null;

		Map<String, Object> confMap = null;

		String integrationSystem = null;

		try {

			FLogger.info(logger, THIS_CLASS, methodName,"Entering Method " + methodName);
			
			integrationSystem = BaseConstants.EXT_VODA_SYSTEM
					+ ((!StringChecks.isFieldEmpty(requestVo.getServiceNme())) ? requestVo.getServiceNme()
							: "APP_REST")+ "_API";

			FLogger.debug(logger, THIS_CLASS, methodName,
					"Input Request Parameters " + StringChecks.convertObjectToJson(requestVo)+" | "+integrationSystem);

			pURL = requestVo.getpURL();

			headerParameters = requestVo.getHeaderParameters();
			urlParameters = requestVo.getUrlParameters();
			urlParamOrder = requestVo.getUrlParamOrder();
			connectionTimeOut = requestVo.getConnectionTimeOut();
			connectReadTimeout = requestVo.getConnectReadTimeout();
			requestType = requestVo.getRequestType();
			confMap = requestVo.getConfMap();
			addProxyFlg = requestVo.isProxyFlag();
			payload = requestVo.getPayload();

			disableSslValidation = requestVo.isDisableSslValidation();
			disableHostNmeVerification = requestVo.isDisableHostNmeVerification();
			tlsVersion = requestVo.getTlsVersion();

			trustStorePath = requestVo.getTrustStorePath();
			trustStorePwd = requestVo.getTrustStorePwd();

			if (requestType.equalsIgnoreCase(BaseConstants.GET_REQUEST)) {
				pURL = pURL + "?"
						+ (StringChecks.isFieldEmpty(payload)
								? generateGetRequestUrlParams(urlParameters, urlParamOrder)
								: payload);
			}

			FLogger.error(logger, THIS_CLASS, methodName,
					"Url To Connect : " + pURL + " | requestType : " + requestType);

			FLogger.info(logger, THIS_CLASS, methodName,
					"input URL :" + pURL + " | urlParams : "
							+ (StringChecks.isFieldEmpty(payload)
									? generateGetRequestUrlParams(urlParameters, urlParamOrder)
									: payload));

			url = new URL(pURL);

			if (requestVo != null) {

				proxyIp = requestVo.getProxyIp();
				proxyPort = requestVo.getProxyPort();
			}

			FLogger.debug(logger, THIS_CLASS, methodName,
					"Proxy Allowed " + addProxyFlg 
					+ " | proxyIp : " + proxyIp 
					+ " | proxyPort : " + proxyPort
					+ " | confMap : " + (!StringChecks.isMapEmpty(confMap)?confMap.size():null)
					);

			if (!StringChecks.connectionIsHttps(pURL)) { // Http Url Connect.

				FLogger.error(logger, THIS_CLASS, methodName,"HTTP Flow");

				if (addProxyFlg) {

					FLogger.info(logger, THIS_CLASS, methodName,"Adding Proxy Server Changes");
					urlconn = url.openConnection(addProxyToConnection(proxyIp, proxyPort));

				} else {
					urlconn = url.openConnection();
				}

				if (!StringChecks.isMapEmpty(headerParameters)) {

					logger.debug("Setting header parameters");

					for (Map.Entry<String, String> map : headerParameters.entrySet()) {

						String key = map.getKey();
						String value = map.getValue();

						FLogger.info(logger, THIS_CLASS, methodName,"Setting header " + key + " | value " + value);
						((HttpURLConnection) urlconn).setRequestProperty(key, value);

					}
				}

				if (connectionTimeOut > 0) {
					((HttpURLConnection) urlconn).setConnectTimeout(connectionTimeOut);
				}

				if (connectReadTimeout > 0) {
					((HttpURLConnection) urlconn).setReadTimeout(connectReadTimeout);
				}

				for (String header : urlconn.getRequestProperties().keySet()) {

					if (header != null) {

						for (String value : urlconn.getRequestProperties().get(header)) {
							logger.debug("Header Set : " + header + ":" + value);
						}
					}
				}

				if (requestType.equalsIgnoreCase(BaseConstants.GET_REQUEST)) {

					((HttpURLConnection) urlconn).setRequestMethod(BaseConstants.GET_REQUEST);

				} else if (requestType.equalsIgnoreCase(BaseConstants.POST_REQUEST)) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							BaseConstants.POST_REQUEST + FLOW_WITH_URL + pURL);

					((HttpURLConnection) urlconn).setRequestMethod(BaseConstants.POST_REQUEST);
					((HttpURLConnection) urlconn).setDoOutput(true);

					DataOutputStream wr = new DataOutputStream(urlconn.getOutputStream());
					wr.writeBytes(
							(StringChecks.isFieldEmpty(payload) ? generatePostRequestUrlParams(urlParameters, false)
									: payload));
					wr.flush();
					wr.close();
					
				} else if (requestType.equalsIgnoreCase(BaseConstants.PUT_REQUEST)) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							BaseConstants.PUT_REQUEST + FLOW_WITH_URL + pURL);

					((HttpURLConnection) urlconn).setRequestMethod(BaseConstants.PUT_REQUEST);
					((HttpURLConnection) urlconn).setDoOutput(true);

					DataOutputStream wr = new DataOutputStream(urlconn.getOutputStream());
					wr.writeBytes((StringChecks.isFieldEmpty(payload) ? generatePostRequestUrlParams(urlParameters, false): payload));
					
					wr.flush();
					wr.close();
					
				}else if (requestType.equalsIgnoreCase(BaseConstants.PATCH_REQUEST)) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							BaseConstants.PATCH_REQUEST + FLOW_WITH_URL + pURL);

					((HttpURLConnection) urlconn).setRequestMethod(BaseConstants.PATCH_REQUEST);
					((HttpURLConnection) urlconn).setDoOutput(true);

					DataOutputStream wr = new DataOutputStream(urlconn.getOutputStream());
					wr.writeBytes((StringChecks.isFieldEmpty(payload) ? generatePostRequestUrlParams(urlParameters, false): payload));
					
					wr.flush();
					wr.close();
					
				}

				((HttpURLConnection) urlconn).connect();

				respCode = ((HttpURLConnection) urlconn).getResponseCode();

				if (respCode != HttpURLConnection.HTTP_CLIENT_TIMEOUT && respCode == HttpURLConnection.HTTP_OK) {

					FLogger.error(logger, THIS_CLASS, methodName,
							"Connection established with " + "response Code :" + respCode);

					BufferedReader inp = null;
					int value = 0;
					StringBuilder sb = new StringBuilder();

					InputStream is = null;
					is = fetchUrlConnStream(urlconn,pURL);

					if (is != null) {

						inp = new BufferedReader(new InputStreamReader(is));

						while ((value = inp.read()) != -1) {
							sb.append((char) value);
						}

						inp.close();

						lRespMesg = sb.toString();

					} else {
						lRespMesg = null;
					}

					valueMap.put(RESPCODE, "" + respCode);
					valueMap.put(RESPMSG, lRespMesg);
					valueMap.put(STATUS, BaseConstants.SUCCESS_MSG);
					valueMap.put(STATUS_DESC, BaseConstants.SUCCESS_MSG);

				} else if (respCode == HttpURLConnection.HTTP_CLIENT_TIMEOUT) {

					logger.error("HTTP_CLIENT_TIMEOUT respCode : " + respCode);

					valueMap.put(RESPCODE, "" + respCode);
					valueMap.put(RESPMSG, lRespMesg);
					valueMap.put(STATUS, BaseConstants.TIMEOUT_MSG);
					valueMap.put(STATUS_DESC, BaseConstants.URL_TIMEOUT);

				} else {

					FLogger.error(logger, THIS_CLASS, methodName,
							"Invalid Http Error code Received" + " respCode : " + respCode);

					BufferedReader inp = null;
					int value = 0;
					StringBuilder sb = new StringBuilder();

					InputStream is = null;
					is = fetchUrlConnStream(urlconn,pURL);

					if (is != null) {

						inp = new BufferedReader(new InputStreamReader(is));

						while ((value = inp.read()) != -1) {
							sb.append((char) value);
						}

						inp.close();

						lRespMesg = sb.toString();

					} else {
						lRespMesg = null;
					}

					logger.error("Invalid Http Error code Received lRespMesg : "
							+ (lRespMesg != null ? lRespMesg.length() : 0));

					valueMap.put(RESPCODE, "" + respCode);
					valueMap.put(RESPMSG, lRespMesg);
					valueMap.put(STATUS, BaseConstants.TIMEOUT_MSG);
					valueMap.put(STATUS_DESC, BaseConstants.NO_RESP);
				}

				((HttpURLConnection) urlconn).disconnect();
				urlconn = null;

			} else {// Https Url Connect

				FLogger.error(logger, THIS_CLASS, methodName,"HTTPS Flow");

				/** Code to Disable SSL Certificate Validation */
				if (disableSslValidation) {

					FLogger.error(logger, THIS_CLASS, methodName,
							"SSL Certificate Validation is Disabled for Https Flow.");
					disableSslVerification();

				} else {

					FLogger.error(logger, THIS_CLASS, methodName,
							"SSL Certificate Validation is enabled for Https Flow " + "with tlsVersion " + tlsVersion);

					if (StringChecks.isFieldEmpty(tlsVersion)) {
						context = retrieveSSLContext(trustStorePath, trustStorePwd);
					} else {
						context = retrieveSSLContext(trustStorePath, trustStorePwd, tlsVersion);
					}
				}

				if (addProxyFlg) {

					logger.error("Adding Proxy Server Changes");
					urlconn = url.openConnection(addProxyToConnection(proxyIp, proxyPort));
					// Authenticator.setDefault(new CustomAuthenticator(proxyUsrNme,proxyPwd));

				} else {
					urlconn = url.openConnection();
				}

				/** Code to Disable Host Name Verification */
				if (disableHostNmeVerification) {

					FLogger.error(logger, THIS_CLASS, methodName,
							"Host Name Validation is Disabled for Https Flow.");
					((HttpsURLConnection) urlconn).setHostnameVerifier(disableHostNameVerification());
				}

				if (!StringChecks.isMapEmpty(headerParameters)) {

					FLogger.info(logger, THIS_CLASS, methodName,"Setting header parameters");

					for (Map.Entry<String, String> map : headerParameters.entrySet()) {

						String key = map.getKey();
						String value = map.getValue();

						FLogger.info(logger, THIS_CLASS, methodName,"Setting header " + key + " | value " + value);
						((HttpsURLConnection) urlconn).setRequestProperty(key, value);

					}
				}

				if (context != null) {

					logger.error("Setting New SSL Context to Https Url Connect.");
					((HttpsURLConnection) urlconn).setSSLSocketFactory(context.getSocketFactory());

				} else {

					logger.error("Https No SSL Context Has Been Set.");

				}

				if (connectionTimeOut > 0) {
					((HttpsURLConnection) urlconn).setConnectTimeout(connectionTimeOut);
				}

				if (connectReadTimeout > 0) {
					((HttpsURLConnection) urlconn).setReadTimeout(connectReadTimeout);
				}

				for (String header : urlconn.getRequestProperties().keySet()) {

					if (header != null) {

						for (String value : urlconn.getRequestProperties().get(header)) {
							logger.debug("Header Set : " + header + ":" + value);
						}
					}
				}

				if (requestType.equalsIgnoreCase(BaseConstants.GET_REQUEST)) {

					((HttpsURLConnection) urlconn).setRequestMethod(BaseConstants.GET_REQUEST);

				} else if (requestType.equalsIgnoreCase(BaseConstants.POST_REQUEST)) {

					FLogger.info(logger, THIS_CLASS, methodName,
							BaseConstants.POST_REQUEST + FLOW_WITH_URL + pURL);

					((HttpsURLConnection) urlconn).setRequestMethod(BaseConstants.POST_REQUEST);
					((HttpsURLConnection) urlconn).setDoOutput(true);

					DataOutputStream wr = new DataOutputStream(urlconn.getOutputStream());
					wr.writeBytes(
							(StringChecks.isFieldEmpty(payload) ? generatePostRequestUrlParams(urlParameters, false)
									: payload));
					wr.flush();
					wr.close();
					
				} else if (requestType.equalsIgnoreCase(BaseConstants.PUT_REQUEST)) {

					FLogger.info(logger, THIS_CLASS, methodName,
							BaseConstants.PUT_REQUEST + FLOW_WITH_URL + pURL);

					((HttpsURLConnection) urlconn).setRequestMethod(BaseConstants.PUT_REQUEST);
					((HttpsURLConnection) urlconn).setDoOutput(true);

					DataOutputStream wr = new DataOutputStream(urlconn.getOutputStream());
					wr.writeBytes((StringChecks.isFieldEmpty(payload) ? generatePostRequestUrlParams(urlParameters, false): payload));
					
					wr.flush();
					wr.close();
					
				}else if (requestType.equalsIgnoreCase(BaseConstants.PATCH_REQUEST)) {

					FLogger.info(logger, THIS_CLASS, methodName,
							BaseConstants.PATCH_REQUEST + FLOW_WITH_URL + pURL);

					((HttpURLConnection) urlconn).setRequestMethod(BaseConstants.PATCH_REQUEST);
					((HttpURLConnection) urlconn).setDoOutput(true);

					DataOutputStream wr = new DataOutputStream(urlconn.getOutputStream());
					wr.writeBytes((StringChecks.isFieldEmpty(payload) ? generatePostRequestUrlParams(urlParameters, false): payload));
					
					wr.flush();
					wr.close();
					
				}

				((HttpsURLConnection) urlconn).connect();

				respCode = ((HttpsURLConnection) urlconn).getResponseCode();

				// Successful Connection
				if (respCode != HttpURLConnection.HTTP_CLIENT_TIMEOUT && respCode == HttpURLConnection.HTTP_OK) {

					FLogger.error(logger, THIS_CLASS, methodName,"Connection established with response Code :" + respCode);

					BufferedReader inp = null;
					int value = 0;
					StringBuilder sb = new StringBuilder();

					InputStream is = null;
					is = fetchUrlConnStream(urlconn,pURL);

					if (is != null) {

						inp = new BufferedReader(new InputStreamReader(is));

						while ((value = inp.read()) != -1) {
							sb.append((char) value);
						}

						inp.close();

						lRespMesg = sb.toString();

					} else {
						lRespMesg = null;
					}

					valueMap.put(RESPCODE, "" + respCode);
					valueMap.put(RESPMSG, lRespMesg);
					valueMap.put(STATUS, BaseConstants.SUCCESS_MSG);
					valueMap.put(STATUS_DESC, BaseConstants.SUCCESS_MSG);

				} else if (respCode == HttpURLConnection.HTTP_CLIENT_TIMEOUT) {

					logger.error("HTTP_CLIENT_TIMEOUT respCode : " + respCode);

					valueMap.put(RESPCODE, "" + respCode);
					valueMap.put(RESPMSG, lRespMesg);
					valueMap.put(STATUS, BaseConstants.TIMEOUT_MSG);
					valueMap.put(STATUS_DESC, BaseConstants.URL_TIMEOUT);

				} else {

					FLogger.error(logger, THIS_CLASS, methodName,
							"Invalid Http Error code " + "Received respCode : " + respCode);

					BufferedReader inp = null;
					int value = 0;
					StringBuilder sb = new StringBuilder();

					InputStream is = null;
					is = fetchUrlConnStream(urlconn,pURL);

					if (is != null) {

						inp = new BufferedReader(new InputStreamReader(is));

						while ((value = inp.read()) != -1) {
							sb.append((char) value);
						}

						inp.close();

						lRespMesg = sb.toString();

					} else {
						lRespMesg = null;
					}

					logger.error("Invalid Http Error code "
							+ "Received lRespMesg : " + (lRespMesg != null ? lRespMesg.length() : 0));

					valueMap.put(RESPCODE, "" + respCode);
					valueMap.put(RESPMSG, lRespMesg);
					valueMap.put(STATUS, BaseConstants.TIMEOUT_MSG);
					valueMap.put(STATUS_DESC, BaseConstants.NO_RESP);
				}

				((HttpsURLConnection) urlconn).disconnect();
				urlconn = null;
			}

			FLogger.info(logger, THIS_CLASS, methodName,"The response code returned" + " by the above URL is :"
					+ respCode + " Response from endPoint : " + (lRespMesg != null ? lRespMesg : ""));

		} catch (SocketTimeoutException ste) {

			StringChecks.printExceptionErrors(ste,logger, THIS_CLASS, methodName);

			valueMap.put(RESPCODE, "" + respCode);
			valueMap.put(RESPMSG, lRespMesg);
			valueMap.put(STATUS, BaseConstants.TIMEOUT_MSG);
			valueMap.put(STATUS_DESC, ste.getMessage());

		} catch (MalformedURLException pME) {

			StringChecks.printExceptionErrors(pME,logger, THIS_CLASS, methodName);

			valueMap.put(RESPCODE, "" + respCode);
			valueMap.put(RESPMSG, lRespMesg);
			valueMap.put(STATUS, BaseConstants.TIMEOUT_MSG);
			valueMap.put(STATUS_DESC, pME.getMessage());

		} catch (Exception ex) {

			StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);

			valueMap.put(RESPCODE, "" + respCode);
			valueMap.put(RESPMSG, lRespMesg);
			valueMap.put(STATUS, BaseConstants.TIMEOUT_MSG);
			valueMap.put(STATUS_DESC, ex.getMessage());

		} finally {

			/** disconnecting UrlConnection if still active */
			if (urlconn != null) {

				logger.error(" disconnecting UrlConnection if still active");

				if (StringChecks.connectionIsHttps(pURL)) {
					((HttpsURLConnection) urlconn).disconnect();
				} else {
					((HttpURLConnection) urlconn).disconnect();
				}
			}

		}

		return valueMap;
	}

	/**
	 * @param trustStorePath
	 * @param trustStorePwd
	 * @return
	 */
	public static SSLContext retrieveSSLContext(String trustStorePath, String trustStorePwd) {

		String methodName = "retrieveSSLContext";

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD);

		KeyStore ts = null;
		SSLContext sslContext = null;

		FileInputStream fs = null;

		try {

			ts = KeyStore.getInstance("JKS");

			fs = new FileInputStream(trustStorePath);

			ts.load(fs, trustStorePwd.toCharArray());

			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(ts);

			sslContext = SSLContext.getInstance(TLSV_1_2);
			sslContext.init(null, tmf.getTrustManagers(), null);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			if (fs != null) {
				try {
					fs.close();
				} catch (Exception e) {
					StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
				}
			}

			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return sslContext;
	}

	/**
	 * @param trustStorePath
	 * @param trustStorePwd
	 * @return
	 */
	public static SSLContext retrieveSSLContext(String trustStorePath, String trustStorePwd, String tlsVersion) {

		String methodName = "retrieveSSLContext";

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD);

		KeyStore ts = null;
		SSLContext sslContext = null;

		FileInputStream fs = null;

		try {

			ts = KeyStore.getInstance("JKS");

			fs = new FileInputStream(trustStorePath);

			ts.load(fs, trustStorePwd.toCharArray());

			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(ts);

			sslContext = SSLContext.getInstance(tlsVersion);
			sslContext.init(null, tmf.getTrustManagers(), null);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			if (fs != null) {
				try {
					fs.close();
				} catch (Exception e) {
					StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
				}
			}

			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return sslContext;
	}

	/**
	 * <p>
	 * This method is used to Fetch Query Parameters passed in Url and create
	 * key-value pairs
	 * </p>
	 * 
	 * @param queryUrl
	 * @return
	 */
	public static Map<String, Object> splitUrlParameters(URL queryUrl) {

		String methodName = "splitUrlParameters";
		FLogger.info(logger, THIS_CLASS, methodName,"Entering Method splitUrlParameters");

		Map<String, Object> query_pairs = new LinkedHashMap<>();
		int idx = 0;
		String query = queryUrl.getQuery();

		try {
			logger.debug("Method splitUrlParameters : Input passed : " + query);

			if (!StringChecks.isFieldEmpty(query)) {

				String[] pairs = query.split("&");

				for (String pair : pairs) {

					idx = pair.indexOf('=');

					if (idx > 0) {

						String key = URLDecoder.decode(pair.substring(0, idx), UTF_8);
						String value = URLDecoder.decode(pair.substring(idx + 1), UTF_8);

						FLogger.debug(logger, THIS_CLASS, methodName,
								"Method splitUrlParameters : key : " + key + VALUE + value);

						if (value != null) {
							query_pairs.put(key, value);
						} else {
							FLogger.debug(logger, THIS_CLASS, methodName,
									"Method splitUrlParameters : No Value passed for Query Param : " + key);
						}
					}

				}
			} else {
				FLogger.error(logger, THIS_CLASS, methodName,
						"Method splitUrlParameters : Query String is Empty or null.");
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

		}

		FLogger.info(logger, THIS_CLASS, methodName,"Exiting Method splitUrlParameters");

		return query_pairs;
	}

	/**
	 * <p>
	 * This method is used to Fetch Query Parameters passed in Url and create
	 * key-value pairs
	 * </p>
	 * 
	 * @param queryUrl
	 * @return
	 */
	public static Map<String, ArrayList<String>> splitUrlMultiParameters(URL queryUrl) {

		String methodName = "splitUrlMultiParameters";
		FLogger.info(logger, THIS_CLASS, methodName,"Entering Method splitUrlMultiParameters");

		Map<String, ArrayList<String>> query_pairs = new LinkedHashMap<>();
		int idx = 0;
		String query = queryUrl.getQuery();

		try {

			logger.debug("Method splitUrlParameters : Input passed : " + query);

			if (!StringChecks.isFieldEmpty(query)) {

				String[] pairs = query.split("&");

				for (String pair : pairs) {

					idx = pair.indexOf('=');

					if (idx > 0) {

						String key = URLDecoder.decode(pair.substring(0, idx), UTF_8);
						String value = URLDecoder.decode(pair.substring(idx + 1), UTF_8);

						FLogger.debug(logger, THIS_CLASS, methodName,
								"Method splitUrlMultiParameters : key : " + key + VALUE + value);

						if (value != null) {
							if (query_pairs.containsKey(key)) {

								ArrayList<String> values = query_pairs.get(key);

								values.add(value);

								query_pairs.put(key, values);

							} else {

								ArrayList<String> values = new ArrayList<>();

								values.add(value);

								query_pairs.put(key, values);
							}
						} else {
							FLogger.debug(logger, THIS_CLASS, methodName,
									"Method splitUrlMultiParameters : No Value passed for Query Param : " + key);
						}

					}
				}
			} else {
				FLogger.error(logger, THIS_CLASS, methodName,
						"Method splitUrlParameters : Query String is Empty or null.");
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

		}

		FLogger.info(logger, THIS_CLASS, methodName,"Exiting Method splitUrlMultiParameters");

		return query_pairs;
	}

	/**
	 * <p>
	 * This method is used to Parse Top Up Response passed in Url and create
	 * key-value pairs
	 * </p>
	 * 
	 * @param respMsg
	 */
	public static Map<String, String> processUrlRespMsg(String respMsg) {

		String methodName = "processUrlRespMsg";
		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD);

		int idx = 0;
		Map<String, String> query_pairs = new LinkedHashMap<>();

		try {

			if (!StringChecks.isFieldEmpty(respMsg)) {

				String[] pairs = respMsg.split("&");

				for (String pair : pairs) {

					if (pair.contains("?")) {

						FLogger.debug(logger, THIS_CLASS, methodName,
								" value : " + pair + " contains ?. so making changes.");

						pair = pair.split("\\?")[1];

						FLogger.debug(logger, THIS_CLASS, methodName,
								" value : " + pair + ".After Making Changes.");

					}

					idx = pair.indexOf('=');

					if (idx > 0) {

						String key = URLDecoder.decode(pair.substring(0, idx), UTF_8);
						String value = URLDecoder.decode(pair.substring(idx + 1), UTF_8);

						logger.debug(" key : " + key + VALUE + value);

						if (value != null) {
							query_pairs.put(key, value);
						} else {
							FLogger.debug(logger, THIS_CLASS, methodName,
									" No Value passed for Query Param : " + key);
						}
					}
				}

				query_pairs.put("stts", BaseConstants.SUCCESS_MSG);

			} else {
				logger.error(" Response Msg passed is Null.");

				query_pairs.put("stts", BaseConstants.FAILED_MSG);
			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

			query_pairs.put("stts", BaseConstants.FAILED_MSG);
		} finally {

			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return query_pairs;
	}

	/**
	 * <p>
	 * This method takes HashMap of Key Values pairs and returns Encoded query
	 * String to be passed in HTTP Post method.
	 * </p>
	 * 
	 * @param params
	 * @return
	 */
	public static String generatePostRequestUrlParams(Map<String, String> params) {

		String methodName = "generatePostRequestUrlParams";
		FLogger.info(logger, THIS_CLASS, methodName,"Entered Method generatePostUrlParams");

		String paramsStr = null;
		StringBuilder query = new StringBuilder();

		try {

			if (!StringChecks.isMapEmpty(params)) {

				for (Map.Entry<String, String> entry : params.entrySet()) {

					String key = entry.getKey();
					String value = entry.getValue();

					if (query.length() > 0) {
						query.append('&');
					}

					query.append(URLEncoder.encode(key, UTF_8));
					query.append('=');

					if (StringChecks.isFieldEmpty(value)) {
						query.append(URLEncoder.encode("", UTF_8));
					} else {
						query.append(URLEncoder.encode(value, UTF_8));
					}

				}

			}

			paramsStr = query.toString();

			FLogger.debug(logger, THIS_CLASS, methodName,
					"Method generatePostUrlParams : Output Encoded Str :" + paramsStr);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return paramsStr;
	}

	/**
	 * <p>
	 * This method takes HashMap of Key Values pairs and returns Encoded query
	 * String to be passed in HTTP Post method.
	 * </p>
	 * 
	 * @param params
	 * @param encodeFlag
	 * @return
	 */
	public static String generatePostRequestUrlParams(Map<String, String> params, boolean encodeFlag) {

		String methodName = "generatePostRequestUrlParams";
		String paramsStr = null;
		StringBuilder query = new StringBuilder();

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		try {

			if (!StringChecks.isMapEmpty(params)) {

				for (Map.Entry<String, String> entry : params.entrySet()) {

					String key = entry.getKey();
					String value = entry.getValue();

					if (query.length() > 0) {
						query.append('&');
					}

					if (encodeFlag) {

						query.append(URLEncoder.encode(key, UTF_8));
						query.append('=');

						if (StringChecks.isFieldEmpty(value)) {
							query.append(URLEncoder.encode("", UTF_8));
						} else {
							query.append(URLEncoder.encode(value, UTF_8));
						}

					} else {

						query.append(key);
						query.append('=');

						if (StringChecks.isFieldEmpty(value)) {
							query.append("");
						} else {
							query.append(value);
						}
					}
				}

				paramsStr = query.toString();
			} else {
				paramsStr = "";
			}

			logger.debug("Output Encoded Str :" + paramsStr);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return paramsStr;
	}

	/**
	 * <p>
	 * This method takes HashMap of Key Values pairs and returns Encoded query
	 * String to be passed in HTTP Post method.
	 * </p>
	 * 
	 * @param params
	 * @return
	 */
	public static String generateGetRequestUrlParams(Map<String, String> params) {

		String methodName = GENERATE_GET_REQUEST_URL_PARAMS;
		String paramsStr = null;
		StringBuilder query = new StringBuilder();

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		try {

			if (!StringChecks.isMapEmpty(params)) {

				for (Map.Entry<String, String> entry : params.entrySet()) {

					String key = entry.getKey();
					String value = entry.getValue();

					if (query.length() > 0) {
						query.append('&');
					}

					query.append(key);
					query.append('=');

					if (StringChecks.isFieldEmpty(value)) {
						query.append("");
					} else {
						query.append(value);
					}
				}

				paramsStr = query.toString();

			} else {
				paramsStr = "";
			}

			logger.debug(OUTPUT_ENCODED_STRING + paramsStr);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return paramsStr;
	}

	/**
	 * <p>
	 * This method takes HashMap of Key Values pairs and returns Encoded query
	 * String to be passed in HTTP Post method.
	 * </p>
	 * 
	 * @param params
	 * @return
	 */
	public static String generateGetRequestUrlParams(Map<String, String> params, boolean encodeFlg) {

		String methodName = GENERATE_GET_REQUEST_URL_PARAMS;
		String paramsStr = null;
		StringBuilder query = new StringBuilder();

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		try {

			if (!StringChecks.isMapEmpty(params)) {

				for (Map.Entry<String, String> entry : params.entrySet()) {

					String key = entry.getKey();
					String value = entry.getValue();

					if (query.length() > 0) {
						query.append('&');
					}

					if (encodeFlg) {
						query.append(URLEncoder.encode(key, UTF_8));
					} else {
						query.append(key);
					}

					query.append('=');

					if (encodeFlg) {

						if (StringChecks.isFieldEmpty(value)) {
							query.append(URLEncoder.encode("", UTF_8));
						} else {
							query.append(URLEncoder.encode(value, UTF_8));
						}

					} else {

						if (StringChecks.isFieldEmpty(value)) {
							query.append("");
						} else {
							query.append(value);
						}
					}
				}

				paramsStr = query.toString();

			} else {
				paramsStr = "";
			}

			logger.debug(OUTPUT_ENCODED_STRING + paramsStr);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return paramsStr;
	}

	/**
	 * <p>
	 * This method takes HashMap of Key Values pairs and returns Encoded query
	 * String to be passed in HTTP Post method.
	 * </p>
	 * 
	 * @param params
	 * @return
	 */
	public static String generateGetRequestUrlParams(Map<String, String> params, List<String> paramOrder) {

		String methodName = GENERATE_GET_REQUEST_URL_PARAMS;
		String paramsStr = null;
		StringBuilder query = new StringBuilder();

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		try {

			if (!StringChecks.isMapEmpty(params)) {

				if (StringChecks.isCollectionEmpty(paramOrder)) {

					for (Map.Entry<String, String> entry : params.entrySet()) {

						String key = entry.getKey();
						String value = entry.getValue();

						if (query.length() > 0) {
							query.append('&');
						}

						query.append(key);
						query.append('=');

						if (StringChecks.isFieldEmpty(value)) {
							query.append("");
						} else {
							query.append(value);
						}

					}

				} else {

					for (String paramKey : paramOrder) {

						if (query.length() > 0) {
							query.append('&');
						}

						query.append(paramKey);
						query.append('=');

						if (StringChecks.isFieldEmpty(params.get(paramKey))) {
							query.append("");
						} else {
							query.append(params.get(paramKey));
						}
					}
				}

				paramsStr = query.toString();

			} else {
				paramsStr = "";
			}

			logger.debug(OUTPUT_ENCODED_STRING + paramsStr);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return paramsStr;
	}

	/**
	 * <p>
	 * This method takes HashMap of Key Values pairs and returns Encoded query
	 * String to be passed in HTTP Post method.
	 * </p>
	 * 
	 * @param params
	 * @return
	 */
	public static String generateGetRequestUrlParams(Map<String, String> params, List<String> paramOrder,
			boolean encodeFlg) {

		String methodName = GENERATE_GET_REQUEST_URL_PARAMS;
		String paramsStr = null;
		StringBuilder query = new StringBuilder();

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		try {

			if (!StringChecks.isMapEmpty(params)) {

				if (StringChecks.isCollectionEmpty(paramOrder)) {

					for (Map.Entry<String, String> entry : params.entrySet()) {

						String key = entry.getKey();
						String value = entry.getValue();

						if (query.length() > 0) {
							query.append('&');
						}

						if (encodeFlg) {
							query.append(URLEncoder.encode(key, UTF_8));
						} else {
							query.append(key);
						}

						query.append('=');

						if (StringChecks.isFieldEmpty(value)) {

							if (encodeFlg) {
								query.append(URLEncoder.encode("", UTF_8));
							} else {
								query.append("");
							}

						} else {

							if (encodeFlg) {
								query.append(URLEncoder.encode(value, UTF_8));
							} else {
								query.append(value);
							}
						}
					}

				} else {

					for (String paramKey : paramOrder) {

						if (query.length() > 0) {
							query.append('&');
						}

						if (encodeFlg) {
							query.append(URLEncoder.encode(paramKey, UTF_8));
						} else {
							query.append(paramKey);
						}

						query.append('=');

						if (StringChecks.isFieldEmpty(params.get(paramKey))) {

							if (encodeFlg) {
								query.append(URLEncoder.encode("", UTF_8));
							} else {
								query.append("");
							}

						} else {

							if (encodeFlg) {
								query.append(URLEncoder.encode(params.get(paramKey), UTF_8));
							} else {
								query.append(params.get(paramKey));
							}
						}
					}
				}

				paramsStr = query.toString();

			} else {
				paramsStr = "";
			}

			logger.debug(OUTPUT_ENCODED_STRING + paramsStr);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return paramsStr;
	}

	/**
	 * <p>
	 * This method is used to Fetch Url Stream
	 * </p>
	 * 
	 * @param connection
	 * @return
	 */
	public static InputStream fetchUrlConnStream(URLConnection connection,String pURL) {

		String methodName = "fetchUrlConnStream";

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		InputStream is = null;
		HttpURLConnection httpConn = null;
		HttpsURLConnection httpsConn = null;

		try {

			if (!StringChecks.connectionIsHttps(pURL)) {

				logger.debug("HttpURLConnection inputStream Fetch ");

				httpConn = (HttpURLConnection) connection;
				is = httpConn.getInputStream();

			} else if (connection instanceof HttpsURLConnection) {

				logger.debug("HttpsURLConnection inputStream Fetch ");

				httpsConn = (HttpsURLConnection) connection;
				is = httpsConn.getInputStream();
			}

		} catch (IOException ie) {

			logger.error(" Got IOException Exception : " + ie.getMessage()
					+ " at " + ie.getStackTrace()[0] + " " + ie.getStackTrace()[1] + " due to: " + ie.getCause(), ie);

			if (!StringChecks.connectionIsHttps(pURL)) {
				
				try {
					httpConn = (HttpURLConnection) connection;

					if (httpConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
						is = httpConn.getErrorStream();
					}

				} catch (IOException e) {
					StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
				}

			} else if (connection instanceof HttpsURLConnection) {
				try {
					httpsConn = (HttpsURLConnection) connection;

					if (httpsConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
						is = httpsConn.getErrorStream();
					}

				} catch (IOException e) {
					StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
				}
			}
			
		} catch (Exception e) {

			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName + " with " + is);
		}

		return is;
	}

	/**
	 * <p>
	 * This method is used to Create Proxy and return same for Http UrlConnection.
	 * </p>
	 * 
	 * @param proxyIp
	 * @param port
	 * @return
	 */
	public static Proxy addProxyToConnection(String proxyIp, int proxyPort) {

		String methodName = "addProxyToConnection";

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD);

		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyIp, proxyPort));

		FLogger.info(logger, THIS_CLASS, methodName,"Exiting Method");

		return proxy;
	}

	/**
	 * This method is used to disable all SSL Validation.
	 */
	/*
	 * Java by default verifies that the certificate CN (Common Name) is the same as
	 * host name in the URL. If the CN in the certificate is not the same as the
	 * host name, your web service client fails. This piece of code allows for using
	 * localhost as host name with a certificate in which the CN does not match.
	 * This is meant to be a workaround while developing the web service and clients
	 * and SHOULD be removed in the production version.
	 */
	public static HostnameVerifier disableHostNameVerification() {

		String methodName = "disableHostNameVerification";

		HostnameVerifier allHostsValid = null;

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		try {

			// Create all-trusting host name verifier
			allHostsValid = new HostnameVerifier() {

				@Override
				public boolean verify(String hostname, SSLSession session) {
					logger.debug("Warning: URL Host: " + hostname + " vs. " + session.getPeerHost());
					return true;
				}
			};

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

		return allHostsValid;
	}

	/**
	 * This method is used to disable all SSL Validation.Must not be used in
	 * Production environment.
	 */
	public static void disableSslVerification() {

		String THIS_CLASS = "RestUtility";
		String methodName = "disableSslVerification";

		FLogger.info(logger, THIS_CLASS, methodName,ENTERED_METHOD + methodName);

		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return new java.security.cert.X509Certificate[0];
				}

				@Override
				public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
						throws CertificateException {

				}

				@Override
				public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
						throws CertificateException {

				}
			} };

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance(TLSV_1_2);
			sc.init(null, trustAllCerts, null);
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName,EXISTING_METHOD + methodName);
		}

	}

}
