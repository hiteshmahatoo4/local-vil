package com.vil.ecom.integration.pojo;


import java.io.Serializable;

public class EcomProcessPaymentReq implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String msisdn;
	
	private String paymentGatewayId;
	
	private String amount;
	
	private String pgOrderID;
	
	private String ecommOrderId;
	
	private String paymentDateTime;
	
	private String gatewayTransactionId;
	
	private String paymentMode;
	
	private String paymentMethodType;
	
	private String paymentGateway;
	
	private String cardIssuer;
	
	private String paymentMethod;
	
	private String cardType;
	
	private String paymentAmount;
	
	
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getPaymentGatewayId() {
		return paymentGatewayId;
	}

	public void setPaymentGatewayId(String paymentGatewayId) {
		this.paymentGatewayId = paymentGatewayId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getPgOrderID() {
		return pgOrderID;
	}

	public void setPgOrderID(String pgOrderID) {
		this.pgOrderID = pgOrderID;
	}

	public String getEcommOrderId() {
		return ecommOrderId;
	}

	public void setEcommOrderId(String pgOrderDetails) {
		this.ecommOrderId = pgOrderDetails;
	}

	public String getPaymentDateTime() {
		return paymentDateTime;
	}

	public void setPaymentDateTime(String refundOrderid) {
		this.paymentDateTime = refundOrderid;
	}

	public String getGatewayTransactionId() {
		return gatewayTransactionId;
	}

	public void setGatewayTransactionId(String gatewayTransactionId) {
		this.gatewayTransactionId = gatewayTransactionId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentMethodType() {
		return paymentMethodType;
	}

	public void setPaymentMethodType(String paymentMethodType) {
		this.paymentMethodType = paymentMethodType;
	}

	public String getPaymentGateway() {
		return paymentGateway;
	}

	public void setPaymentGateway(String paymentGateway) {
		this.paymentGateway = paymentGateway;
	}

	public String getCardIssuer() {
		return cardIssuer;
	}

	public void setCardIssuer(String cardIssuer) {
		this.cardIssuer = cardIssuer;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	
}
