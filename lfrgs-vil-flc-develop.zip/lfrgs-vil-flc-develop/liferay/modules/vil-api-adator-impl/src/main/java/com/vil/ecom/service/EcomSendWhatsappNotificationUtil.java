package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.dxl.whatsappNotification.pojo.Characteristic;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomSendWhatsappNotificationReq;
import com.vil.ecom.integration.pojo.EcomSendWhatsappNotificationResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomSendWhatsappNotificationProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomSendWhatsappNotificationUtil {

	private static final Log logger = LogFactoryUtil.getLog(EcomSendWhatsappNotificationUtil.class);
	private static final String THIS_CLASS = "EcomWhatsappNotificationUtil";
	
	/**
	 * @author 2137665
	 * <p>WhatsApp Notification API: send whatsapp notification</p>
	 * @param processorInput : EcomSendWhatsappNotificationReq pojo to be set for input paramater . Mandatory
	 * <p>
	 * <h2>EcomSendWhatsappNotificationReq pojo details:</h2>
	 * @param msisdn : msisdn for which whatsapp notification to be send is passed .  Mandatory
     * @param whatsappUseCase : WhatsappUseCase to be passed . Mandatory
	 * @param characteristic : List of characteristic objects (name &amp; value ) to be set. Mandatory
	 * <ul>
	 * <li>name : name to be passed. Mandatory</li>
	 * <li>value : value to be passed. Mandatory</li>
	 * </ul>
	 * </p>
	 * 
	 * @return EcomSendWhatsappNotificationResp : WhatsApp Notification process call response
	 * <ul>
	 * <li>responseStatus : response status details for the process call</li>
	 * <li>description: </li>
	 * </ul>
	 * 
	 * 
	 */
	public static EcomSendWhatsappNotificationResp sendWhatsappNotification(EcomSendWhatsappNotificationReq processorInput) {
		
		String methodName =  "sendWhatsappNotification";
		StopWatch stopwatch = null;
		EcomSendWhatsappNotificationResp response = null;
		MrchntRespStts respStts = null;

		
		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();
			
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}
			
			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_SEND_WHATSAPP_NOTIFICATION);
			}
			
            FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
			
			 if(processorInput != null) {
				
				 FLogger.debug(logger, THIS_CLASS, methodName, "Entered method  sendWhatsappNotification with processorInput"
						 +StringChecks.convertObjectToJson(processorInput));
				 
				 respStts = validateInputs(processorInput);
				 
				 if(respStts == null) {
						EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
						srvcRequest.setServiceNme(BaseConstants.API_SERVICES.DXL_SEND_WHATSAPP_NOTIFICATION);
						
						srvcRequest.setWhatsappNotificationReq(processorInput);
				 
						EcomSendWhatsappNotificationProcessor processor = new EcomSendWhatsappNotificationProcessor(srvcRequest);
						EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
						srvcResp = processor.execute();
						
						if(srvcResp != null) {
							if(srvcResp.getWhatsappNotificationResp()!= null) {
								FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API");
								
								response = new EcomSendWhatsappNotificationResp();
								response = srvcResp.getWhatsappNotificationResp();
				 
							}else {
								FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
								respStts = new MrchntRespStts();
								respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
								
								response = new EcomSendWhatsappNotificationResp();
								response.setDescription(null);
								response.setResponseStatus(respStts);
							}
					   }else {
							FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
							
							respStts = new MrchntRespStts();
							respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
							
							response = new EcomSendWhatsappNotificationResp();
							response.setDescription(null);
							response.setResponseStatus(respStts);
						}
						
				 }else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
						
						response = new EcomSendWhatsappNotificationResp();
						response.setDescription(null);
						response.setResponseStatus(respStts);
						
						FLogger.error(logger, THIS_CLASS, methodName, "Response: "+StringChecks.convertObjectToJson(response));
					}
			
			 }else {
					FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");
					
					respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
					
					response = new EcomSendWhatsappNotificationResp();
					response.setDescription(null);
					response.setResponseStatus(respStts);
				}
			 
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			response = new EcomSendWhatsappNotificationResp();
			response.setDescription(null);
			response.setResponseStatus(respStts);
		}finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		 
		}		
		return response;
	}
	/**
	 * 
	 * @param processorInput
	 * @return MrchntRespStts
	 */
	public static MrchntRespStts validateInputs(EcomSendWhatsappNotificationReq processorInput) {
		
		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName);
		
      try {
			
		       FLogger.info(logger, THIS_CLASS, methodName, "Payload: "+StringChecks.convertObjectToJson(processorInput));
				if(processorInput == null) {
					respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
					FLogger.info(logger, THIS_CLASS, methodName, "processorInput is null");
					return respStts;
				}
				
				if(!StringChecks.checkMsisdn(processorInput.getMsisdn())) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Msisdn");
					return respStts;
				}
								
				respStts = RsValiatorResponse.validateStrInput(processorInput.getWhatsappUseCase(), null, "WhatsappUse Case");
				if(respStts !=null) {
					return respStts;
				}				
				
				for(Characteristic chars:processorInput.getCharacteristic()) {
					
					if(StringChecks.isNullOrSpace(chars)) {
						respStts = RsValiatorResponse.invalidParamsResponse(null, "characteristic list is not valid");
						return respStts;
					}
					else {
						respStts = RsValiatorResponse.validateStrInput(chars.getName(),null,"name is not valid in list");
						if(respStts != null) {	
							return respStts;
						}
						respStts = RsValiatorResponse.validateStrInput(chars.getValue(),null,"value is not valid in list");
						if(respStts != null) {
							return respStts;
					}
			     }
					
				}	
			}catch (Exception e) {
				StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			}
			
			return respStts;
		}	
	 }
