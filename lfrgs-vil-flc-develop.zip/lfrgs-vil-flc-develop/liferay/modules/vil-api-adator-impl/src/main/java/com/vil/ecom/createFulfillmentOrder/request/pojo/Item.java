
package com.vil.ecom.createFulfillmentOrder.request.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "quantity",
    "unit_price",
    "total_price",
    "sku_id",
    "description",
    "product_category",
    "fulfillment"
})
public class Item implements Serializable
{

    @JsonProperty("id")
    private String id;
    @JsonProperty("quantity")
    private String quantity;
    @JsonProperty("unit_price")
    private String unitPrice;
    @JsonProperty("total_price")
    private String totalPrice;
    @JsonProperty("sku_id")
    private String skuId;
    @JsonProperty("description")
    private String description;
    @JsonProperty("product_category")
    private String productCategory;
    @JsonProperty("fulfillment")
    private Fulfillment fulfillment;
    private final static long serialVersionUID = 5646453792446807350L;

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("quantity")
    public String getQuantity() {
        return quantity;
    }

    @JsonProperty("quantity")
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    @JsonProperty("unit_price")
    public String getUnitPrice() {
        return unitPrice;
    }

    @JsonProperty("unit_price")
    public void setUnitPrice(String unitPrice) {
        this.unitPrice = unitPrice;
    }

    @JsonProperty("total_price")
    public String getTotalPrice() {
        return totalPrice;
    }

    @JsonProperty("total_price")
    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    @JsonProperty("sku_id")
    public String getSkuId() {
        return skuId;
    }

    @JsonProperty("sku_id")
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("product_category")
    public String getProductCategory() {
        return productCategory;
    }

    @JsonProperty("product_category")
    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    @JsonProperty("fulfillment")
    public Fulfillment getFulfillment() {
        return fulfillment;
    }

    @JsonProperty("fulfillment")
    public void setFulfillment(Fulfillment fulfillment) {
        this.fulfillment = fulfillment;
    }

}
