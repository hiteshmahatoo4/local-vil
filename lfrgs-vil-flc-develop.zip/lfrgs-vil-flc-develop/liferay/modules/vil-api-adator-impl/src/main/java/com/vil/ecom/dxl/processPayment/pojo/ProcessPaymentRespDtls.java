package com.vil.ecom.dxl.processPayment.pojo;

public class ProcessPaymentRespDtls {

	private String orderId;

	private String fulfillmentTransactionId;
	
	private String fulfillmentTransactionStatus ;
	
	private String fulfillmentTransactionStatusCode;
	
	private String fulfillmentFailureReason;

	

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getFulfillmentTransactionId() {
		return fulfillmentTransactionId;
	}

	public void setFulfillmentTransactionId(String fulfillmentTransactionId) {
		this.fulfillmentTransactionId = fulfillmentTransactionId;
	}

	public String getFulfillmentTransactionStatus() {
		return fulfillmentTransactionStatus;
	}

	public void setFulfillmentTransactionStatus(String fulfillmentTransactionStatus) {
		this.fulfillmentTransactionStatus = fulfillmentTransactionStatus;
	}

	public String getFulfillmentTransactionStatusCode() {
		return fulfillmentTransactionStatusCode;
	}

	public void setFulfillmentTransactionStatusCode(String fulfillmentTransactionStatusCode) {
		this.fulfillmentTransactionStatusCode = fulfillmentTransactionStatusCode;
	}

	public String getFulfillmentFailureReason() {
		return fulfillmentFailureReason;
	}

	public void setFulfillmentFailureReason(String fulfillmentFailureReason) {
		this.fulfillmentFailureReason = fulfillmentFailureReason;
	}
	
	
}
