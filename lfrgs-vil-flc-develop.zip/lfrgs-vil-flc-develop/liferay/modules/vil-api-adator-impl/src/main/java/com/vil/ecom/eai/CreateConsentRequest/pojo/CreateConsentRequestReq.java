
package com.vil.ecom.eai.CreateConsentRequest.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "client_code",
    "requested_msisdns"
})
public class CreateConsentRequestReq {

    @JsonProperty("client_code")
    private String clientCode;
    @JsonProperty("requested_msisdns")
    private RequestedMsisdns requestedMsisdns;
   

    @JsonProperty("client_code")
    public String getClientCode() {
        return clientCode;
    }

    @JsonProperty("client_code")
    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    @JsonProperty("requested_msisdns")
    public RequestedMsisdns getRequestedMsisdns() {
        return requestedMsisdns;
    }

    @JsonProperty("requested_msisdns")
    public void setRequestedMsisdns(RequestedMsisdns requestedMsisdns) {
        this.requestedMsisdns = requestedMsisdns;
    }

   

}
