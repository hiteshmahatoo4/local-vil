package com.vil.ecom.eai.UploadEvents.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Beneficiary_Name",
    "Product_Name",
    "Duration",
    "Category",
    "Price",
    "start_date",
    "end_date"
})
public class EvtData implements Serializable
{

    @JsonProperty("Beneficiary_Name")
    private String beneficiaryName;
    @JsonProperty("Product_Name")
    private String productName;
    @JsonProperty("Duration")
    private String duration;
    @JsonProperty("Category")
    private String category;
    @JsonProperty("Price")
    private Double price;
    @JsonProperty("start_date")
    private String startDate;
    @JsonProperty("end_date")
    private String endDate;
    private final static long serialVersionUID = -9103120544428465791L;

    @JsonProperty("Beneficiary_Name")
    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    @JsonProperty("Beneficiary_Name")
    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    @JsonProperty("Product_Name")
    public String getProductName() {
        return productName;
    }

    @JsonProperty("Product_Name")
    public void setProductName(String productName) {
        this.productName = productName;
    }

    @JsonProperty("Duration")
    public String getDuration() {
        return duration;
    }

    @JsonProperty("Duration")
    public void setDuration(String duration) {
        this.duration = duration;
    }

    @JsonProperty("Category")
    public String getCategory() {
        return category;
    }

    @JsonProperty("Category")
    public void setCategory(String category) {
        this.category = category;
    }

    @JsonProperty("Price")
    public Double getPrice() {
        return price;
    }

    @JsonProperty("Price")
    public void setPrice(Double price) {
        this.price = price;
    }

    @JsonProperty("start_date")
    public String getStartDate() {
        return startDate;
    }

    /**
     * 
     * @param startDate : String of startDate in format yyyy-MM-dd HH:mm:ss
     */
    @JsonProperty("start_date")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("end_date")
    public String getEndDate() {
        return endDate;
    }

    /**
     * 
     * @param endDate : String of endDate in format yyyy-MM-dd HH:mm:ss
     */
    @JsonProperty("end_date")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

}
