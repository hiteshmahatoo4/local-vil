package com.vil.ecom.dxl.processPayment.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"msisdn",
	"parentMSISDN",
	"action",
	"signature",
	"platform",
	"correlatorId",
	"transactionType",
	"description",
	"redirectURL",
	"paymentGatewayId",
	"paymentGateway",
	"paymentDate",
	"totalAmount",
	"payer",
	"paymentItem",
	"characteristic"
	
})

public class ProcessPaymentReq {

	@JsonProperty("msisdn")
	private String msisdn;
	@JsonProperty("parentMSISDN")
	private String parentMSISDN;
	@JsonProperty("action")
	private String action;
	@JsonProperty("signature")
	private String signature;
	@JsonProperty("platform")
	private String platform;
	@JsonProperty("correlatorId")
	private String correlatorId;
	@JsonProperty("transactionType")
	private String transactionType;
	@JsonProperty("description")
	private String description;
	@JsonProperty("redirectURL")
	private String redirectUrl;
	@JsonProperty("paymentGatewayId")
	private String paymentGatewayId;
	@JsonProperty("paymentGateway")
	private String paymentGateway;
	@JsonProperty("paymentDate")
	private String paymentDate;
	@JsonProperty("totalAmount")
	private TotalAmount totalAmount;
	@JsonProperty("payer")
	private Payer payer;
	@JsonProperty("paymentItem")
	private List<PaymentItem> paymentItem;
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic;
	
	
	@JsonProperty("msisdn")
	public String getMsisdn() {
	return msisdn;
	}
	
	@JsonProperty("msisdn")
	public void setMsisdn(String msisdn) {
	this.msisdn = msisdn;
	}
	
	@JsonProperty("parentMSISDN")
	public String getParentMSISDN() {
	return parentMSISDN;
	}
	
	@JsonProperty("parentMSISDN")
	public void setParentMSISDN(String parentMSISDN) {
	this.parentMSISDN = parentMSISDN;
	}
	
	@JsonProperty("action")
	public String getAction() {
	return action;
	}
	
	@JsonProperty("action")
	public void setAction(String action) {
	this.action = action;
	}
	
	@JsonProperty("signature")
	public String getSignature() {
	return signature;
	}
	
	@JsonProperty("signature")
	public void setSignature(String signature) {
	this.signature = signature;
	}
	
	@JsonProperty("platform")
	public String getPlatform() {
	return platform;
	}
	
	@JsonProperty("platform")
	public void setPlatform(String platform) {
	this.platform = platform;
	}
	
	@JsonProperty("correlatorId")
	public String getCorrelatorId() {
	return correlatorId;
	}
	
	@JsonProperty("correlatorId")
	public void setCorrelatorId(String correlatorId) {
	this.correlatorId = correlatorId;
	}
	
	@JsonProperty("transactionType")
	public String getTransactionType() {
	return transactionType;
	}
	
	@JsonProperty("transactionType")
	public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
	}
	
	@JsonProperty("description")
	public String getDescription() {
	return description;
	}
	
	@JsonProperty("description")
	public void setDescription(String description) {
	this.description = description;
	}
	
	@JsonProperty("redirectURL")
	public String getRedirectUrl() {
	return redirectUrl;
	}

	@JsonProperty("redirectURL")
	public void setRedirectUrl(String redirectUrl) {
	this.redirectUrl = redirectUrl;
	}

	@JsonProperty("paymentGatewayId")
	public String getPaymentGatewayId() {
		return paymentGatewayId;
	}

	@JsonProperty("paymentGatewayId")
	public void setPaymentGatewayId(String paymentGatewayId) {
		this.paymentGatewayId = paymentGatewayId;
	}
	
	public String getPaymentGateway() {
		return paymentGateway;
	}

	public void setPaymentGateway(String paymentGateway) {
		this.paymentGateway = paymentGateway;
	}

	@JsonProperty("paymentDate")
	public String getPaymentDate() {
	return paymentDate;
	}
	
	@JsonProperty("paymentDate")
	public void setPaymentDate(String paymentDate) {
	this.paymentDate = paymentDate;
	}
	
	@JsonProperty("totalAmount")
	public TotalAmount getTotalAmount() {
	return totalAmount;
	}
	
	@JsonProperty("totalAmount")
	public void setTotalAmount(TotalAmount totalAmount) {
	this.totalAmount = totalAmount;
	}
	
	@JsonProperty("payer")
	public Payer getPayer() {
	return payer;
	}
	
	@JsonProperty("payer")
	public void setPayer(Payer payer) {
	this.payer = payer;
	}
	
	@JsonProperty("paymentItem")
	public List<PaymentItem> getPaymentItem() {
	return paymentItem;
	}
	
	@JsonProperty("paymentItem")
	public void setPaymentItem(List<PaymentItem> paymentItem) {
	this.paymentItem = paymentItem;
	}
	
	@JsonProperty("characteristic")
	public List<Characteristic> getCharacteristic() {
	return characteristic;
	}
	
	@JsonProperty("characteristic")
	public void setCharacteristic(List<Characteristic> characteristic) {
	this.characteristic = characteristic;
	}

}