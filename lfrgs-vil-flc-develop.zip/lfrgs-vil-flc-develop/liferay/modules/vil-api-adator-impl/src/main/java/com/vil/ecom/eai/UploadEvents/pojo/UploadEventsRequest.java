package com.vil.ecom.eai.UploadEvents.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "d"
})

public class UploadEventsRequest implements Serializable
{

    @JsonProperty("d")
    private List<D> d;
    private final static long serialVersionUID = -4027416146851845601L;

    @JsonProperty("d")
    public List<D> getD() {
        return d;
    }

    @JsonProperty("d")
    public void setD(List<D> d) {
        this.d = d;
    }

}
