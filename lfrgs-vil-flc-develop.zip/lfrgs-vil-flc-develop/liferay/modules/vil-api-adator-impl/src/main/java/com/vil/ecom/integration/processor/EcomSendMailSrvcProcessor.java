package com.vil.ecom.integration.processor;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.integration.config.AppServiceProcessor;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntLogVO;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomSendMailReqDtls;
import com.vil.ecom.integration.pojo.EcomSendMailRespDtls;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.logger.srvc.EcomMrchntLogHelper;
import com.vil.ecom.service.EcomSendMailServiceImpl;
import com.vil.ecom.service.EcomSrvcConfigCnstntsServiceImpl;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EcomSendMailSrvcProcessor implements AppServiceProcessor {

	private static final Log logger = LogFactoryUtil.getLog(EcomSendMailSrvcProcessor.class);
	private static final String THIS_CLASS = EcomSendMailSrvcProcessor.class.toString();

	private EcomMrchntServiceRequest srvcRequest = null;
	private EcomMrchntServiceResponse srvcResponse;

	private EcomSendMailReqDtls request = null;

	/** Map consisting API specific configurations stored in DB. */
	private Map<String, Object> confMap = null;

	/** Map consisting Url response received after connecting to 3rd party api. */
	private Map<String, Object> urlResponseMap = null;

	/** API Name for which processor is implemented. */
	private String serviceNme = null;

	/** Pojo for logging of API request and response. */
	private EcomMrchntLogVO logVO = null;


	public EcomSendMailSrvcProcessor(EcomMrchntServiceRequest srvcRequest) {
		this.srvcRequest = srvcRequest;
	}

	@Override
	public void preSrvcInputProcessor() {

		String thisMethod = "preSrvcInputProcessor";

		FLogger.debug(logger, THIS_CLASS, thisMethod, "Entered " + thisMethod);

		if (srvcRequest != null && srvcRequest.getSendMailReqDtls() != null) {

			serviceNme = srvcRequest.getServiceNme();

			FLogger.debug(logger, THIS_CLASS, thisMethod,
					"Setting Request Data for Service : " + srvcRequest.getServiceNme()
					+" | serviceNme : "+serviceNme);

			confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap(srvcRequest.getServiceNme());

			request = new EcomSendMailReqDtls();
			request.setEmailBody(srvcRequest.getSendMailReqDtls().getEmailBody());
			request.setSubject(srvcRequest.getSendMailReqDtls().getSubject());
			request.setFrmEmailId(srvcRequest.getSendMailReqDtls().getFrmEmailId());
			request.setToEmailId(srvcRequest.getSendMailReqDtls().getToEmailId());
			request.setCcEmailId(srvcRequest.getSendMailReqDtls().getCcEmailId());
			request.setRefNo(srvcRequest.getSendMailReqDtls().getRefNo());
			request.setAttachment(srvcRequest.getSendMailReqDtls().getAttachment());
			
			if(RequestResourceThreadLocal.getModuleNmeForCurrentThread()==null) {
				RequestResourceThreadLocal.addModuleNmeForCurrentThread("api-adaptor");
			}
			
		} else {

			FLogger.error(logger,THIS_CLASS, thisMethod, "Request Object is null");
		}

	}

	@Override
	public EcomMrchntServiceResponse execute() {

		String thisMethod = "execute";
		FLogger.debug(logger, THIS_CLASS, thisMethod, "START");

		try {

			preSrvcInputProcessor();

			String senderEmailId = null;
			
			if(!StringChecks.isFieldEmpty(request.getFrmEmailId())) {
				senderEmailId = request.getFrmEmailId();
			}else {
				senderEmailId = (String) confMap.get(BaseConstants.EMAIL.SENDER_EMAIL_ID);
			}
			
			FLogger.debug(logger, THIS_CLASS, thisMethod, "senderEmailId is " + senderEmailId);

			logVO = new EcomMrchntLogVO();
			logVO.setRequestType(BaseConstants.RESTWS.REST_OUTWARD_REQ);
			logVO.setFiller6(RequestResourceThreadLocal.getRequestIdForCurrentThread());
			logVO.setServiceNme(srvcRequest.getServiceNme());
			logVO.setSourceIp(StringChecks.fetchLocalIpAddr());
			logVO.setIpAddr(StringChecks.fetchLocalIpAddr());
			logVO.setMsisdn(senderEmailId);
			logVO.setRequestParams(request.getEmailBody());
			
			logVO.setFiller1(request.getToEmailId());
			logVO.setFiller2(request.getCcEmailId());
			logVO.setFiller3(request.getSubject());
			logVO.setFiller4(request.getRefNo());
			
			logVO.setRequestTime(Calendar.getInstance().getTime());
			
			EcomSendMailServiceImpl mailService = new EcomSendMailServiceImpl();
			
			String toEmailList = request.getToEmailId();
			String ccEmailList = request.getCcEmailId();
			
			if(!StringChecks.isAnyFieldEmpty((String) confMap.get("TO_EMAIL_LIST"))) {
				
				toEmailList = (String) confMap.get("TO_EMAIL_LIST");
				ccEmailList = null;
				FLogger.error(logger, THIS_CLASS, thisMethod, "toEmailList is: "+toEmailList);
			}
			
			if(!StringChecks.isAnyFieldEmpty((String) confMap.get("CC_EMAIL_LIST"))) {
				
				ccEmailList = (String) confMap.get("CC_EMAIL_LIST");
				FLogger.error(logger, THIS_CLASS, thisMethod, "ccEmailList is: "+ccEmailList);
			
			}
			
			if(request.getAttachment()!=null) {
				
				FLogger.error(logger,THIS_CLASS, thisMethod, "Attachment Flow is " + senderEmailId);

				urlResponseMap = mailService.sendMailWithAttachment(request.getAttachment(),toEmailList, 
						ccEmailList,request.getEmailBody(),senderEmailId, request.getSubject(), false, confMap);

			}else {
				
				urlResponseMap = mailService.sendMail(toEmailList, ccEmailList,
						request.getEmailBody(),senderEmailId, request.getSubject(), false, confMap);

			}
			
			/** Changes done for Local Testing */
			if (confMap.get("REST_DUMMY_RESP_FLG") != null) {

				boolean dummyFlg = Boolean.parseBoolean((String) confMap.get("REST_DUMMY_RESP_FLG"));

				if (dummyFlg) {

					String dummyResp = (String) confMap.get("REST_DUMMY_RESP");

					if (!StringChecks.isFieldEmpty(dummyResp)) {

						FLogger.info(logger,THIS_CLASS, thisMethod,
								"Dummy Response Set for Service " + srvcRequest.getServiceNme());

						HashMap<String, Object> dummyMap = new HashMap<>();
						dummyMap.put("respCode", "200");
						dummyMap.put("status", BaseConstants.SUCCESS_MSG);
						dummyMap.put("statusDesc", BaseConstants.SUCCESS_MSG);
						dummyMap.put("respMsg", dummyResp);

						urlResponseMap = dummyMap;
					}

				} else {
					FLogger.info(logger,THIS_CLASS, thisMethod, "No Dummy Response Set.");
				}
			}

			parseResponse();

			if(srvcResponse!=null 
					&& srvcResponse.getResponseStatus()!=null) {
				
				FLogger.error(logger,THIS_CLASS, thisMethod, "Exiting Method " + thisMethod + " with Stts "
						+ (srvcResponse.getResponseStatus().getStatus()));
			}
			

		} catch (Exception e) {

			FLogger.error(logger,THIS_CLASS, thisMethod, " Got Exception: " + e.getMessage() + " at "
					+ e.getStackTrace()[0] + " " + e.getStackTrace()[1] + " due to: " + e.getCause(), e);
		}

		return postSrvcOutputProcessor();

	}

	@Override
	public EcomMrchntServiceResponse postSrvcOutputProcessor() {

		FLogger.error(logger,THIS_CLASS, "postSrvcOutputProcessor", "Returning response");
		return srvcResponse;

	}

	@Override
	public void parseResponse() {

		String thisMethod = "parseResponse";
		String status = null;

		String respJson = null;

		status = (urlResponseMap != null ? (String) urlResponseMap.get("status") : null);
		String errorDesc = (urlResponseMap != null ? (String) urlResponseMap.get("statusDesc") : null);
		String errorCde = (urlResponseMap != null ? (String) urlResponseMap.get("respCode") : null);

		if (BaseConstants.SUCCESS_MSG.equalsIgnoreCase(status)) {

			FLogger.error(logger,THIS_CLASS, thisMethod, "Success In API Url Connection");

			MrchntRespStts respStts = new MrchntRespStts();
			respStts.setDescription(BaseConstants.SUCCESS_MSG);
			respStts.setStatus(BaseConstants.SUCCESS_MSG);
			respStts.setStatusCde(BaseConstants.SUCCESS_MSG);

			logVO.setRespStts(BaseConstants.SUCCESS_MSG);
			logVO.setRespSttsCde(errorCde);
			logVO.setRespSttsDesc(errorDesc);

			Long recordIdLong= EcomMrchntLogHelper.logResponseForRestWs(logVO);

			EcomSendMailRespDtls sendMailRespDtls = new EcomSendMailRespDtls();
			sendMailRespDtls.setRefNo(request.getRefNo());
			sendMailRespDtls.setAuditId(recordIdLong);
			sendMailRespDtls.setResponseStatus(respStts);
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setResponseStatus(respStts);
			srvcResponse.setSendMailRespDtls(sendMailRespDtls);

		} else if (BaseConstants.ERROR_MSG.equalsIgnoreCase(status)
				|| BaseConstants.FAILED_MSG.equalsIgnoreCase(status)
				|| BaseConstants.FAILURE_MSG.equalsIgnoreCase(status)) {

			FLogger.error(logger,THIS_CLASS, thisMethod, "Failure Scenario in API");

			MrchntRespStts respStts = new MrchntRespStts();
			respStts.setStatus(BaseConstants.FAILURE_MSG);
			respStts.setDescription(errorDesc);
			respStts.setStatusCde(errorCde);

			logVO.setRespStts(BaseConstants.FAILURE_MSG);
			logVO.setRespSttsCde(errorCde);
			logVO.setRespSttsDesc(errorDesc);

			FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");

			logVO.setResponseParams(respJson);

			Long recordIdLong= EcomMrchntLogHelper.logResponseForRestWs(logVO);

			EcomSendMailRespDtls sendMailRespDtls = new EcomSendMailRespDtls();
			sendMailRespDtls.setRefNo(request.getRefNo());
			sendMailRespDtls.setAuditId(recordIdLong);
			sendMailRespDtls.setResponseStatus(respStts);
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setResponseStatus(respStts);
			srvcResponse.setSendMailRespDtls(sendMailRespDtls);

		} else if (BaseConstants.TIMEOUT_MSG.equalsIgnoreCase(status)) {

			FLogger.error(logger,THIS_CLASS, thisMethod, "TimeOut Scenario in Url Connection to API");

			MrchntRespStts respStts = new MrchntRespStts();
			respStts.setDescription(BaseConstants.TIMEOUT_MSG);
			respStts.setStatus(BaseConstants.TIMEOUT_MSG);
			respStts.setStatusCde(BaseConstants.TIMEOUT_MSG);

			logVO.setRespStts(BaseConstants.TIMEOUT_MSG);
			logVO.setRespSttsCde(errorCde);
			logVO.setRespSttsDesc(errorDesc);
			logVO.setResponseParams(respJson);

			FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");

			Long recordIdLong= EcomMrchntLogHelper.logResponseForRestWs(logVO);

			EcomSendMailRespDtls sendMailRespDtls = new EcomSendMailRespDtls();
			sendMailRespDtls.setRefNo(request.getRefNo());
			sendMailRespDtls.setAuditId(recordIdLong);
			sendMailRespDtls.setResponseStatus(respStts);
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setResponseStatus(respStts);
			srvcResponse.setSendMailRespDtls(sendMailRespDtls);

		} else {

			FLogger.error(logger,THIS_CLASS, thisMethod, "Unknown Scenario in Url Connection to API");

			
			MrchntRespStts respStts = new MrchntRespStts();
			respStts.setDescription(BaseConstants.TIMEOUT_MSG);
			respStts.setStatus(BaseConstants.TIMEOUT_MSG);
			respStts.setStatusCde(BaseConstants.TIMEOUT_MSG);

			logVO.setRespStts(BaseConstants.TIMEOUT_MSG);
			logVO.setRespSttsCde(errorCde);
			logVO.setRespSttsDesc(errorDesc);

			FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");

			logVO.setResponseParams(respJson);

			Long recordIdLong= EcomMrchntLogHelper.logResponseForRestWs(logVO);

			EcomSendMailRespDtls sendMailRespDtls = new EcomSendMailRespDtls();
			sendMailRespDtls.setRefNo(request.getRefNo());
			sendMailRespDtls.setAuditId(recordIdLong);
			sendMailRespDtls.setResponseStatus(respStts);
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setResponseStatus(respStts);
			srvcResponse.setSendMailRespDtls(sendMailRespDtls);

		}

	}

}
