
package com.vil.ecom.fulfillmentOrderSttsQuery.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "state",
    "items"
})
public class Order implements Serializable {

	@JsonProperty("id")
	private String id;
	@JsonProperty("state")
	private String state;
	@JsonProperty("items")
	private List<Item> items;
	private final static long serialVersionUID = 261437939833154193L;

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	public Order withId(String id) {
		this.id = id;
		return this;
	}

	@JsonProperty("state")
	public String getState() {
		return state;
	}

	@JsonProperty("state")
	public void setState(String state) {
		this.state = state;
	}

	public Order withState(String state) {
		this.state = state;
		return this;
	}

	@JsonProperty("items")
	public List<Item> getItems() {
		return items;
	}

	@JsonProperty("items")
	public void setItems(List<Item> items) {
		this.items = items;
	}

	public Order withItems(List<Item> items) {
		this.items = items;
		return this;
	}

}
