package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class EcomMrchntSmsLogVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;

	private String msisdn;

	private String circleId;

	private String stts;

	private String smsTxt;

	private String event;

	private String crtdby;

	private String crctOn;

	private String updtdby;

	private String updtdOn;

	private String resend_sms_flag;

	private String filler1;

	private String filler2;

	private String filler3;

	private String filler4;

	private String filler5;

	private String senderId;

	private String purpose;

	private String srNumber;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the stts
	 */
	public String getStts() {
		return stts;
	}

	/**
	 * @param stts the stts to set
	 */
	public void setStts(String stts) {
		this.stts = stts;
	}

	/**
	 * @return the smsTxt
	 */
	public String getSmsTxt() {
		return smsTxt;
	}

	/**
	 * @param smsTxt the smsTxt to set
	 */
	public void setSmsTxt(String smsTxt) {
		this.smsTxt = smsTxt;
	}

	/**
	 * @return the event
	 */
	public String getEvent() {
		return event;
	}

	/**
	 * @param event the event to set
	 */
	public void setEvent(String event) {
		this.event = event;
	}

	/**
	 * @return the crtdby
	 */
	public String getCrtdby() {
		return crtdby;
	}

	/**
	 * @param crtdby the crtdby to set
	 */
	public void setCrtdby(String crtdby) {
		this.crtdby = crtdby;
	}

	/**
	 * @return the crctOn
	 */
	public String getCrctOn() {
		return crctOn;
	}

	/**
	 * @param crctOn the crctOn to set
	 */
	public void setCrctOn(String crctOn) {
		this.crctOn = crctOn;
	}

	/**
	 * @return the updtdby
	 */
	public String getUpdtdby() {
		return updtdby;
	}

	/**
	 * @param updtdby the updtdby to set
	 */
	public void setUpdtdby(String updtdby) {
		this.updtdby = updtdby;
	}

	/**
	 * @return the updtdOn
	 */
	public String getUpdtdOn() {
		return updtdOn;
	}

	/**
	 * @param updtdOn the updtdOn to set
	 */
	public void setUpdtdOn(String updtdOn) {
		this.updtdOn = updtdOn;
	}

	/**
	 * @return the resend_sms_flag
	 */
	public String getResend_sms_flag() {
		return resend_sms_flag;
	}

	/**
	 * @param resend_sms_flag the resend_sms_flag to set
	 */
	public void setResend_sms_flag(String resend_sms_flag) {
		this.resend_sms_flag = resend_sms_flag;
	}

	/**
	 * @return the filler1
	 */
	public String getFiller1() {
		return filler1;
	}

	/**
	 * @param filler1 the filler1 to set
	 */
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

	/**
	 * @return the filler2
	 */
	public String getFiller2() {
		return filler2;
	}

	/**
	 * @param filler2 the filler2 to set
	 */
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	/**
	 * @return the filler3
	 */
	public String getFiller3() {
		return filler3;
	}

	/**
	 * @param filler3 the filler3 to set
	 */
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}

	/**
	 * @return the filler4
	 */
	public String getFiller4() {
		return filler4;
	}

	/**
	 * @param filler4 the filler4 to set
	 */
	public void setFiller4(String filler4) {
		this.filler4 = filler4;
	}

	/**
	 * @return the filler5
	 */
	public String getFiller5() {
		return filler5;
	}

	/**
	 * @param filler5 the filler5 to set
	 */
	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the senderId
	 */
	public String getSenderId() {
		return senderId;
	}

	/**
	 * @param senderId the senderId to set
	 */
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	/**
	 * @return the srNumber
	 */
	public String getSrNumber() {
		return srNumber;
	}

	/**
	 * @param srNumber the srNumber to set
	 */
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}

	/**
	 * @return the purpose
	 */
	public String getPurpose() {
		return purpose;
	}

	/**
	 * @param purpose the purpose to set
	 */
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

}
