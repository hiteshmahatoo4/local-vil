package com.vil.ecom.integration.pojo;

import java.io.Serializable;
import java.util.Date;

public class EcomMrchntLogVO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String msisdn;

	private String amt;

	private String serviceNme;

	private String channelId;

	private String requestId;

	private String respStts;

	private String respSttsCde;

	private String respSttsDesc;

	private String errorMsg;

	private String requestParams;

	private String responseParams;
	
	private Integer recordId;
	
	private String requestType;

	private String sourceIp;
	
	/** HTTP_STTS_CDE */
	private String httpSttsCde;

	/** HTTP_STTS_MSG */
	private String httpSttsMsg;
	
	/** IP_ADDR */
	private String ipAddr;

	private String filler1;

	private String filler2;

	private String filler3;

	private String filler4;

	private String filler5;
	
	private String filler6;

	private String filler7;

	private String filler8;

	private String filler9;
	
	private String filler10;
	
	private Date requestTime;
	
	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the amt
	 */
	public String getAmt() {
		return amt;
	}

	/**
	 * @param amt the amt to set
	 */
	public void setAmt(String amt) {
		this.amt = amt;
	}

	/**
	 * @return the serviceNme
	 */
	public String getServiceNme() {
		return serviceNme;
	}

	/**
	 * @param serviceNme the serviceNme to set
	 */
	public void setServiceNme(String serviceNme) {
		this.serviceNme = serviceNme;
	}

	/**
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the filler1
	 */
	public String getFiller1() {
		return filler1;
	}

	/**
	 * @param filler1 the filler1 to set
	 */
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

	/**
	 * @return the filler2
	 */
	public String getFiller2() {
		return filler2;
	}

	/**
	 * @param filler2 the filler2 to set
	 */
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	/**
	 * @return the filler3
	 */
	public String getFiller3() {
		return filler3;
	}

	/**
	 * @param filler3 the filler3 to set
	 */
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}

	/**
	 * @return the filler4
	 */
	public String getFiller4() {
		return filler4;
	}

	/**
	 * @param filler4 the filler4 to set
	 */
	public void setFiller4(String filler4) {
		this.filler4 = filler4;
	}

	/**
	 * @return the filler5
	 */
	public String getFiller5() {
		return filler5;
	}

	/**
	 * @param filler5 the filler5 to set
	 */
	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}

	/**
	 * @return the filler6
	 */
	public String getFiller6() {
		return filler6;
	}

	/**
	 * @param filler6 the filler6 to set
	 */
	public void setFiller6(String filler6) {
		this.filler6 = filler6;
	}

	/**
	 * @return the respStts
	 */
	public String getRespStts() {
		return respStts;
	}

	/**
	 * @param respStts the respStts to set
	 */
	public void setRespStts(String respStts) {
		this.respStts = respStts;
	}

	/**
	 * @return the respSttsCde
	 */
	public String getRespSttsCde() {
		return respSttsCde;
	}

	/**
	 * @param respSttsCde the respSttsCde to set
	 */
	public void setRespSttsCde(String respSttsCde) {
		this.respSttsCde = respSttsCde;
	}

	/**
	 * @return the respSttsDesc
	 */
	public String getRespSttsDesc() {
		return respSttsDesc;
	}

	/**
	 * @param respSttsDesc the respSttsDesc to set
	 */
	public void setRespSttsDesc(String respSttsDesc) {
		this.respSttsDesc = respSttsDesc;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the requestParams
	 */
	public String getRequestParams() {
		return requestParams;
	}

	/**
	 * @param requestParams the requestParams to set
	 */
	public void setRequestParams(String requestParams) {
		this.requestParams = requestParams;
	}

	/**
	 * @return the responseParams
	 */
	public String getResponseParams() {
		return responseParams;
	}

	/**
	 * @param responseParams the responseParams to set
	 */
	public void setResponseParams(String responseParams) {
		this.responseParams = responseParams;
	}

	/**
	 * @return the recordId
	 */
	public Integer getRecordId() {
		return recordId;
	}

	/**
	 * @param recordId the recordId to set
	 */
	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}

	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}

	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	/**
	 * @return the sourceIp
	 */
	public String getSourceIp() {
		return sourceIp;
	}

	/**
	 * @param sourceIp the sourceIp to set
	 */
	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}

	/**
	 * @return the httpSttsCde
	 */
	public String getHttpSttsCde() {
		return httpSttsCde;
	}

	/**
	 * @param httpSttsCde the httpSttsCde to set
	 */
	public void setHttpSttsCde(String httpSttsCde) {
		this.httpSttsCde = httpSttsCde;
	}

	/**
	 * @return the httpSttsMsg
	 */
	public String getHttpSttsMsg() {
		return httpSttsMsg;
	}

	/**
	 * @param httpSttsMsg the httpSttsMsg to set
	 */
	public void setHttpSttsMsg(String httpSttsMsg) {
		this.httpSttsMsg = httpSttsMsg;
	}

	/**
	 * @return the ipAddr
	 */
	public String getIpAddr() {
		return ipAddr;
	}

	/**
	 * @param ipAddr the ipAddr to set
	 */
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}

	/**
	 * @return the filler7
	 */
	public String getFiller7() {
		return filler7;
	}

	/**
	 * @param filler7 the filler7 to set
	 */
	public void setFiller7(String filler7) {
		this.filler7 = filler7;
	}

	/**
	 * @return the filler8
	 */
	public String getFiller8() {
		return filler8;
	}

	/**
	 * @param filler8 the filler8 to set
	 */
	public void setFiller8(String filler8) {
		this.filler8 = filler8;
	}

	/**
	 * @return the filler9
	 */
	public String getFiller9() {
		return filler9;
	}

	/**
	 * @param filler9 the filler9 to set
	 */
	public void setFiller9(String filler9) {
		this.filler9 = filler9;
	}

	/**
	 * @return the filler10
	 */
	public String getFiller10() {
		return filler10;
	}

	/**
	 * @param filler10 the filler10 to set
	 */
	public void setFiller10(String filler10) {
		this.filler10 = filler10;
	}

	/**
	 * @return the requestTime
	 */
	public Date getRequestTime() {
		return requestTime;
	}

	/**
	 * @param requestTime the requestTime to set
	 */
	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}
	
}
