package com.vil.ecom.eai.verifyOtpCreditInsight.pojo;

import java.io.Serializable;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "verify" })

public class Other implements Serializable {

	@JsonProperty("verify")
	private String verify;
	private final static long serialVersionUID = -8623563017348677928L;

	@JsonProperty("verify")
	public String getVerify() {
		return verify;
	}

	@JsonProperty("verify")
	public void setVerify(String verify) {
		this.verify = verify;
	}

}
