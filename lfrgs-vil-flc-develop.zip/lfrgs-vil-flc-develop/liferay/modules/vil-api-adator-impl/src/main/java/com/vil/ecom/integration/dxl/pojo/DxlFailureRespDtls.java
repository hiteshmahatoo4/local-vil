package com.vil.ecom.integration.dxl.pojo;

import java.io.Serializable;

public class DxlFailureRespDtls implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String errorCode;
	
	private String errorType;
	
	private String errorMessage;
	
	private String errorDescription;
	
	private String causingSystemName;
	
	private String causingSystemErrorCode;
	
	private String causingSystemErrorMessage;

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorType
	 */
	public String getErrorType() {
		return errorType;
	}

	/**
	 * @param errorType the errorType to set
	 */
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}

	/**
	 * @param errorDescription the errorDescription to set
	 */
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	/**
	 * @return the causingSystemName
	 */
	public String getCausingSystemName() {
		return causingSystemName;
	}

	/**
	 * @param causingSystemName the causingSystemName to set
	 */
	public void setCausingSystemName(String causingSystemName) {
		this.causingSystemName = causingSystemName;
	}

	/**
	 * @return the causingSystemErrorCode
	 */
	public String getCausingSystemErrorCode() {
		return causingSystemErrorCode;
	}

	/**
	 * @param causingSystemErrorCode the causingSystemErrorCode to set
	 */
	public void setCausingSystemErrorCode(String causingSystemErrorCode) {
		this.causingSystemErrorCode = causingSystemErrorCode;
	}

	/**
	 * @return the causingSystemErrorMessage
	 */
	public String getCausingSystemErrorMessage() {
		return causingSystemErrorMessage;
	}

	/**
	 * @param causingSystemErrorMessage the causingSystemErrorMessage to set
	 */
	public void setCausingSystemErrorMessage(String causingSystemErrorMessage) {
		this.causingSystemErrorMessage = causingSystemErrorMessage;
	}
	
	

}
