package com.vil.ecom.integration.pojo;

import com.vil.ecom.integration.dxl.customerLookup.pojo.CustomerLookupRespDtls;

import java.io.Serializable;

public class EcomCustomerLookupResp  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
	
	private CustomerLookupRespDtls customerLoopkupDetails;

	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	/**
	 * @return the customerLoopkupDetails
	 */
	public CustomerLookupRespDtls getCustomerLoopkupDetails() {
		return customerLoopkupDetails;
	}

	/**
	 * @param customerLoopkupDetails the customerLoopkupDetails to set
	 */
	public void setCustomerLoopkupDetails(CustomerLookupRespDtls customerLoopkupDetails) {
		this.customerLoopkupDetails = customerLoopkupDetails;
	}

	

}
