@javax.xml.bind.annotation.XmlSchema(
		namespace = "http://eai.vodafone.com/MetaInfoReq", 
		elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED,
		xmlns={
	        @XmlNs(namespaceURI = "http://eai.vodafone.com/MetaInfoReq", prefix = "met"),
	        @XmlNs(namespaceURI = "http://eai.vodafone.com/CPOSServices", prefix = "cpos"),
	    }
)
package com.vodafone.eai.metainforeq;

import javax.xml.bind.annotation.XmlNs;
