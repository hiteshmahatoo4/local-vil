package com.vil.ecom.integration.creditInsightsInternalConsent;

import com.fasterxml.jackson.annotation.JsonInclude;  
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * 
 */

import java.io.Serializable;

/**
 * @author 1856895
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ 
	"verdict",
	"message",
	"time",
	"requestId",
	"creditScore",
	"telcoCode"
})
public class CreditInsightsInternalConsentResponse implements Serializable {
	@JsonProperty("verdict")
	private String verdict;
	@JsonProperty("message")
	private String message;
	@JsonProperty("time")
	private String time;
	@JsonProperty("requestId")
	private String requestId;
	@JsonProperty("creditScore")
	private String creditScore;
	@JsonProperty("telcoCode")
	private String telcoCode;
	
	private final static long serialVersionUID = 1494376529680245813L;

	@JsonProperty("verdict")
	public String getVerdict() {
		return verdict;
	}

	@JsonProperty("verdict")
	public void setVerdict(String verdict) {
		this.verdict = verdict;
	}

	@JsonProperty("message")
	public String getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(String message) {
		this.message = message;
	}

	@JsonProperty("time")
	public String getTime() {
		return time;
	}

	@JsonProperty("time")
	public void setTime(String time) {
		this.time = time;
	}

	@JsonProperty("requestId")
	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	@JsonProperty("creditScore")
	public String getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}

	@JsonProperty("telcoCode")
	public String getTelcoCode() {
		return telcoCode;
	}

	public void setTelcoCode(String telcoCode) {
		this.telcoCode = telcoCode;
	}
	
}
