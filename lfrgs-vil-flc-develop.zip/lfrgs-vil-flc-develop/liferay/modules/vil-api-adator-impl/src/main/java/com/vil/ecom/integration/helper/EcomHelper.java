package com.vil.ecom.integration.helper;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class EcomHelper {

	private static final Log logger = LogFactoryUtil.getLog(EcomHelper.class);
	
	private static final String UNKNOWN_CLASS = "CommonHelper";
	private static final String UNKNOWN_METHOD = "CommonHelper";

	private EcomHelper() {
		super();
	}

	private static void printWarnLog(String msg) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (null != stackTraceElements && stackTraceElements.length >= 4) {
			FLogger.warn(logger,msg);
		} else {
			FLogger.warn(logger, UNKNOWN_CLASS, UNKNOWN_METHOD, msg);
		}
	}

	public static void warnLog(String msg) {
		printWarnLog(msg);
	}

	public static void warnLog(Object... msgs) {
		printWarnLog(objectLstToString(msgs));
	}

	private static void printErrorLog(String msg) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (null != stackTraceElements && stackTraceElements.length >= 4) {
			FLogger.error(logger, thisClass(stackTraceElements[3].getClassName()),
					stackTraceElements[3].getMethodName(), msg);
		} else {
			FLogger.error(logger, UNKNOWN_CLASS, UNKNOWN_METHOD, msg);
		}
	}

	public static void errorLog(String msg) {
		printErrorLog(msg);
	}

	public static void errorLog(Object... msgs) {
		printErrorLog(objectLstToString(msgs));
	}

	private static void printInfoLog(String msg) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (null != stackTraceElements && stackTraceElements.length >= 4) {
			FLogger.info(logger, thisClass(stackTraceElements[3].getClassName()),
					stackTraceElements[3].getMethodName(), msg);
		} else {
			FLogger.info(logger, UNKNOWN_CLASS, UNKNOWN_METHOD, msg);
		}
	}

	public static void infoLog(String msg) {
		printInfoLog(msg);
	}

	public static void infoLog(Object... msgs) {
		printInfoLog(objectLstToString(msgs));
	}

	private static void printDebugLog(String msg) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (null != stackTraceElements && stackTraceElements.length >= 4) {
			FLogger.debug(logger, thisClass(stackTraceElements[3].getClassName()),
					stackTraceElements[3].getMethodName(), msg);
		} else {
			FLogger.debug(logger, UNKNOWN_CLASS, UNKNOWN_METHOD, msg);
		}
	}

	public static void debugLog(String msg) {
		printDebugLog(msg);
	}

	public static void debugLog(Object... msgs) {
		printDebugLog(objectLstToString(msgs));
	}

	private static String objectLstToString(Object... msgs) {
		StringBuilder builder = new StringBuilder();
		try {
			if (null != msgs) {
				for (Object k : msgs) {
					if (null != k) {
						if (k.getClass().isInstance(String.class)) {
							builder.append(k).append(" | ");
						} else {
							builder.append(k.getClass().getSimpleName()).append(" = ").append(k.toString())
									.append(" | ");
						}
					}
				}
			}
		} catch (Exception e) {
			exceptionLog(e);
		}
		return builder.toString();
	}

	public static void exceptionLog(Exception e) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (null != stackTraceElements && stackTraceElements.length >= 3) {
			StringChecks.printExceptionErrors(e, logger, thisClass(stackTraceElements[2].getClassName()),
					stackTraceElements[2].getMethodName());
		} else {
			StringChecks.printExceptionErrors(e, logger, UNKNOWN_CLASS, UNKNOWN_METHOD);
		}
	}

	public static void exceptionLog(Exception e, int noOfExceptionSteps) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (0 == noOfExceptionSteps) {
			noOfExceptionSteps = 3;
		}
		if (null != stackTraceElements && stackTraceElements.length >= 3) {
			StringChecks.printExceptionErrors(e, logger, thisClass(stackTraceElements[2].getClassName()),
					stackTraceElements[2].getMethodName(), noOfExceptionSteps);
		} else {
			StringChecks.printExceptionErrors(e, logger, UNKNOWN_CLASS, UNKNOWN_METHOD, noOfExceptionSteps);
		}
	}

	public static void exceptionLog(Exception e, String msg) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (null != stackTraceElements && stackTraceElements.length >= 3) {
			StringChecks.printExceptionErrors(e, logger, thisClass(stackTraceElements[2].getClassName()),
					stackTraceElements[2].getMethodName(),
					"Line number:" + stackTraceElements[2].getLineNumber() + " - " + msg);
		} else {
			StringChecks.printExceptionErrors(e, logger, UNKNOWN_CLASS, UNKNOWN_METHOD, msg);
		}
	}

	public static void exceptionLog(Exception e, String msg, int noOfExceptionSteps) {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (null != stackTraceElements && stackTraceElements.length >= 3) {
			StringChecks.printExceptionErrors(e, logger, thisClass(stackTraceElements[2].getClassName()),
					stackTraceElements[2].getMethodName(),
					"Line number:" + stackTraceElements[2].getLineNumber() + " - " + msg, noOfExceptionSteps);
		} else {
			StringChecks.printExceptionErrors(e, logger, UNKNOWN_CLASS, UNKNOWN_METHOD, msg, noOfExceptionSteps);
		}
	}

	public static String thisClass(String thisClass) {
		try {
			if (thisClass.contains(".") && thisClass.indexOf(".") != -1) {
				thisClass = thisClass.substring(thisClass.lastIndexOf(".") + 1, thisClass.length());
			}
		} catch (Exception e) {
			exceptionLog(e);
		}
		return thisClass;
	}

	/**
	 * @param input
	 * @return clone date from input
	 */
	public static Date cloneDate(Date input) {
		try {
			if (null != input) {
				return (Date) input.clone();
			}
		} catch (Exception e) {
			exceptionLog(e);
		}
		return null;
	}

	/**
	 * Return a shallow copy of List <br>
	 * Returns empty List if null is passed as input
	 */
	public static <T> List<T> cloneList(List<T> input) {
		List<T> output = new ArrayList<>();
		if (null != input) {
			output.addAll(input);
		}
		return output;
	}

	/**
	 * Return a shallow copy of Set <br>
	 * Returns empty Set if null is passed as input
	 */
	public static <T> Set<T> cloneList(Set<T> input) {
		Set<T> output = new HashSet<>();
		if (null != input) {
			output.addAll(input);
		}
		return output;
	}

	/**
	 * @param b
	 * @return boolean true or false for Boolean object
	 */
	public static boolean getBoolean(Boolean b) {
		return Boolean.TRUE.equals(b);
	}

	/**
	 * @param <T>
	 * @param input
	 * @return size of collection
	 */
	public static <T> int getCollectionSize(Collection<T> input) {

		if (!StringChecks.isCollectionEmpty(input)) {
			return input.size();
		}

		return LoggerConstants.NUM_0;
	}

	/**
	 * @param <K>
	 * @param <V>
	 * @param input
	 * @return size of Map
	 */
	public static <K, V> int getMapSize(Map<K, V> input) {

		if (!StringChecks.isMapEmpty(input)) {
			return input.size();
		}

		return LoggerConstants.NUM_0;
	}

	public static String getThreadId() {
		return RequestResourceThreadLocal.getURI();
	}

	public static <T> List<T> setToList(Set<T> in) {
		List<T> out = new ArrayList<>();
		try {
			if (null != in) {
				for (T k : in) {
					out.add(k);
				}
			}
		} catch (Exception e) {
			exceptionLog(e);
		}
		return out;
	}

	public static BigDecimal getContractualLoad(String sanctionedLoad) {
		BigDecimal contractualLoad = new BigDecimal("0");
		try {
			Float float1 = Float.valueOf(sanctionedLoad);
			contractualLoad = BigDecimal.valueOf(float1 / 0.85);
			contractualLoad = contractualLoad.setScale(2, RoundingMode.FLOOR);
		} catch (Exception e) {
			exceptionLog(e);
		}
		return contractualLoad;
	}

	public static String cleanString(String input) {

		if (StringChecks.isFieldEmpty(input)) {
			return null;
		} else {
			return input;
		}
	}

	public static Integer cleanInteger(Integer input) {

		if (input != null) {
			return input;
		} else {
			return null;
		}
	}

	public static Long cleanLong(Long input) {

		if (input != null) {
			return input;
		} else {
			return null;
		}
	}

	public static Double cleanDouble(Double input) {

		if (input != null) {
			return input;
		} else {
			return null;
		}
	}

	public static Date cleanDate(Date input) {

		if (input != null) {
			return input;
		} else {
			return null;
		}
	}

}
