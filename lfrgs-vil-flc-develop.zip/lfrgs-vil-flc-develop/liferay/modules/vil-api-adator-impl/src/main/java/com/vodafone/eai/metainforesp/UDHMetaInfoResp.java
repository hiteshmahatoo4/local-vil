
package com.vodafone.eai.metainforesp;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UDHMetaInfoResp complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UDHMetaInfoResp">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ConsumerReqInfo" type="{http://eai.vodafone.com/MetaInfoResp}CLSConsumerReqInfo1" minOccurs="0"/>
 *         &lt;element name="StatusInfo" type="{http://eai.vodafone.com/MetaInfoResp}CLSMetaStatusInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UDHMetaInfoResp", propOrder = {
    "consumerReqInfo",
    "statusInfo"
})
public class UDHMetaInfoResp {

    @XmlElement(name = "ConsumerReqInfo")
    protected CLSConsumerReqInfo1 consumerReqInfo;
    @XmlElement(name = "StatusInfo")
    protected CLSMetaStatusInfo statusInfo;

    /**
     * Gets the value of the consumerReqInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CLSConsumerReqInfo1 }
     *     
     */
    public CLSConsumerReqInfo1 getConsumerReqInfo() {
        return consumerReqInfo;
    }

    /**
     * Sets the value of the consumerReqInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CLSConsumerReqInfo1 }
     *     
     */
    public void setConsumerReqInfo(CLSConsumerReqInfo1 value) {
        this.consumerReqInfo = value;
    }

    /**
     * Gets the value of the statusInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CLSMetaStatusInfo }
     *     
     */
    public CLSMetaStatusInfo getStatusInfo() {
        return statusInfo;
    }

    /**
     * Sets the value of the statusInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CLSMetaStatusInfo }
     *     
     */
    public void setStatusInfo(CLSMetaStatusInfo value) {
        this.statusInfo = value;
    }

}
