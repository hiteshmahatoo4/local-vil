package com.vil.ecom.eai.verifyOtpCreditInsight.pojo;

import java.io.Serializable;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "request_id", "score", "score_version" })

public class ScoreInfo implements Serializable {

	@JsonProperty("request_id")
	private int requestId;
	@JsonProperty("score")
	private String score;
	@JsonProperty("score_version")
	private String scoreVersion;
	private final static long serialVersionUID = 8293878966841703525L;

	@JsonProperty("request_id")
	public int getRequestId() {
		return requestId;
	}

	@JsonProperty("request_id")
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	@JsonProperty("score")
	public String getScore() {
		return score;
	}

	@JsonProperty("score")
	public void setScore(String score) {
		this.score = score;
	}

	@JsonProperty("score_version")
	public String getScoreVersion() {
		return scoreVersion;
	}

	@JsonProperty("score_version")
	public void setScoreVersion(String scoreVersion) {
		this.scoreVersion = scoreVersion;
	}

}
