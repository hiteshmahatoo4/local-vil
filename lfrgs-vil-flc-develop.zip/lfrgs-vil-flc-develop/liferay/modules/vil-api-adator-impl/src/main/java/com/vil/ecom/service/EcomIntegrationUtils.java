package com.vil.ecom.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.StopWatch;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.db.model.EcomCrcleMstr;
import com.vil.ecom.db.service.EcomCrcleMstrLocalServiceUtil;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomSendMailReqDtls;
import com.vil.ecom.integration.pojo.EcomSendMailRespDtls;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomSendMailSrvcProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;
import com.vil.ecom.utilities.UniqueIdGenerator;

public class EcomIntegrationUtils {

	private static final Log logger = LogFactoryUtil.getLog(EcomIntegrationUtils.class);
	private static final String THIS_CLASS = "EcomIntegrationUtils";

	/**
	 * @author TCS
	 * <p>sendEmail</p>
	 * @param emailSubject : email Subject. Mandatory
	 * @param emailBodyTxt : email body content. Mandatory
	 * @param emailTo : to email ID - comma separated if multiple email id's to be sent. Mandatory
	 * @param emailCc : cc email ID - comma separated if multiple email id's to be sent. Optional
	 * @return EcomSendMailRespDtls Object
	 */
	public static EcomSendMailRespDtls sendEmail(String emailSubject,String emailBodyTxt, String emailTo, String emailCc) {

		EcomSendMailRespDtls emailResp = null;
		String methodName = "sendEmail";

		StopWatch stopwatch = null;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.APP_EMAIL_SRVC);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);

			EcomSendMailReqDtls sendMailReqDtls = new EcomSendMailReqDtls();
			sendMailReqDtls.setEmailBody(emailBodyTxt);
			sendMailReqDtls.setSubject(emailSubject);
			sendMailReqDtls.setToEmailId(emailTo);
			sendMailReqDtls.setCcEmailId(emailCc);

			EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
			srvcRequest.setServiceNme(BaseConstants.API_SERVICES.APP_EMAIL_SRVC);
			srvcRequest.setSendMailReqDtls(sendMailReqDtls);

			EcomSendMailSrvcProcessor sendSmsDtlsProcessor=new EcomSendMailSrvcProcessor(srvcRequest);
			EcomMrchntServiceResponse srvcResponse =sendSmsDtlsProcessor.execute();

			if (srvcResponse != null 
					&& srvcResponse.getResponseStatus()!=null ) {
				
				if(BaseConstants.SUCCESS_MSG.equalsIgnoreCase(srvcResponse.getResponseStatus().getStatus())) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							"Success Response received : " 
							+ StringChecks.convertObjectToJson(srvcResponse.getResponseStatus()));
					
					emailResp = srvcResponse.getSendMailRespDtls();
					
				}else {

					FLogger.error(logger, THIS_CLASS, methodName,
							"Error / timeout Response received : " 
							+ StringChecks.convertObjectToJson(srvcResponse.getResponseStatus()));

					emailResp = srvcResponse.getSendMailRespDtls();
					
				}
			
			} else {
				
				FLogger.error(logger, THIS_CLASS, methodName, "No Response from end System API, TIMEOUT");

				MrchntRespStts respStts = new MrchntRespStts();
				respStts.setDescription(BaseConstants.TIMEOUT_MSG);
				respStts.setStatus(BaseConstants.TIMEOUT_MSG);
				respStts.setStatusCde(BaseConstants.TIMEOUT_MSG);

				emailResp = new EcomSendMailRespDtls();
				emailResp.setRefNo(sendMailReqDtls.getRefNo());
				emailResp.setResponseStatus(respStts);
			}

		} catch (Exception e) {
			
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
			
			MrchntRespStts respStts = new MrchntRespStts();
			respStts.setDescription(BaseConstants.errorInProcessingReq);
			respStts.setStatus(BaseConstants.FAILURE_MSG);
			respStts.setStatusCde(BaseConstants.errorInProcessingReq);

			emailResp = new EcomSendMailRespDtls();
			emailResp.setResponseStatus(respStts);
			
		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		
		}
		
		return emailResp;
	}

	/**
	 * @author TCS
	 * <p>sendEmail</p>
	 * @param emailSubject : email Subject. Mandatory
	 * @param emailBodyTxt : email body content. Mandatory
	 * @param emailTo : to email ID - comma separated if multiple email id's to be sent. Mandatory
	 * @param emailCc : cc email ID - comma separated if multiple email id's to be sent. Optional
	 * @param refNo : Unique reference id send for each mail. Optional
	 * @return EcomSendMailRespDtls Response object with status of call and refNo, auditNo.
	 */
	public static EcomSendMailRespDtls sendEmail(String emailSubject,String emailBodyTxt, String emailTo, String emailCc, String refNo) {

		EcomSendMailRespDtls emailResp = null;
		String methodName = "sendEmail";
	
		StopWatch stopwatch = null;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.APP_EMAIL_SRVC);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);

			EcomSendMailReqDtls sendMailReqDtls = new EcomSendMailReqDtls();
			sendMailReqDtls.setEmailBody(emailBodyTxt);
			sendMailReqDtls.setSubject(emailSubject);
			sendMailReqDtls.setToEmailId(emailTo);
			sendMailReqDtls.setCcEmailId(emailCc);
			sendMailReqDtls.setRefNo(refNo);

			EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
			srvcRequest.setServiceNme(BaseConstants.API_SERVICES.APP_EMAIL_SRVC);
			srvcRequest.setSendMailReqDtls(sendMailReqDtls);

			EcomSendMailSrvcProcessor sendSmsDtlsProcessor=new EcomSendMailSrvcProcessor(srvcRequest);
			EcomMrchntServiceResponse srvcResponse =sendSmsDtlsProcessor.execute();
			
			if (srvcResponse != null 
					&& srvcResponse.getResponseStatus()!=null ) {
				
				if(BaseConstants.SUCCESS_MSG.equalsIgnoreCase(srvcResponse.getResponseStatus().getStatus())) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							"Success Response received : " 
							+ StringChecks.convertObjectToJson(srvcResponse.getResponseStatus()));
					
					emailResp = srvcResponse.getSendMailRespDtls();
					
				}else {

					FLogger.error(logger, THIS_CLASS, methodName,
							"Error / timeout Response received : " 
							+ StringChecks.convertObjectToJson(srvcResponse.getResponseStatus()));

					emailResp = srvcResponse.getSendMailRespDtls();
					
				}
			
			} else {
				
				FLogger.error(logger, THIS_CLASS, methodName, "No Response from end System API, TIMEOUT");

				MrchntRespStts respStts = new MrchntRespStts();
				respStts.setDescription(BaseConstants.TIMEOUT_MSG);
				respStts.setStatus(BaseConstants.TIMEOUT_MSG);
				respStts.setStatusCde(BaseConstants.TIMEOUT_MSG);

				emailResp = new EcomSendMailRespDtls();
				emailResp.setRefNo(sendMailReqDtls.getRefNo());
				emailResp.setResponseStatus(respStts);
			}
			
		} catch (Exception e) {
			
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
			
			MrchntRespStts respStts = new MrchntRespStts();
			respStts.setDescription(BaseConstants.errorInProcessingReq);
			respStts.setStatus(BaseConstants.FAILURE_MSG);
			respStts.setStatusCde(BaseConstants.errorInProcessingReq);

			emailResp = new EcomSendMailRespDtls();
			emailResp.setResponseStatus(respStts);
			
		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		
		}
		
		return emailResp;
	}

	/**
	 * @author TCS
	 * <p>sendEmail</p>
	 * @param emailSubject : email Subject. Mandatory
	 * @param emailBodyTxt : email body content. Mandatory
	 * @param emailTo : to email ID - comma separated if multiple email id's to be sent. Mandatory
	 * @param emailCc : cc email ID - comma separated if multiple email id's to be sent. Optional
	 * @param attachmentFile : attachment File Object if needs to send with email, max 5MB file is allowed.
	 * @return emailSent boolean flag
	 */
	public static EcomSendMailRespDtls sendEmailWithAttachment(String emailSubject, String emailBodyTxt, String emailTo, String emailCc,
			File attachmentFile) {

		EcomSendMailRespDtls emailResp = null;
		String methodName = "sendEmailWithAttachment";
		
		StopWatch stopwatch = null;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.APP_EMAIL_SRVC);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);

			EcomSendMailReqDtls sendMailReqDtls = new EcomSendMailReqDtls();
			sendMailReqDtls.setEmailBody(emailBodyTxt);
			sendMailReqDtls.setSubject(emailSubject);
			sendMailReqDtls.setToEmailId(emailTo);
			sendMailReqDtls.setCcEmailId(emailCc);
			sendMailReqDtls.setAttachment(attachmentFile);

			EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
			srvcRequest.setServiceNme(BaseConstants.API_SERVICES.APP_EMAIL_SRVC);
			srvcRequest.setSendMailReqDtls(sendMailReqDtls);

			EcomSendMailSrvcProcessor sendSmsDtlsProcessor=new EcomSendMailSrvcProcessor(srvcRequest);
			EcomMrchntServiceResponse srvcResponse =sendSmsDtlsProcessor.execute();

			if (srvcResponse != null 
					&& srvcResponse.getResponseStatus()!=null ) {
				
				if(BaseConstants.SUCCESS_MSG.equalsIgnoreCase(srvcResponse.getResponseStatus().getStatus())) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							"Success Response received : " 
							+ StringChecks.convertObjectToJson(srvcResponse.getResponseStatus()));
					
					emailResp = srvcResponse.getSendMailRespDtls();
					
				}else {

					FLogger.error(logger, THIS_CLASS, methodName,
							"Error / timeout Response received : " 
							+ StringChecks.convertObjectToJson(srvcResponse.getResponseStatus()));

					emailResp = srvcResponse.getSendMailRespDtls();
					
				}
			
			} else {
				
				FLogger.error(logger, THIS_CLASS, methodName, "No Response from end System API, TIMEOUT");

				MrchntRespStts respStts = new MrchntRespStts();
				respStts.setDescription(BaseConstants.TIMEOUT_MSG);
				respStts.setStatus(BaseConstants.TIMEOUT_MSG);
				respStts.setStatusCde(BaseConstants.TIMEOUT_MSG);

				emailResp = new EcomSendMailRespDtls();
				emailResp.setRefNo(sendMailReqDtls.getRefNo());
				emailResp.setResponseStatus(respStts);
				
			}
			
		} catch (Exception e) {
			
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

			MrchntRespStts respStts = new MrchntRespStts();
			respStts.setDescription(BaseConstants.errorInProcessingReq);
			respStts.setStatus(BaseConstants.FAILURE_MSG);
			respStts.setStatusCde(BaseConstants.errorInProcessingReq);

			emailResp = new EcomSendMailRespDtls();
			emailResp.setResponseStatus(respStts);
			
		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		
		}
		

		return emailResp;
	}

	
	/**
	 *<p>     
	 * This method is used to generate Unique Transaction Id upto given length.     
	 * </p>    
	 * @param len
	 * @return
	 */
	public static String generateAppId(int len) {
        String methodName = "generateAppId";
        String idGenerated = null;
        String finalIdValue = null;
        String dateStr = null;
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
        StopWatch stopwatch = null;
        int length = 12;
        int idLen = 0;
        int noOfPadding = 0;
        try {
            stopwatch = new StopWatch();
            stopwatch.start();
        	if(len < 0) {
                len = 16;
            }
            if(len==16) {
                length = len - 6;
            }
            if(len > 0 && len > 16) {
                length = len - 6;
            }
            if(len > 0 && len < 16) {
                length = len - 6;
            }
            dateStr = sdf.format(StringChecks.getCurrentDate());
            idGenerated = String.valueOf(UniqueIdGenerator.INSTANCE.incrementAndGet());
            idLen = idGenerated.length();
            FLogger.debug(logger, THIS_CLASS, methodName,
                    "length : " + length+" | len : "+len+" | idLen : "+idLen);
            if (idLen < length) {
                noOfPadding = length - idLen;
            } else if (idLen == length) {
                noOfPadding = 0;
            } else if (idLen > length) {
                noOfPadding = 0;
                idGenerated = idGenerated.substring(idLen - length);
            }
            for (int i = 0; i < noOfPadding; i++) {
                sb.append("0");
            }
            sb.append(idGenerated);
            finalIdValue = dateStr + sb.toString();
            FLogger.debug(logger, THIS_CLASS, methodName,
                    "DcrmIntegrationUtils : method finalIdValue : " + finalIdValue);
        } catch (Exception e) {
            StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
        } finally {
        	if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}
        }
        return finalIdValue;
    }
	
	/**
	 * <p>
	 * This method is used to generate Unique Transaction Id of 16 digits.
	 * </p>
	 * 
	 * @return
	 */
	public static String generateAppId() {

		String methodName = "generateAppId";
		String idGenerated = null;
		String finalIdValue = null;
		String dateStr = null;

		int length = 10;
		StringBuilder sb = new StringBuilder();

		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");

		StopWatch stopwatch = null;

		int idLen = 0;
		int noOfPadding = 0;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			length = 10;
			dateStr = sdf.format(StringChecks.getCurrentDate());

			idGenerated = String.valueOf(UniqueIdGenerator.INSTANCE.incrementAndGet());

			idLen = idGenerated.length();
			
			if(idLen > length) {
				idGenerated = idGenerated.substring(idLen - length);
			}
			
			if (idLen < length) {
				noOfPadding = length - idLen;

			} else if (idLen == length) {
				noOfPadding = 0;
			} else {
				noOfPadding = 0;
			}

			for (int i = 0; i < noOfPadding; i++) {
				sb.append("0");
			}

			sb.append(idGenerated);

			finalIdValue = dateStr + sb.toString();

			FLogger.debug(logger, THIS_CLASS, methodName,
					"EcomIntegrationUtils : method finalIdValue : " + finalIdValue);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

		}

		return finalIdValue;
	}

	/**
	 * <p>
	 * This method is used to generate Unique Transaction Id of 16 digits.
	 * </p>
	 * 
	 * @return
	 */
	public static String generateLoggerId() {

		String methodName = "generateLoggerId";
		String idGenerated = null;
		String finalIdValue = null;
		String dateStr = null;

		int length = 10;
		StringBuilder sb = new StringBuilder();

		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");

		StopWatch stopwatch = null;

		int idLen = 0;
		int noOfPadding = 0;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			dateStr = sdf.format(StringChecks.getCurrentDate());

			idGenerated = String.valueOf(UniqueIdGenerator.INSTANCE.incrementAndGet());

			idLen = idGenerated.length();

			if (idLen < length) {
				noOfPadding = length - idLen;

			} else if (idLen == length) {
				noOfPadding = 0;
			} else {
				noOfPadding = 0;
			}

			for (int i = 0; i < noOfPadding; i++) {
				sb.append("0");
			}

			sb.append(idGenerated);

			finalIdValue = dateStr + sb.toString();

			FLogger.debug(logger, THIS_CLASS, methodName,
					"EcomIntegrationUtils : method finalIdValue : " + finalIdValue);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

		}

		return finalIdValue;
	}

	/**
	 * @author TCS
	 * @since 03-10-2019
	 *        <p>
	 *        Fetch EAI Circle Id Based on UPSS Circle ID as input
	 *        </p>
	 * @param upssCircleId
	 * @return
	 */
	public static String fetchEaiCircleIdFrmUpssCrcle(String upssCircleId) {

		String circleId = null;

		EcomCrcleMstr circleRecord = null;

		String methodName = "fetchEaiCircleIdFrmUpssCrcle";

		FLogger.debug(logger, THIS_CLASS, methodName,
				"Entered Method " + methodName + " with Inputs " + upssCircleId);

		try {

			if (!StringChecks.isFieldEmpty(upssCircleId)) {

				if (upssCircleId.length() == LoggerConstants.NUM_4) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							"As length of circle ID is 4 so fetching based on EAI Circle ID");

					circleRecord = EcomCrcleMstrLocalServiceUtil.findByEaiCircleId(upssCircleId);

					if (circleRecord != null) {
						circleId = circleRecord.getEai_circle_id();
					}

				} else {

					circleRecord = EcomCrcleMstrLocalServiceUtil.findByUpssCircleId(upssCircleId);

					if (circleRecord != null) {
						circleId = circleRecord.getEai_circle_id();
					}

				}
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			FLogger.debug(logger, THIS_CLASS, methodName,
					"Exiting Method " + methodName + " with output " + circleId);

		}

		return circleId;

	}

	/**
	 * @author TCS
	 * @since 10-10-2019
	 *        <p>
	 *        Fetch UPSS Circle Id Based on EAI Circle Id as input
	 *        </p>
	 * @param upssCircleId
	 * @return
	 */
	public static String fetchUpssCircleIdFrmEaiCrcle(String circleCde) {

		String circleId = null;

		EcomCrcleMstr circleRecord = null;

		String methodName = "fetchUpssCircleIdFrmEaiCrcle";

		FLogger.debug(logger, THIS_CLASS, methodName,
				"Entered Method " + methodName + " with Inputs " + circleCde);

		try {

			if (!StringChecks.isFieldEmpty(circleCde)) {

				circleRecord = EcomCrcleMstrLocalServiceUtil.findByEaiCircleId(circleCde);

				if (circleRecord != null) {
					circleId = circleRecord.getUpss_circle_id();
				}

			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			FLogger.debug(logger, THIS_CLASS, methodName,
					"Exiting Method " + methodName + " with output " + circleId);

		}

		return circleId;

	}

	/**
	 * This method is used to check if API DB logging is enabled or not.
	 * 
	 * @return true : if DB logging is enabled false : if DB logging is disabled.
	 */
	public static boolean isApiDBLoggingEnabled(String eaiCircle, String serviceNme) {

		final String methodName = "isApiDBLoggingEnabled";
		boolean enableLoggingFlg = true;

		Map<String, Object> confMap = null;

		try {

			FLogger.debug(logger, THIS_CLASS, methodName,
					"Entered with inputs " + eaiCircle + " | " + (serviceNme));

			confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap("APP_WS");

			if (StringChecks.isMapEmpty(confMap)) {

				FLogger.error(logger, THIS_CLASS, methodName,
						"enableLoggingFlg is true for DB logging as confMap is Null");
				return true;

			} else {

				FLogger.debug(logger, THIS_CLASS, methodName,
						"Checking with ConfMap for main Flag " + confMap.size());

				if (!StringChecks.isFieldEmpty(serviceNme)
						&& (String) confMap.get("API_RESP_LOGGING_DISABLED") != null) {

					String disableApisStr = (String) confMap.get("API_RESP_LOGGING_DISABLED");
					List<String> disableApisList = null;

					if (!StringChecks.isFieldEmpty(disableApisStr)) {
						disableApisList = Arrays.asList(disableApisStr.split("[\\|]+", -1));
					}

					if (StringChecks.isCollectionEmpty(disableApisList)) {

						FLogger.error(logger, THIS_CLASS, methodName, "disableApisList is not configured so"
								+ " not doing further checks for enableLoggingFlg " + enableLoggingFlg);
						return true;

					} else {

						if (disableApisList != null && disableApisList.contains(serviceNme)) {

							FLogger.error(logger, THIS_CLASS, methodName,
									"disableApisList contain input serviceNme : " + serviceNme
											+ " so not allowing logging of Response");

							return Boolean.FALSE;

						} else {

							FLogger.debug(logger, THIS_CLASS, methodName,
									"disableApisList does not contain input serviceNme : " + serviceNme
											+ " so allowing response logging");

							return Boolean.TRUE;

						}
					}

				} else {

					FLogger.error(logger, THIS_CLASS, methodName,
							"No Service configuration so not checking, enableLoggingFlg : " + enableLoggingFlg);
					return Boolean.TRUE;

				}

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

		} finally {

			FLogger.debug(logger, THIS_CLASS, methodName,
					"Exiting Method " + methodName + " with enableLoggingFlg " + enableLoggingFlg);

		}

		return enableLoggingFlg;
	}

	/**
	 * This method is used to Fetch Jboss Port based on Server Name
	 * 
	 * @return
	 */
	public String fetchJbossPortFrmDB(String appNme) {

		final String methodName = "fetchJbossPortFrmDB";

		String port = null;

		String logsPortConfigs = null;
		List<String> logsPortConfigList = null;
		Map<String, Object> confMap = null;
		String jbossServerName = null;

		try {

			jbossServerName = System.getProperty("jboss.server.name");

			FLogger.debug(logger, THIS_CLASS, methodName, "jbossServerName " + jbossServerName);

			if (!StringChecks.isFieldEmpty(jbossServerName)) {

				confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap("APP_WS");

				if (StringChecks.isMapEmpty(confMap)) {

					FLogger.debug(logger, THIS_CLASS, methodName,
							"confMap is empty so sending default Port as 8080");
					port = "8080";
					return port;

				} else {

					logsPortConfigs = ((String) confMap.get("LOG_PORT_CONFIG"));

					FLogger.debug(logger, THIS_CLASS, methodName, "logsPortConfigs " + logsPortConfigs);

					if (!StringChecks.isFieldEmpty(logsPortConfigs)) {
						logsPortConfigList = Arrays.asList(logsPortConfigs.split("[\\|]+", -1));
					}

					if (StringChecks.isCollectionEmpty(logsPortConfigList)) {

						FLogger.debug(logger, THIS_CLASS, methodName,
								"logsPortConfigList is not configured or empty so sending default Port as 8080");
						port = "8080";
						return port;

					} else {

						// FLogger.debug(logger, THIS_CLASS, methodName,"logsPortConfigList is ->
						// "+logsPortConfigList);

						Map<String, String> portMap = new HashMap<>();

						for (String server : logsPortConfigList) {

							// FLogger.debug(logger, THIS_CLASS, methodName,"server is -> "+server);

							List<String> serverList = Arrays.asList(server.split("[\\:]+", -1));

							if (!StringChecks.isCollectionEmpty(serverList)) {
								portMap.put(serverList.get(0), serverList.get(1));
							}
						}

						FLogger.debug(logger, THIS_CLASS, methodName, "portMap is -> " + portMap);

						if (StringChecks.isMapEmpty(portMap)) {

							FLogger.error(logger, THIS_CLASS, methodName,
									"portMap is empty for sending default port : 8080");
							port = "8080";
							return port;

						} else {

							if (portMap.containsKey(jbossServerName)) {

								FLogger.debug(logger, THIS_CLASS, methodName,
										"portMap contain jbossServerName : " + jbossServerName);
								port = portMap.get(jbossServerName);

							} else {

								if (portMap.containsKey(appNme)) {

									FLogger.debug(logger, THIS_CLASS, methodName,
											"portMap contain  appNme : " + appNme);
									port = portMap.get(appNme);

								} else {

									FLogger.debug(logger, THIS_CLASS, methodName,
											"portMap does not contain jbossServerName or appNme : " + jbossServerName
													+ " so sending default Port as 8080");
									port = "8080";

								}

							}
						}
					}
				}

			} else {

				FLogger.error(logger, THIS_CLASS, methodName,
						"jbossServerName is empty so sending default Port as 8080");
				port = "8080";
				return port;

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
			port = "8080";

		} finally {
			FLogger.debug(logger, THIS_CLASS, methodName, "Exiting Method " + methodName + " with port " + port);

		}

		return port;
	}

	/**
	 * @author TCS
	 *         <h2>parseResponse</h2>
	 * @Created On : 09-10-2019
	 * @Description : This method is used Fetch the content of given Tag from Web
	 *              Service Respnse.
	 * @param response
	 * @param tagName
	 * @return
	 */
	public List<String> parseXmlTag(String response, String tagName) {

		String methodName = "parseXmlTag";
		String startTag = "<" + tagName + ">";
		String endTag = "</" + tagName + ">";

		List<String> values = new ArrayList<>();
		List<Integer> startIndexes = null;
		List<Integer> endIndexes = null;

		try {

			if (!StringChecks.isFieldEmpty(response) && !StringChecks.isFieldEmpty(tagName)) {

				startIndexes = findWordIndex(response, startTag);
				endIndexes = findWordIndex(response, endTag);

				FLogger.debug(logger, THIS_CLASS, methodName, "Inputs : startIndexes " + startIndexes
						+ " | endIndexes : " + endIndexes + " | response len : " + response.length());

				for (int i = 0; i < startIndexes.size(); i++) {

					int startIndex = startIndexes.get(i) + startTag.length();
					int endIndex = endIndexes.get(i);

					FLogger.debug(logger, THIS_CLASS, methodName,
							"startIndex " + startIndex + " | endIndex : " + endIndex);

					values.add(response.substring(startIndex, endIndex));

				}

			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, "parseXmlTag");
		}

		return values;
	}

	/**
	 * <p>
	 * Find Word indexes in given String
	 * </p>
	 * 
	 * @param textString
	 * @param word
	 * @return
	 */
	public List<Integer> findWordIndex(String textString, String word) {

		List<Integer> indexes = new ArrayList<>();
		int index = 0;

		while (index != -1) {

			index = textString.indexOf(word, index);

			if (index != -1) {
				indexes.add(index);
				index++;
			}
		}

		return indexes;
	}
	
	/**
	 * <p>
	 * For the given circleId it fetches the sms sender_id
	 * </p>
	 * @param circleId
	 * @return
	 */
	public static String fetchSmsSenderID(String circleId) {
		
		String methodName = "fetchSmsSenderID";
		String senderId = null;
		
		try {
			
			FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName+" for circleId: "+circleId);
			
			if(!StringChecks.isFieldEmpty(circleId) && circleId.length()==LoggerConstants.NUM_4) {
				
				EcomCrcleMstr record = EcomCrcleMstrLocalServiceUtil.findByEaiCircleId(circleId);
				
				if(record != null) {
					FLogger.debug(logger, THIS_CLASS, methodName, "CrcleMstr record found with circleId: "+circleId);
					senderId = record.getMsdp_circle_nme();
				}else{
					FLogger.error(logger, THIS_CLASS, methodName, "CrcleMstr record not found with circleId: "+circleId);
				}
			}else {
				
				FLogger.error(logger, THIS_CLASS, methodName, "Not a valid circleID: "+circleId);
			}
						
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}
		
		
		return senderId;
	}

}
