package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.createFulfillmentOrder.request.pojo.EcomCreateFulfillmentOrderRequest;
import com.vil.ecom.createFulfillmentOrder.response.pojo.EcomCreateFulfillmentOrderResponse;
import com.vil.ecom.createFulfillmentOrder.response.pojo.ResponseStatus;
import com.vil.ecom.fulfillmentOrderSttsQuery.response.ResponseStts;
import com.vil.ecom.fulfillmentOrderSttsQuery.request.EcomFulfillmentOrderSttsQueryReq;
import com.vil.ecom.fulfillmentOrderSttsQuery.response.EcomFulfillmentOrderSttsQueryResp;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomCreateFulfillmentOrderProcessor;
import com.vil.ecom.integration.processor.EcomFulfillmentOrderSttsQueryProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomFulfillmentOrderUtils {

	private static final Log logger = LogFactoryUtil.getLog(EcomFulfillmentOrderUtils.class);
	private static final String THIS_CLASS = "EcomCreateFulfillmentOrderUtil";

	/**
	 * @author Monika
	 *         <p>
	 *         Create Fullfillment Order API
	 *         </p>
	 * @param processorInput : EcomCreateFulfillmentOrderRequest pojo to be set for
	 *                       input paramater . Mandatory
	 *                       <p>
	 *                       <h2>EcomCreateFulfillmentOrderRequest pojo
	 *                       details:</h2>
	 *                       <ul>
	 *                       <li>RequestMessage : RequestMessage object to be
	 *                       passed.
	 *                       <ul>
	 *                       <li>CommonServiceRequest : CommonServiceRequest object
	 *                       to be passed.
	 *                       <ul>
	 *                       <li>partnerId : Partner Id of Vi Marketplace to be
	 *                       passed.</li>
	 *                       <li>channel : Default �VI Marketplace� to be
	 *                       passed.</li>
	 *                       <li>requestId : Unique Request id from VI marketplace
	 *                       channel to be passed.</li>
	 *                       <li>serviceName : CreateFulfillmentOrder to be
	 *                       passed.</li>
	 *                       </ul>
	 *                       </li>
	 *                       <li>Order : Order Parent Request Tag to be passed.
	 *                       <ul>
	 *                       <li>id : Marketplace Order ID for fulfillment to be
	 *                       passed.</li>
	 *                       <li>state : state to be passed.</li>
	 *                       <li>Item : Array of Multiple Order Line-Items to be
	 *                       passed.
	 *                       <ul>
	 *                       <li>id : Order line-item ID from marketplace to be
	 *                       passed.</li>
	 *                       <li>quantity : Number of products to be passed.</li>
	 *                       <li>unitPrice : Base price of product to be
	 *                       passed.</li>
	 *                       <li>totalPrice : Total Product value basis quantity to
	 *                       be passed.</li>
	 *                       <li>skuId : Partner Product SKU Id to be passed.</li>
	 *                       <li>description : SKU description to be passed.</li>
	 *                       <li>productCategory : productCategory(OTT, MUSIC,
	 *                       Recharge, Insurance) to be passed.</li>
	 *                       <li>Fulfillment : Fullfillment object to be passed.
	 *                       <ul>
	 *                       <li>Customer : Customer object to be passed.
	 *                       <ul>
	 *                       <li>firstName : Customer First name to be passed.</li>
	 *                       <li>lastName : Customer Last name to be passed.</li>
	 *                       <li>gender : Customer Gender: M, F, O to be
	 *                       passed.</li>
	 *                       <li>age : Customer Age to be passed.</li>
	 *                       <li>dob : Customers DOB to be passed.</li>
	 *                       <li>mobileNumber : 10-digit Customer Mobile Number to
	 *                       be passed.</li>
	 *                       <li>emailid : Customer email id to be passed.</li>
	 *                       <li>address : Address object to be passed.
	 *                       <ul>
	 *                       <li>line1 : Address line 1 to be passed.</li>
	 *                       <li>line2 : Address line 2 to be passed.</li>
	 *                       <li>city : City to be passed.</li>
	 *                       <li>zipcode : PIN CODE to be passed.</li>
	 *                       <li>state : State to be passed.</li>
	 *                       </ul>
	 *                       </li>
	 *                       <li>employmentType : Public, Private, Business to be
	 *                       passed.</li>
	 *                       <li>salary : Salary to be passed.</li>
	 *                       <li>fatherName : Name to be passed.</li>
	 *                       <li>motherName : Name to be passed.</li>
	 *                       <li>maritalStatus : Maaried/Single to be passed.</li>
	 *                       <li>education : education detail to be passed.</li>
	 *                       <li>bankName : Bank Name to be passed.</li>
	 *                       <li>bankAccountType : Savings, corporate, Current to be
	 *                       passed.</li>
	 *                       <li>bankAccountNumber : Bank Account Number to be
	 *                       passed.</li>
	 *                       <li>property1 : Free text to be passed.</li>
	 *                       <li>property2 : Free text to be passed.</li>
	 *                       <li>IdentityProof : Array List of IdentityProof to be
	 *                       passed.
	 *                       <ul>
	 *                       <li>type : Proof Type Example: Aadhar, Pan Card,
	 *                       Driving Licence, Passport to be passed.</li>
	 *                       <li>value : Proof Unique Value to be passed.</li>
	 *                       </ul>
	 *                       </li>
	 *                       </ul>
	 *                       </li>
	 *                       <li>Agent :Agent Object to be passed.
	 *                       <ul>
	 *                       <li>name : Agent Name to be passed.</li>
	 *                       <li>phone : Agent Mobile Number to be passed.</li>
	 *                       </ul>
	 *                       </li>
	 *                       </ul>
	 *                       </li>
	 *                       </ul>
	 *                       </li>
	 *                       <li>Payment : Payment object to be passed.
	 *                       <ul>
	 *                       <li>transactionId : PG transaction ID to be
	 *                       passed.</li>
	 *                       <li>transactionStatus : SUCCESS to be passed.</li>
	 *                       <li>amount : Amount in INR to be passed.</li>
	 *                       <li>currency : INR to be passed.</li>
	 *                       <li>property1 : Free text to be passed.</li>
	 *                       <li>property2 : Free text to be passed.</li>
	 *                       <li>paymentMode : Payment Mode used CC, DC, IB, UPI,
	 *                       WALLET to be passed.</li>
	 *                       <li>status : PAID to be passed.</li>
	 *                       <li>timestamp : Payment Timestamp YYYY-MM-DD
	 *                       HH24:MI:SS.USS to be passed.</li>
	 *                       <li>Payment Gateway Name : collectedBy to be
	 *                       passed.</li>
	 *                       </ul>
	 *                       </li>
	 *                       </ul>
	 *                       </li>
	 *                       </ul>
	 *                       </li>
	 *                       </ul>
	 * 
	 *                       </p>
	 * @return EcomCreateFulfillmentOrderResponse : EcomCreateFulfillmentOrder API
	 *         response
	 */
	public static EcomCreateFulfillmentOrderResponse createFulfillmentOrder(EcomCreateFulfillmentOrderRequest input) {

		String methodName = "createFulfillmentOrder";
		StopWatch stopwatch = null;
		EcomCreateFulfillmentOrderResponse response = null;
		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			if (RequestResourceThreadLocal.getRequestIdForCurrentThread() == null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if (RequestResourceThreadLocal.getServiceForCurrentThread() == null) {
				RequestResourceThreadLocal
						.addServiceForCurrentThread(BaseConstants.API_SERVICES.EAI_PRODUCT_FULLFILLMENT);
			}

			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);

			if (input != null) {

				FLogger.debug(logger, THIS_CLASS, methodName, "Entered :" + methodName);

				EcomMrchntServiceRequest srvcReq = new EcomMrchntServiceRequest();
				srvcReq.setServiceNme(BaseConstants.API_SERVICES.EAI_PRODUCT_FULLFILLMENT);
				srvcReq.setCreateFulfillmentOrderReq(input);

				EcomCreateFulfillmentOrderProcessor processor = new EcomCreateFulfillmentOrderProcessor(srvcReq);

				EcomMrchntServiceResponse srvcResp = processor.execute();

				if (srvcResp != null) {
					if (srvcResp.getCreateFulfillmentOrderResp() != null) {
						FLogger.info(logger, THIS_CLASS, methodName, "Got Response from the API");

						FLogger.info(logger, THIS_CLASS, methodName,
								"Response status: " + StringChecks.convertObjectToJson(srvcResp.getResponseStatus())
										+ " | Response: "
										+ StringChecks.convertObjectToJson(srvcResp.getCreateFulfillmentOrderResp()));

						response = new EcomCreateFulfillmentOrderResponse();
						response = srvcResp.getCreateFulfillmentOrderResp();
					} else {
						FLogger.error(logger, THIS_CLASS, methodName,
								"Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
						MrchntRespStts respStts = new MrchntRespStts();
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
						ResponseStatus respStatus = new ResponseStatus();
						respStatus.setCode(respStts.getStatusCde());
						respStatus.setStatus(BaseConstants.FAILURE_MSG);
						respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
						response = new EcomCreateFulfillmentOrderResponse();
						response.setResponseStatus(respStatus);
						response.setMessage(null);
					}
				} else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
					ResponseStatus respStatus = new ResponseStatus();
					respStatus.setCode(respStts.getStatusCde());
					respStatus.setStatus(BaseConstants.FAILURE_MSG);
					respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
					response = new EcomCreateFulfillmentOrderResponse();
					response.setResponseStatus(respStatus);
				}

			} else {
				FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");

				MrchntRespStts respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
				ResponseStatus respStatus = new ResponseStatus();
				respStatus.setCode(respStts.getStatusCde());
				respStatus.setStatus(BaseConstants.FAILURE_MSG);
				respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
				response = new EcomCreateFulfillmentOrderResponse();
				response.setResponseStatus(respStatus);
				response.setMessage(null);
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			MrchntRespStts respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			ResponseStatus respStatus = new ResponseStatus();
			respStatus.setCode(respStts.getStatusCde());
			respStatus.setStatus(BaseConstants.FAILURE_MSG);
			respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
			response = new EcomCreateFulfillmentOrderResponse();
			response.setResponseStatus(respStatus);

		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();

		}

		return response;
	}


	
	/**
	 * @author Om
	 * @since 2023-02-10
	 * <p>Product fulfillment Order Status Query frm Partners</p>
	 * @param input : EcomFulfillmentOrderSttsQueryReq Object to be set. Mandatory
	 *
	 *<h2>EcomFulfillmentOrderSttsQueryReq pojo details</h2>
	 *<ul><li>RequestMessage pojo to be set</li></ul>
	 * <h2>RequestMessage: RequestMessage pojo details </h2>
	 * <ul> 
	 * <li> CommonServiceRequest pojo to be set. Details are as follows:</li>
	 * 	 <ul>
	 * 		<li> PartnerId: Partner ID to be passed </li>
	 * 		<li> Channel: Channel to be passed. </li>
	 * 		<li> RequestId: Unique Request id to be passed.  </li>
	 * 		<li> ServiceName: Service name UpdateFulfillmentStatus to be passed . Mandatory  </li>
	 * 	 </ul>
	 * 
	 * 
	 *<li> Order pojo to be set . Details are as follows:
	 * 		<ul>
	 * 		<li>  OrderId: Marketplace Order ID for fulfillment.</li>
	 *	 	<li>  Items: List of Item Pojos to be set </li>
	 *			<ul>		 
	 *			<li> Id: Order line-item ID of marketplace.  </li>
	 * 	    	<li> FulfilmentReferenceId: Partner fulfilment order id for a line item.  </li>
	 *    		</ul>
	 * 		</ul>
	 * </ul>
	 * </li>
	 * </ul>
 	 * @return EcomFulfillmentOrderSttsQueryResp: status of fulfillment done by 3rd party merchant.Details are:
 	 * <ul>
 	 * <li>ResponseStts pojo</li>
 	 * <li>Message pojo</li>
 	 * </ul>
 	 * <h2> Message  </h2>
 	 * <ul>
 	 * 		<li> Request Id : Unique Request id of marketplace channel . </li>
 	 * 		<li> Order : Order object </li>
 	 * 			<ul>
 	 * 				<li> Id: Marketplace Order ID for fulfilment .</li>
 	 * 				<li> State: LOV - ACK, Fulfilled, Failed, partial_fulfilled . </li>
 	 * 				<li> Items: List of Item pojos . Item pojo details are:</li>
 	 * 					<ul>
 	 * 						<li> ItemId : Order line-item ID from marketplace.</li>
 	 * 						<li> Quantity : Number of products. </li> 
 	 * 						<li> Unit_Price : Base price of the product . </li>
 	 * 						<li> Total_price : Total Product value basis quantity . </li>
 	 * 						<li> sku_id  : Partner Product SKU Id . </li>
 	 * 						<li> Description : SKU description . </li>
 	 * 						<li> Product_category : Product Category to be passed. </li>
 	 * 						<li> fulfillment_reference_id : Partner fulfillment order id for a line item . </li>
 	 * 						<li> State: LOV - ACK, Fulfilled, Failed .  </li>
 	 * 						<li> Product_Start_Date : Product Start Date and timestamp YYYY-MM-DD HH24:MI:SS.USS.  </li>
 	 * 						<li> Product_End_Date : Product End Date and timestamp YYYY-MM-DD HH24:MI:SS.USS .  </li>
 	 * 					</ul>
 	 * 			</ul>
 	 * </ul>
	 */
	public static EcomFulfillmentOrderSttsQueryResp fulfillmentOrderSttsQuery(EcomFulfillmentOrderSttsQueryReq input) {

		EcomFulfillmentOrderSttsQueryResp resp = null;
		StopWatch stopwatch = null;

		String thisMethod = "fulfillmentOrderSttsQuery";

		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();

			if (RequestResourceThreadLocal.getRequestIdForCurrentThread() == null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if (RequestResourceThreadLocal.getServiceForCurrentThread() == null) {
				RequestResourceThreadLocal
						.addServiceForCurrentThread(BaseConstants.API_SERVICES.EAI_FULFILLMENT_ORDER_STTS_QUERY);
			}

			if (input != null) {

				String partnerIdReceived = input.getRequestMessage().getCommonServiceRequest().getPartnerId();
				FLogger.error(logger, THIS_CLASS, thisMethod, "partnerString is: " + partnerIdReceived);

				/**
				 * Based on Partner ID, select respective processor class and call API and get
				 * response
				 */

				resp = new EcomFulfillmentOrderSttsQueryResp();

				EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
				srvcRequest.setServiceNme(BaseConstants.API_SERVICES.EAI_FULFILLMENT_ORDER_STTS_QUERY);
				srvcRequest.setFulfillmentOrderSttsQueryReq(input);

				EcomFulfillmentOrderSttsQueryProcessor processor = new EcomFulfillmentOrderSttsQueryProcessor(srvcRequest);
				EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
				srvcResp = processor.execute();

				resp = srvcResp.getFulfillmentOrderSttsQueryResp();

				FLogger.info(logger, THIS_CLASS, thisMethod, "Response is: " + StringChecks.convertObjectToJson(resp));

			} else {

				resp = new EcomFulfillmentOrderSttsQueryResp();
				
				ResponseStts respStatus = new ResponseStts();
				respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
				respStatus.setStatus(BaseConstants.FAILURE_MSG);
				resp.setResponseStatus(respStatus);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Response is: " + StringChecks.convertObjectToJson(resp));
			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);

			ResponseStts respStts = new ResponseStts();
			respStts.setDescription(BaseConstants.ERR_PROCESSING_REQ);
			respStts.setStatus(BaseConstants.FAILED_MSG);

			resp = new EcomFulfillmentOrderSttsQueryResp();
			resp.setResponseStatus(respStts);

		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, thisMethod,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();

		}

		return resp;
	}

}
