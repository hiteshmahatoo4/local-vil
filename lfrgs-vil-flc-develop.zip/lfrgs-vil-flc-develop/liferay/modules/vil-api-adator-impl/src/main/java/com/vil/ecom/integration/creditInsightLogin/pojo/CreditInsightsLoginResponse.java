/**
 * 
 */
package com.vil.ecom.integration.creditInsightLogin.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "verdict",
    "message",
    "time",
    "data"
})

public class CreditInsightsLoginResponse implements Serializable {
	@JsonProperty("verdict")
    private String verdict;
    @JsonProperty("message")
    private String message;
    @JsonProperty("time")
    private String time;
    @JsonProperty("data")
    private Data data;
    private final static long serialVersionUID = 4331578435417113372L;

    @JsonProperty("verdict")
    public String getVerdict() {
        return verdict;
    }

    @JsonProperty("verdict")
    public void setVerdict(String verdict) {
        this.verdict = verdict;
    }

    @JsonProperty("message")
    public String getMessage() {
        return message;
    }

    @JsonProperty("message")
    public void setMessage(String message) {
        this.message = message;
    }

    @JsonProperty("time")
    public String getTime() {
        return time;
    }

    @JsonProperty("time")
    public void setTime(String time) {
        this.time = time;
    }

    @JsonProperty("data")
    public Data getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(Data data) {
        this.data = data;
    }

}
