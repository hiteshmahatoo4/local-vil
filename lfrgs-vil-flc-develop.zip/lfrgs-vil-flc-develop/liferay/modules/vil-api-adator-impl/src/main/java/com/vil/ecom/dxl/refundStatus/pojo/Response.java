
package com.vil.ecom.dxl.refundStatus.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "pgOrderId",
    "correlatorId",
    "refundOrderId",
    "refundOrderStatus",
    "amount",
    "srNumber"
})
public class Response implements Serializable{

	@JsonProperty("pgOrderId")
    private String pgOrderId;
    @JsonProperty("correlatorId")
    private String correlatorId;
    @JsonProperty("refundOrderId")
    private String refundOrderId;
    @JsonProperty("refundOrderStatus")
    private String refundOrderStatus;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("srNumber")
    private String srNumber;
    private final static long serialVersionUID = 1928688501439734911L;
    
    @JsonProperty("pgOrderId")
    public String getPgOrderId() {
        return pgOrderId;
    }

    @JsonProperty("pgOrderId")
    public void setPgOrderId(String pgOrderId) {
        this.pgOrderId = pgOrderId;
    }

    @JsonProperty("correlatorId")
    public String getCorrelatorId() {
        return correlatorId;
    }

    @JsonProperty("correlatorId")
    public void setCorrelatorId(String correlatorId) {
        this.correlatorId = correlatorId;
    }

    @JsonProperty("refundOrderId")
    public String getRefundOrderId() {
        return refundOrderId;
    }

    @JsonProperty("refundOrderId")
    public void setRefundOrderId(String refundOrderId) {
        this.refundOrderId = refundOrderId;
    }

    @JsonProperty("refundOrderStatus")
    public String getRefundOrderStatus() {
        return refundOrderStatus;
    }

    @JsonProperty("refundOrderStatus")
    public void setRefundOrderStatus(String refundOrderStatus) {
        this.refundOrderStatus = refundOrderStatus;
    }

    @JsonProperty("amount")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @JsonProperty("srNumber")
	public String getSrNumber() {
		return srNumber;
	}

    @JsonProperty("srNumber")
	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}
	

}
