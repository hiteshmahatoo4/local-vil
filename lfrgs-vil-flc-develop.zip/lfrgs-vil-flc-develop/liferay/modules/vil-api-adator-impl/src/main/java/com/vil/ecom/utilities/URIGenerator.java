package com.vil.ecom.utilities;

import java.util.UUID;

public final class URIGenerator {

	public static String generateURI() {
		return String.valueOf(UUID.randomUUID());
	}
}
