
package com.vil.ecom.dxl.sendSmsNotification.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "msisdn",
    "parentMSISDN",
    "usecase",
    "communicationType",
    "senderID",
    "content"
})
public class SendSmsReq {

    @JsonProperty("msisdn")
    private String msisdn;
    @JsonProperty("parentMSISDN")
    private String parentMSISDN;
    @JsonProperty("usecase")
    private String usecase;
    @JsonProperty("communicationType")
    private String communicationType;
    @JsonProperty("senderID")
    private String senderID;
    @JsonProperty("content")
    private String content;
    
    @JsonProperty("msisdn")
    public String getMsisdn() {
        return msisdn;
    }

    @JsonProperty("msisdn")
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    @JsonProperty("parentMSISDN")
    public String getParentMSISDN() {
        return parentMSISDN;
    }

    @JsonProperty("parentMSISDN")
    public void setParentMSISDN(String parentMSISDN) {
        this.parentMSISDN = parentMSISDN;
    }

    @JsonProperty("usecase")
    public String getUsecase() {
        return usecase;
    }

    @JsonProperty("usecase")
    public void setUsecase(String usecase) {
        this.usecase = usecase;
    }

    @JsonProperty("communicationType")
    public String getCommunicationType() {
        return communicationType;
    }

    @JsonProperty("communicationType")
    public void setCommunicationType(String communicationType) {
        this.communicationType = communicationType;
    }

    @JsonProperty("senderID")
    public String getSenderID() {
        return senderID;
    }

    @JsonProperty("senderID")
    public void setSenderID(String senderID) {
        this.senderID = senderID;
    }

    @JsonProperty("content")
    public String getContent() {
        return content;
    }

    @JsonProperty("content")
    public void setContent(String content) {
        this.content = content;
    }


}
