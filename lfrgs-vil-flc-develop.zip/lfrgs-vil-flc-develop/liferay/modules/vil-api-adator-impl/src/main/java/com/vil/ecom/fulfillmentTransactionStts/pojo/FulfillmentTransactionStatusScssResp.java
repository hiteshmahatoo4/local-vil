package com.vil.ecom.fulfillmentTransactionStts.pojo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"responseList"
})

public class FulfillmentTransactionStatusScssResp {

	@JsonProperty("responseList")
	private List<Response> responseList;
	
	@JsonProperty("responseList")
	public List<Response> getResponseList() {
	return responseList;
	}
	
	@JsonProperty("responseList")
	public void setResponseList(List<Response> responseList) {
	this.responseList = responseList;
	}

}