package com.vil.ecom.integration.pojo;

import com.vil.ecom.dxl.additionalBenefits.pojo.AdditionalBenefitsRespDtls;

import java.io.Serializable;

public class EcomAdditionalBenefitsResp implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
	
	private AdditionalBenefitsRespDtls promotionResponse;
	

	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	/**
	 * @return the promotionResponse
	 */
	public AdditionalBenefitsRespDtls getPromotionResponse() {
		return promotionResponse;
	}

	/**
	 * @param promotionResponse the promotionResponse to set
	 */
	public void setPromotionResponse(AdditionalBenefitsRespDtls promotionResponse) {
		this.promotionResponse = promotionResponse;
	}


	
	

}
