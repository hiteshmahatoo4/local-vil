package com.vil.ecom.integration.processor;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.vil.ecom.adaptors.http.RestUtilVo;
import com.vil.ecom.adaptors.http.RestUtility;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.config.AppServiceProcessor;
import com.vil.ecom.integration.helper.EcomHelper;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomCreditInsightsLoginResp;
import com.vil.ecom.integration.pojo.EcomMrchntLogVO;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.logger.srvc.EcomMrchntLogHelper;
import com.vil.ecom.service.EcomIntegrationUtils;
import com.vil.ecom.service.EcomSrvcConfigCnstntsServiceImpl;
import com.vil.ecom.utilities.RequestResourceThreadLocal;
import com.vil.ecom.integration.creditInsightLogin.pojo.CreditInsightsLoginRequest;
import com.vil.ecom.integration.creditInsightLogin.pojo.CreditInsightsLoginRespDtls;
import com.vil.ecom.integration.creditInsightLogin.pojo.CreditInsightsLoginResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class EcomCreditInsightsLoginProcessor implements AppServiceProcessor {

	private static final String THIS_CLASS = EcomCreditInsightsLoginProcessor.class.toString();
	private static final Log logger = LogFactoryUtil.getLog(EcomCreditInsightsLoginProcessor.class);

	/** Processor input and output pojo. */
	private EcomMrchntServiceRequest srvcRequest = null;
	private EcomMrchntServiceResponse srvcResponse;

	/**
	 * Application defined Inputs and output Pojo for given API which will be used
	 * by calling party.
	 */
	private EcomCreditInsightsLoginResp response;

	/**
	 * API request and response which needs to be sent/Received to/from 3rd party
	 * API Call.
	 */
	private CreditInsightsLoginRequest apiReq;
	private CreditInsightsLoginResponse apiResp;

	/** Map consisting API specific configurations stored in DB. */
	private Map<String, Object> confMap;

	/** Map consisting Url response received after connecting to 3rd party api. */
	private Map<String, String> urlResponseMap;

	/** API Name for which processor is implemented. */
	private String serviceNme;

	/** Pojo for logging of API request and response. */
	private EcomMrchntLogVO logVO = null;

	private Long auditId = null;

	public EcomCreditInsightsLoginProcessor(EcomMrchntServiceRequest srvcRequest) {
		this.srvcRequest = srvcRequest;
	}

	@Override
	public void preSrvcInputProcessor() {

		String thisMethod = "preSrvcInputProcessor";

		FLogger.error(logger, "Entered :" + thisMethod);

		if (srvcRequest.getServiceNme() != null) {

			serviceNme = srvcRequest.getServiceNme();

			confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap(srvcRequest.getServiceNme());

			FLogger.info(logger, THIS_CLASS, thisMethod, srvcRequest.getServiceNme());

			String user = (String) confMap.get(BaseConstants.API_SERVICES.REST_USR_NAME);
			String psd = (String) confMap.get(BaseConstants.API_SERVICES.REST_USR_PASSWORD);

			FLogger.debug(logger, THIS_CLASS, thisMethod, "Fetched Service Specific API Configurations for Service "
					+ serviceNme + " | confMap : " + confMap.size());

			FLogger.debug(logger, THIS_CLASS, thisMethod,
					"Populating API Specific Request Object for Service " + serviceNme);

			apiReq = new CreditInsightsLoginRequest();
			apiReq.setUserName(user);
			apiReq.setPassword(psd);

		} else {
			FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is null");
		}

	}

	@Override
	public EcomMrchntServiceResponse execute() {

		String thisMethod = "execute";

		String payload = null;

		MrchntRespStts respStts = null;

		String serviceProtocol = null;

		String apiUrl = null;

		int readTimeout = LoggerConstants.NUM_45000;
		int connTimeout = LoggerConstants.NUM_30000;

		String userId = null;
		String password = null;
		String authKey = null;

		boolean proxyFlg = false;
		boolean disableSslValidation = false;
		boolean disableHostNmeVerification = false;

		String trustStorePath = null;
		String trustStorePwd = null;
		String tlsVersion = null;

		String applicationRequestId = null;

		try {

			/** Formatting Input received into API specific pojo */
			preSrvcInputProcessor();

			/**
			 * Checking if input Object is not null and configurations are fetched from DB
			 * for given Service
			 */
			if (!StringChecks.isMapEmpty(confMap)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "confMap fetched -> " + confMap.size());

				serviceProtocol = (String) (confMap.get(BaseConstants.RESTWS.REST_REQ_PROTOCOL));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "serviceProtocol is " + serviceProtocol);

				proxyFlg = Boolean.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_PROXY_FLG));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "proxy Flg is " + proxyFlg);

				if (confMap.get(BaseConstants.RESTWS.REST_USR_ID) != null) {

					userId = (String) confMap.get(BaseConstants.RESTWS.REST_USR_ID);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "userId is " + userId);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_USR_PSWD) != null) {

					password = (String) confMap.get(BaseConstants.RESTWS.REST_USR_PSWD);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "password is " + password);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY) != null) {

					authKey = (String) confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "authKey is " + authKey);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT) != null) {
					connTimeout = Integer.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT) != null) {
					readTimeout = Integer.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT));
				}

				/** SSL Related properties Start */
				if (confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE) != null) {
					disableSslValidation = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY) != null) {
					disableHostNmeVerification = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION) != null) {
					tlsVersion = (String) confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH) != null) {
					trustStorePath = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD) != null) {
					trustStorePwd = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD);
				}

				/** SSL Related properties End */

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"connTimeout is " + connTimeout + " | readTimeout is " + readTimeout
								+ " | disableSslValidation is " + disableSslValidation
								+ " | disableHostNmeVerification is " + disableHostNmeVerification);

				/** 3rd Party API url to which requests needs to be submitted */


				if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTP_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTP_URL));

				} else if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTPS_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));

				} else {
					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));
				}

				FLogger.error(logger, THIS_CLASS, thisMethod, "API URl to Connect : " + apiUrl);

				/**
				 * Generating API specific payload in Json/XML Here as its Soap Web Service,
				 * payload is in XML
				 */

				payload = StringChecks.convertObjectToJson(apiReq);

				FLogger.debug(logger, THIS_CLASS, thisMethod, "Generated payload For API : " + payload);

				/** logging Request in DB for API before connection */
				logVO = new EcomMrchntLogVO();
				logVO.setServiceNme(srvcRequest.getServiceNme());
				logVO.setSourceIp(StringChecks.fetchLocalIpAddr());
				logVO.setIpAddr(StringChecks.fetchLocalIpAddr());
				logVO.setRequestParams(payload);
				logVO.setRequestType(BaseConstants.RESTWS.REST_OUTWARD_REQ);
				logVO.setFiller6(RequestResourceThreadLocal.getRequestIdForCurrentThread());
				logVO.setFiller4(apiUrl);
				logVO.setFiller3(BaseConstants.APIMODES.HTTP);
				logVO.setRequestTime(Calendar.getInstance().getTime());

				String threadId = RequestResourceThreadLocal.getURI();
				if (!StringChecks.isFieldEmpty(threadId)) {
					logVO.setFiller5(threadId);
				}

				applicationRequestId = EcomIntegrationUtils.generateAppId();

				/**
				 * Header if any needs to be sent during API Url Connection For Web Service API
				 * call, Content-type needs to be set as text/xml For Rest API Calls,
				 * Content-type will be application/json or application/x-www-url-encoded as per
				 * API IDD document
				 */
				
				if (confMap != null && confMap.get("REST_DUMMY_RESP_FLG") != null
						&& Boolean.parseBoolean((String) confMap.get("REST_DUMMY_RESP_FLG"))) {

					logVO.setFiller2(BaseConstants.API_SERVICES.DUMMY_CALL);
					EcomHelper.errorLog(logger,"Dummy Response Enabled for Service : " + serviceNme);
					urlResponseMap = EcomMrchntLogHelper.populateDummyResp(confMap, serviceNme);
					
				} else {	

					HashMap<String, String> headerParameters = new HashMap<>();
					headerParameters.put(HttpHeaders.CONTENT_TYPE, "application/json");
	
					/** Calling Url Connection Utility to Connect to API url with given payload */
					RestUtilVo requestVo = new RestUtilVo();
					requestVo.setpURL(apiUrl);
					requestVo.setHeaderParameters(headerParameters);
					requestVo.setPayload(payload);
					requestVo.setUrlParameters(null);
					requestVo.setConnectionTimeOut(connTimeout);
					requestVo.setConnectReadTimeout(readTimeout);
					requestVo.setDisableHostNmeVerification(disableHostNmeVerification);
					requestVo.setDisableSslValidation(disableSslValidation);
					requestVo.setProxyFlag(proxyFlg);
					requestVo.setTlsVersion(tlsVersion);
					requestVo.setTrustStorePath(trustStorePath);
					requestVo.setTrustStorePwd(trustStorePwd);
					requestVo.setRequestType(BaseConstants.POST_REQUEST);
					requestVo.setServiceNme(srvcRequest.getServiceNme());
					requestVo.setConfMap(confMap);
	
					FLogger.debug(logger, THIS_CLASS, thisMethod, "calling url connect method");
					urlResponseMap = RestUtility.doConnectUrl(requestVo);
				}
				
				/** Parse Response Received in Url Connection From API */
				parseResponse();

				if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {

					srvcResponse.getResponseStatus().setResponseId(applicationRequestId);
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Exiting Method " + thisMethod + " with Stts "
									+ (srvcResponse.getResponseStatus() != null
											? srvcResponse.getResponseStatus().getStatus()
											: ""));
				}

			}
			 else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "No Configurations Fetched, No Processing");
			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod,
					"Exception scenario in processing service : " + serviceNme);

			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setCreditInsightsLoginResp(response);
			srvcResponse.setResponseStatus(respStts);

		}

		return postSrvcOutputProcessor();

	}

	@Override
	public void parseResponse() {

		String thisMethod = "parseResponse";
		String status = null;
		String respMsg = null;

		String errCde = null;
		String errDesc = null;
		String errStts = null;

		try {

			status = urlResponseMap.get("status");
			respMsg = urlResponseMap.get("respMsg");
			String respCde = urlResponseMap.get("respCode");

			if (BaseConstants.SUCCESS_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success In API Url Connection");

				apiResp = (CreditInsightsLoginResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsLoginResponse.class);

				FLogger.info(logger, THIS_CLASS, thisMethod,
						"Successful API Call :Got UPI Response from API," + " processing Response.");

				errCde = respCde;
				errStts = BaseConstants.STTS_MSG_SUCCESS;
				errDesc = BaseConstants.SUCCESS_MSG;

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);

				response = new EcomCreditInsightsLoginResp();
				response.setCreditInsightsLoginResponse(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				FLogger.error(logger, "setting service response");
				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsLoginResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.ERROR_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAILED_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAILURE_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Failure Scenario in Url Connection to API");

				apiResp = (CreditInsightsLoginResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsLoginResponse.class);				

				errCde = respCde;
				errStts = BaseConstants.STTS_MSG_FAIL;
				errDesc = BaseConstants.FAILURE_MSG;

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);

				response = new EcomCreditInsightsLoginResp();
				response.setCreditInsightsLoginResponse(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsLoginResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.TIMEOUT_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "TimeOut Scenario in Url Connection to API");

				apiResp = (CreditInsightsLoginResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsLoginResponse.class);

				errCde = respCde;
				errStts = BaseConstants.STTS_MSG_FAIL;
				errDesc = BaseConstants.FAILURE_MSG;

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);

				response = new EcomCreditInsightsLoginResp();
				response.setCreditInsightsLoginResponse(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsLoginResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Unknown Scenario in Url Connection to API");

				apiResp = (CreditInsightsLoginResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsLoginResponse.class);

				errCde = BaseConstants.STTS_CODE_FAILURE;
				errStts = BaseConstants.STTS_MSG_FAIL;
				errDesc = BaseConstants.FAILURE_MSG;
				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
				response = new EcomCreditInsightsLoginResp();
				response.setCreditInsightsLoginResponse(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsLoginResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);

			MrchntRespStts respStts = new MrchntRespStts();
			respStts=RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			response = new EcomCreditInsightsLoginResp();
			response.setResponseStatus(respStts);

			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setCreditInsightsLoginResp(response);
			srvcResponse.setResponseStatus(respStts);

			logVO.setResponseParams(respMsg);
			logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
			logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
			logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

			auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

		} finally {
			if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {
				srvcResponse.getResponseStatus().setAuditId(auditId);
			}
		}
	}

	@Override
	public EcomMrchntServiceResponse postSrvcOutputProcessor() {
		FLogger.error(logger, THIS_CLASS, "postSrvcOutputProcessor",
				"Returning response: " + StringChecks.convertObjectToJson(srvcResponse.getCreditInsightsLoginResp()));
		return srvcResponse;
	}

	public CreditInsightsLoginRespDtls transformResponse(CreditInsightsLoginResponse response) {

		String thisMethod = "transformResponse";
		CreditInsightsLoginRespDtls respDtls = null;

		FLogger.debug(logger, THIS_CLASS, thisMethod, "Entered: "+thisMethod);

		try {

			if (response != null) {
				respDtls = new CreditInsightsLoginRespDtls();
				respDtls.setAccessToken(response.getData().getAccessToken());
				respDtls.setMessage(response.getMessage());
				respDtls.setTime(response.getTime());
				respDtls.setVerdict(response.getVerdict());
			} else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "Response Object is null");
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}

		return respDtls;
	}

	/**
	 * @param serviceNme
	 * @param confMap
	 * @param errCde
	 * @param errStts
	 * @param errDesc
	 * @return
	 */
	public static MrchntRespStts parseErrorCode(String serviceNme, Map<String, Object> confMap, String errCde,
			String errStts, String errDesc) {

		MrchntRespStts respStts = null;
		String thisMethod = "parseErrorCode";

		String successCodes = null;
		String pendingSuccessCodes = null;
		String failureCodes = null;

		String status = null;
		String statusDesc = null;

		List<String> successCodesList = new ArrayList<>();
		List<String> pendingSuccessCodesList = new ArrayList<>();
		List<String> failureCodesList = new ArrayList<>();

		try {
			
			
			successCodes = (String) confMap.get(BaseConstants.RESTWS.REST_SUCCESS_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "successCodes is " + successCodes);

			pendingSuccessCodes = (String) confMap.get(BaseConstants.RESTWS.REST_PENDING_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "pendingCodes is " + pendingSuccessCodes);

			failureCodes = (String) confMap.get(BaseConstants.RESTWS.REST_FAILURE_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "failureCodes is " + failureCodes);

			if (!StringChecks.isFieldEmpty(successCodes)) {
				successCodesList = Arrays.asList(successCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(pendingSuccessCodes)) {
				pendingSuccessCodesList = Arrays.asList(pendingSuccessCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(failureCodes)) {
				failureCodesList = Arrays.asList(failureCodes.split("[\\|]+"));
			}

			if (successCodesList != null && !successCodesList.contains(errCde)) {

				FLogger.error(logger, THIS_CLASS, thisMethod,
						"Non-Success Scenario for Service :: " + serviceNme);

				if (pendingSuccessCodesList != null && pendingSuccessCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Timeout Scenario for " + " as Response Code is : " + errStts + " is timeout code.");

					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				} else if (failureCodesList != null && failureCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"FAILURE Scenario for " + " as Response Code is : " + errStts + " is FAILURE code.");

					status = BaseConstants.FAILED_MSG;

					if (StringChecks.isFieldEmpty(errDesc)) {
						statusDesc = BaseConstants.FAILURE_MSG;
					} else {
						statusDesc = errDesc;
					}
				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Unknown/Deemed-Success Scenario for Service ::" + serviceNme);
					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				}

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success Scenario for Service :: " + serviceNme);
				status = BaseConstants.SUCCESS_MSG;

				if (StringChecks.isFieldEmpty(errDesc)) {
					statusDesc = BaseConstants.SUCCESS_MSG;
				} else {
					statusDesc = errDesc;
				}
			}

			respStts = new MrchntRespStts();
			respStts.setStatus(status);
			respStts.setStatusCde(errCde);
			respStts.setDescription(statusDesc);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}
		return respStts;
	}

}