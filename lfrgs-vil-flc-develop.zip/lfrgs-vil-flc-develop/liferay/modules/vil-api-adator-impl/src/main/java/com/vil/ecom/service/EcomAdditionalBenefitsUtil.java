package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.dxl.additionalBenefits.pojo.Promotion;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomAdditionalBenefitsReq;
import com.vil.ecom.integration.pojo.EcomAdditionalBenefitsResp;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomAdditionalBenefitsProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomAdditionalBenefitsUtil {

	private static final Log logger = LogFactoryUtil.getLog(EcomAdditionalBenefitsUtil.class);
	private static final String THIS_CLASS = "EcomAdditionalBenefitsUtil";
	
	/**
	 * @author Jeswanth
	 * <p>Additional Benefits API : assignPromoCode</p>
	 * @param processorInput : EcomAdditionalBenefitsReq pojo to be set for input paramater . Mandatory
	 * <p>
	 * <h2>EcomAdditionalBenefitsReq pojo details:</h2>
	 * @param msisdn : msisdn for assigning promocode . Mandatory
	 * @param circleId : circle id to be passed . Mandatory
	 * @param subscriberType : Subscription type &#34;PREPAID&#34; or &#34;POSTPAID&#34; . Mandatory
	 * @param provider : Provider (Vodafone / Idea) to be passed . Mandatory
	 * @param promotion :List&#60;Promotion&#62; - List of Promotion pojos to be set. Mandatory
	 * </p>
	 * @return EcomAdditionalBenefitsResp : EcomAdditionalBenefits API response
	 */
	public static EcomAdditionalBenefitsResp assignPromoCode(EcomAdditionalBenefitsReq processorInput) {
		
		String methodName =  "assignPromoCode";
		StopWatch stopwatch = null;
		EcomAdditionalBenefitsResp response = null;
		MrchntRespStts respStts = null;
		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();
			
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_ADDITIONAL_BENEFITS);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
			
			if(processorInput != null) {
				
				FLogger.debug(logger, THIS_CLASS, methodName, "Entered method to assign promo code for msisdn: "+processorInput.getMsisdn()+
						" | circle id: "+processorInput.getCircleId());
				
				respStts = validateInputs(processorInput);
				
				if(respStts == null) {
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.DXL_ADDITIONAL_BENEFITS);
					srvcRequest.setAdditionalBenefitsReq(processorInput);
					
					
					EcomAdditionalBenefitsProcessor processor = new EcomAdditionalBenefitsProcessor(srvcRequest);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();
					
					if(srvcResp != null) {
						if(srvcResp.getAdditionalBenefitsResp()!= null) {
							FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API");
							
							response = new EcomAdditionalBenefitsResp();
							response = srvcResp.getAdditionalBenefitsResp();
						}else {
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = new MrchntRespStts();
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
							
							response = new EcomAdditionalBenefitsResp();
							response.setPromotionResponse(null);
							response.setResponseStatus(respStts);
						}
					}else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
						
						respStts = new MrchntRespStts();
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
						
						
						response = new EcomAdditionalBenefitsResp();
						response.setPromotionResponse(null);
						response.setResponseStatus(respStts);
					}
				}else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
					
					response = new EcomAdditionalBenefitsResp();
					response.setPromotionResponse(null);
					response.setResponseStatus(respStts);
				}
				
			}else {
				FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");
				
				respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
				
				response = new EcomAdditionalBenefitsResp();
				response.setPromotionResponse(null);
				response.setResponseStatus(respStts);
			}
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			response = new EcomAdditionalBenefitsResp();
			response.setPromotionResponse(null);
			response.setResponseStatus(respStts);
			
		}finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
			
			FLogger.debug(logger, THIS_CLASS, methodName, "Returning Response: "+StringChecks.convertObjectToJson(response));
		}

		
		return response;
	}
	
	/**
	 * 
	 * @param processorInput
	 * @return
	 */
	public static MrchntRespStts validateInputs(EcomAdditionalBenefitsReq processorInput) {
		
		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName);
		try {
			
			FLogger.info(logger, THIS_CLASS, methodName, "Payload: "+StringChecks.convertObjectToJson(processorInput));
			if(processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}
			
			respStts = RsValiatorResponse.checkCircleResponse(processorInput.getCircleId(),null);
			if(respStts != null) {
				return respStts;
			}
			if(!StringChecks.checkMsisdn(processorInput.getMsisdn())) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Msisdn");
				return respStts;
			}
			if(!(processorInput.getSubscriberType().equalsIgnoreCase("PREPAID") || processorInput.getSubscriberType().equalsIgnoreCase("POSTPAID")) ) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "not a valid SubscriberType");
				return respStts;
			}
			if(!(processorInput.getProvider().equalsIgnoreCase("VODAFONE") || processorInput.getProvider().equalsIgnoreCase("IDEA")) ) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "not a valid Provider");
				return respStts;
			}
			if(StringChecks.isNullOrSpace(processorInput.getPromotion())) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Promotion data");
				return respStts;
			}
			for(Promotion promo:processorInput.getPromotion()) {
				
				if(StringChecks.isNullOrSpace(promo)) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Promotion data");
					return respStts;
				}
				
				respStts = RsValiatorResponse.validateStrInput(promo.getType(),null,"Promotion Data is not valid");
				if(respStts != null) {
					return respStts;
				}
				respStts = RsValiatorResponse.validateStrInput(promo.getId(),null,"Promotion Data is not valid");
				if(respStts != null) {
					return respStts;
				}
					
				
			}
			
			
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}
		
		return respStts;
	}
	
	
}
