@javax.xml.bind.annotation.XmlSchema(namespace = "http://eai.vodafone.com/MetaInfoResp", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.vodafone.eai.metainforesp;
