package com.vil.ecom.adaptors.http;

import java.io.Serializable;
import java.util.HashMap;

public class HttpProp implements Serializable{

	private static final long serialVersionUID = 1L;

	private String url;
	
	private String prototcol;

	private String reqType;

	private HashMap<String, String> headerParams;
	
	private HashMap<String, String> urlParams;
	
	private boolean useProxy;
	
	private String proxyIp;
	
	private int proxyPort;

	private String proxyUsrNme;

	private String proxyPwd;

	private boolean useSsl;

	private String trustStorePath;

	private String trustStorePwd;

	private String keyStorePath;

	private String keyStorePwd;
	
	private String tlsVersion;
	
	private boolean disableHostVerification;

	private int connTimeout;
	
	private int connReadTimeout;
	
	
	/**
	 * @return the connTimeout
	 */
	public int getConnTimeout() {
		return connTimeout;
	}

	/**
	 * @param connTimeout the connTimeout to set
	 */
	public void setConnTimeout(int connTimeout) {
		this.connTimeout = connTimeout;
	}

	/**
	 * @return the connReadTimeout
	 */
	public int getConnReadTimeout() {
		return connReadTimeout;
	}

	/**
	 * @param connReadTimeout the connReadTimeout to set
	 */
	public void setConnReadTimeout(int connReadTimeout) {
		this.connReadTimeout = connReadTimeout;
	}

	/**
	 * @return the disableHostVerification
	 */
	public boolean isDisableHostVerification() {
		return disableHostVerification;
	}

	/**
	 * @param disableHostVerification the disableHostVerification to set
	 */
	public void setDisableHostVerification(boolean disableHostVerification) {
		this.disableHostVerification = disableHostVerification;
	}

	/**
	 * @return the headerParams
	 */
	public HashMap<String, String> getHeaderParams() {
		return headerParams;
	}

	/**
	 * @param headerParams the headerParams to set
	 */
	public void setHeaderParams(HashMap<String, String> headerParams) {
		this.headerParams = headerParams;
	}

	/**
	 * @return the keyStorePath
	 */
	public String getKeyStorePath() {
		return keyStorePath;
	}

	/**
	 * @param keyStorePath the keyStorePath to set
	 */
	public void setKeyStorePath(String keyStorePath) {
		this.keyStorePath = keyStorePath;
	}

	/**
	 * @return the keyStorePwd
	 */
	public String getKeyStorePwd() {
		return keyStorePwd;
	}

	/**
	 * @param keyStorePwd the keyStorePwd to set
	 */
	public void setKeyStorePwd(String keyStorePwd) {
		this.keyStorePwd = keyStorePwd;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the prototcol
	 */
	public String getPrototcol() {
		return prototcol;
	}

	/**
	 * @param prototcol the prototcol to set
	 */
	public void setPrototcol(String prototcol) {
		this.prototcol = prototcol;
	}

	/**
	 * @return the reqType
	 */
	public String getReqType() {
		return reqType;
	}

	/**
	 * @param reqType the reqType to set
	 */
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	/**
	 * @return the urlParams
	 */
	public HashMap<String, String> getUrlParams() {
		return urlParams;
	}

	/**
	 * @param urlParams the urlParams to set
	 */
	public void setUrlParams(HashMap<String, String> urlParams) {
		this.urlParams = urlParams;
	}

	/**
	 * @return the useProxy
	 */
	public boolean isUseProxy() {
		return useProxy;
	}

	/**
	 * @param useProxy the useProxy to set
	 */
	public void setUseProxy(boolean useProxy) {
		this.useProxy = useProxy;
	}

	/**
	 * @return the proxyIp
	 */
	public String getProxyIp() {
		return proxyIp;
	}

	/**
	 * @param proxyIp the proxyIp to set
	 */
	public void setProxyIp(String proxyIp) {
		this.proxyIp = proxyIp;
	}

	/**
	 * @return the proxyPort
	 */
	public int getProxyPort() {
		return proxyPort;
	}

	/**
	 * @param proxyPort the proxyPort to set
	 */
	public void setProxyPort(int proxyPort) {
		this.proxyPort = proxyPort;
	}

	/**
	 * @return the proxyUsrNme
	 */
	public String getProxyUsrNme() {
		return proxyUsrNme;
	}

	/**
	 * @param proxyUsrNme the proxyUsrNme to set
	 */
	public void setProxyUsrNme(String proxyUsrNme) {
		this.proxyUsrNme = proxyUsrNme;
	}

	/**
	 * @return the proxyPwd
	 */
	public String getProxyPwd() {
		return proxyPwd;
	}

	/**
	 * @param proxyPwd the proxyPwd to set
	 */
	public void setProxyPwd(String proxyPwd) {
		this.proxyPwd = proxyPwd;
	}

	/**
	 * @return the useSsl
	 */
	public boolean isUseSsl() {
		return useSsl;
	}

	/**
	 * @param useSsl the useSsl to set
	 */
	public void setUseSsl(boolean useSsl) {
		this.useSsl = useSsl;
	}

	/**
	 * @return the trustStorePath
	 */
	public String getTrustStorePath() {
		return trustStorePath;
	}

	/**
	 * @param trustStorePath the trustStorePath to set
	 */
	public void setTrustStorePath(String trustStorePath) {
		this.trustStorePath = trustStorePath;
	}

	/**
	 * @return the trustStorePwd
	 */
	public String getTrustStorePwd() {
		return trustStorePwd;
	}

	/**
	 * @param trustStorePwd the trustStorePwd to set
	 */
	public void setTrustStorePwd(String trustStorePwd) {
		this.trustStorePwd = trustStorePwd;
	}

	/**
	 * @return the tlsVersion
	 */
	public String getTlsVersion() {
		return tlsVersion;
	}

	/**
	 * @param tlsVersion the tlsVersion to set
	 */
	public void setTlsVersion(String tlsVersion) {
		this.tlsVersion = tlsVersion;
	}
	
	
	
}
