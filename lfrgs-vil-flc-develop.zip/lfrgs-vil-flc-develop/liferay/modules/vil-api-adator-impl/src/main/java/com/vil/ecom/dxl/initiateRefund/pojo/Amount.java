package com.vil.ecom.dxl.initiateRefund.pojo;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;



@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"amount",
"units"
})

public class Amount {
	@JsonProperty("amount")
	private String amount;
	@JsonProperty("units")
	private String units;


	@JsonProperty("amount")
	public String getAmount() {
	return amount;
	}

	@JsonProperty("amount")
	public void setAmount(String amount) {
	this.amount = amount;
	}

	@JsonProperty("units")
	public String getUnits() {
	return units;
	}

	@JsonProperty("units")
	public void setUnits(String units) {
	this.units = units;
	}

}
