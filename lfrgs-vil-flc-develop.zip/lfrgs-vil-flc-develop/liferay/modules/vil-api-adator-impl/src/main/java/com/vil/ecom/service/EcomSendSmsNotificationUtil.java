package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomSendSmsNotificationReq;
import com.vil.ecom.integration.pojo.EcomSendSmsNotificationResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomSendSmsNotificationProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomSendSmsNotificationUtil {
	
	private static final Log logger = LogFactoryUtil.getLog(EcomSendSmsNotificationUtil.class);
	private static final String THIS_CLASS = "EcomSendSmsNotificationUtil";
	
	
	/**
	 * @author Jeswanth
	 * <p>Send Sms Notification API: sendSmsNotification</p>
	 * 
	 * @param processorInput : EcomSendSmsNotificationReq pojo to be set . Mandatory
	 * 
	 * <p>
	 * <h2>EcomSendSmsNotificationReq pojo details<h2>
	 * @param msisdn : Msisdn to which sms to be sent . Mandatory
	 * @param smsTxt  : SMS content to be set. Mandatory	 
	 * </p>
	 * @return EcomSendSmsNotificationResp pojo: gets the detials of SMS Notification
	 * <ul>
	 * <li>responseStatus : response status details.</li>
	 * <li>descripton: Status message for the sms notification whether it send or not.</li>
	 * </ul>
	 * 
	 *
	 */
	public static EcomSendSmsNotificationResp sendSmsNotification(EcomSendSmsNotificationReq processorInput) {
		
		String methodName =  "sendSmsNotification";
		StopWatch stopwatch = null;
		EcomSendSmsNotificationResp response = null;
		MrchntRespStts respStts = null;
		
		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();
			
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_SEND_SMS_NOTIFICATION);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
			
			respStts = validateInputs(processorInput);
			
			if(respStts == null) {
			
				if(processorInput != null) {
					
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.DXL_SEND_SMS_NOTIFICATION);
					srvcRequest.setSendSmsNtfReq(processorInput);
					
					
					EcomSendSmsNotificationProcessor processor = new EcomSendSmsNotificationProcessor(srvcRequest);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();
					
					if(srvcResp != null) {
						if(srvcResp.getSendSmsNtfResp() != null) {
							
							FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API");
							
							response = new EcomSendSmsNotificationResp();
							response = srvcResp.getSendSmsNtfResp();
						}else {
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = new MrchntRespStts();
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
							
							response = new EcomSendSmsNotificationResp();
							response.setDescription(null);
							response.setResponseStatus(respStts);
						}
					}else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
						
						response = new EcomSendSmsNotificationResp();
						response.setDescription(null);
						response.setResponseStatus(respStts);
					}
					
				}else {
					FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");
					
					respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
					
					response = new EcomSendSmsNotificationResp();
					response.setDescription(null);
					response.setResponseStatus(respStts);
				}
			}else {
				FLogger.error(logger, THIS_CLASS, methodName, "Invalid inputs");
				response =  new EcomSendSmsNotificationResp();
				response.setDescription(null);
				response.setResponseStatus(respStts);
				FLogger.error(logger, THIS_CLASS, methodName, "Rseponse: "+StringChecks.convertObjectToJson(response));
			}
			
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			response = new EcomSendSmsNotificationResp();
			response.setDescription(null);;
			response.setResponseStatus(respStts);
			
		}finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
			
			FLogger.debug(logger, THIS_CLASS, methodName, "Returning Response: "+StringChecks.convertObjectToJson(response));
		}
		
		return response;
		
		
	}
	
	
	/**
	 * 
	 * @param processorInput
	 * @return
	 */
	public static MrchntRespStts validateInputs(EcomSendSmsNotificationReq processorInput) {
		
		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName);
		try {
			
			FLogger.info(logger, THIS_CLASS, methodName, "Payload: "+StringChecks.convertObjectToJson(processorInput));
			if(processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}
			
			
			if(!StringChecks.checkMsisdn(processorInput.getMsisdn())) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Msisdn");
				return respStts;
			}
			
			
			respStts = RsValiatorResponse.validateStrInput(processorInput.getSmsTxt(), null, "SMS content is not valid");
			if(respStts != null) {
				return respStts;
			}
			
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}
		
		return respStts;
	}
	

}
