package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomCreditInsightsLoginResp;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomCreditInsightsLoginProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomCreditInsightsLoginUtil {

	private static final String THIS_CLASS = "EcomCreditInsightsLoginUtil";
	private static final Log logger = LogFactoryUtil.getLog(EcomCreditInsightsLoginUtil.class);

	/**
	 * @author Om
	 *         <p>
	 *         creditInsightLogin: generates access token
	 *         </p>
	 * @return EcomCreditInsightsLoginResp : EcomCreditInsightLogin API response
	 */
	public static EcomCreditInsightsLoginResp creditInsightLogin() {
		String methodName = "creditInsightLogin";
		StopWatch stopwatch = null;
		EcomCreditInsightsLoginResp response = null;
		MrchntRespStts respStts = null;

		try {
			
			FLogger.error(logger, THIS_CLASS, methodName, "Entered method: " + methodName);

			stopwatch = new StopWatch();
			stopwatch.start();

			if (RequestResourceThreadLocal.getRequestIdForCurrentThread() == null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if (RequestResourceThreadLocal.getServiceForCurrentThread() == null) {
				RequestResourceThreadLocal
						.addServiceForCurrentThread(BaseConstants.API_SERVICES.EAI_CREDIT_INSIGHTS_LOGIN);
			}

			EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
			srvcRequest.setServiceNme(BaseConstants.API_SERVICES.EAI_CREDIT_INSIGHTS_LOGIN);

			EcomCreditInsightsLoginProcessor processor = new EcomCreditInsightsLoginProcessor(srvcRequest);
			
			EcomMrchntServiceResponse srvcResp = processor.execute();

			if (srvcResp != null) {
				
				if (srvcResp.getCreditInsightsLoginResp() != null) {
				
					FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from Access Token API."
							+srvcResp.getCreditInsightsLoginResp().getResponseStatus().getStatus());
					
					response = srvcResp.getCreditInsightsLoginResp();
				
				} else {
					
					FLogger.error(logger, THIS_CLASS, methodName,
							"Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
					
					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

					response = new EcomCreditInsightsLoginResp();
					response.setResponseStatus(respStts);
				}
				
			} else {
				
				FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
				
				respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

				response = new EcomCreditInsightsLoginResp();
				response.setResponseStatus(respStts);
		
			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			response = new EcomCreditInsightsLoginResp();
			response.setResponseStatus(respStts);
		
		} finally {
			
			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();

		}
		
		return response;
	}

}
