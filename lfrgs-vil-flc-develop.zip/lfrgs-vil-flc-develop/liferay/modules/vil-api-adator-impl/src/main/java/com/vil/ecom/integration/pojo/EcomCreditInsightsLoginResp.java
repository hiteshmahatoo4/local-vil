package com.vil.ecom.integration.pojo;

import com.vil.ecom.integration.creditInsightLogin.pojo.CreditInsightsLoginRespDtls;
import java.io.Serializable;

public class EcomCreditInsightsLoginResp implements Serializable {
	private static final long serialVersionUID = 1L;

	private MrchntRespStts responseStatus;
	
	private CreditInsightsLoginRespDtls creditInsightsLoginResponse;

	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	public CreditInsightsLoginRespDtls getCreditInsightsLoginResponse() {
		return creditInsightsLoginResponse;
	}

	public void setCreditInsightsLoginResponse(CreditInsightsLoginRespDtls creditInsightsLoginResponse) {
		this.creditInsightsLoginResponse = creditInsightsLoginResponse;
	}

	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

}
