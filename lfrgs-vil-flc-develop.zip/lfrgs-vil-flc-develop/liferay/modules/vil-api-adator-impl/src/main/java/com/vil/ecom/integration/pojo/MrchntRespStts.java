package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class MrchntRespStts implements Serializable{
	  
	private static final long serialVersionUID = 1L;

	private String description;
	
	private String status;
	
	private String statusCde;

	private String responseId;
	
	private Long auditId;
	
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the statusCde
	 */
	public String getStatusCde() {
		return statusCde;
	}

	/**
	 * @param statusCde the statusCde to set
	 */
	public void setStatusCde(String statusCde) {
		this.statusCde = statusCde;
	}

	/**
	 * @return the responseId
	 */
	public String getResponseId() {
		return responseId;
	}

	/**
	 * @param responseId the responseId to set
	 */
	public void setResponseId(String responseId) {
		this.responseId = responseId;
	}

	/**
	 * @return the auditId
	 */
	public Long getAuditId() {
		return auditId;
	}

	/**
	 * @param auditId the auditId to set
	 */
	public void setAuditId(Long auditId) {
		this.auditId = auditId;
	}

	
}
