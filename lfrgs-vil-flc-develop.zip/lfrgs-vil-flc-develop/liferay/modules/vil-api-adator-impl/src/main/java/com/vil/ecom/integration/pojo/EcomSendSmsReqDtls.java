package com.vil.ecom.integration.pojo;

import com.vil.ecom.integration.helper.EcomHelper;

import java.io.Serializable;
import java.util.List;

public class EcomSendSmsReqDtls implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String event;

	private String circleId;

	private List<String> key;

	private String requestType;

	private String mobileNumber;

	private String message;

	private String originAddress;

	private String type;

	private String segment;

	private String srNo;

	private String threadId;

	private String requestId;

	private String moduleNme;

	private String senderId;

	private boolean disableDbLogging;
	
	private String smsMde; //Offline or Online

	private String purpose;

	private boolean digitalFlg;

	/**
	 * @return the srNo
	 */
	public String getSrNo() {
		return srNo;
	}

	/**
	 * @param srNo the srNo to set
	 */
	public void setSrNo(String srNo) {
		this.srNo = srNo;
	}

	/**
	 * @return the event
	 */
	public String getEvent() {
		return event;
	}

	/**
	 * @param event the event to set
	 */
	public void setEvent(String event) {
		this.event = event;
	}

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the key
	 */
	public List<String> getKey() {
		return  EcomHelper.cloneList(key);
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(List<String> key) {
		this.key =  EcomHelper.cloneList(key);
	}

	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}

	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the originAddress
	 */
	public String getOriginAddress() {
		return originAddress;
	}

	/**
	 * @param originAddress the originAddress to set
	 */
	public void setOriginAddress(String originAddress) {
		this.originAddress = originAddress;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the segment
	 */
	public String getSegment() {
		return segment;
	}

	/**
	 * @param segment the segment to set
	 */
	public void setSegment(String segment) {
		this.segment = segment;
	}

	/**
	 * @return the smsMde
	 */
	public String getSmsMde() {
		return smsMde;
	}

	/**
	 * @param smsMde the smsMde to set
	 */
	public void setSmsMde(String smsMde) {
		this.smsMde = smsMde;
	}

	/**
	 * @return the threadId
	 */
	public String getThreadId() {
		return threadId;
	}

	/**
	 * @param threadId the threadId to set
	 */
	public void setThreadId(String threadId) {
		this.threadId = threadId;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the moduleNme
	 */
	public String getModuleNme() {
		return moduleNme;
	}

	/**
	 * @param moduleNme the moduleNme to set
	 */
	public void setModuleNme(String moduleNme) {
		this.moduleNme = moduleNme;
	}

	/**
	 * @return the senderId
	 */
	public String getSenderId() {
		return senderId;
	}

	/**
	 * @param senderId the senderId to set
	 */
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	/**
	 * @return the disableDbLogging
	 */
	public boolean isDisableDbLogging() {
		return disableDbLogging;
	}

	/**
	 * @param disableDbLogging the disableDbLogging to set
	 */
	public void setDisableDbLogging(boolean disableDbLogging) {
		this.disableDbLogging = disableDbLogging;
	}

	/**
	 * @return the purpose
	 */
	public String getPurpose() {
		return purpose;
	}

	/**
	 * @param purpose the purpose to set
	 */
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	/**
	 * @return the digitalFlg
	 */
	public boolean isDigitalFlg() {
		return digitalFlg;
	}

	/**
	 * @param digitalFlg the digitalFlg to set
	 */
	public void setDigitalFlg(boolean digitalFlg) {
		this.digitalFlg = digitalFlg;
	}
	
}
