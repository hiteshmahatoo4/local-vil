package com.vil.ecom.constants;

public class BaseConstants {

	public static final String ERR_LOG_PRFIX = " Error Log : ";
	public static final String GOT_EXCEPTION_PREFIX = " Got Exception : ";
	public static final String GOT_EXCEPTION_DUE_TO_SUFFIX = " due to: ";

	public static final String errorInProcessingReq = "Error in Processing Request.Kindly try after Some time";

	public static final String LOGIN_LOG_REF_SEQ_LENGTH = "LOGIN_LOG_REF_SEQ_LENGTH";

	public static final String LOGIN_LOG_REF_SEQ_QUERY_STR = "LOGIN_LOG_REF_SEQ_QUERY_STR";

	public static final String HTTP_PROTOCOL = "http";

	public static final String HTTPS_PROTOCOL = "https";

	public static final String GET_REQUEST = "GET";

	public static final String POST_REQUEST = "POST";

	public static final String PUT_REQUEST = "PUT";
	
	public static final String PATCH_REQUEST = "PATCH";

	public static final String DELETE_REQUEST = "DELETE";

	public static final String SUCCESS_MSG = "SUCCESS";

	public static final String PENDING_MSG = "PENDING";

	public static final String COMPLETED_MSG = "COMPLETED";

	public static final String RESENT_MSG = "RESENT";

	public static final String SENT_MSG = "SENT";

	public static final String FAILED_MSG = "FAILED";
	
	public static final String FAIL_MSG = "FAIL";
	
	public static final String NOT_SUPPORTED_MSG = "NOT_SUPPORTED";

	public static final String FAILURE_MSG = "FAILURE";

	public static final String ERROR_MSG = "ERROR";

	public static final String TIMEOUT_MSG = "TIMEOUT";

	public static final String MAINTENANCE_MSG = "MAINTENANCE";

	public static final String PROXY_FLG = "ADD_PROXY_FLG";

	public static final String PROXY_IP = "PROXY_IP";

	public static final String PROXY_PORT = "PROXY_PORT";

	public static final String PROXY_USR_NME = "PROXY_USR_NME";

	public static final String PROXY_PSWD = "PROXY_PSWD";

	public static final String NO_RESP = "No Response Received";

	public static final String URL_TIMEOUT = "URl timeout occurred";

	public static final String ERR_PROCESSING_REQ = "Error in Processing Request.Kindly try after Some time";

	public static final String MQ_CONN_ERROR = "Error in MQ Connection";

	public static final String EXT_VODA_SYSTEM = "exV_";

	public static final String EXT_SYSTEM = "ex3_";

	public static final String TRANS_FAIL = "Transaction Failed";

	public static final String TRANS_SUCCESS = "Transaction Successful";
	
	public static final String ENCRYPT = "ENCRYPT";
	
	public static final String DECRYPT = "DECRYPT";
	
	public static final String TRUE = "true";
	
	public static final String YYYYMMDDHHMMSS= "yyyy-MM-dd HH:mm:ss";

	/*---------------Status Codes-----------------*/
	public static final String STTS_CODE_SUCCESS = "100";
	public static final String STTS_CODE_AUTH_FAIL = "101";
	public static final String STTS_CODE_EXISTING_CSTMR = "102";
	public static final String STTS_CODE_INVALID_MANDATORY_PARAMS = "103";
	public static final String STTS_CODE_INVALID_MSISDN = "104";
	public static final String STTS_CODE_MANDATORY_PARAMS_NOT_PASSED = "105";
	public static final String STTS_CODE_FAILURE = "106";
	public static final String STTS_MSG_BULK_SR_CODE = "1";
	public static final String STTS_CODE_PENDING = "107";
	public static final String STTS_CODE_NO_RECORDS = "125";
	public static final String STTS_CODE_USER_VALIDATIONS = "102";

	/*---------------Status----------------*/
	public static final String STTS_MSG_SUCCESS = "SUCCESS";
	public static final String STTS_MSG_FAIL = "FAILURE";
	public static final String STTS_NO_RECORD_MSG_FAIL = "No Records found";
	public static final String STTS_MSG_INVALID_CREDS = "Authentication Failed";

	/** Added Inner class for MAIL Constants */
	public static final class EMAIL {

		private EMAIL() {
			throw new IllegalStateException(" final class");
		}
		
		public static final String MAIL_HOST_PROPERTY = "mail.smtp.host";

		public static final String MAIL_PORT_PROPERTY = "mail.smtp.port";

		public static final String MAIL_CONN_TIMEOUT_PROPERTY = "mail.smtp.connectiontimeout";

		public static final String MAIL_TIMEOUT_PROPERTY = "mail.smtp.timeout";

		public static final String MAIL_AUTH_PROPERTY = "mail.smtp.auth";

		public static final String MAIL_AUTH_USRNME = "username";

		public static final String MAIL_AUTH_PSWD = "password";

		public static final String BLOCK_MAIL = "BLOCK_MAIL";

		public static final String EMAIL_HOST_NAME = "EMAIL_HOST_NME";

		public static final String EMAIL_PORT = "EMAIL_PORT";

		public static final String EMAIL_CONN_TIMEOUT = "EMAIL_CONN_TIMEOUT";

		public static final String EMAIL_READ_TIMEOUT = "EMAIL_READ_TIMEOUT";

		public static final String SENDER_EMAIL_ID = "SENDER_EMAIL_ID";

	}
	
	/**Added Inner class for HttpHeader constants*/
	public static final class HTTPHEADERS {

		private HTTPHEADERS() {
			throw new IllegalStateException(" final class");
		}
		
		public static final String CIRCLE_ID = "CircleID";
		public static final String PROVIDER = "Provider";
		public static final String CHANNEL = "Channel";
		public static final String X_EXTERNAL_CORRELATION_ID = "X-External-CorrelationId";
		public static final String X_BUSINESS_Tx_ID = "X-BusinessTx-ID";
		public static final String SUBSCRIPTION_TYPE = "SubscriptionType";
		public static final String IS_MIGRATED = "IsMigrated";
		public static final String X_REQUEST_ID = "X-REQUEST-ID";
		
		public static final String X_CleverTap_Account_Id = "X-CleverTap-Account-Id";
		public static final String X_CleverTap_Passcode="X-CleverTap-Passcode";
		
		
	}

	public static final class LOGEVENTS {

		private LOGEVENTS() {
			throw new IllegalStateException(" final class");
		}
		
		public static final String WS_VALIDATION = "WS_VALIDATION";
		public static final String WS_SRVC = "WS_SRVC";
		public static final String WS_CONTROLLER = "WS_CONTROLLER";
		public static final String RS_VALIDATION = "RS_VALIDATION";
		public static final String RS_SRVC = "RS_SRVC";
		public static final String RS_CONTROLLER = "RS_CONTROLLER";
		public static final String DB_CALL_EXT = "DB_CALL_EXT";
		public static final String DB_CALL = "DB_CALL";

	}

	public static final class APIMODES {

		private APIMODES() {
			throw new IllegalStateException("final class");
		}
		
		public static final String MQ = "MQ";
		public static final String SOAP = "SOAP";
		public static final String JSON = "JSON";
		public static final String HTTP = "HTTP";
		public static final String SFTP = "SFTP";

	}

	public static final class MQ {

		private MQ() {
			throw new IllegalStateException("final class");
		}

		public static final String HOST_IP = "HOST_IP";
		public static final String HOST_PORT = "HOST_PORT";
		public static final String QUEUE_MANAGER = "QUEUE_MANAGER";
		public static final String INPUT_QUEUE_NME = "INPUT_QUEUE_NME";
		public static final String OUTPUT_QUEUE_NME = "OUTPUT_QUEUE_NME";
		public static final String OUTPUT_QUEUE_NME_VF = "OUTPUT_QUEUE_NME_VF";
		public static final String OUTPUT_QUEUE_NME_IDEA = "OUTPUT_QUEUE_NME_IDEA";
		public static final String ASYNC_OUTPUT_QUEUE_NME = "ASYNC_OUTPUT_QUEUE_NME";
		public static final String QUEUE_CHNNL_NME = "QUEUE_CHNNL_NME";
		public static final String MQ_SSL_FLG = "MQ_SSL_FLG";
		public static final String MQ_WAIT_RESPONSE_FLG = "MQ_WAIT_RESPONSE_FLG";

		public static final String READ_MQ_MESSAGES_ENABLE_FLG = "READ_MQ_MESSAGES_ENABLE_FLG";

		public static final String QUEUE_REPLY_TIMEOUT = "QUEUE_REPLY_TIMEOUT";
		public static final String SSL_CIPHER_SUITE = "SSL_CIPHER_SUITE";

	}

	/** Added Inner class for SFTP Integration Constants */
	public static final class SFTP {

		private SFTP() {
			throw new IllegalStateException("final class");
		}

		public static final String SFTP_PROCESS_FLG = "SFTP_PROCESS_FLG";

		public static final String SFTP_REMOTE_DIR = "SFTP_REMOTE_DIR";
		public static final String SFTP_INPUT_DIR = "SFTP_INPUT_DIR";
		public static final String SFTP_ARCHIEVE_DIR = "SFTP_ARCHIEVE_DIR";
		public static final String SFTP_RENAME_DIR = "SFTP_RENAME_DIR";

		/** SFTP constants */
		public static final String SFTP_HOST = "SFTP_HOST";
		public static final String SFTP_PORT = "SFTP_PORT";
		public static final String SFTP_USRID = "SFTP_USRID";
		public static final String SFTP_PSWD = "SFTP_PWD";

		public static final String SFTP_DELETE_FLG = "SFTP_DELETE_FLG";
		public static final String SFTP_GET_FLG = "SFTP_GET_FLG";
		public static final String SFTP_PUT_FLG = "SFTP_PUT_FLG";
		public static final String SFTP_PROXY_FLG = "SFTP_PROXY_FLG";
		public static final String SFTP_RENAME_FLG = "SFTP_RENAME_FLG";

		public static final String SFTP_PROXY_IP = "SFTP_PROXY_IP";
		public static final String SFTP_PROXY_PORT = "SFTP_PROXY_PORT";
		public static final String SFTP_CONN_TIMEOUT = "SFTP_CONN_TIMEOUT";

		public static final String SFTP_FILE_EXTENSION = "SFTP_FILE_EXTENSION";
		public static final String PROCESS_FULL_DMP = "PROCESS_FULL_DMP";

		public static final String TRUSTSTORE_PATH = "TRUST_STORE_PATH";
		public static final String TRUSTSTORE_PSWD = "TRUST_STORE_PWD";

	}

	/** Added Inner class for Rest Services related Constants */
	public static final class RESTWS {

		public static final String ENABLE_SPRING_JMS = "ENABLE_SPRING_JMS";
		public static final String ENABLE_HTTP_CLIENT = "ENABLE_HTTP_CLIENT";
		public static final String ENABLE_REST_TEMPLATE = "ENABLE_REST_TEMPLATE";

		public static final String ENABLE_SSL_HANDSHAKE = "ENABLE_SSL_HANDSHAKE";
		public static final String TRUSTSTORE_PATH = "TRUSTSTORE.PATH";
		public static final String TRUSTSTORE_PAWD = "TRUSTSTORE.PWD";

		public static final String REST_INVALID_PAYLOAD_ERR_MSG = "Invalid Request Passed";
		public static final String REST_MANDATORY_PARAM_ERR_MSG = "Mandatory Parameters not Passed";
		public static final String REST_INVALID_PARAM_ERR_MSG = "Invalid Parameters Passed";

		public static final String REST_MS_SUCCESS_CDE = "100";
		public static final String REST_MS_FAILURE_CDE = "106";
		public static final String REST_MANDATORY_PARAM_ERR_CDE = "105";
		public static final String REST_INVALID_PARAM_ERR_CDE = "103";

		public static final String URL_TIMEOUT = "URI Time out Occurred";
		public static final String NO_RESP = "No response from API";

		public static final String DATE_PATTERN1 = "dd/MM/yyyy";
		public static final String DATE_PATTERN2 = "dd-MM-yyyy";
		public static final String DATE_PATTERN3 = "yyyy-MM-dd";
		public static final String DATE_PATTERN4 = "dd-MM-yyyy HH:MM:SS";
		public static final String DATE_PATTERN5 = "yyyy-MM-dd HH:mm:ss.SSS";
		public static final String DATE_PATTERN6 = "yyyy-MM-dd HH:mm:ss";
		public static final String DATE_PATTERN7 = "dd-MM-yyyy";
		public static final String DATE_PATTERN8 = "dd-MMM-yyyy";
		public static final String DATE_PATTERN9 = "dd-MMM-YY HH:mm:ss";
		public static final String DATE_PATTERN10 = "dd/MM/yyyy HH:mm:ss";
		public static final String DATE_PATTERN11 = "MM/dd/yyyy HH:mm:ss";
		public static final String DATE_PATTERN12 = "dd-MMM-yy";
		public static final String DATE_PATTERN13 = "MM-dd-yyyy HH:mm:ss";
		public static final String DATE_PATTERN14 = "MM/dd/yyyy";

		public static final String DATE_PATTERN15 = "dd-MM-yyyy HH:mm:ss";
		public static final String GET_IN_BAL_TIMEZONE_DATE_PATTERN = "yyyyMMdd'T'hh:mm:ss";

		public static final String TNPS_DATE_PATTERN = "dd-MMM-yyyy HH:mm:ss";
		public static final String TNPS_DATE_FILE_DATE_PATTERN = "ddMMyyyyHHmmss";
		public static final String TNPS_AON_DATE_FILE_DATE_PATTERN = "E MMM dd HH:mm:ss Z yyyy";

		/** DB Constants */
		public static final String REST_HOST_NME_VERIFY = "REST_HOST_NME_VERIFY";
		public static final String REST_SSL_DISABLE = "REST_SSL_DISABLE";
		public static final String REST_PROXY_FLG = "REST_PROXY_FLG";

		public static final String REST_INTERFACE_TYPE = "REST_INTERFACE_TYPE";
		public static final String REST_INTERFACE_KEY = "REST_INTERFACE_KEY";

		public static final String REST_USR_ID = "REST_USR_ID";
		public static final String REST_USR_PSWD = "REST_USR_PWD";
		public static final String REST_REQ_PROTOCOL = "REST_REQ_PROTOCOL";
		public static final String REST_METHOD_PROTOCOL = "REST_METHOD_PROTOCOL";
		public static final String REST_USR_CHNNL = "REST_USR_CHNNL";
		public static final String REST_REQ_MDE = "REST_REQ_MDE";
		public static final String REST_SRV_NME = "REST_SRV_NME";
		public static final String REST_FROM = "REST_FROM";
		public static final String REST_SERVICE_NME = "REST_SERVICE_NME";
		public static final String REST_SOURCE_INDICATOR = "REST_SOURCE_INDICATOR";
		public static final String REST_FLASH_REQ_NME = "REST_FLASH_REQ_NME";

		public static final String REST_HTTP_URL = "REST_HTTP_URL";
		public static final String REST_HTTPS_URL = "REST_HTTPS_URL";
		public static final String REST_HTTP_URL_LOCAL = "REST_HTTP_URL_LOCAL";
		public static final String REST_NO_AUTH_URL = "REST_NO_AUTH_URL";
		public static final String REST_NO_AUTH_HTTPS_URL = "REST_NO_AUTH_HTTPS_URL";

		public static final String REST_SUCCESS_CDES = "REST_SUCCESS_CDES";
		public static final String REST_PENDING_CDES = "REST_PENDING_CDES";
		public static final String REST_FAILURE_CDES = "REST_FAILURE_CDES";
		public static final String MQ_ENABLE_CORRELATION_ID = "MQ_ENABLE_CORRELATION_ID";

		public static final String REST_CONN_TIMEOUT = "REST_CONN_TIMEOUT";
		public static final String REST_CONN_READ_TIMEOUT = "REST_CONN_READ_TIMEOUT";
		public static final String REST_SOAP_HEADER = "REST_SOAP_HEADER";
		public static final String REST_SMS_ORIGIN_ADDRSS = "REST_SMS_ORIGIN_ADDRSS";
		public static final String REST_AUTH_TOKEN = "REST_AUTH_TOKEN";

		public static final String REST_TLS_VERSION = "REST_TLS_VERSION";
		public static final String TRUST_STORE_PATH = "TRUST_STORE_PATH";
		public static final String TRUST_STORE_PSWD = "TRUST_STORE_PWD";

		public static final String PROXY_IP = "PROXY_IP";
		public static final String PROXY_PORT = "PROXY_PORT";
		public static final String PROXY_USR_NME = "PROXY_USR_NME";
		public static final String PROXY_PSWD = "PROXY_PSWD";

		public static final String REST_SUCCESS_CDE = "100";
		public static final String REST_AUTH_FAILURE_CDE = "101";
		public static final String REST_FAILURE_CDE = "106";
		public static final String REST_INVALID_PARAM_CDE = "103";
		public static final String REST_INVALID_USR_CDE = "104";
		public static final String REST_MANDATORY_PARAM_CDE = "105";
		public static final String REST_SR_ERROR_CDE = "1";
		public static final String REST_SR_SCSS_CDE = "0";

		public static final String REST_INVALID_PARAM_MSG = "Invalid mandatory parameters passed";
		public static final String REST_MANDATORY_PARAM_MSG = "All Mandatory parameters not passed";
		public static final String REST_INVALID_USR_MSG = "Invalid Hierarchy User Details Passed";
		public static final String REST_NO_SECRET_QSTN_SET = "No Secret Questions set for input User";
		public static final String REST_SRVC_NOT_ALLOWED_MSG = "Service is not allowed for Input Channel";
		public static final String REST_NO_HRRCHY_MSG = "No hierrachy Records found for input";
		public static final String REST_RQST_SUBMIT_SCSS_MSG = "Request Submitted Successfully";
		public static final String REST_RQST_EXCEPTION_MSG = "Technical error occured. Please try again";

		public static final String BEARER_HEADER = "Bearer";
		public static final String SOAP_ACTION_HEADER = "SOAPAction";
		public static final String REST_AUTH_HEADER = "Authorization";

		public static final String REST_APP_ID = "REST_APP_ID";
		public static final String REST_AUTH_KEY = "REST_AUTH_KEY";
		public static final String REST_SOAP_ACTION = "REST_SOAP_ACTION";
		public static final String REST_OUTWARD_REQ = "OW";
		public static final String REST_INWARD_REQ = "IW";
		public static final String JMS_INWARD_REQ = "JMS";

		public static final String REST_CLIENT_ID = "CLIENT_ID";
		public static final String REST_CLIENT_SECRET = "CLIENT_SECRET";
		public static final String REST_OAUTH_GRANT_TYPE_PSWD = "password";
		public static final String REST_OAUTH_REFRESH_GRANT_TYPE = "refresh_token";
		public static final String REFRESH_TOKEN_HEADER = "refresh_token";
		public static final String REST_GRANT_TYPE = "grant_type";
		public static final String REST_USERNAME = "username";
		
		
		public static final String REST_PROVIDER = "REST_PROVIDER";
		public static final String REST_CHANNEL = "REST_CHANNEL";
		public static final String REST_IS_MIGRATED = "REST_IS_MIGRATED";
		
		public static final String REST_CLIENT_CODE = "CLIENT_CODE";
		public static final String REST_ENC_PUBLIC_KEY = "ENC_PUBLIC_KEY";
		public static final String REST_ENC_PRIVATE_KEY = "ENC_PRIVATE_KEY";
		public static final String REST_TRANSACTION_TYPE = "REST_TRANSACTION_TYPE";
		public static final String REST_SECRET_KEY = "REST_SECRET_KEY";
		public static final String AMOUNT_UNITS = "INR";
		public static final String ITEM_NAME = "PACK";
		public static final String PG_ORDER_ID = "paymentPgOrderID";
		public static final String SERVICE_ACTIVATION_CORRELATION_ID = "serviceActivationCorrelationID";
		public static final String REFUND_ORDER_ID = "refundOrderid";
		public static final String REST_COMMUNICATION_TYPE ="REST_COMMUNICATION_TYPE";
		public static final String ECOM_ORDER_ID = "ecommOrderId";
		public static final String PAYMENT_DATE_TIME= "paymentDateTime";
		public static final String PAYMENT_CHANNEL="paymentChannel";
		public static final String REDIRECT_URL="REDIRECT_URL";
		public static final String GATEWAY_TRANSACTION_ID="gatewayTransactionId";
		public static final String PAYMENT_MODE="paymentMode";
		public static final String PAYMENT_METHOD_TYPE="paymentMethodType";
		public static final String PAYMENT_GATEWAY="paymentGateway";
		public static final String CARD_ISSUER="cardIssuer";
		public static final String PAYMENT_METHOD="paymentMethod";
		public static final String CARD_TYPE="cardType";
		public static final String PAYMENT_AMOUNT="paymentAmount";
		public static final String PAYMENT_GATEWAY_ID="paymentGatewayId";
		public static final String REST_ACTION = "REFUND";
		public static final String INITIATE_REFUND_TRANSACTION_TYPE = "MARKETPLACE";
		
		public static final String REST_SMS_USE_CASE = "REST_SMS_USE_CASE";	
		public static final String REST_SENDER_ID = "REST_SENDER_ID";
		public static final String REST_CUSTOMER_LOOKUP_FLG = "REST_CUSTOMER_LOOKUP_FLG";
		public static final String REST_EVENT_TYPE = "REST_EVENT_TYPE";		
		public static final String REST_ACCOUNT_ID = "REST_ACCOUNT_ID";
		public static final String REST_PASSCODE = "REST_PASSCODE";
		
		
		

		private RESTWS() {
			throw new IllegalStateException("RESTWS final class");
		}

	}

	public static final class RESTENDPOINT {

		private RESTENDPOINT() {
			throw new IllegalStateException("final class");
		}

		public static final String RESP_STTS = "TIMEOUT";
		public static final String RESP_ERR_CDE = "TIMEOUT";
		public static final String RESP_ERR_DESC = "The Service is not Active Currently";

		public static final String SRVC_ACTIVE = "Y";
		public static final String SRVC_DEACTIVE = "N";

	}

	/** Added Inner class for SSL Constants */
	public static final class SSL {

		private SSL() {
			throw new IllegalStateException("SSL final class");
		}

		public static final String TRUST_STORE_PATH = "TRUST_STORE_PATH";
		public static final String TRUST_STORE_PSWD = "TRUST_STORE_PWD";

	}

	/** Added Inner class for SMS API Constants */
	public static final class SMS {

		public static final String SWIFT_OFFLINE_SMS_PROCESSOR = "SWIFT_OFFLINE_SMS_PROCESSOR";

		public static final String SFTP_INPUT_DIR = "SFTP_INPUT_DIR";
		public static final String SFTP_ARCHIEVE_DIR = "SFTP_ARCHIEVE_DIR";

		public static final String BLOCK_SMS_FLG = "BLOCK_SMS_FLG";

		public static final String RESEND_SMS_FLG = "RESEND_SMS_FLG";

		public static final String SMS_PROCESSING_STTS = "PROCESSING";

		public static final String SMS_PROCESSED_STTS = "PROCESSED";

		public static final String SMS_RESENT_STTS = "RESENT";

		public static final String SMS_URI = "SMS_API_URL";

		public static final String SMS_API_ID_LENGTH = "SMS_API_ID_LENGTH";

		public static final String SMS_API_SEQ_QUERY_STR = "SMS_API_SEQ_QUERY_STR";

		public static final String URL_TIMEOUT = "URI Time out Occurred";

		public static final String NO_RESP = "No response from API";

		public static final String SMS_API_MSG_PART_LGTH = "SMS_API_MSG_PART_LGTH";

		public static final String SMS_API_MSG_LIMIT = "SMS_API_MSG_LIMIT";

		public static final String SMS_API_TYPE = "SMS_API_TYPE";

		public static final String SMS_PROXY_FLG = "SMS_PROXY_FLG";

		public static final String DFT_SMS_CRLCE_CDE = "DFT_SMS_CRLCE_CDE";

		public static final String SMS_CONN_TIMEOUT = "SMS_CONN_TIMEOUT";
		public static final String SMS_READ_CONN_TIMEOUT = "SMS_READ_CONN_TIMEOUT";

		public static final String RESEND_SMS_MAX_RECORD_FETCH = "RESEND_SMS_MAX_RECORD_FETCH";
		public static final String RESEND_SMS_MAX_BATCH_EXEC_LIMIT = "RESEND_SMS_MAX_BATCH_EXEC_LIMIT";
		public static final String RESEND_SMS_BATCH_SIZE = "RESEND_SMS_BATCH_SIZE";
		public static final String DISABLE_SMS_BULK_PROCESSOR = "DISABLE_SMS_BULK_PROCESSOR";

		public static final String RESEND_SMS_PAST_DATE_RANGE = "RESEND_SMS_PAST_DATE_RANGE";
		public static final String RESEND_SMS_ENABLE_DATE_RANGE = "RESEND_SMS_ENABLE_DATE_RANGE";

		public static final String SMS_WHITELIST_EVENTS = "SMS_WHITELIST_EVENTS";
		public static final String BLOCK_SMS_PROCESSOR = "Sms Sending is Blocked";
		public static final String SMS_PROCESSOR_DELAY = "SMS_PROCESSOR_DELAY";
		public static final String SMS_TO_BE_SENT = "TO_BE_SENT";
		public static final String SMS_SENT = "SMS_SENT";

		public static final String SMS_OFFLINE_MDE = "OFFLINE";
		public static final String SMS_ONLINE_MDE = "ONLINE";
		public static final String SFTP_FAILURE = "SFTP Transfer Failure";
		
		public static final String SMS_SRVC = "SMS";
		public static final String SMS_USE_CASE = "DIGITAL_STORE"; 

	}

	/** Added Inner class for EAI Integrations Constants */
	public static final class Eai {

		public static final String PRE_SEGMENT = "PREPAID";
		public static final String POST_SEGMENT = "POSTPAID";

		public static final String POSTPAY_CRM_SUB_TYPE_VAL = "E - Payment Enquiry";

		public static final String EAI_HOST_NME_VERIFY = "EAI_HOST_NME_VERIFY";

		public static final String EAI_SSL_DISABLE = "EAI_SSL_DISABLE";

		public static final String EAI_REQ_PROTOCOL = "EAI_REQ_PROTOCOL";

		public static final String SUCCESS_MSG = "Request Submitted Successfully";

		public static final String VALIDATION_ERR = "Error in Validation of Input EAI Notification XML";

		public static final String EAI_CIPHER_SUITE = "EAI_CIPHER_SUITE";

	}

	public static final class API_SERVICES {

		/** OAuth API Service */
		public static final String OAUTH_get_Access_token = "OAUTH_getAccessToken";
		public static final String OAUTH_refresh_Access_token = "OAUTH_refreshAccessToken";

		public static final String PRE = "PRE";
		public static final String POST = "POST";
		
		public static final String PREPAID_SEGMENT = "PREPAID";
		public static final String POSTPAID_SEGMENT = "POSTPAID";
		
		public static final String PROVIDER_VODAFONE = "VODAFONE";

		public static final String APP_EMAIL_SRVC = "ECOM_SEND_MAIL";

		/**DXL API Service */
		public static final String DXL_ADDITIONAL_BENEFITS = "DXL_additionalBenefits";
		public static final String DXL_PROCESS_PAYMENT = "DXL_processPayment";
		public static final String DXL_REFUND_STATUS = "DXL_RefundStatus";
		public static final String DXL_CUSTOMER_LOOKUP = "DXL_customerLookup";
		public static final String DXL_SEND_SMS_NOTIFICATION = "DXL_sendSmsNotification";
		public static final String DXL_SEND_WHATSAPP_NOTIFICATION ="DXL_sendWhatsappNotification";
		public static final String DXL_INITIATE_REFUND = "DXL_initiateRefund";
		public static final String DXL_FULFILLMENT_TRANSACTION_STATUS="DXL_fulfillmentTransactionStatus";
		
		/** EAI API Service */
		public static final String EAI_KEY_SUBSCRIBER_LOOKUP = "EAI_keySubscriberLookup";
		public static final String EAI_CUSTOMER_ACCOUNT_LIST = "EAI_customerAccountList";
		public static final String EAI_CREDIT_INSIGHTS_LOGIN = "EAI_creditInsightsLogin";
		public static final String EAI_VERIFY_OTP_CREDIT_INSIGHTS = "EAI_verifyOtpCreditInsights";
		public static final String EAI_CREDIT_INSIGHTS_INTERNAL_CONSENT = "EAI_creditInsightsInternalConsent";
		public static final String EAI_CREATE_CONSENT_REQUEST = "EAI_createConsentRequest";
		public static final String EAI_PRODUCT_FULLFILLMENT = "EAI_productFullfillment";
		public static final String EAI_FULFILLMENT_ORDER_STTS_QUERY = "EAI_FulfillmentOrderSttsQuery";
		public static final String CREATE_CONSENT_REQUEST_CLIENT_CODE = "CLIENT_CODE";

		public static final String REST_USR_NAME = "REST_USR_NAME";
		public static final String REST_USR_PASSWORD = "REST_USR_PASSWORD";
		public static final String CLIENT_CODE = "CLIENT_CODE";
		public static final String EAI_JUSPAY_REFUND = "EAI_juspayRefund";
		public static final String VERSION = "VERSION";
		public static final String X_MERCHANTID = "X_MERCHANTID";
		public static final String REST_TOKEN = "REST_TOKEN";
		public static final String REST_ENC_KEY = "REST_ENC_KEY";
		public static final String CORE_VERSION = "CORE_VERSION";
		
		public static final String EAI_SEND_SMS_DETAILS_SERVICE_NAME = "sendSmsMSDP";
		public static final String EAI_SEND_SMS_DETAILS_SEC_USR_ID = "EAI_SEND_SMS_DETAILS_SEC_USR_ID";
		public static final String EAI_SEND_SMS_DETAILS_SEC_PSWD_ID = "EAI_SEND_SMS_DETAILS_SEC_PWD_ID";
		public static final String WS_SECURITY_CHANGES_ENABLE = "WS_SECURITY_CHANGES_ENABLE";
		
		public static final String WS_SECURITY_SERVICE_NAME ="WS_SECURITY_SERVICE_NAME";
		public static final String WS_SECURITY_HTTPS_URL ="WS_SECURITY_HTTPS_URL";
		public static final String WS_SECURITY_HTTP_URL ="WS_SECURITY_HTTP_URL";
		
		public static final String EAI_SEND_SMS_DETAILS_SRVC = "EAI_sendSmsMSDP";
		
		public static final String EAI_UPLOAD_EVENTS = "EAI_uploadEvents";
		
		/** Swift Service SRCreate Job */
		public static final String SWIFT_SR_CREATE_SRVC = "SWIFT_srCreate";
		public static final String SWIFT_SR_MEDIA = "Inbound";

		/** Swift Service SRUpdate Job */
		public static final String SWIFT_SR_UPDATE_SRVC = "SWIFT_srUpdate";

		/**/
		public static final String SMS_RECEIVED = "Received";
		public static final String SMS_SENT = "Sent";
		public static final String UPSS_SMS_TYPEOUT = "Out";
		public static final String UPSS_SMS_TYPEIN = "In";

		/* Pt stubbing */
		public static final String PT_STUBBING_CALL = "PT FLOW";
		/** Pt stubbing */
		public static final String DUMMY_CALL = "DUMMY_CALL";
		
		

	}

	public static final class REST_ENDPOINT {

		public static final String RESP_STTS = "TIMEOUT";
		public static final String RESP_ERR_CDE = "TIMEOUT";
		public static final String RESP_ERR_DESC = "The Service is not Active Currently";

		public static final String SRVC_ACTIVE = "Y";
		public static final String SRVC_DEACTIVE = "N";

	}

}
