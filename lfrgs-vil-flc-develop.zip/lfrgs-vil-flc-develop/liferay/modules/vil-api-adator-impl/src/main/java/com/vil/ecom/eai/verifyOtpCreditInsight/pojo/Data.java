package com.vil.ecom.eai.verifyOtpCreditInsight.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "consent_info", "other", "score_info", "telco_code" })

public class Data implements Serializable {
	@JsonProperty("consent_info")
	private ConsentInfo consentInfo;
	@JsonProperty("other")
	private Other other;
	@JsonProperty("score_info")
	private ScoreInfo scoreInfo;
	@JsonProperty("telco_code")
	private String telcoCode;
	private final static long serialVersionUID = -231013185918352052L;

	@JsonProperty("consent_info")
	public ConsentInfo getConsentInfo() {
		return consentInfo;
	}

	@JsonProperty("consent_info")
	public void setConsentInfo(ConsentInfo consentInfo) {
		this.consentInfo = consentInfo;
	}

	@JsonProperty("other")
	public Other getOther() {
		return other;
	}

	@JsonProperty("other")
	public void setOther(Other other) {
		this.other = other;
	}

	@JsonProperty("score_info")
	public ScoreInfo getScoreInfo() {
		return scoreInfo;
	}

	@JsonProperty("score_info")
	public void setScoreInfo(ScoreInfo scoreInfo) {
		this.scoreInfo = scoreInfo;
	}

	@JsonProperty("telco_code")
	public String getTelcoCode() {
		return telcoCode;
	}

	@JsonProperty("telco_code")
	public void setTelcoCode(String telcoCode) {
		this.telcoCode = telcoCode;
	}

}


