package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomCustomerLookupReq;
import com.vil.ecom.integration.pojo.EcomCustomerLookupResp;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomCustomerLookupProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;



public class EcomCstmrLookupUtil {

	private static final Log logger = LogFactoryUtil.getLog(EcomCstmrLookupUtil.class);
	private static final String THIS_CLASS = EcomCstmrLookupUtil.class.toString();
	
	/**
	 * @author Ishita
	 * <p>Customer Lookup API : fetchCstmrLookupDtls </p>
	 * @param processorInput : EcomCustomerLookupReq pojo to be set for input paramater . Mandatory
	 * <p>
	 * <h2>EcomCustomerLookupReq pojo details:</h2>
	 * @param msisdn : msisdn to be passed . Mandatory
	 * @param circleId : circle id if passed, it should be numeric. Optional 
	 * @param subscriberType: SubscriberType if passed, should be PREPAID / POSTPAID . Optional
	 * @param provider: Provider if passed, it should be VODAFONE / IDEA . Optional
	 * </p>
	 * @return EcomCustomerLookupResp : EcomCustomerLookup API response
	 */
	public static EcomCustomerLookupResp fetchCstmrLookupDtls(EcomCustomerLookupReq processorInput) {
			
		String methodName = "fetchCstmrLookupDtls";
		StopWatch stopwatch = null;
		EcomCustomerLookupResp response = null;
		MrchntRespStts respStts = null;
			
		try {
				
			stopwatch = new StopWatch();
			stopwatch.start();
				
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}
	
			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_CUSTOMER_LOOKUP);
			}
				
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
				
			if (processorInput != null) {
				FLogger.debug(logger, THIS_CLASS, methodName,"Entered Method to fetch customerLookup details for msisdn " + processorInput.getMsisdn()+ 
						" | Circle ID : "+ processorInput.getCircleId());
	
				respStts=validateInputs(processorInput);
					
				if(respStts==null) {
	
					EcomMrchntServiceRequest srvcRqst = new EcomMrchntServiceRequest();
					srvcRqst.setServiceNme(BaseConstants.API_SERVICES.DXL_CUSTOMER_LOOKUP);
					srvcRqst.setCstmrLookupReq(processorInput);
	
					EcomCustomerLookupProcessor processor = new EcomCustomerLookupProcessor(srvcRqst);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();
						
					if (srvcResp != null) {
						if (srvcResp.getCstmrLookupResp()!= null) {
							FLogger.debug(logger, THIS_CLASS, methodName,"Got Reponse from the API ");
									
							response = new EcomCustomerLookupResp();
							response = srvcResp.getCstmrLookupResp();
	
						}else {
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
	
							response = new EcomCustomerLookupResp();
							response.setCustomerLoopkupDetails(null);
							response.setResponseStatus(respStts);
						}
					} else {
						FLogger.error(logger, THIS_CLASS, methodName, "service response is null");
	
						respStts = RsValiatorResponse.errorResponse(null,BaseConstants.errorInProcessingReq);
	
						response = new EcomCustomerLookupResp();
						response.setCustomerLoopkupDetails(null);
						response.setResponseStatus(respStts);
					}
				}else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
						
					response = new EcomCustomerLookupResp();
					response.setCustomerLoopkupDetails(null);
					response.setResponseStatus(respStts);
					
					FLogger.debug(logger, THIS_CLASS, methodName, "Returning response: "+StringChecks.convertObjectToJson(response));
				}
					
			}else {
				FLogger.error(logger, THIS_CLASS, methodName, "processorInput is Null");
	
				respStts = RsValiatorResponse.errorResponse(null,BaseConstants.errorInProcessingReq);
	
				response = new EcomCustomerLookupResp();
				response.setCustomerLoopkupDetails(null);
				response.setResponseStatus(respStts);
	
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = RsValiatorResponse.errorResponse(null,BaseConstants.errorInProcessingReq);
					
			response = new EcomCustomerLookupResp();
			response.setCustomerLoopkupDetails(null);
			response.setResponseStatus(respStts);
					
		} finally {
					
			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName, "Exiting Method " + methodName );
			}
					
			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		}
		
		return response;
		}
	
	/**
	 * 
	 * @param processorInput
	 * @return
	 */
	public static MrchntRespStts validateInputs(EcomCustomerLookupReq request){

	    String methodNme = "validateInputs";
	    MrchntRespStts respStts = null;
	
	    FLogger.info(logger, THIS_CLASS, methodNme, "Entered Method " + methodNme);
	    try {
	    	if(request==null) {
	    		respStts=RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
	    		return respStts;
	    	}
		    
	    	if(!(StringChecks.checkMsisdn(request.getMsisdn()))) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Msisdn is not valid");
				return respStts;
			}
	    	
	    	if(!StringChecks.isFieldEmpty(request.getCircleId())) {
	    		respStts = RsValiatorResponse.checkCircleResponse(request.getCircleId(),null);
		    	if(respStts!=null) {
		    		return respStts;
		    	}
	    	}

	    	if(!StringChecks.isFieldEmpty(request.getSubscriberType())) {
	    		if(!(request.getSubscriberType().equalsIgnoreCase("PREPAID") || request.getSubscriberType().equalsIgnoreCase("POSTPAID")) ) {
	    			respStts = RsValiatorResponse.invalidParamsResponse(null, "not a valid SubscriberType");
	    			return respStts;
	    		}
	    	}
	    	if(!StringChecks.isFieldEmpty(request.getProvider())) {
	    		if(!(request.getProvider().equalsIgnoreCase("VODAFONE") || request.getProvider().equalsIgnoreCase("IDEA")) ) {
	    			respStts = RsValiatorResponse.invalidParamsResponse(null, "not a valid Provider");
	    			return respStts;
	    		}
	    	}
	    	
	    	 
	    } catch(Exception e) {
	    	StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodNme);
	    } finally {
			FLogger.debug(logger, THIS_CLASS, methodNme, "Exiting: "+methodNme);
		}
	    return respStts;
	}
}
