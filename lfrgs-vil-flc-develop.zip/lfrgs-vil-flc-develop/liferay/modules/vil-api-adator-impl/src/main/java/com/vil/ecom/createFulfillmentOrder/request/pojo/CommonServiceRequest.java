
package com.vil.ecom.createFulfillmentOrder.request.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "partner_id",
    "channel",
    "request_id",
    "service_name"
})
public class CommonServiceRequest implements Serializable
{

    @JsonProperty("partner_id")
    private String partnerId;
    @JsonProperty("channel")
    private String channel;
    @JsonProperty("request_id")
    private String requestId;
    @JsonProperty("service_name")
    private String serviceName;
    private final static long serialVersionUID = 5559111578480125882L;

    @JsonProperty("partner_id")
    public String getPartnerId() {
        return partnerId;
    }

    @JsonProperty("partner_id")
    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    @JsonProperty("channel")
    public String getChannel() {
        return channel;
    }

    @JsonProperty("channel")
    public void setChannel(String channel) {
        this.channel = channel;
    }

    @JsonProperty("request_id")
    public String getRequestId() {
        return requestId;
    }

    @JsonProperty("request_id")
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    @JsonProperty("service_name")
    public String getServiceName() {
        return serviceName;
    }

    @JsonProperty("service_name")
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

}
