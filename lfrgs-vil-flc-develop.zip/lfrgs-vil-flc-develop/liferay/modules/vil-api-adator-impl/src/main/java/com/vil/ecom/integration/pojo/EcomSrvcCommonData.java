package com.vil.ecom.integration.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class EcomSrvcCommonData implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String msisdn;
	
	private String requestId;

	private String circleId;
	
	private String chnnlId;
	
	private String serviceNme;
	
	private String srNo;

	@JsonIgnore
	@JsonInclude(Include.NON_NULL)
	protected String refresh = null;  //OPTIONAL :  if 0 or null --> default (can be fetched from Cache), 1 --> FETCH from Backend not from Cache
	
	@JsonIgnore
	@JsonInclude(Include.NON_NULL)
	protected String key = null;		//this can be the unique Data Entity for which the request is being sent. eg. msisdn, empID, etc
	
	@JsonIgnore
	@JsonInclude(Include.NON_EMPTY)
	protected String isWrite = null ;  //  1--> write . write is used to evict cache entries 
	
	public String getIsWrite() {
		return isWrite ;
	}

	public void setIsWrite(String isWrite) {
		this.isWrite = ( (null!=isWrite) && "1".equals(isWrite)) ? "1" : null ; 
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
	public String getRefresh() {
		return refresh;
	}

	public void setRefresh(String refresh) {
		this.refresh = refresh;
	}

	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the chnnlId
	 */
	public String getChnnlId() {
		return chnnlId;
	}

	/**
	 * @param chnnlId the chnnlId to set
	 */
	public void setChnnlId(String chnnlId) {
		this.chnnlId = chnnlId;
	}

	/**
	 * @return the serviceNme
	 */
	public String getServiceNme() {
		return serviceNme;
	}

	/**
	 * @param serviceNme the serviceNme to set
	 */
	public void setServiceNme(String serviceNme) {
		this.serviceNme = serviceNme;
	}

	/**
	 * @return the srNo
	 */
	public String getSrNo() {
		return srNo;
	}

	/**
	 * @param srNo the srNo to set
	 */
	public void setSrNo(String srNo) {
		this.srNo = srNo;
	}

}
