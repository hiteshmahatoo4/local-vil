package com.vil.ecom.integration.creditInsightsInternalConsent;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ 
	"request_id",
	"score",
	"telco_code" 
})
public class Data implements Serializable {

	@JsonProperty("request_id")
	private int requestId;
	@JsonProperty("score") 
	private String score; 
	@JsonProperty("telco_code")
	private String telcoCode;
	private final static long serialVersionUID = -1245572159996573722L;

	@JsonProperty("request_id")
	public int getRequestId() {
		return requestId;
	}

	@JsonProperty("request_id")
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	@JsonProperty("score")
	public String getScore() {
		return score;
	}

	@JsonProperty("score")
	public void setScore(String score) {
		this.score = score;
	}

	@JsonProperty("telco_code")
	public String getTelcoCode() {
		return telcoCode;
	}

	@JsonProperty("telco_code")
	public void setTelcoCode(String telcoCode) {
		this.telcoCode = telcoCode;
	}

}
