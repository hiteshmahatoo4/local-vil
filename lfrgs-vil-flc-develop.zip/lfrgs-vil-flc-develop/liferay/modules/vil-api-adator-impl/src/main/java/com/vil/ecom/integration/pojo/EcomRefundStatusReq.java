package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class EcomRefundStatusReq implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String circleId;
	
	private String pgOrderId;
	
	private String provider;
	
	private String subscriptionType;

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the pgOrderId
	 */
	public String getPgOrderId() {
		return pgOrderId;
	}

	/**
	 * @param pgOrderId the pgOrderId (DXL orderId) to set
	 */
	public void setPgOrderId(String pgOrderId) {
		this.pgOrderId = pgOrderId;
	}

	/**
	 * @return the provider
	 */
	public String getProvider() {
		return provider;
	}

	/**
	 * @param provider the provider (VODAFONE / IDEA) to set
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}

	/**
	 * @return the subscriptionType
	 */
	public String getSubscriptionType() {
		return subscriptionType;
	}

	/**
	 * @param subscriptionType the subscriptionType (PREPAID / POSTPAID) to set
	 */
	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}
	
	
	
	

}
