package com.vil.ecom.integration.processor;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.vil.ecom.adaptors.http.RestUtilVo;
import com.vil.ecom.adaptors.http.RestUtility;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.fulfillmentOrderSttsQuery.request.EcomFulfillmentOrderSttsQueryReq;
import com.vil.ecom.fulfillmentOrderSttsQuery.response.EcomFulfillmentOrderSttsQueryResp;
import com.vil.ecom.fulfillmentOrderSttsQuery.response.ResponseStts;
import com.vil.ecom.integration.config.AppServiceProcessor;
import com.vil.ecom.integration.helper.EcomHelper;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntLogVO;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.logger.srvc.EcomMrchntLogHelper;
import com.vil.ecom.service.EcomIntegrationUtils;
import com.vil.ecom.service.EcomSrvcConfigCnstntsServiceImpl;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EcomFulfillmentOrderSttsQueryProcessor implements AppServiceProcessor {

	private static final String THIS_CLASS = EcomFulfillmentOrderSttsQueryProcessor.class.toString();
	private static final Log logger = LogFactoryUtil.getLog(EcomFulfillmentOrderSttsQueryProcessor.class);

	private EcomMrchntServiceRequest srvcRequest;
	private EcomMrchntServiceResponse srvcResponse;

	private EcomFulfillmentOrderSttsQueryReq apiReq;
	private EcomFulfillmentOrderSttsQueryResp apiResp;

	/** Map consisting API specific configurations stored in DB. */
	private Map<String, Object> confMap;

	/** Map consisting of unique Partner specific configuration stored in DB */
	private Map<String, Object> partnerConfMap;

	/** Map consisting Url response received after connecting to 3rd party api. */
	private Map<String, String> urlResponseMap;

	/** API Name for which processor is implemented. */
	private String serviceNme;

	/** Pojo for logging of API request and response. */
	private EcomMrchntLogVO logVO;

	/** Pojo for logging AuditID */
	Long auditId = null;

	public EcomFulfillmentOrderSttsQueryProcessor(EcomMrchntServiceRequest srvcRequest) {
		this.srvcRequest = srvcRequest;
	}

	public void preSrvcInputProcessor() {

		String thisMethod = "preSrvcInputProcessor";
		try {

			if (srvcRequest != null) {

				if (RequestResourceThreadLocal.getModuleNmeForCurrentThread() == null) {
					RequestResourceThreadLocal.addModuleNmeForCurrentThread("api-adaptor");
				}

				serviceNme = srvcRequest.getServiceNme();

				apiReq = srvcRequest.getFulfillmentOrderSttsQueryReq();

				if (apiReq != null) {
					confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap(srvcRequest.getServiceNme());
					
					
					/**
					 * partner service name for particular partnerId is in format of baseServiceName_partnerId (EAI_FulfillmentOrderSttsQuery_partnerId)
					 */

					String partnerSrvcNme = String.format("%s_%s", srvcRequest.getServiceNme(),
							apiReq.getRequestMessage().getCommonServiceRequest().getPartnerId());
					
					/**
					 * 
					 * PartnerConfMap -  The constants which are unique for the particular partnerId are stored in partnerConf Map
					 *                     { Url, AuthToken, UserId, Password, serviceProtocol, Connection and Read Timeout }
					 */

					partnerConfMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap(partnerSrvcNme);

					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"Fetched Service Specific API Configurations for Service " + serviceNme + " | confMap : "
									+ confMap.size());

					FLogger.debug(logger, THIS_CLASS, thisMethod, "Fetched Partner Specific Configurations for Service "
							+ serviceNme + " | partnerConfMap : " + partnerConfMap.size());
				}

			} else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is Null");
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);

		} finally {
			FLogger.debug(logger, THIS_CLASS, thisMethod, "Exiting this method");
		}
	}

	public EcomMrchntServiceResponse execute() {

		String thisMethod = "execute";

		String payload = null;

		String serviceProtocol = null;

		String apiUrl = null;

		int readTimeout = LoggerConstants.NUM_45000;
		int connTimeout = LoggerConstants.NUM_30000;

		String userId = null;
		String password = null;
		String authKey = null;

		boolean proxyFlg = false;
		boolean disableSslValidation = false;
		boolean disableHostNmeVerification = false;

		String trustStorePath = null;
		String trustStorePwd = null;
		String tlsVersion = null;

		String requestedId = null;

		FLogger.debug(logger, THIS_CLASS, thisMethod, "START");

		try {
			/** Formatting Input received into API specific pojo */
			preSrvcInputProcessor();

			
			if (!StringChecks.isMapEmpty(confMap) && !StringChecks.isMapEmpty(partnerConfMap)) {
				FLogger.debug(logger, THIS_CLASS, thisMethod, "confMap fetched -> " + confMap.size());

				FLogger.debug(logger, THIS_CLASS, thisMethod, "partnerConfMap fetched -> " + partnerConfMap.size());

				serviceProtocol = (String) (partnerConfMap.get(BaseConstants.RESTWS.REST_REQ_PROTOCOL));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "serviceProtocol is " + serviceProtocol);

				proxyFlg = Boolean.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_PROXY_FLG));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "proxy Flg is " + proxyFlg);

				/** Unique User Id will be fetched for different partners from partnerConfMap */
				if (partnerConfMap.get(BaseConstants.RESTWS.REST_USR_ID) != null) {

					userId = (String) partnerConfMap.get(BaseConstants.RESTWS.REST_USR_ID);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "userId is " + userId);
				}

				/** Unique User password will be fetched for different partners from partnerConfMap */
				if (partnerConfMap.get(BaseConstants.RESTWS.REST_USR_PSWD) != null) {

					password = (String) partnerConfMap.get(BaseConstants.RESTWS.REST_USR_PSWD);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "password is " + password);
				}
				
				/** Unique AuthToken will be fetched for different partners from partnerConfMap */
				if (partnerConfMap.get(BaseConstants.RESTWS.REST_AUTH_TOKEN) != null) {

					authKey = (String) partnerConfMap.get(BaseConstants.RESTWS.REST_AUTH_TOKEN);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "authKey is " + authKey);
				}

				/** Connection Timeout Value will be fetched for different partners from partnerConfMap */
				if (partnerConfMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT) != null) {
					connTimeout = Integer.parseInt((String) partnerConfMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT));
				}

				/** Read Timeout Value will be fetched for different partners from partnerConfMap */
				if (partnerConfMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT) != null) {
					readTimeout = Integer.parseInt((String) partnerConfMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT));
				}

				/** 
				 * SSL Related properties Start 
				 *  
				 */
				

				if (confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE) != null) {
					disableSslValidation = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY) != null) {
					disableHostNmeVerification = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION) != null) {
					tlsVersion = (String) confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH) != null) {
					trustStorePath = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD) != null) {
					trustStorePwd = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD);
				}

				/** SSL Related properties End */

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"connTimeout is " + connTimeout + " | readTimeout is " + readTimeout
								+ " | disableSslValidation is " + disableSslValidation
								+ " | disableHostNmeVerification is " + disableHostNmeVerification);

				/** 3rd Party API url to which requests needs to be submitted */

				if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTP_PROTOCOL)) {

					apiUrl = (String) (partnerConfMap.get(BaseConstants.RESTWS.REST_HTTP_URL));

				} else if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTPS_PROTOCOL)) {

					apiUrl = (String) (partnerConfMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));

				} else {
					apiUrl = (String) (partnerConfMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));
				}

				FLogger.error(logger, THIS_CLASS, thisMethod, "API URl to Connect : " + apiUrl);
				
				
				/**
				 * Generating API specific payload in Json/XML,
				 * payload is in JSON 
				 */

				payload = StringChecks.convertObjectToJson(apiReq);

				FLogger.info(logger, THIS_CLASS, thisMethod, "Generated payload For API : " + payload);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Request in DB");

				/** logging Request in DB for API before connection */
				logVO = new EcomMrchntLogVO();
				logVO.setRequestType(BaseConstants.RESTWS.REST_OUTWARD_REQ);
				logVO.setServiceNme(srvcRequest.getServiceNme());
				logVO.setSourceIp(StringChecks.fetchLocalIpAddr());
				logVO.setIpAddr(StringChecks.fetchLocalIpAddr());
				logVO.setRequestParams(payload);
				logVO.setFiller6(RequestResourceThreadLocal.getRequestIdForCurrentThread());
				logVO.setFiller4(apiUrl);
				logVO.setFiller3(BaseConstants.APIMODES.HTTP);
				logVO.setRequestTime(Calendar.getInstance().getTime());
				logVO.setMsisdn(apiReq.getRequestMessage().getCommonServiceRequest().getPartnerId());
				logVO.setAmt(apiReq.getRequestMessage().getOrder().getId());
				logVO.setChannelId(apiReq.getRequestMessage().getCommonServiceRequest().getChannel());
				logVO.setRequestId(apiReq.getRequestMessage().getCommonServiceRequest().getRequestId());
				logVO.setFiller1(apiReq.getRequestMessage().getCommonServiceRequest().getServiceName());
				
				String threadId = RequestResourceThreadLocal.getURI(); //unique thread created for each thread to track logs

				if (!StringChecks.isFieldEmpty(threadId)) {
					logVO.setFiller5(threadId);
				}

				if (confMap != null && confMap.get("REST_DUMMY_RESP_FLG") != null
						&& Boolean.parseBoolean((String) confMap.get("REST_DUMMY_RESP_FLG"))) {

					logVO.setFiller2(BaseConstants.API_SERVICES.DUMMY_CALL);
					EcomHelper.errorLog(logger, "Dummy Response Enabled for Service : " + serviceNme);
					urlResponseMap = EcomMrchntLogHelper.populateDummyResp(confMap, serviceNme);

				} else {

					FLogger.info(logger, THIS_CLASS, thisMethod, "No Dummy Response Set.");

					requestedId = apiReq.getRequestMessage().getCommonServiceRequest().getRequestId();

					/** Required Headers to be set here fot the Given API **/
					
					if (StringChecks.isFieldEmpty(requestedId)) {
						requestedId = EcomIntegrationUtils.generateAppId();
						apiReq.getRequestMessage().getCommonServiceRequest().setRequestId(requestedId);
					}

					
					String authToken = String.format("Bearer %s", authKey);

					String core_version = (String) confMap.get(BaseConstants.API_SERVICES.CORE_VERSION);

					HashMap<String, String> headerParameters = new HashMap<>();
					headerParameters.put(HttpHeaders.AUTHORIZATION, authToken);
					headerParameters.put(HttpHeaders.CONTENT_TYPE, "application/json");
					headerParameters.put(BaseConstants.API_SERVICES.CORE_VERSION, core_version);

					/** Calling Url Connection Utility to Connect to API with payload */
					
					RestUtilVo requestVo = new RestUtilVo();
					requestVo.setpURL(apiUrl);
					requestVo.setHeaderParameters(headerParameters);
					requestVo.setPayload(payload);
					requestVo.setUrlParameters(null); // No Form Data needs to be sent in this request so its null.
					requestVo.setConnectionTimeOut(connTimeout);
					requestVo.setConnectReadTimeout(readTimeout);
					requestVo.setDisableHostNmeVerification(disableHostNmeVerification);
					requestVo.setDisableSslValidation(disableSslValidation);
					requestVo.setProxyFlag(proxyFlg);
					requestVo.setTlsVersion(tlsVersion);
					requestVo.setTrustStorePath(trustStorePath);
					requestVo.setTrustStorePwd(trustStorePwd);
					requestVo.setRequestType(BaseConstants.POST_REQUEST);
					requestVo.setServiceNme(srvcRequest.getServiceNme());

					urlResponseMap = RestUtility.doConnectUrl(requestVo);
				}

				parseResponse();
				if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {

					srvcResponse.getResponseStatus().setResponseId(requestedId);
					FLogger.error(logger, THIS_CLASS, thisMethod, "Exiting Method " + thisMethod + " with Stts "
							+ srvcResponse.getResponseStatus().getStatus());
				}
			}
		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod,
					"Exception scenario in processing service : " + serviceNme);

			MrchntRespStts respSts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			/**
			 * Response Status to be set which includes auditId, description and responseStatus
			 */
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setFulfillmentOrderSttsQueryResp(null);
			srvcResponse.setResponseStatus(respSts);   
			
			

		} finally {
			FLogger.error(logger, THIS_CLASS, thisMethod, "Exting this Method");
		}

		return postSrvcOutputProcessor();

	}

	public void parseResponse() {

		String thisMethod = "parseResponse";
		String status = null;
		String respMsg = null;
		String respCde = null;

		String errCde = null;
		String errDesc = null;
		String errStts = null;

		try {

			status = urlResponseMap.get("status");
			respMsg = urlResponseMap.get("respMsg");
			respCde = urlResponseMap.get("respCode");
			

			if (BaseConstants.SUCCESS_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success In API Url Connection");

				apiResp = (EcomFulfillmentOrderSttsQueryResp) StringChecks.convertJsonToObject(respMsg,
						EcomFulfillmentOrderSttsQueryResp.class);

				if (apiResp != null) {

					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Successful API Call :Got UPI Response from API," + " processing Response.");

					errCde = respCde;
					errStts = BaseConstants.STTS_MSG_SUCCESS;
					errDesc = BaseConstants.SUCCESS_MSG;

					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts, errDesc);

					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Response is" + StringChecks.convertObjectToJson(srvcResponse.getFulfillmentOrderSttsQueryResp()));

				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod, "Successful API Connection but no proper response");

					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);

					ResponseStts respStatus = new ResponseStts();
					respStatus.setCode(respStts.getStatusCde());
					respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
					respStatus.setStatus(BaseConstants.FAILURE_MSG);

					apiResp = new EcomFulfillmentOrderSttsQueryResp();
					apiResp.setResponseStatus(respStatus);
					apiResp.setMessage(null);
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);

				}

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(errStts);
				logVO.setRespSttsCde(errCde);
				logVO.setRespSttsDesc(errDesc);

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.FAILURE_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAILED_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Failure Scenario");

				apiResp = (EcomFulfillmentOrderSttsQueryResp) StringChecks.convertJsonToObject(respMsg,
						EcomFulfillmentOrderSttsQueryResp.class);

				if (apiResp != null) {

					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API" + " processing Response.");

					errCde = respCde;
					errStts = BaseConstants.STTS_MSG_FAIL;
					errDesc = BaseConstants.FAILURE_MSG;

					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts, errDesc);

					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Response is" + StringChecks.convertObjectToJson(srvcResponse.getFulfillmentOrderSttsQueryResp()));

				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod, "Failure in Url Connection , Failure scenario.");

					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);

					ResponseStts respStatus = new ResponseStts();
					respStatus.setCode(respStts.getStatusCde());
					respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
					respStatus.setStatus(BaseConstants.FAILURE_MSG);

					apiResp = new EcomFulfillmentOrderSttsQueryResp();
					apiResp.setResponseStatus(respStatus);
					apiResp.setMessage(null);
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);


				}

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(errStts);
				logVO.setRespSttsCde(errCde);
				logVO.setRespSttsDesc(errDesc);

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.TIMEOUT_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "TimeOut Scenario in Url Connection to API");

				apiResp = (EcomFulfillmentOrderSttsQueryResp) StringChecks.convertJsonToObject(respMsg,
						EcomFulfillmentOrderSttsQueryResp.class);

				if (apiResp != null) {

					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");

					errCde = respCde;
					errStts = BaseConstants.TIMEOUT_MSG;
					errDesc = BaseConstants.NO_RESP;

					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts, errDesc);

					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Response is" + StringChecks.convertObjectToJson(srvcResponse.getFulfillmentOrderSttsQueryResp()));

				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod, "Timeout in Url Connection , Failure scenario.");

					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);

					ResponseStts respStatus = new ResponseStts();
					respStatus.setCode(respStts.getStatusCde());
					respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
					respStatus.setStatus(BaseConstants.FAILURE_MSG);
					
					apiResp = new EcomFulfillmentOrderSttsQueryResp();
					apiResp.setResponseStatus(respStatus);
					apiResp.setMessage(null);
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);


				}

				FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");
					
				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());
				
				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);
			
			} else {
				FLogger.error(logger,THIS_CLASS, thisMethod, "Unknown Scenario in Url Connection to API");
				
				apiResp = (EcomFulfillmentOrderSttsQueryResp) StringChecks.convertJsonToObject(respMsg,
						EcomFulfillmentOrderSttsQueryResp.class);
			
				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");

					errCde = BaseConstants.STTS_CODE_FAILURE;
					errStts = BaseConstants.STTS_MSG_FAIL;
					errDesc = BaseConstants.FAILURE_MSG;
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
					
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
			
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);
				
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse.getFulfillmentOrderSttsQueryResp()));
				
				} else {
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"TIMEOUT in Url Connection , Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
					
					ResponseStts respStatus = new ResponseStts();
					respStatus.setCode(respStts.getStatusCde());
					respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
					respStatus.setStatus(BaseConstants.FAILURE_MSG);

					apiResp = new EcomFulfillmentOrderSttsQueryResp();
					apiResp.setResponseStatus(respStatus);
					apiResp.setMessage(null);
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setResponseStatus(respStts);
					srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);

				}
				FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");
				
				logVO.setResponseParams(respMsg);
				logVO.setRespStts(errStts);
				logVO.setRespSttsCde(errCde);
				logVO.setRespSttsDesc(errDesc);
				
				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);
			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);

			MrchntRespStts respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			FLogger.debug(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

			ResponseStts respStatus = new ResponseStts();
			respStatus.setCode(respStts.getStatusCde());
			respStatus.setDescription(BaseConstants.ERR_PROCESSING_REQ);
			respStatus.setStatus(BaseConstants.FAILURE_MSG);
			
			apiResp = new EcomFulfillmentOrderSttsQueryResp();
			
			apiResp.setResponseStatus(respStatus);
			apiResp.setMessage(null);
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setResponseStatus(respStts);
			srvcResponse.setFulfillmentOrderSttsQueryResp(apiResp);


			logVO.setResponseParams(respMsg);
			logVO.setRespStts(errStts);
			logVO.setRespSttsCde(errCde);
			logVO.setRespSttsDesc(errDesc);

		} finally {
			if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {
				srvcResponse.getFulfillmentOrderSttsQueryResp().getResponseStatus().setAuditId(auditId.toString());
				FLogger.debug(logger, THIS_CLASS, thisMethod, "Exiting method: " + thisMethod);
				
				
			}
		}
	}

	public EcomMrchntServiceResponse postSrvcOutputProcessor() {
		FLogger.debug(logger, THIS_CLASS, "postSrvcOutputProcessor", "Returning response: "
				+ StringChecks.convertObjectToJson(srvcResponse.getFulfillmentOrderSttsQueryResp())
				+" | Response status: "+StringChecks.convertObjectToJson(srvcResponse.getResponseStatus()));
		return srvcResponse;
	}

	public static MrchntRespStts parseErrorCode(String serviceNme, Map<String, Object> confMap, String errCde,
			String errStts, String errDesc) {

		MrchntRespStts respStts = null;
		String thisMethod = "parseErrorCode";

		String successCodes = null;
		String pendingSuccessCodes = null;
		String failureCodes = null;

		String status = null;
		String statusDesc = null;

		List<String> successCodesList = new ArrayList<>();
		List<String> pendingSuccessCodesList = new ArrayList<>();
		List<String> failureCodesList = new ArrayList<>();

		try {

			successCodes = (String) confMap.get(BaseConstants.RESTWS.REST_SUCCESS_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "successCodes is " + successCodes);

			pendingSuccessCodes = (String) confMap.get(BaseConstants.RESTWS.REST_PENDING_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "pendingCodes is " + pendingSuccessCodes);

			failureCodes = (String) confMap.get(BaseConstants.RESTWS.REST_FAILURE_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "failureCodes is " + failureCodes);

			if (!StringChecks.isFieldEmpty(successCodes)) {
				successCodesList = Arrays.asList(successCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(pendingSuccessCodes)) {
				pendingSuccessCodesList = Arrays.asList(pendingSuccessCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(failureCodes)) {
				failureCodesList = Arrays.asList(failureCodes.split("[\\|]+"));
			}

			if (successCodesList != null && !successCodesList.contains(errCde)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Non-Success Scenario for Service :: " + serviceNme);

				if (pendingSuccessCodesList != null && pendingSuccessCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Timeout Scenario for " + " as Response Code is : " + errStts + " is timeout code.");

					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				} else if (failureCodesList != null && failureCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"FAILURE Scenario for " + " as Response Code is : " + errStts + " is FAILURE code.");

					status = BaseConstants.FAILED_MSG;

					if (StringChecks.isFieldEmpty(errDesc)) {
						statusDesc = BaseConstants.FAILURE_MSG;
					} else {
						statusDesc = errDesc;
					}
				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Unknown/Deemed-Success Scenario for Service ::" + serviceNme);
					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				}

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success Scenario for Service :: " + serviceNme);
				status = BaseConstants.SUCCESS_MSG;

				if (StringChecks.isFieldEmpty(errDesc)) {
					statusDesc = BaseConstants.SUCCESS_MSG;
				} else {
					statusDesc = errDesc;
				}
			}

			respStts = new MrchntRespStts();
			respStts.setStatus(status);
			respStts.setStatusCde(errCde);
			respStts.setDescription(statusDesc);

		} catch (Exception e) {

		} finally {
			FLogger.debug(logger, THIS_CLASS, thisMethod, "Exiting: " + thisMethod);

		}

		return respStts;
	}

}
