package com.vil.ecom.integration.pojo;

import com.vil.ecom.dxl.processPayment.pojo.ProcessPaymentRespDtls;

import java.io.Serializable;

public class EcomProcessPaymentResp implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
		
	private ProcessPaymentRespDtls processPaymentResponse;

	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	public ProcessPaymentRespDtls getProcessPaymentResponse() {
		return processPaymentResponse;
	}

	public void setProcessPaymentResponse(ProcessPaymentRespDtls processPaymentResponse) {
		this.processPaymentResponse = processPaymentResponse;
	}
	
}
