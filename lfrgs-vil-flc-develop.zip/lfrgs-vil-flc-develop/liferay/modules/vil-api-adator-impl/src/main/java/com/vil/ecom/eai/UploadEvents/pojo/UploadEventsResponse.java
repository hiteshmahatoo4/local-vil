
package com.vil.ecom.eai.UploadEvents.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "status",
    "processed",
    "unprocessed",
    "error",
    "code"
})

public class UploadEventsResponse implements Serializable
{

    @JsonProperty("status")
    private String status;
    @JsonProperty("processed")
    private String processed;
    @JsonProperty("unprocessed")
    private List<Unprocessed> unprocessed;
    @JsonProperty("error")
    private String error;
    @JsonProperty("code")
    private Integer code;
    private final static long serialVersionUID = -342039898380512728L;

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("processed")
    public String getProcessed() {
        return processed;
    }

    @JsonProperty("processed")
    public void setProcessed(String processed) {
        this.processed = processed;
    }

    @JsonProperty("unprocessed")
    public List<Unprocessed> getUnprocessed() {
        return unprocessed;
    }

    @JsonProperty("unprocessed")
    public void setUnprocessed(List<Unprocessed> unprocessed) {
        this.unprocessed = unprocessed;
    }

    @JsonProperty("error")
    public String getError() {
        return error;
    }

    @JsonProperty("error")
    public void setError(String error) {
        this.error = error;
    }

    @JsonProperty("code")
    public Integer getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(Integer code) {
        this.code = code;
    }

}
