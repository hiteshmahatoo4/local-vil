package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.StringChecks;


import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;


public class AESEncryptionUtility {

	private static final String ALGORITHM = "AES";
	//private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
	private static final String TRANSFORMATION = "AES/GCM/NoPadding";
	private static final int GCM_IV_LENGTH = 12;
	private static final int GCM_TAG_LENGTH = 16; 
	private static final Log logger = LogFactoryUtil.getLog(AESEncryptionUtility.class);
	private static final String THIS_CLASS = AESEncryptionUtility.class.toString();

	private static SecretKeySpec secretKey;
	private static byte[] key;

	public static void setKey(String myKey) {
		
		String thisMethod = "setKey";
		MessageDigest sha = null;
		
		try {
			key = myKey.getBytes("UTF-8");
			sha = MessageDigest.getInstance("SHA-1");  //NOSONAR
			key = sha.digest(key);
			key = Arrays.copyOf(key, LoggerConstants.NUM_16);
			secretKey = new SecretKeySpec(key, ALGORITHM);
		} catch (NoSuchAlgorithmException e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		} catch (UnsupportedEncodingException e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}
	}

	public static String encrypt(String strToEncrypt, String secret) {
		
		String thisMethod = "encrypt";
		
		try {
			setKey(secret);
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			byte[] IV = new byte[GCM_IV_LENGTH];
			GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV); 
			cipher.init(Cipher.ENCRYPT_MODE, secretKey,gcmParameterSpec);
			return Base64.encodeBase64String(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod, "Error while encrypting");
		}
		return null;
	}

	public static String decrypt(String strToDecrypt, String secret) {
		
		String thisMethod = "encrypt";
		
		try {
			setKey(secret);
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			byte[] IV = new byte[GCM_IV_LENGTH];
			GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV); 
			cipher.init(Cipher.DECRYPT_MODE, secretKey,gcmParameterSpec);
			return new String(cipher.doFinal(Base64.decodeBase64(strToDecrypt)));
			
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod, "Error while decrypting");
		}
		return null;
	}

	public static void main(String[] args) {
		
		final String secretKey = "TVFhMdk268s7DPnQ";

		String originalString = "PRE1770756655083299|MARKETPLACE|100.00";
		String encryptedString = AESEncryptionUtility.encrypt(originalString, secretKey);
		String decryptedString = AESEncryptionUtility.decrypt(encryptedString, secretKey);

		System.out.println(originalString);
		System.out.println(encryptedString);
		System.out.println(decryptedString);
		
	}
}
