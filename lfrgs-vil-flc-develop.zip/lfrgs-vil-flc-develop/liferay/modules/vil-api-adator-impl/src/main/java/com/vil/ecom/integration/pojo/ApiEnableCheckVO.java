/**
 * 
 */
package com.vil.ecom.integration.pojo;

import java.io.Serializable;

/**
 * @author 365353
 *
 */
public class ApiEnableCheckVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String apiNme;
	
	private String circleId;
	
	private boolean apiCheckerFlg;

	/**
	 * @return the apiNme
	 */
	public String getApiNme() {
		return apiNme;
	}

	/**
	 * @param apiNme the apiNme to set
	 */
	public void setApiNme(String apiNme) {
		this.apiNme = apiNme;
	}

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the apiCheckerFlg
	 */
	public boolean isApiCheckerFlg() {
		return apiCheckerFlg;
	}

	/**
	 * @param apiCheckerFlg the apiCheckerFlg to set
	 */
	public void setApiCheckerFlg(boolean apiCheckerFlg) {
		this.apiCheckerFlg = apiCheckerFlg;
	}

	public ApiEnableCheckVO() {
		super();
	}

	public ApiEnableCheckVO(String apiNme, String circleId, boolean apiCheckerFlg) {
		super();
		this.apiNme = apiNme;
		this.circleId = circleId;
		this.apiCheckerFlg = apiCheckerFlg;
	}
	
}
