
package com.vil.ecom.eai.CreateConsentRequest.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "vil",
    "airtel"
})
public class RequestedMsisdns {

    @JsonProperty("vil")
    private String vil;
    @JsonProperty("airtel")
    private String airtel;
    
    @JsonProperty("vil")
    public String getVil() {
        return vil;
    }

    @JsonProperty("vil")
    public void setVil(String vil) {
        this.vil = vil;
    }

    @JsonProperty("airtel")
    public String getAirtel() {
        return airtel;
    }

    @JsonProperty("airtel")
    public void setAirtel(String airtel) {
        this.airtel = airtel;
    }


}
