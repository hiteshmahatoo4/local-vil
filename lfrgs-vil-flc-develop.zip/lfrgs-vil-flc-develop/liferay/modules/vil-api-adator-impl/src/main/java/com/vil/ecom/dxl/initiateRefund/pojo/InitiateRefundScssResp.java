package com.vil.ecom.dxl.initiateRefund.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Message"
})
public class InitiateRefundScssResp {
	
	@JsonProperty("Message")
	private String Message;

	@JsonProperty("Message")
	public String getMessage() {
		return Message;
	}

	@JsonProperty("Message")
	public void setMessage(String message) {
		Message = message;
	}
	

}
