package com.vil.ecom.integration.processor;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.adaptors.http.RestUtilVo;
import com.vil.ecom.adaptors.http.RestUtility;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.config.AppServiceProcessor;
import com.vil.ecom.integration.creditInsightsInternalConsent.CreditInsightsInternalConsentRequest;
import com.vil.ecom.integration.creditInsightsInternalConsent.CreditInsightsInternalConsentRespDtls;
import com.vil.ecom.integration.creditInsightsInternalConsent.CreditInsightsInternalConsentResponse;
import com.vil.ecom.integration.creditInsightsInternalConsent.RequestedMsisdns;
import com.vil.ecom.integration.helper.EcomHelper;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomCreditInsightsInternalConsentReq;
import com.vil.ecom.integration.pojo.EcomCreditInsightsInternalConsentResp;
import com.vil.ecom.integration.pojo.EcomCreditInsightsLoginResp;
import com.vil.ecom.integration.pojo.EcomMrchntLogVO;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.logger.srvc.EcomMrchntLogHelper;
import com.vil.ecom.service.EcomCreditInsightsLoginUtil;
import com.vil.ecom.service.EcomIntegrationUtils;
import com.vil.ecom.service.EcomSrvcConfigCnstntsServiceImpl;
import com.vil.ecom.utilities.EncDecutil;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.HttpHeaders;

public class EcomCreditInsightsInternalConsentProcessor implements AppServiceProcessor {

	private static final String THIS_CLASS = EcomCreditInsightsInternalConsentProcessor.class.toString();
	private static final Log logger = LogFactoryUtil.getLog(EcomCreditInsightsInternalConsentProcessor.class);

	/** Processor input and output pojo. */
	private EcomMrchntServiceRequest srvcRequest;
	private EcomMrchntServiceResponse srvcResponse;

	/**
	 * Application defined Inputs and output Pojo for given API which will be used
	 * by calling party.
	 */
	private EcomCreditInsightsInternalConsentReq request;
	private EcomCreditInsightsInternalConsentResp response;

	/**
	 * API request and response which needs to be sent/Received to/from 3rd party
	 * API Call.
	 */
	private CreditInsightsInternalConsentRequest apiReq;
	private CreditInsightsInternalConsentResponse apiResp;

	/** Map consisting API specific configurations stored in DB. */
	private Map<String, Object> confMap;

	/** Map consisting Url response received after connecting to 3rd party api. */
	private Map<String, String> urlResponseMap;

	/** API Name for which processor is implemented. */
	private String serviceNme;

	/** Pojo for logging of API request and response. */
	private EcomMrchntLogVO logVO;

	private Long auditId = null;

	public EcomCreditInsightsInternalConsentProcessor(EcomMrchntServiceRequest srvcRequest) {
		this.srvcRequest = srvcRequest;
	}

	@Override
	public void preSrvcInputProcessor() {

		String thisMethod = "preSrvcInputProcessor";
		
		try {
			
			FLogger.info(logger, THIS_CLASS, thisMethod, "Entered : "+thisMethod);
			
			if(srvcRequest !=null && srvcRequest.getCreditInsightsInternalConsentReq()!=null) {
				
				if(RequestResourceThreadLocal.getModuleNmeForCurrentThread()==null) {
					RequestResourceThreadLocal.addModuleNmeForCurrentThread("api-adaptor");
				}
				
				request = srvcRequest.getCreditInsightsInternalConsentReq();
				serviceNme = srvcRequest.getServiceNme();
				
				if(request != null) {
					confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap(srvcRequest.getServiceNme());
	
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"Fetched Service Specific API Configurations for Service " + serviceNme + " | confMap : "
									+ confMap.size());
	
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"Populating API Specific Request Object for Service " + serviceNme);
					
					
					
					String clientCode = (String)confMap.get(BaseConstants.RESTWS.REST_CLIENT_CODE);
					if(clientCode!=null) {
						
						RequestedMsisdns msisdns=new RequestedMsisdns();
						
						/*
						 * Requested msisdns are encrypted for the transaction
						 * 
						 * */
						
						String publicKeyPath = (String) confMap.get(BaseConstants.RESTWS.REST_ENC_PUBLIC_KEY);
						
						msisdns.setAirtel((!StringChecks.isFieldEmpty(request.getAirtelMsisdn()))?EncDecutil.EncryptDecrypt(request.getAirtelMsisdn(), publicKeyPath, BaseConstants.ENCRYPT):null);
						msisdns.setVil((!StringChecks.isFieldEmpty(request.getVilMsisdn()))?EncDecutil.EncryptDecrypt(request.getVilMsisdn(), publicKeyPath, BaseConstants.ENCRYPT):null);
						
						
						apiReq = new CreditInsightsInternalConsentRequest();
						apiReq.setClientCode(clientCode);
						apiReq.setRequestedMsisdns(msisdns);
						FLogger.error(logger, THIS_CLASS, thisMethod,"API Request set with Client Code : "+clientCode);
					}else {
						FLogger.error(logger, THIS_CLASS, thisMethod, "ClientCode constant not set in dB");
					}
					
					
				}else {
					FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is null");
				}
			}else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is null");
			}
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}		
	}
	
	@Override
	public EcomMrchntServiceResponse execute() {

		String thisMethod = "execute";

		String payload = null;

		MrchntRespStts respStts = null;

		String serviceProtocol = null;

		String apiUrl = null;

		int readTimeout = LoggerConstants.NUM_45000;
		int connTimeout = LoggerConstants.NUM_30000;

		String userId = null;
		String password = null;
		String authKey = null;

		boolean proxyFlg = false;
		boolean disableSslValidation = false;
		boolean disableHostNmeVerification = false;

		String trustStorePath = null;
		String trustStorePwd = null;
		String tlsVersion = null;

		String applicationRequestId = null;

		try {

			/** Formatting Input received into API specific pojo */
			preSrvcInputProcessor();

			/**
			 * Checking if input Object is not null and configurations are fetched from DB
			 * for given Service
			 */
			if (!StringChecks.isMapEmpty(confMap)) {

				FLogger.debug(logger, THIS_CLASS, thisMethod, "confMap fetched -> " + confMap.size());

				serviceProtocol = (String) (confMap.get(BaseConstants.RESTWS.REST_REQ_PROTOCOL));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "serviceProtocol is " + serviceProtocol);

				proxyFlg = Boolean.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_PROXY_FLG));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "proxy Flg is " + proxyFlg);

				if (confMap.get(BaseConstants.RESTWS.REST_USR_ID) != null) {

					userId = (String) confMap.get(BaseConstants.RESTWS.REST_USR_ID);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "userId is " + userId);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_USR_PSWD) != null) {

					password = (String) confMap.get(BaseConstants.RESTWS.REST_USR_PSWD);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "password is " + password);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY) != null) {

					authKey = (String) confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "authKey is " + authKey);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT) != null) {
					connTimeout = Integer.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT) != null) {
					readTimeout = Integer.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT));
				}

				/** SSL Related properties Start */
				if (confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE) != null) {
					disableSslValidation = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY) != null) {
					disableHostNmeVerification = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION) != null) {
					tlsVersion = (String) confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH) != null) {
					trustStorePath = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD) != null) {
					trustStorePwd = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD);
				}

				/** SSL Related properties End */

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"connTimeout is " + connTimeout + " | readTimeout is " + readTimeout
								+ " | disableSslValidation is " + disableSslValidation
								+ " | disableHostNmeVerification is " + disableHostNmeVerification);

				/** 3rd Party API url to which requests needs to be submitted */
				if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTP_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTP_URL));

				} else if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTPS_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));

				} else {
					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));
				}

				FLogger.error(logger, THIS_CLASS, thisMethod, "API URl to Connect : " + apiUrl);
				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Request in DB");

				/**
				 * Generating API specific payload in Json/XML Here as its Soap Web Service,
				 * payload is in XML
				 */

				payload = StringChecks.convertObjectToJson(apiReq);

				FLogger.debug(logger, THIS_CLASS, thisMethod, "Generated payload For API : " + payload);
				applicationRequestId = EcomIntegrationUtils.generateAppId();

				/** logging Request in DB for API before connection */
				logVO = new EcomMrchntLogVO();
				logVO.setServiceNme(srvcRequest.getServiceNme());
				logVO.setSourceIp(StringChecks.fetchLocalIpAddr());
				logVO.setIpAddr(StringChecks.fetchLocalIpAddr());
				logVO.setRequestParams(payload);
				logVO.setRequestType(BaseConstants.RESTWS.REST_OUTWARD_REQ);
				logVO.setFiller6(RequestResourceThreadLocal.getRequestIdForCurrentThread());
				logVO.setRequestTime(Calendar.getInstance().getTime());
				logVO.setFiller4(apiUrl);
				logVO.setFiller3(BaseConstants.APIMODES.HTTP);

				String threadId = RequestResourceThreadLocal.getURI(); // Unique Thread ID generated for each processor
				// request, used for tracking logs.

				if (!StringChecks.isFieldEmpty(threadId)) {
					logVO.setFiller5(threadId);
				}

				/**
				 * Header if any needs to be sent during API Url Connection For Web Service API
				 * call, Content-type needs to be set as text/xml For Rest API Calls,
				 * Content-type will be application/json or application/x-www-url-encoded as per
				 * API IDD document
				 */

				if (confMap != null && confMap.get("REST_DUMMY_RESP_FLG") != null
						&& Boolean.parseBoolean((String) confMap.get("REST_DUMMY_RESP_FLG"))) {

					logVO.setFiller2(BaseConstants.API_SERVICES.DUMMY_CALL);
					EcomHelper.errorLog(logger, "Dummy Response Enabled for Service : " + serviceNme);
					urlResponseMap = EcomMrchntLogHelper.populateDummyResp(confMap, serviceNme);

				} else {

					FLogger.info(logger, THIS_CLASS, thisMethod, "No Dummy Response Set.");

					applicationRequestId = EcomIntegrationUtils.generateAppId();
					EcomCreditInsightsLoginResp ecomCreditInsightsLoginResp = EcomCreditInsightsLoginUtil
							.creditInsightLogin();
					String accessToken = ecomCreditInsightsLoginResp.getCreditInsightsLoginResponse().getAccessToken();
					
					if (accessToken != null ) {
						
						String token = String.format("Bearer %s", accessToken);
						
						
						HashMap<String, String> headerParameters = new HashMap<>();
						headerParameters.put(HttpHeaders.CONTENT_TYPE, "application/json");
						headerParameters.put(HttpHeaders.AUTHORIZATION, token);
						headerParameters.put("X-REQUEST-ID", applicationRequestId);
						
					/** Calling Url Connection Utility to Connect to API url with given payload */
						RestUtilVo requestVo = new RestUtilVo();
						requestVo.setpURL(apiUrl);
						requestVo.setHeaderParameters(headerParameters);
						requestVo.setPayload(payload);
						requestVo.setUrlParameters(null); // No Form Data needs to be sent in this request so its null.
						requestVo.setConnectionTimeOut(connTimeout);
						requestVo.setConnectReadTimeout(readTimeout);
						requestVo.setDisableHostNmeVerification(disableHostNmeVerification);
						requestVo.setDisableSslValidation(disableSslValidation);
						requestVo.setProxyFlag(proxyFlg);
						requestVo.setTlsVersion(tlsVersion);
						requestVo.setTrustStorePath(trustStorePath);
						requestVo.setTrustStorePwd(trustStorePwd);
						requestVo.setRequestType(BaseConstants.POST_REQUEST);
						requestVo.setServiceNme(srvcRequest.getServiceNme());
	
						FLogger.error(logger, THIS_CLASS, thisMethod,
								"Calling HTTP client for the servicename : " + serviceNme);
						urlResponseMap = RestUtility.doConnectUrl(requestVo);
					}
					else {
						FLogger.error(logger, THIS_CLASS, thisMethod, "Access token is not present");
					}

				}

				/** Parse Response Received in Url Connection From API */
				parseResponse();
				if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {
					srvcResponse.getResponseStatus().setResponseId(applicationRequestId);
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Exiting Method " + thisMethod + " with Stts "
									+ (srvcResponse.getResponseStatus() != null
											? srvcResponse.getResponseStatus().getStatus()
											: ""));
				}
			}

			else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "No Configurations Fetched, No Processing");
			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod,
					"Exception scenario in processing service : " + serviceNme);

			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			

			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setCreditInsightsInternalConsentResp(null);
			srvcResponse.setResponseStatus(respStts);

		}

		return postSrvcOutputProcessor();

	}

	@Override
	public EcomMrchntServiceResponse postSrvcOutputProcessor() {

		FLogger.error(logger, THIS_CLASS, "postSrvcOutputProcessor", "Returning response: "+StringChecks.convertObjectToJson(srvcResponse.getCreditInsightsInternalConsentResp()));
		return srvcResponse;

	}

	@Override
	public void parseResponse() {

		String thisMethod = "parseResponse";
		String status = null;
		String respMsg = null;

		String errCde = null;
		String errDesc = null;
		String errStts = null;

		try {

			status = urlResponseMap.get("status");
			respMsg = urlResponseMap.get("respMsg");
			String respCde = urlResponseMap.get("respCode");

			if (BaseConstants.SUCCESS_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success In API Url Connection");

				apiResp = (CreditInsightsInternalConsentResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsInternalConsentResponse.class);

				FLogger.info(logger, THIS_CLASS, thisMethod,
						"Successful API Call :Got UPI Response from API," + " processing Response.");

				errCde = respCde;
				errStts = BaseConstants.STTS_MSG_SUCCESS;
				errDesc = BaseConstants.SUCCESS_MSG;

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, errDesc);

				response = new EcomCreditInsightsInternalConsentResp();
				response.setInternalConsentDetails(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsInternalConsentResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.ERROR_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAILED_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAILURE_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Failure Scenario in Url Connection to API");

				apiResp = (CreditInsightsInternalConsentResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsInternalConsentResponse.class);

				errCde = respCde;
				errStts = BaseConstants.STTS_MSG_FAIL;
				errDesc = BaseConstants.FAILURE_MSG;

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, errDesc);

				response = new EcomCreditInsightsInternalConsentResp();
				response.setInternalConsentDetails(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsInternalConsentResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.TIMEOUT_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "TimeOut Scenario in Url Connection to API");

				apiResp = (CreditInsightsInternalConsentResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsInternalConsentResponse.class);

				errCde = respCde;
				errStts = BaseConstants.STTS_MSG_FAIL;
				errDesc = BaseConstants.FAILURE_MSG;

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, errDesc);

				response = new EcomCreditInsightsInternalConsentResp();
				response.setInternalConsentDetails(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsInternalConsentResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Unknown Scenario in Url Connection to API");

				apiResp = (CreditInsightsInternalConsentResponse) StringChecks.convertJsonToObject(respMsg,
						CreditInsightsInternalConsentResponse.class);

				errCde = BaseConstants.STTS_CODE_FAILURE;
				errStts = BaseConstants.STTS_MSG_FAIL;
				errDesc = BaseConstants.FAILURE_MSG;
				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);

				MrchntRespStts respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, errDesc);

				response = new EcomCreditInsightsInternalConsentResp();
				response.setInternalConsentDetails(transformResponse(apiResp));
				response.setResponseStatus(respStts);

				srvcResponse = new EcomMrchntServiceResponse();
				srvcResponse.setCreditInsightsInternalConsentResp(response);
				srvcResponse.setResponseStatus(respStts);

				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);

			MrchntRespStts respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
	
			response = new EcomCreditInsightsInternalConsentResp();
			response.setResponseStatus(respStts);

			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setCreditInsightsInternalConsentResp(response);
			srvcResponse.setResponseStatus(respStts);

			logVO.setResponseParams(respMsg);
			logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
			logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
			logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());
			auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

		} finally {

			if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {
				srvcResponse.getResponseStatus().setAuditId(auditId);
			}
			FLogger.info(logger, THIS_CLASS, thisMethod, "auditId:  " + auditId);
		}

	}

	public CreditInsightsInternalConsentRespDtls transformResponse(CreditInsightsInternalConsentResponse response) {

		String thisMethod = "transformResponse";
		CreditInsightsInternalConsentRespDtls respDtls = null;

		FLogger.debug(logger, THIS_CLASS, thisMethod, "Entered: " + thisMethod);

		try {

			if (response != null) {
				respDtls = new CreditInsightsInternalConsentRespDtls();
				
				/*
				 * Credit Score Encryption
				 * 
				 * */
				
				String privateKeyPath = (String) confMap.get(BaseConstants.RESTWS.REST_ENC_PRIVATE_KEY);
				response.setCreditScore((!StringChecks.isFieldEmpty(response.getCreditScore()))?EncDecutil.EncryptDecrypt(response.getCreditScore(), privateKeyPath, BaseConstants.DECRYPT):null);

				respDtls.setRequestId(response.getRequestId());
				respDtls.setCreditScore(response.getCreditScore());
				respDtls.setTelcoCode(response.getTelcoCode());
				respDtls.setMessage(response.getMessage());
				respDtls.setTime(response.getTime());
				respDtls.setVerdict(response.getVerdict());

			} else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "Response Object is null");
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}

		return respDtls;
	}

	/**
	 * @param serviceNme
	 * @param confMap
	 * @param errCde
	 * @param errStts
	 * @param errDesc
	 * @return
	 */
	public static MrchntRespStts parseErrorCode(String serviceNme, Map<String, Object> confMap, String errCde,
			String errStts, String errDesc) {

		MrchntRespStts respStts = null;
		String thisMethod = "parseErrorCode";

		String successCodes = null;
		String pendingSuccessCodes = null;
		String failureCodes = null;

		String status = null;
		String statusDesc = null;

		List<String> successCodesList = new ArrayList<>();
		List<String> pendingSuccessCodesList = new ArrayList<>();
		List<String> failureCodesList = new ArrayList<>();

		try {

			successCodes = (String) confMap.get(BaseConstants.RESTWS.REST_SUCCESS_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "successCodes is " + successCodes);

			pendingSuccessCodes = (String) confMap.get(BaseConstants.RESTWS.REST_PENDING_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "pendingCodes is " + pendingSuccessCodes);

			failureCodes = (String) confMap.get(BaseConstants.RESTWS.REST_FAILURE_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "failureCodes is " + failureCodes);

			if (!StringChecks.isFieldEmpty(successCodes)) {
				successCodesList = Arrays.asList(successCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(pendingSuccessCodes)) {
				pendingSuccessCodesList = Arrays.asList(pendingSuccessCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(failureCodes)) {
				failureCodesList = Arrays.asList(failureCodes.split("[\\|]+"));
			}

			if (successCodesList != null && !successCodesList.contains(errStts)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Non-Success Scenario for Service :: " + serviceNme);

				if (pendingSuccessCodesList != null && pendingSuccessCodesList.contains(errStts)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Timeout Scenario for " + " as Response Code is : " + errStts + " is timeout code.");

					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				} else if (failureCodesList != null && failureCodesList.contains(errStts)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"FAILURE Scenario for " + " as Response Code is : " + errStts + " is FAILURE code.");

					status = BaseConstants.FAILED_MSG;

					if (StringChecks.isFieldEmpty(errDesc)) {
						statusDesc = BaseConstants.FAILURE_MSG;
					} else {
						statusDesc = errDesc;
					}
				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Unknown/Deemed-Success Scenario for Service ::" + serviceNme);
					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				}

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success Scenario for Service :: " + serviceNme);
				status = BaseConstants.SUCCESS_MSG;

				if (StringChecks.isFieldEmpty(errDesc)) {
					statusDesc = BaseConstants.SUCCESS_MSG;
				} else {
					statusDesc = errDesc;
				}
			}

			respStts = new MrchntRespStts();
			respStts.setStatus(status);
			respStts.setStatusCde(errCde);
			respStts.setDescription(statusDesc);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}

		return respStts;
	}

	/**
	 * @author GovindK
	 *         <h2>parseResponse</h2>
	 * @Created On : 03-May-2013
	 * @Description : This method is used Fetch the content of given Tag from Web
	 *              Service Respnse.
	 * @param response
	 * @param tagName
	 * @return
	 */
	public static String parseXmlTag(String response, String tagName) {
		String retMsg = null;

		String startTag = "<" + tagName + ">";
		String endTag = "</" + tagName + ">";

		if (response.contains(startTag)) {

			int startIndex = response.indexOf(startTag) + startTag.length();
			int endIndex = response.indexOf(endTag);

			retMsg = response.substring(startIndex, endIndex);

		} else {

			retMsg = null;
		}

		return retMsg;
	}
}
