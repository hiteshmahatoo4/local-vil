package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class EcomSendSmsRespDtls implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;

	private String circleId;

	private String serviceName;

	private String channelName;

	private String segment;

	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/**
	 * @return the channelName
	 */
	public String getChannelName() {
		return channelName;
	}

	/**
	 * @param channelName the channelName to set
	 */
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	/**
	 * @return the segment
	 */
	public String getSegment() {
		return segment;
	}

	/**
	 * @param segment the segment to set
	 */
	public void setSegment(String segment) {
		this.segment = segment;
	}

}
