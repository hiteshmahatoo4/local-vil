package com.vil.ecom.integration.pojo;

import com.vil.ecom.eai.UploadEvents.pojo.EvtData;

import java.io.Serializable;

public class EcomUploadEventsReq implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String customerMsisdn;
	
	private String eventName;
	
	private EvtData eventData;

	/**
	 * @return the customerMsisdn
	 */
	public String getCustomerMsisdn() {
		return customerMsisdn;
	}

	/**
	 * @param customerMsisdn the customerMsisdn to set
	 */
	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * @param eventName the event name for which notifications to be Sent
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * @return the eventData
	 */
	public EvtData getEventData() {
		return eventData;
	}

	/**
	 * @param eventData the eventData for which notifications to be Sent
	 */
	public void setEventData(EvtData eventData) {
		this.eventData = eventData;
	}
	
	

}
