package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class EcomSendSmsNotificationReq implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String msisdn;
	
	private String smsTxt;

	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the smsTxt
	 */
	public String getSmsTxt() {
		return smsTxt;
	}

	/**
	 * @param smsTxt the smsTxt to set
	 */
	public void setSmsTxt(String smsTxt) {
		this.smsTxt = smsTxt;
	}

	
	
	

	
}
