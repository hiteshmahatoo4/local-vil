package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class EcomUploadEventsResp implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
	

	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

		
	
}
