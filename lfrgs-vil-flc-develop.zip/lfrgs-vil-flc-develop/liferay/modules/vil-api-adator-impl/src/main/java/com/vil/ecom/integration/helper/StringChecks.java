/**
 * 
 */
package com.vil.ecom.integration.helper;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;


/**
 * @author TCS
 * @param <T>
 * @date 22/12/2022 This class contains validation functions for various data. All
 *       methods are static and return a boolean value stating whether the data
 *       is valid or not. For example, a checkNumeric function checks to see if
 *       given string is numeric or not. If all characters in it are numeric it
 *       returns 'true' else it returns false.
 */
public class StringChecks {

	private static final Log logger = LogFactoryUtil.getLog(StringChecks.class);
	
	private static final String THIS_CLASS = StringChecks.class.getName();
	private static final String DATE_COMPARE = "dateCompare";
	private static final String DDMMMYYYY = "dd-MMM-yyyy";
	private static final String END_DATE = " | endDate::";
	private static final String ENTERED_METHOD = "Entered method ";
	private static final String DATE_EQUAL = "dateEqual";
	private static final String DATE_2 = " | date2::";
	private static final String ENTERED_METHOD_WITH_DATE_1 = "Entered method with date1::";
	private static final String EXITING_METHOD_WITH_DIFF = "Exiting method with diff : ";
	private static final String GOT_EXCEPTION_IN_PARSING_DATE = " Got Exception in parsing Date : ";
	private static final String PATTERN = " | Pattern : ";
	private static final String DUE_TO = " due to: ";
	private static final String GET_FUTURE_DATE = "getFutureDate";
	private static final String GET_FIRST_DATE_OF_MONTH = "getFirstDateOfMonth";
	private static final String ENTERING_METHOD = "Entering Method ";
	private static final String EXITING_METHOD = "Exiting Method ";
	private static final String VALIDATE_AMT = "validateAmt";
	private static final String ENTERING_METHOD_WITH_INPUT = "Entering Method with input :";
	private static final String EXITING_METHOD_WITH_RETURN_VALUE = "Exiting Method with returnValue :";
	private static final String UTF_8 = "UTF-8";
	private static final String OBJ_TO_XML_CONVERTER = "objToXmlConverter";
	private static final String PRINT_EXCEPTION_ERRORS = "printExceptionErrors";
	private static final String ERROR_LOG = " Error Log : ";
	private static final String ENTERED_METHOD_INPUT = "Entered Method : Input : ";
	private static final String MSG_PART_NUMBER = " Msg Part Number : ";
	private static final String LIST_OF_FILES_IN_DIRECTORY = "List of files in directory::";
	private static final String FILE_CREATED = "File Created:: ";
	private static final String DDMMYYYYHHMMSS = "ddMMyyyyHHmmss";
	private static final String READ_FILE_CONTENT = "readFileContent";
	private static final String READ_FILE_LINES = "readFileLines";
	private static final String WITH_CLIENT_IP = "with clientIp : ";
	private static final String CLOSE_CONNECTION = "closeConnection";
	


	// Check if it is a valid email id
	public static boolean validateEmailAddress(String email) {
		boolean returnValue = false;

		Pattern p = Pattern.compile("^[a-zA-Z0-9._-]{1,}@[a-zA-Z0-9]{1,}.[a-zA-Z0-9]{2,}[a-zA-Z0-9.]{0,}$"); // Email id must of the form xyz@abc.def
		Matcher m = p.matcher(email);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	// Test if password conforms with password policy
	public static boolean validatePassword(String password) {
		boolean isValid = false;
		String pwd = password;
		int conditionChecker = 0;
		if (testNumeric(pwd)) { // Check if there is atleast 1 number
			conditionChecker++;
		}
		if (testCapital(pwd)) { // Check if there is atleast 1 capital alphabet
			conditionChecker++;
		}
		if (testLower(pwd)) { // Check if there are lower case alphabets
			conditionChecker++;
		}
		if (testSpecialCharacter(pwd)) { // Check if there is atleast 1 special character among ^.*[!@#$&_]+*$
			conditionChecker++;
		}
		if (conditionChecker >= LoggerConstants.NUM_3) {
			isValid = true;
		} else {
			isValid = false;
		}

		return isValid;
	}

	public static String validatePassword(String pwd, int minLenght, int maxLength) {
		String outPut = "VALID";
		if (isFieldEmpty(pwd)) {
			outPut = "EMPTY";
		} else if (!testNumeric(pwd)) {
			outPut = "NO_NUMBER";
		} else if (!testCapital(pwd)) {
			outPut = "NO_UPPER_CASE";
		} else if (!testLower(pwd)) {
			outPut = "NO_LOWER_CASE";
		} else if (!testSpecialCharacter(pwd)) {
			outPut = "NO_SPECIAL_CHAR";
		} else if (pwd!=null && minLenght > pwd.length()) {
			outPut = "TOO_SHORT";
		} else if (pwd!=null && maxLength < pwd.length()) {
			outPut = "TOO_LONG";
		}
		return outPut;
	}

	public static boolean validateExpression(String value, String filter) {
		boolean returnValue = false;

		Pattern p = Pattern.compile(filter); // Value should be of particular filter
		Matcher m = p.matcher(value);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	// Check if there is atleast 1 number
	public static boolean testNumeric(String pwd) {
		// RegEx r1 = new RegEx();
		Pattern p = Pattern.compile("^.*[\\d]+.*$");
		Matcher m = p.matcher(pwd);
		return m.matches();

	}

	// Check if there is atleast 1 capital alphabet
	public static boolean testCapital(String pwd) {
		Pattern p = Pattern.compile("^.*[A-Z]+.*$");
		Matcher m = p.matcher(pwd);
		return m.matches();
	}

	// Check if there are lower case alphabets
	public static boolean testLower(String pwd) {
		Pattern p = Pattern.compile("^.*[a-z]+.*$");
		Matcher m = p.matcher(pwd);
		return m.matches();
	}

	// Check if there is atleast 1 special character among ^.*[!@#$&_]+*$
	public static boolean testSpecialCharacter(String pwd) {
		Pattern p = Pattern.compile("^.*[!@#$%^&*_]+.*$");
		Matcher m = p.matcher(pwd);
		return m.matches();
	}

	// Check if all characters are alphabets
	public static boolean checkAlphabetic(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z\\s]+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	// Check if all characters are alphabets
	/**
	 * @param submittedValue
	 * @return true : if input String is alphabetic false : if input String is not
	 *         alphabetic.
	 */
	public static boolean checkAlphabeticWTdSpace(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z]+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	// Check if all characters are alphabets or numbers

	/**
	 * @param submittedValue
	 * @return true : if input String is alphaNumeric false : if input String is not
	 *         alphaNumeric.
	 */
	public static boolean checkAlphaNumeric(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z0-9\\s]+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	/**
	 * @param submittedValue
	 * @return true : if input String is alphaNumeric and having max length 20 false
	 *         : if input String is not alphaNumeric or length greater than 20.
	 */
	public static boolean checkAlphaNumericLength(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z0-9\\s]{0,20}+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	/**
	 * @param submittedValue
	 * @return true : if input String is alphaNumeric and having slash false : if
	 *         input String is not alphaNumeric.
	 */
	public static boolean checkAlphaNumericSlash(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z0-9\\/\\s]+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	/**
	 * @param submittedValue
	 * @return true : if input String is alphaNumeric false : if input String is not
	 *         alphaNumeric.
	 */
	public static boolean checkAlphaNumericWithSpacialChars(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z0-9~@#$*_+|,.: -]*$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	public static boolean checkAlphaNumbericWithDot(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z0-9.]*$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	/**
	 * @param submittedValue
	 * @return true : if input String is alphaNumeric false : if input String is not
	 *         alphaNumeric.
	 */
	public static boolean checkAlphaWTdSpaceNumeric(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[a-zA-Z0-9]+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	public static boolean validateAddress(String submittedValue) {
		boolean returnValue = true;
		String allowedChars = "qwertyuiopasdfghjklmnbvcxzQWERTYUIOPASDFGHJKLMNBVCXZ1234567890()-.,/@& ";
		for (char a : submittedValue.toCharArray()) {
			if (allowedChars.indexOf(a) == -1) {
				returnValue = false;
				break;
			}
		}
		return returnValue;
	}

	/**
	 * <h1>isFieldEmpty</h1>
	 * <p>
	 * Method checks if given Input String is empty or null. If its empty or Null,It
	 * returns boolean true If its not empty,it returns boolean false.
	 * </p>
	 * 
	 * @param value
	 * @return
	 */
	public static boolean isFieldEmpty(String checkfield) {

		return !((checkfield != null) && (!"".equalsIgnoreCase(checkfield.trim()))
				&& !"null".equalsIgnoreCase(checkfield));
	}

	public static boolean isAnyFieldEmpty(List<String> checkfield) {
		for (String string : checkfield) {
			if (isFieldEmpty(string)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isAnyFieldMatches(List<String> checkfield, String obj1) {
		
		if (obj1!=null 
				&& !isFieldEmpty(obj1)) {
			
			for (String string : checkfield) {
				if (string!=null 
						&& !isFieldEmpty(string) 
						&& string.contains(obj1)) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isMatchesAnyField(List<String> checkfield, String obj1) {
		
		if (obj1!=null 
				&& !isFieldEmpty(obj1)) {
			
			for (String string : checkfield) {
				
				if (string!=null 
						&& !isFieldEmpty(string) && obj1.contains(string)) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isAnyFieldEquals(List<String> checkfield, String obj1) {

		if (obj1!=null 
				&& !isFieldEmpty(obj1)) {
			
			for (String string : checkfield) {
				
				if (string!=null 
						&& !isFieldEmpty(string) 
						&& string.equals(obj1)) {
					return true;
				}
			}
		}
		return false;
	}

	public static boolean isAnyFieldEmpty(String... checkfield) {
		return isAnyFieldEmpty(Arrays.asList(checkfield));
	}

	@SuppressWarnings("rawtypes")
	public static final boolean isNullOrSpace(Object o) {

		if (o == null) {
			return true;
		}

		return ((o instanceof Map && ((Map) o).isEmpty())
				||(o instanceof Collection && ((Collection) o).isEmpty())
				||(o instanceof Object[] && ((Object[]) o).length == 0)
				||(o instanceof String && ((String) o).trim().length() == 0));
	}

	/**
	 * <h1>checkValidDate</h1>
	 * 
	 * @param day   (int)
	 * @param month (int)
	 * @param year  (int)
	 * @return isValid (boolean)
	 * @description Checks for the validity of the dates given the date, month and
	 *              year in integers
	 */
	public static boolean checkValidDate(int day, int month, int year) {
		boolean isValid;
		// Check if day, month and year are >0 and the day is not more than 29 for
		// non-leap-year-feb and
		// not 30 or more for leap-year-feb and for other months the number of days can
		// only be 30 or 31
		if (day <= 0 || month <= 0 || year <= 0 || day > LoggerConstants.NUM_31 || (month == LoggerConstants.NUM_2 && day >= LoggerConstants.NUM_29 && !checkIfLeapYear(year))
				|| (month == LoggerConstants.NUM_2 && day >= LoggerConstants.NUM_30 && checkIfLeapYear(year)) || (!isa31DayMonth(month) && day == LoggerConstants.NUM_31)
				|| month > LoggerConstants.NUM_12)
			isValid = false;
		else
			isValid = true;
		return isValid;
	}

	/**
	 * @param month (int). e.g : Jan =1,Feb=2,...
	 * @return boolean
	 * @description Checks whether the given month (int) has 31 days.
	 */
	public static boolean isa31DayMonth(int month) {
		if (month == 1 || month == LoggerConstants.NUM_3 || month == LoggerConstants.NUM_5 || month == LoggerConstants.NUM_7 || month == LoggerConstants.NUM_8 || month == LoggerConstants.NUM_10 || month == LoggerConstants.NUM_12)
			return true;
		return false;
	}

	/**
	 * @param year (int)
	 * @return boolean
	 * @description Check if the given year (int) is a leap year
	 */
	public static boolean checkIfLeapYear(int year) {
		// Standard logic for checking if it is a leap year
		return (year % LoggerConstants.NUM_4 == 0 && year % LoggerConstants.NUM_100 != 0) || year % LoggerConstants.NUM_400 == 0;
	}

	// Checks if given string contains numeric values or not
	/**
	 * @param number
	 * @return
	 */
	public static boolean checkNumeric(String number) {
		char[] num = number.toCharArray();
		for (int i = 0; i < num.length; i++) {
			if (!(num[i] == '1' || num[i] == '2' || num[i] == '3' || num[i] == '4' || num[i] == '5' || num[i] == '6'
					|| num[i] == '7' || num[i] == '8' || num[i] == '9' || num[i] == '0'))
				return false;
		}
		return true;
	}

	public static boolean checkMaskedNumeric(String number) {
		char[] num = number.toCharArray();
		for (int i = 0; i < num.length; i++) {
			if (!(num[i] == '1' || num[i] == '2' || num[i] == '3' || num[i] == '4' || num[i] == '5' || num[i] == '6'
					|| num[i] == '7' || num[i] == '8' || num[i] == '9' || num[i] == '0' || num[i] == 'x'
					|| num[i] == 'X'))
				return false;
		}
		return true;
	}

	/**
	 * @author TCS This method is used to Check if input String is Numeric or
	 *         not. If String is Numeric then return true, else return false
	 * @param currentCellValue
	 * @return
	 */
	public static boolean isNumber(String currentCellValue) {

		boolean returnValue = false;
		Pattern p = Pattern.compile(".*[^0-9].*");
		Matcher m = p.matcher(currentCellValue);
		if (!m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	/**
	 * <h2>dateCompare</h2>
	 * <p>
	 * 
	 * @description : This function is used to compare two dates passed as input
	 *              String in dd-MMM-yyyy format.
	 *              </p>
	 * @param startDate
	 * @param endDate
	 * @return true if both the Dates in String format are equal.
	 * @throws ParseException
	 */
	public static boolean dateCompare(String startDate, String endDate) {

		Date d1;
		Date d2;
		boolean flag = false;
		String methodName = DATE_COMPARE;
		SimpleDateFormat df = new SimpleDateFormat(DDMMMYYYY);

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD + "with startDate::" + startDate + END_DATE + endDate);

		try {
			d1 = df.parse(startDate);
			d2 = df.parse(endDate);

			if (d1.before(d2) || d1.after(d2)) {
				flag = false;
			} else {
				flag = true;
			}
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		return flag;
	}
	
	/**
	 * <h2>dateCompare</h2>
	 * <p>
	 * 
	 * @description : This function is used to compare two dates passed whether start date is before end date or not.
	 *              </p>
	 * @param startDate
	 * @param endDate
	 * @param pattern
	 * @return true if start date is before end date or else false.
	 * @throws ParseException
	 */
	public static boolean dateCompare(String startDate, String endDate,String pattern) {

		Date d1;
		Date d2;
		boolean flag = false;
		String methodName = DATE_COMPARE;
		SimpleDateFormat df = new SimpleDateFormat(pattern);

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD + "with startDate::" + startDate + END_DATE + endDate);

		try {
			d1 = df.parse(startDate);
			d2 = df.parse(endDate);

			if (d1.before(d2)) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		return flag;
	}

	/**
	 * <h2>dateCompare</h2>
	 * <p>
	 * 
	 * @description : This function is used to compare two dates passed.
	 *              </p>
	 * @param startDate
	 * @param endDate
	 * @return true
	 * @throws ParseException
	 */
	public static boolean dateCompare(Date startDate, Date endDate) {

		Date d1;
		Date d2;
		boolean flag = false;
		String methodName = DATE_COMPARE;
		SimpleDateFormat df = new SimpleDateFormat(DDMMMYYYY);

		try {

			FLogger.debug(logger,  THIS_CLASS, methodName,
					ENTERED_METHOD + "with startDate::" + startDate + END_DATE + endDate);

			d1 = df.parse(df.format(startDate));
			d2 = df.parse(df.format(endDate));

			if (d1.before(d2) || d1.after(d2)) {
				flag = false;
			} else {
				flag = true;
			}
		} catch (Exception e) {
			printExceptionErrors(e,logger, THIS_CLASS, DATE_COMPARE);
		}

		return flag;
	}

	public static Date getCurrentDate() {
		return Calendar.getInstance().getTime();
	}
	
	/**
	 * <p>This method generates the current Epoch Time</p>
	 * @return EpochTime in Long
	 */
	public static Long getCurrentEpochTime() {
		return getCurrentDate().getTime()/1000;
	}
	
	public static Long convertDateToEpoch(String date,String pattern) {
		
		Long epochTime = null;
		
		if(date != null && pattern != null) {
			Date d =  getDateFrmString(date, pattern);
			epochTime = d.getTime()/1000;
		}
		
		return epochTime;
		
	}

	/**
	 * <h2>dateEqual</h2>
	 * <p>
	 * 
	 * @description : This function is used to compare two dates passed as input as
	 *              String in dd-MMM-yyyy format are equal or not.
	 *              </p>
	 * @param startDate
	 * @param endDate
	 * @return true
	 * @throws ParseException
	 */
	public static boolean dateEqual(String startDate, String endDate) {

		Date d1;
		Date d2;
		boolean flag = true;
		String methodName = DATE_EQUAL;
		SimpleDateFormat df = new SimpleDateFormat(DDMMMYYYY);

		try {
			d1 = df.parse(startDate);
			d2 = df.parse(endDate);

			if (d1.before(d2) || d1.after(d2)) {
				flag = false;
			} else {
				flag = true;
			}
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		return flag;
	}

	/**
	 * <h2>dateEqual</h2>
	 * <p>
	 * 
	 * @description : This function is used to compare two dates passed as input as
	 *              Date are equal or not.
	 *              </p>
	 * @param startDate
	 * @param endDate
	 * @return true if Dates are equal.
	 * @throws ParseException
	 */
	public static boolean dateEqual(Date startDate, Date endDate) {

		Date d1;
		Date d2;
		boolean flag = true;
		String methodName = DATE_EQUAL;
		SimpleDateFormat df = new SimpleDateFormat(DDMMMYYYY);

		FLogger.debug(logger,  THIS_CLASS, methodName,
				"Entered method with startDate::" + startDate + END_DATE + endDate);

		try {

			d1 = df.parse(df.format(startDate));
			d2 = df.parse(df.format(endDate));

			if (d1.before(d2) || d1.after(d2)) {
				flag = false;
			} else {
				flag = true;
			}
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting method with flag : " + flag);

		return flag;
	}

	/**
	 * <h2>compareDates</h2>
	 * <p>
	 * 
	 * @description : This function is used to compare two dates passed as input as
	 *              Date are equal or not.
	 *              </p>
	 * @param startDate
	 * @param endDate
	 * @return 0 if Dates are equal.<br/>
	 *         1 if startDate > endDate <br/>
	 *         -1 if startDate less than endDate
	 * @throws ParseException
	 */
	public static int compareDates(Date startDate, Date endDate) {

		Date d1;
		Date d2;
		int flg = 0;

		String methodName = "compareDates";
		// SimpleDateFormat df = new SimpleDateFormat(DDMMMYYYY);

		FLogger.debug(logger,  THIS_CLASS, methodName,
				"Entered method with startDate::" + startDate + END_DATE + endDate);

		try {

			// d1 = df.parse(df.format(startDate));
			// d2 = df.parse(df.format(endDate));

			d1 = startDate;
			d2 = endDate;

			if (d1.compareTo(d2) > 0) {

				FLogger.debug(logger,  THIS_CLASS, methodName, "Date 1 occurs after Date 2");

				flg = 1;

			} else if (d1.compareTo(d2) < 0) {

				FLogger.debug(logger,  THIS_CLASS, methodName, "Date 1 occurs before Date 2");

				flg = -1;

			} else if (d1.compareTo(d2) == 0) {

				FLogger.debug(logger,  THIS_CLASS, methodName, "Both dates are equal");
				flg = 0;

			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting method with flag : " + flg);
		}

		return flg;
	}

	/**
	 * <h2>getDiffYears</h2>
	 * <p>
	 * 
	 * @description : This function is used to get difference between two dates in
	 *              Years.
	 *              </p>
	 * @param first
	 * @param last
	 * @return
	 */
	public static int getDiffYears(Date first, Date last) {

		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		String methodName = "getDiffYears";
		int diff = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD_WITH_DATE_1 + first + DATE_2 + last);

		try {

			diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);

			if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH) || (a.get(Calendar.MONTH) == b.get(Calendar.MONTH)
					&& a.get(Calendar.DATE) > b.get(Calendar.DATE))) {

				diff--;
			}
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD_WITH_DIFF + diff);

		return diff;
	}

	/**
	 * <h2>getDiffDays</h2>
	 * <p>
	 * 
	 * @description : This function is used to get difference between two dates in
	 *              Days.
	 *              </p>
	 * @param currentDate :
	 * @param pastDate    :
	 * @return
	 */

	public static Map<String, String> getDaysHrsMinSec(Date input1, Date input2) {
		String methodName = "getDaysHrsMinSec";
		FLogger.error(logger, THIS_CLASS, methodName,
				"Entered method with input1 :" + input1 + " | input2::" + input2);
		Map<String, String> dateDiffdtls = new HashMap<>();
		try {

			long diff = input1.getTime() - input2.getTime();

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffDays = diff / (24 * 60 * 60 * 1000);
			long diffHours = diff / (60 * 60 * 1000) % 24;
			FLogger.error(logger, THIS_CLASS, methodName, "Days :" + diffDays + " Hours :  " + diffHours
					+ " Minutes : " + diffMinutes + " seconds : " + diffSeconds);
			dateDiffdtls.put("days", String.valueOf(diffDays));
			dateDiffdtls.put("hrs", String.valueOf(diffHours));
			dateDiffdtls.put("mins", String.valueOf(diffMinutes));
			dateDiffdtls.put("sec", String.valueOf(diffSeconds));

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}
		return dateDiffdtls;
	}

	public static int getDiffDays(Date input1, Date input2) {

		String methodName = "getDiffDays";
		Date d1;
		Date d2;
		SimpleDateFormat df = new SimpleDateFormat(DDMMMYYYY);

		int diff = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName,
				"Entered method with input1 :" + input1 + " | input2::" + input2);

		try {

			if (dateEqual(input1, input2)) {// Passed Dates are Equal.

				FLogger.debug(logger,  THIS_CLASS, methodName, "Dates are equal.");

				diff = 0;

			} else {// Passed Dates are not Equal.

				d1 = df.parse(df.format(input1));
				d2 = df.parse(df.format(input2));

				if (d1.before(d2)) {

					FLogger.debug(logger,  THIS_CLASS, methodName, "input1 is before than input2.");

					diff = Days.daysBetween(new DateTime(d1), new DateTime(d2)).getDays();

				} else if (d1.after(d2)) {

					FLogger.debug(logger,  THIS_CLASS, methodName, "input1 is after than input2.");

					diff = Days.daysBetween(new DateTime(d2), new DateTime(d1)).getDays();
				}
			}

		} catch (Exception e) {
			printExceptionErrors(e,logger, THIS_CLASS, "getDiffDays");
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD_WITH_DIFF + diff);

		return diff;
	}

	public static Calendar getCalendar(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal;
	}

	/**
	 * @author TCS This method check if input String value is Valid Date. if
	 *         yes,returnValue : true else false.
	 * @param currentCellValue
	 * @param pattern          : Pattern used for Simple Date format e.g dd-MMM-yyyy
	 * @return
	 */
	public static boolean isValidDate(String value, String pattern) {

		String methodName = "isValidDate";
		boolean returnValue = false;
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date d = null;

		try {

			d = sdf.parse(value);

			if (d != null) {
				returnValue = true;
			}

		} catch (ParseException e) {
			FLogger.error(logger, THIS_CLASS, methodName, GOT_EXCEPTION_IN_PARSING_DATE + value
					+ PATTERN + pattern + " | " + e.getMessage() + DUE_TO + e.getCause(), e);

		} catch (Exception e) {
			FLogger.error(logger, THIS_CLASS, methodName, GOT_EXCEPTION_IN_PARSING_DATE + value
					+ PATTERN + pattern + " | " + e.getMessage() + DUE_TO + e.getCause(), e);

		}

		return returnValue;
	}

	/**
	 * @author TCS This method used to return a Date based on String.
	 * @param currentCellValue
	 * @param pattern          : Pattern used for Simple Date format e.g
	 *                         dd-MMM-yyyy-(02-Jan-2015) yyyy-MM-dd-(2009-12-31)
	 *                         dd-MM-YYYY-(31-12-2009) yyyy-MM-dd
	 *                         HH:mm:ss-(2009-12-31 23:59:59)
	 *                         HH:mm:ss.SSS-(23:59.59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS-(2009-12-31 23:59:59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS Z-(2009-12-31 23:59:59.999 +0530)
	 * @return
	 */
	public static Date getDateFrmString(String value, String pattern) {

		String methodName = "getDateFrmString";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date formatDate = null;

		try {

			// sdf.setLenient(false);
			formatDate = sdf.parse(value);
			return formatDate;

		} catch (Exception e) {

			FLogger.error(logger, THIS_CLASS, methodName, GOT_EXCEPTION_IN_PARSING_DATE + value
					+ PATTERN + pattern + " | " + e.getMessage() + DUE_TO + e.getCause(), e);

			return null;
		}

	}
	
	

	/**
	 * @author TCS This method used to return a Date based on String.
	 * @param currentCellValue
	 * @param pattern          : Pattern used for Simple Date format e.g
	 *                         dd-MMM-yyyy-(02-Jan-2015) yyyy-MM-dd-(2009-12-31)
	 *                         dd-MM-YYYY-(31-12-2009) yyyy-MM-dd
	 *                         HH:mm:ss-(2009-12-31 23:59:59)
	 *                         HH:mm:ss.SSS-(23:59.59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS-(2009-12-31 23:59:59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS Z-(2009-12-31 23:59:59.999 +0530)
	 * @return
	 */
	public static Date getDateFrmString(String value, String pattern, TimeZone timezone) {

		final String methodName = "getDateFrmString";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date formatDate = null;

		try {

			// sdf.setLenient(false);

			if (timezone != null) {
				sdf.setTimeZone(timezone);
			}

			formatDate = sdf.parse(value);

			return formatDate;

		} catch (Exception e) {

			FLogger.error(logger, THIS_CLASS, methodName,
					GOT_EXCEPTION_IN_PARSING_DATE + value + " | " + e.getMessage() + DUE_TO + e.getCause(),
					e);

			return null;
		}

	}

	/**
	 * @author TCS
	 *         <p>
	 *         This method used to return Julian Date String in yddd format for
	 *         input Date String
	 *         </p>
	 * @param d date object to be formatted
	 * @return date in YDDD format julian format.
	 */
	public static String getJulianDate(Date d) {

		String day = null;
		String year = null;

		String returnDate = null;

		try {

			if (d != null) {

				day = getStrFrmDate(d, "DDD", TimeZone.getDefault());
				year = getStrFrmDate(d, "yy", TimeZone.getDefault());

				if (year != null) {
					year = year.substring(1);
				}

				returnDate = year + day;

			} else {
				returnDate = null;
			}

		} catch (Exception e) {
			return null;
		}

		return returnDate;
	}

	/**
	 * @author TCS This method used to return a Date based on String.
	 * @param d        date object to be formatted
	 * @param timeZone for GMT for example, use TimeZone.getTimeZone("GMT")
	 * @return date in YDDD format depending on interchange
	 */
	/**
	 * @author TCS
	 *         <p>
	 *         This method used to return julian Date String in yddd format for
	 *         input Date String
	 *         </p>
	 * @param d        date object to be formatted
	 * @param timeZone for GMT
	 * @return date in YDDD format julian format.
	 */
	public static String getJulianDate(Date d, TimeZone timeZone) {

		String day = null;
		String year = null;

		String returnDate = null;

		try {

			if (d != null) {

				day = getStrFrmDate(d, "DDD", timeZone);
				year = getStrFrmDate(d, "yy", timeZone);

				if (year != null) {
					year = year.substring(1);
				}

				returnDate = year + day;

			} else {
				returnDate = null;
			}

		} catch (Exception e) {
			return null;
		}

		return returnDate;
	}

	/**
	 * @author TCS This method used to return a Date based on String.
	 * @param currentCellValue
	 * @param pattern          : Pattern used for Simple Date format e.g
	 *                         dd-MMM-yyyy-(02-Jan-2015) yyyy-MM-dd-(2009-12-31)
	 *                         dd-MM-YYYY-(31-12-2009) yyyy-MM-dd
	 *                         HH:mm:ss-(2009-12-31 23:59:59)
	 *                         HH:mm:ss.SSS-(23:59.59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS-(2009-12-31 23:59:59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS Z-(2009-12-31 23:59:59.999 +0530)
	 * @return
	 */
	public static String getStrFrmDate(Date d, String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		String str = null;

		try {

			sdf.setLenient(false);
			str = sdf.format(d);
			return str;

		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @author TCS This method used to return a Date based on String.
	 * @param currentCellValue
	 * @param pattern          : Pattern used for Simple Date format e.g
	 *                         dd-MMM-yyyy-(02-Jan-2015) yyyy-MM-dd-(2009-12-31)
	 *                         dd-MM-YYYY-(31-12-2009) yyyy-MM-dd
	 *                         HH:mm:ss-(2009-12-31 23:59:59)
	 *                         HH:mm:ss.SSS-(23:59.59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS-(2009-12-31 23:59:59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS Z-(2009-12-31 23:59:59.999 +0530)
	 * @param timezone         : timezone Object
	 * @return
	 */
	public static String getStrFrmDate(Date d, String pattern, TimeZone timezone) {

		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		String str = null;

		try {

			sdf.setLenient(false);

			if (timezone != null) {
				sdf.setTimeZone(timezone);
			}

			str = sdf.format(d);

			return str;

		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @author TCS This method is used to Fetch Past Date from Current Day.
	 * @param range   : Number of days to go in past
	 * @param pattern : Pattern used for Simple Date format e.g dd-MMM-yyyy
	 * @return
	 */
	public static Date getPastDate(int range) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = "getPastDate";

		Date formatDate = null;
		Calendar cal = Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.DATE, -range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	/**
	 * @author TCS This method is used to Fetch Past Date from Current Day.
	 * @param range   : Number of days to go in past
	 * @param pattern : Pattern used for Simple Date format e.g dd-MMM-yyyy
	 * @return
	 */
	public static Date getPastDate(int range, Calendar cal) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = "getPastDate";

		Date formatDate = null;
		// Calendar cal=Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.DATE, -range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	/**
	 * @author TCS This method is used to Fetch Future Date from Current Day.
	 * @param range   : Number of days to go in past
	 * @param pattern : Pattern used for Simple Date format e.g dd-MMM-yyyy
	 * @return
	 */
	public static Date getFutureDate(int range) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = GET_FUTURE_DATE;

		Date formatDate = null;
		Calendar cal = Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.DATE, range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	/**
	 * @author TCS This method is used to Fetch Future Date from Current Day.
	 * @param range   : Number of days to go in past
	 * @param pattern : Pattern used for Simple Date format e.g dd-MMM-yyyy
	 * @return
	 */
	public static Date getFutureDate(int range, Calendar cal) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = GET_FUTURE_DATE;

		Date formatDate = null;
		// Calendar cal=Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.DATE, range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	/**
	 * @author ruhiK This method is used to Add month in particular date
	 * @param range   : Number of days to go in past
	 * @param pattern : Pattern used for Simple Date format e.g dd-MMM-yyyy
	 * @return
	 */
	public static Date getDateByAddingMonth(int range, Calendar cal) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = "getDateByAddingMonth";

		Date formatDate = null;
		// Calendar cal=Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.MONTH, range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	/**
	 * @author TCS This method is used to check if Input Date is Future Date or
	 *         not
	 * @return : true : if Input Date is Future Date<br/>
	 *         false: if Input Date is Not Future Date<br/>
	 */
	public static boolean checkForFutureDate(Date inputDate) {

		String methodName = "checkForFutureDate";
		boolean flag = Boolean.FALSE;

		Calendar cal = Calendar.getInstance();
		Date currentDate = cal.getTime();

		try {

			if (inputDate.after(currentDate)) {
				flag = Boolean.TRUE;
			} else {
				flag = Boolean.FALSE;
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			flag = Boolean.FALSE;
		}

		return flag;
	}

	/**
	 * @author TCS This method used to return a Date based on String.
	 * @param currentCellValue
	 * @param pattern          : Pattern used for Simple Date format e.g
	 *                         dd-MMM-yyyy-(02-Jan-2015) yyyy-MM-dd-(2009-12-31)
	 *                         dd-MM-YYYY-(31-12-2009) yyyy-MM-dd
	 *                         HH:mm:ss-(2009-12-31 23:59:59)
	 *                         HH:mm:ss.SSS-(23:59.59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS-(2009-12-31 23:59:59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS Z-(2009-12-31 23:59:59.999 +0530)
	 * @return
	 */
	public static Date getFirstDateOfMonth(Date d, String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = GET_FIRST_DATE_OF_MONTH;

		Date formatDate = null;
		Calendar cal = Calendar.getInstance();

		try {

			if (StringChecks.isFieldEmpty(pattern)) {
				sdf = new SimpleDateFormat(DDMMMYYYY);
			} else {
				sdf = new SimpleDateFormat(pattern);
			}

			if (d != null) {
				cal.setTime(d);
			}

			cal.set(Calendar.DAY_OF_MONTH, 1);

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	/**
	 * @author TCS This method used to return a Date based on String.
	 * @param currentCellValue
	 * @param pattern          : Pattern used for Simple Date format e.g
	 *                         dd-MMM-yyyy-(02-Jan-2015) yyyy-MM-dd-(2009-12-31)
	 *                         dd-MM-YYYY-(31-12-2009) yyyy-MM-dd
	 *                         HH:mm:ss-(2009-12-31 23:59:59)
	 *                         HH:mm:ss.SSS-(23:59.59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS-(2009-12-31 23:59:59.999) yyyy-MM-dd
	 *                         HH:mm:ss.SSS Z-(2009-12-31 23:59:59.999 +0530)
	 * @return
	 */
	public static String getStrFirstDateOfMonth(Date d, String pattern) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = GET_FIRST_DATE_OF_MONTH;

		Date formatDate = null;
		String returnDate = null;

		Calendar cal = Calendar.getInstance();

		try {

			if (StringChecks.isFieldEmpty(pattern)) {
				sdf = new SimpleDateFormat(DDMMMYYYY);
			} else {
				sdf = new SimpleDateFormat(pattern);
			}

			if (d != null) {
				cal.setTime(d);
			}

			cal.set(Calendar.DAY_OF_MONTH, 1);

			formatDate = cal.getTime();

			returnDate = sdf.format(formatDate);

			return returnDate;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	/**
	 * <p>
	 * This method returns input double value into double of Rs.Ps #.## format
	 * </p>
	 * 
	 * @param value
	 * @param places
	 * @return
	 */
	public static double round(double value, int places) {

		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = BigDecimal.valueOf(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);

		// DecimalFormat df = new DecimalFormat("####0.00");
		// double v = Double.valueOf(df.format(bd.doubleValue()));

		return bd.doubleValue();
	}

	/**
	 * <p>
	 * This method returns input double value into double of Rs.Ps #.## format
	 * </p>
	 * 
	 * @param value
	 * @param places
	 * @return
	 */
	public static double roundDown(double value, int places) {

		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = BigDecimal.valueOf(value);
		bd = bd.setScale(places, RoundingMode.DOWN);

		// DecimalFormat df = new DecimalFormat("####0.00");
		// double v = Double.valueOf(df.format(bd.doubleValue()));

		return bd.doubleValue();
	}

	/**
	 * <p>
	 * This method returns input double value into String of Rs.Ps #.## format
	 * </p>
	 * 
	 * @param value
	 * @param places
	 * @return
	 */
	public static String roundToStr(double value, int places) {

		String roundedStr = null;

		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = BigDecimal.valueOf(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);

		DecimalFormat df = new DecimalFormat("####0.00");
		roundedStr = df.format(bd.doubleValue());

		return roundedStr;
	}

	/**
	 * <p>
	 * This method returns input String into String of Rs.Ps #.## format
	 * </p>
	 * 
	 * @param value
	 * @param places
	 * @return
	 */
	public static String roundToStr(String value, int places) {

		String roundedStr = null;

		double d = Double.parseDouble(value);

		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = BigDecimal.valueOf(d);
		bd = bd.setScale(places, RoundingMode.HALF_UP);

		DecimalFormat df = new DecimalFormat("####0.00");
		roundedStr = df.format(bd.doubleValue());

		return roundedStr;
	}

	/**
	 * <p>
	 * Converts XMLGregorianCalendar to java.util.Date in Java
	 * </p>
	 * 
	 * @param calendar
	 * @return
	 */
	public static Date dateTimeToDate(XMLGregorianCalendar calendar) {

		if (calendar == null) {
			return null;
		}
		return calendar.toGregorianCalendar().getTime();
	}

	/**
	 * <p>
	 * This method is used to Convert java.util.Date to XMLGregorianCalendar
	 * DateTime
	 * </p>
	 * 
	 * @param inputDate
	 * @return
	 */
	public static XMLGregorianCalendar convertDatetoDateTime(Date inputDate) {

		String methodName = "convertDatetoDateTime";
		GregorianCalendar c = new GregorianCalendar(TimeZone.getTimeZone("IST"));
		XMLGregorianCalendar outputDate = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (inputDate != null) {

				c.setTime(inputDate);
				c.setTimeZone(TimeZone.getTimeZone("IST"));

				outputDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
				// outputDate.setTimezone( DatatypeConstants.FIELD_UNDEFINED );
				outputDate.setFractionalSecond(null);

			}

		} catch (DatatypeConfigurationException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return outputDate;
	}

	/**
	 * <p>
	 * This method is used to Convert java.util.Date to XMLGregorianCalendar
	 * DateTime
	 * </p>
	 * 
	 * @param inputDate
	 * @return
	 */
	public static XMLGregorianCalendar convertDatetoDateTimeWithoutTimeAndZone(Date inputDate) {

		String methodName = "convertDatetoDateTimeWithoutTimeAndZone";
		GregorianCalendar c = new GregorianCalendar(TimeZone.getTimeZone("IST"));
		XMLGregorianCalendar outputDate = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (inputDate != null) {

				c.setTime(inputDate);
				c.setTimeZone(TimeZone.getTimeZone("IST"));

				outputDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
				outputDate.setFractionalSecond(null);
				outputDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
				outputDate.setTime(DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
						DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
			} 

		} catch (DatatypeConfigurationException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return outputDate;
	}

	/**
	 * <p>
	 * This method is used to Convert java.util.Date to XMLGregorianCalendar
	 * DateTime
	 * </p>
	 * 
	 * @param inputDate
	 * @return
	 */
	public static XMLGregorianCalendar convertDatetoDateTimeWithoutTimeAndZone1(Date inputDate) {

		String methodName = "convertDatetoDateTimeWithoutTimeAndZone";
		GregorianCalendar c = new GregorianCalendar(TimeZone.getTimeZone("IST"));
		XMLGregorianCalendar outputDate = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (inputDate != null) {

				c.setTime(inputDate);
				c.setTimeZone(TimeZone.getTimeZone("IST"));

				outputDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
				outputDate.setFractionalSecond(null);
				outputDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
				/*
				 * outputDate.setTime(DatatypeConstants.FIELD_UNDEFINED,
				 * DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
				 * DatatypeConstants.FIELD_UNDEFINED);
				 */
			}

		} catch (DatatypeConfigurationException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return outputDate;
	}

	/**
	 * <p>
	 * This method is used to Convert java.util.Date to XMLGregorianCalendar
	 * DateTime
	 * </p>
	 * 
	 * @param inputDate
	 * @return
	 */
	public static XMLGregorianCalendar convertDatetoDateTime1(Date inputDate) {

		String methodName = "convertDatetoDateTime1";
		GregorianCalendar c = new GregorianCalendar(TimeZone.getTimeZone("IST"));
		XMLGregorianCalendar outputDate = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (inputDate != null) {

				c.setTime(inputDate);
				c.setTimeZone(TimeZone.getTimeZone("IST"));

				outputDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

				/**
				 * Un-Comment below line as this is used to remove timestamp from
				 * XMLGregorianCalendar
				 */
				/** outputDate.setTimezone( DatatypeConstants.FIELD_UNDEFINED ); */

				/**
				 * Un-Comment below line as this is used to remove fractional seconds from
				 * XMLGregorianCalendar
				 */
				/** outputDate.setFractionalSecond(null); */

			} 

		} catch (DatatypeConfigurationException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return outputDate;
	}

	/**
	 * <p>
	 * This method is used to check input msisdn is valid or not
	 * </p>
	 * ^ #Match the beginning of the string [6789] #Match a 6,7, 8 or 9 \\d #Match a
	 * digit (0-9 and anything else that is a "digit" in the regex engine) {9}
	 * #Repeat the previous "\d" 9 times (9 digits) $ #Match the end of the string
	 * 
	 * @param msisdn
	 * @return true : if valid Input is passed. false : if invalid Input is passed
	 */
	public static boolean checkMsisdn(String msisdn) {

		boolean returnValue = false;
		String methodName = "checkMsisdn";
		Pattern p = Pattern.compile("^[6789]\\d{9}$");
		Matcher m = p.matcher(msisdn);

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERING_METHOD + methodName + " with msisdn : " + msisdn);

		if(isFieldEmpty(msisdn)) {
			returnValue = false;
		} else if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName,
				EXITING_METHOD + methodName + " with returnValue : " + returnValue);

		return returnValue;
	}

	/**
	 * <h2>validateAmt</h2>
	 * <p>
	 * This Regex Check for Following conditions. Number should be of format :
	 * ####.## format. Number of Digits after Decimal Places should be from 0 to 2.
	 * Minimum digits should be 1 and maximum digits can be 9 on left hand side of
	 * decimal.
	 * </p>
	 * 
	 * @param input : Amount String which needs to be Validated.
	 * @return Boolean Value
	 *         <ul>
	 *         <li><b>true</b> : If valid Amount has been passed as input</li>
	 *         <li><b>false</b> : If invalid Amount has been passed as input.</li>
	 *         </ul>
	 */
	public static boolean validateAmt(String input) {

		boolean returnValue = false;
		double amt;
		String methodName = VALIDATE_AMT;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD_WITH_INPUT + input);

		Pattern p = Pattern.compile("((\\d{1,9})(((\\.)(\\d{0,2})){0,1}))");

		Matcher m = p.matcher(input);

		if (m.matches()) {

			amt = Double.parseDouble(input);

			if (amt > 0) {

				returnValue = Boolean.TRUE;
			} else {

				returnValue = Boolean.FALSE;
			}

		} else {
			returnValue = false;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD_WITH_RETURN_VALUE + returnValue);

		return returnValue;
	}

	/**
	 * <h2>validateAmt</h2>
	 * <p>
	 * This Regex Check for Following conditions. Number should be of format :
	 * ####.## format. Number of Digits after Decimal Places should be from 0 to 2.
	 * Minimum digits should be 1 and maximum digits can be 9 on left hand side of
	 * decimal.
	 * </p>
	 * 
	 * @param input      : Amount String which needs to be Validated.
	 * @param zeroChkFlg : flag to Check if Value greater than 0 check should be
	 *                   done or not.<br/>
	 *                   <ul>
	 *                   <li>true : input amount > 0 check is carried out</li>
	 *                   <li>false : input amount > 0 check not carried out.</li>
	 *                   </ul>
	 * 
	 * @return Boolean Value
	 *         <ul>
	 *         <li><b>true</b> : If valid Amount has been passed as input</li>
	 *         <li><b>false</b> : If invalid Amount has been passed as input.</li>
	 *         </ul>
	 */
	public static boolean validateAmt(String input, boolean zeroChkFlg) {

		boolean returnValue = false;
		double amt;
		String methodName = VALIDATE_AMT;

		FLogger.debug(logger,  THIS_CLASS, methodName,
				"Entering Method with " + "input :" + input + " | zeroChkFlg : " + zeroChkFlg);

		Pattern p = Pattern.compile("((\\d{1,9})(((\\.)(\\d{0,2})){0,1}))");

		Matcher m = p.matcher(input);

		if (m.matches()) {

			amt = Double.parseDouble(input);

			if (zeroChkFlg) {

				if (amt > 0) {

					returnValue = Boolean.TRUE;
				} else {

					returnValue = Boolean.FALSE;
				}
			} else {

				returnValue = Boolean.TRUE;
			}
		} else {
			returnValue = false;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD_WITH_RETURN_VALUE + returnValue);

		return returnValue;
	}

	/**
	 * <p>
	 * This method is used to validate Input String is passed in Valid Date Format
	 * or not.
	 * </p>
	 * 
	 * @param inputDate
	 * @param pattern
	 * @return true : if String is in Valid date Format. false : if String is not in
	 *         valid Format.
	 */
	public static boolean validateDate(String inputDate, String pattern) {

		boolean returnValue = false;
		String methodName = "validateDate";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date formatDate = null;

		try {
			sdf.setLenient(false);
			formatDate = sdf.parse(inputDate);

			if (formatDate != null) {

				FLogger.debug(logger,  THIS_CLASS, methodName, "formatDate Success for pattern : " + pattern);
				returnValue = true;
			}

		} catch (Exception e) {

			FLogger.error(logger, THIS_CLASS, methodName,
					" Got Exception for pattern : " + pattern + " as " + e.getMessage() + " at " + e.getStackTrace()[0]
							+ " " + e.getStackTrace()[1] + DUE_TO + e.getCause(),
					e);

			returnValue = false;
		}

		return returnValue;
	}

	/**
	 * <p>
	 * This method marshals input Java Object and returns XML as String output.
	 * </p>
	 * 
	 * @param pContext
	 * @param pObject
	 * @return
	 * @throws JAXBException
	 */
	public static String marshalAsString(JAXBContext pContext, Object pObject) throws JAXBException {

		String methodName = "marshalAsString";
		FLogger.debug(logger,  THIS_CLASS, methodName, "Entered Method marshalAsString");

		StringWriter sw = new StringWriter();

		Marshaller marshaller = pContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_ENCODING, UTF_8);
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

		marshaller.marshal(pObject, sw);

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting  Method marshalAsString");

		return sw.toString();
	}

	/**
	 * @author TCS
	 * @since 27-5-2015
	 *        <p>
	 *        This method marshals input Java Object and returns XML as String
	 *        output.
	 *        </p>
	 * @param pContext        : JAXB Context
	 * @param pObject         : Java Object from which XML needs to be generated.
	 * @param formatOutputFlg : Boolean flag to enable or disable formatting of
	 *                        generated XML
	 * @return
	 * @throws JAXBException
	 */
	public static String marshalAsString(JAXBContext pContext, Object pObject, boolean formatOutputFlg)
			throws JAXBException {

		String methodName = "marshalString";
		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		StringWriter sw = new StringWriter();

		Marshaller marshaller = pContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_ENCODING, UTF_8);

		if (formatOutputFlg) {
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		} else {
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.FALSE);
		}

		marshaller.marshal(pObject, sw);

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting  Method marshalAsString");

		return sw.toString();
	}

	/**
	 * @author TCS
	 * @since 31-Dec-2015
	 *        <h2>objectToJson</h2>
	 *        <p>
	 *        This method is used to Convert Java Object into Json String It uses
	 *        Jackson APIs for Conversion.
	 * @param pObject
	 * @return
	 */
	public static String convertObjectToJson(Object pObject) {

		String methodName = "convertObjectToJson";
		String respJson = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		try {

			if (pObject != null) {

				ObjectMapper mapper = new ObjectMapper();
				mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

				respJson = mapper.writeValueAsString(pObject);

			}
			
		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return respJson;
	}

	/**
	 * @author TCS
	 * @since 31-Dec-2015
	 *        <h2>jsonToObject</h2>
	 *        <p>
	 *        This method is used to Convert Json String into Java Object. It uses
	 *        Jackson APIs for Conversion.
	 *        </p>
	 * @param response
	 * @return
	 */

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Object convertJsonToObject(String jsonInput, Class classInput) {

		Object obj = null;
		String methodName = "convertJsonToObject";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (!StringChecks.isFieldEmpty(jsonInput)) {

				ObjectMapper mapper = new ObjectMapper();
				mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

				obj = mapper.readValue(jsonInput, classInput);

			} else {

				FLogger.error(logger, THIS_CLASS, methodName, " Response Msg is Null.");
				
			}

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return obj;
	}

	/**
	 * <p>
	 * This method returns input double value into double of Rs.Ps #.## format
	 * </p>
	 * 
	 * @param d
	 */
	public static String roundDouble(double d) {

		double d1 = d;
		String returnValue = "";

		DecimalFormat df = new DecimalFormat("#####.00");

		returnValue = df.format(d1);

		return returnValue;

	}

	/**
	 * <p>
	 * This method returns String conversion of List of String Passed as input
	 * </p>
	 * 
	 * @param d
	 */
	public static String convertListToString(List<String> list) {

		StringBuilder sb = new StringBuilder();

		for (String s : list) {
			sb.append(s);
			sb.append(",");
		}

		return sb.toString();

	}

	/**
	 * <p>
	 * This method returns masked conversion of given Input String
	 * </p>
	 * 
	 * @param inputStr   : Input String which needs to be Masked
	 * @param beginRange : Index value from Start of String till where we have to
	 *                   keep unmasked Value.
	 * @param endRange   : Number of Characters from end of String which we have to
	 *                   keep unmasked Value.
	 * @return Masked Value.
	 * 
	 *         e.g :
	 * 
	 *         1. input String : abc123456 ,beginRange : 3 , endRange : 3 output :
	 *         abcxxx456
	 * 
	 *         2. input String : abc123456 ,beginRange : 0 , endRange : 3 output :
	 *         xxxxxx456
	 * 
	 *         3. input String : abc123456 ,beginRange : 0 , endRange : 0 output :
	 *         xxxxxxxxx
	 * 
	 */
	public static String addMaskToString(String inputStr, int beginRange, int endRange) {

		StringBuilder sb = new StringBuilder();
		String outputValue = null;

		String methodName = "addMaskToString";

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD + methodName + " " + "with BeginRange : " + beginRange + " | EndRange : " + endRange);

		try {

			if (inputStr!=null && !isFieldEmpty(inputStr)) {

				int len = inputStr.length();
				int maskLen = 0;

				maskLen = len - (beginRange + endRange);

				if (len >= (beginRange + endRange)) {

					sb = new StringBuilder(inputStr.substring(0, beginRange));

					for (int i = 0; i < maskLen; i++) {

						sb.append('X');
					}

					sb.append(inputStr.substring(beginRange + maskLen, len));
					outputValue = sb.toString();

				} else {
					outputValue = inputStr;
				}

			}

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					EXITING_METHOD + methodName + " with masked Value  : " + outputValue);
		}

		return outputValue;

	}

	/**
	 * <p>
	 * This method returns masked conversion of given Input String
	 * </p>
	 * 
	 * @param inputStr   : Input String which needs to be Masked
	 * @param beginRange : Index value from Start of String till where we have to
	 *                   keep unmasked Value.
	 * @param endRange   : Number of Characters from end of String which we have to
	 *                   keep unmasked Value.
	 * @return Masked Value.
	 * 
	 *         e.g :
	 * 
	 *         1. input String : abc123456 ,beginRange : 3 , endRange : 3 output :
	 *         abcxxx456
	 * 
	 *         2. input String : abc123456 ,beginRange : 0 , endRange : 3 output :
	 *         xxxxxx456
	 * 
	 *         3. input String : abc123456 ,beginRange : 0 , endRange : 0 output :
	 *         xxxxxxxxx
	 * 
	 */
	public static String addMaskToString(String inputStr, int beginRange, int endRange, String avoidChar,
			String maskChar) {

		StringBuilder sb = new StringBuilder();
		String outputValue = null;

		String methodName = "addMaskToString";

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD + methodName + " " + "with BeginRange : " + beginRange + " | EndRange : " + endRange);

		try {

			if (inputStr!=null && !isFieldEmpty(inputStr)) {

				int len = inputStr.length();
				int maskLen = 0;

				maskLen = len - (beginRange + endRange);

				if (len >= (beginRange + endRange)) {

					sb = new StringBuilder(inputStr.substring(0, beginRange));

					for (int i = 0; i < maskLen; i++) {

						if (avoidChar != null && avoidChar.equalsIgnoreCase("" + inputStr.charAt(beginRange + i))) {
							sb.append(avoidChar);
						} else {

							if (StringChecks.isFieldEmpty(maskChar)) {
								sb.append("X");
							} else {
								sb.append(maskChar);
							}
						}

					}

					sb.append(inputStr.substring(beginRange + maskLen, len));
					outputValue = sb.toString();

				} 

			}

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					EXITING_METHOD + methodName + " with masked Value  : " + outputValue);
		}

		return outputValue;

	}

	/**
	 * <p>
	 * This method unmarshal input String XML and returns java Object.
	 * </p>
	 * 
	 * @param pContext
	 * @param inputStr
	 * @return
	 * @throws JAXBException
	 */
	public static Object unmarshalXmlToObj(JAXBContext pContext, String inputStr) throws JAXBException {

		Object obj = null;
		InputStream stream = null;
		String methodName = "unmarshalXmlToObj";

		try {

			inputStr = inputStr.replaceAll("&(?!amp;)", "&amp;");

			stream = new ByteArrayInputStream(inputStr.getBytes(UTF_8));
			Unmarshaller unmarshller = pContext.createUnmarshaller();
			obj = unmarshller.unmarshal(stream);

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		}

		return obj;
	}

	/**
	 * <p>
	 * This method is used to Convert given Java Object with Jaxb annotations into
	 * XML.
	 * </p>
	 * 
	 * @param record
	 * @param objectClass
	 * @param formatOutputFlg : Boolean flag to enable or disable formatting of
	 *                        generated XML
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static String objToXmlConverter(Object record, Class objectClass, boolean formatOutputFlg) {

		String methodName = OBJ_TO_XML_CONVERTER;
		String responseXML = "";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		try {

			if (record != null) {

				JAXBContext context = JAXBContext.newInstance(objectClass);
				responseXML = marshalAsString(context, record, formatOutputFlg);

			}

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);

		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return responseXML;
	}

	/**
	 * <p>
	 * This method is used to Convert given Java Object with Jaxb annotations into
	 * XML.
	 * </p>
	 * 
	 * @param record
	 * @param objectClass
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static String objToXmlConverter(Object record, Class objectClass) {

		String methodName = OBJ_TO_XML_CONVERTER;
		FLogger.debug(logger,  THIS_CLASS, methodName, "Entered Method objToXmlConverter");

		String responseXML = "";

		try {
			if (record != null) {

				JAXBContext context = JAXBContext.newInstance(objectClass);
				responseXML = marshalAsString(context, record);

			} 
			
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting Method objToXmlConverter");
		}

		return responseXML;
	}

	/**
	 * <p>
	 * This method is used to Convert given Java Object with Jaxb annotations into
	 * XML.
	 * </p>
	 * 
	 * @param record
	 * @param JAXBContext     Context
	 * @param formatOutputFlg : Boolean flag to enable or disable formatting of
	 *                        generated XML
	 * @return
	 */
	public static String objToXmlConverter(Object record, JAXBContext context, boolean formatOutputFlg) {

		String methodName = OBJ_TO_XML_CONVERTER;
		String responseXML = "";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		try {

			if (record != null) {

				responseXML = marshalAsString(context, record, formatOutputFlg);

			}

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);

		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return responseXML;
	}

	/**
	 * <p>
	 * This method is used print Exceptions logs in log file.
	 * </p>
	 * 
	 * @param e           : Exception Object
	 * @param logCategory : Logger Category like MPesa
	 * @param classNme    : Class Name
	 * @param methodNme   : Method Name from which exception thrown
	 */
	public static void printExceptionErrors(Exception e, Log logger, String classNme, String methodNme) {

		String methodName = PRINT_EXCEPTION_ERRORS;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD);

		FLogger.error(logger,  classNme, methodNme,
				" Error Log : Got Exception : " + e.getMessage() + DUE_TO + e.getCause(), e);

		for (int i = 0; i < e.getStackTrace().length; i++) {
			FLogger.debug(logger,  classNme, methodNme, ERROR_LOG + e.getStackTrace()[i]);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD);

	}

	/**
	 * <p>
	 * This method is used print Exceptions logs in log file.
	 * </p>
	 * 
	 * @param e                  : Exception Object
	 * @param logCategory        : Logger Category like MPesa
	 * @param classNme           : Class Name
	 * @param methodNme          : Method Name from which exception thrown
	 * @param noOfExceptionSteps : Number of stack trace elements to be print. 0
	 *                           means will print up-to 3 steps
	 */
	public static void printExceptionErrors(Exception e, Log logger, String classNme, String methodNme,
			int noOfExceptionSteps) {

		String methodName = PRINT_EXCEPTION_ERRORS;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD);

		FLogger.error(logger,  classNme, methodNme,
				" Error Log : Got Exception : " + e.getMessage() + DUE_TO + e.getCause(), e);
		if (0 == noOfExceptionSteps) {
			noOfExceptionSteps = LoggerConstants.NUM_3;
		}
		if (noOfExceptionSteps > e.getStackTrace().length) {
			noOfExceptionSteps = e.getStackTrace().length;
		}
		for (int i = 0; i < noOfExceptionSteps; i++) {
			FLogger.debug(logger,  classNme, methodNme, ERROR_LOG + e.getStackTrace()[i]);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD);

	}

	/**
	 * <p>
	 * This method is used print Exceptions logs in log file.
	 * </p>
	 * 
	 * @param e           : Exception Object
	 * @param logCategory : Logger Category like MPesa
	 * @param classNme    : Class Name
	 * @param methodNme   : Method Name from which exception thrown
	 * @param comment     : Comment if any you want to Add along with Exception
	 *                    Trace in Log.
	 */
	public static void printExceptionErrors(Exception e, Log logger, String classNme, String methodNme,
			String comment) {

		String methodName = PRINT_EXCEPTION_ERRORS;

		FLogger.debug(logger, THIS_CLASS, methodName, ENTERING_METHOD);

		if (!isFieldEmpty(comment)) {
			FLogger.debug(logger,  classNme, methodNme, comment);
		}
		
		FLogger.error(logger,  classNme, methodNme, " Error Log :  Got Exception : " + e.getMessage() + " at "
				+ e.getStackTrace()[0] + " " + e.getStackTrace()[1] + DUE_TO + e.getCause(), e);

		for (int i = 0; i < e.getStackTrace().length; i++) {
			FLogger.error(logger,  classNme, methodNme, ERROR_LOG + e.getStackTrace()[i]);
		}

		FLogger.debug(logger, THIS_CLASS, methodName, EXITING_METHOD);

	}

	/**
	 * <p>
	 * This method is used print Exceptions logs in log file.
	 * </p>
	 * 
	 * @param e           : Exception Object
	 * @param logCategory : Logger Category like MPesa
	 * @param classNme    : Class Name
	 * @param methodNme   : Method Name from which exception thrown
	 * @param comment     : Comment if any you want to Add along with Exception
	 *                    Trace in Log.
	 */
	public static void printExceptionErrors(Exception e, Log logger, String classNme, String methodNme,
			String comment, int noOfExceptionSteps) {

		String methodName = PRINT_EXCEPTION_ERRORS;

		FLogger.debug(logger, THIS_CLASS, methodName, ENTERING_METHOD);

		if (!isFieldEmpty(comment)) {
			FLogger.debug(logger, classNme, methodNme, comment);
		}
		
		FLogger.error(logger, classNme, methodNme, " Error Log :  Got Exception : " + e.getMessage() + " at "
				+ e.getStackTrace()[0] + " " + e.getStackTrace()[1] + DUE_TO + e.getCause(), e);

		if (noOfExceptionSteps > e.getStackTrace().length) {
			noOfExceptionSteps = e.getStackTrace().length;
		}
		for (int i = 0; i < noOfExceptionSteps; i++) {
			FLogger.debug(logger,  classNme, methodNme, ERROR_LOG + e.getStackTrace()[i]);
		}
		
		FLogger.debug(logger, THIS_CLASS, methodName, EXITING_METHOD);

	}

	/**
	 * @author TCS This method is used to Convert Hex Value to Ascii.
	 * @param currentCellValue
	 * @return
	 */
	public static String HexToAsciiConverter(String input) {

		StringBuilder output = new StringBuilder();
		String methodName = "HexToAsciiConverter";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD_INPUT + input);

		for (int i = 0; i < input.length(); i += LoggerConstants.NUM_2) {

			String str = input.substring(i, i + LoggerConstants.NUM_2);
			output.append((char) Integer.parseInt(str, LoggerConstants.NUM_16));
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, output);

		return output.toString();
	}

	/**
	 * @author TCS This method is used to Convert Hex Value to Decimal.
	 * @param currentCellValue
	 * @return
	 */
	public static String HexToDecimalConverter(String input) {

		StringBuilder output = new StringBuilder();
		String methodName = "HexToDecimalConverter";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD_INPUT + input);

		for (int i = 0; i < input.length(); i += LoggerConstants.NUM_2) {

			String str = input.substring(i, i + LoggerConstants.NUM_2);
			output.append(Integer.parseInt(str, LoggerConstants.NUM_16));
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, output);

		return output.toString();
	}

	/**
	 * @author TCS This method is used to Convert Integer to Hex String
	 * @param currentCellValue
	 * @return
	 */
	public static String DecimalToHexConverter(int input) {

		StringBuilder output = new StringBuilder();
		String methodName = "DecimalToHexConverter";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD_INPUT + input);

		if (isNumber(String.valueOf(input))) {

			output.append(Integer.toHexString(input).toUpperCase());

		} else {
			output.append("Invalid Input.");
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, output);

		return output.toString();
	}

	public static int hex2decimal(String s) {

		String digits = "0123456789ABCDEF";

		s = s.toUpperCase();

		int val = 0;

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			int d = digits.indexOf(c);
			val = LoggerConstants.NUM_16 * val + d;
		}

		return val;
	}

	public static String decimal2hex(int d) {

		String digits = "0123456789ABCDEF";

		if (d == 0)
			return "0";

		String hex = "";

		StringBuilder sb = null;

		while (d > 0) {
			int digit = d % LoggerConstants.NUM_16; // rightmost digit

			sb = new StringBuilder();
			hex = sb.append(digits.charAt(digit)).append(hex).toString(); // string concatenation

			d = d / LoggerConstants.NUM_16;
		}

		return hex;
	}

	/**
	 * @author TCS This method is used to Convert String Value to Hex using
	 *         Charset encoding Value passed.
	 * @param currentCellValue
	 * @return
	 */
	public static String HexConverter(String arg, String charsetEncoding) {

		String methodName = "HexConverter";
		String hexValue = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD);

		try {

			if (StringChecks.isFieldEmpty(charsetEncoding)) {

				hexValue = String.format("%040x", new BigInteger(1, arg.getBytes()));

			} else {

				hexValue = String.format("%040x", new BigInteger(1, arg.getBytes(charsetEncoding)));
			}

		} catch (UnsupportedEncodingException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exting Method with convertedHex : " + hexValue);

		return hexValue;
	}

	/**
	 * @author TCS This method is used to Convert String Value to Hex.
	 * @param currentCellValue
	 * @return
	 */
	public static String HexConverter(String arg) {

		String methodName = "HexConverter";
		String hexValue = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD);

		try {

			hexValue = String.format("%x", new BigInteger(1, arg.getBytes()));

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exting Method with convertedHex : " + hexValue);

		return hexValue;
	}

	/**
	 * @param data
	 * @return
	 */
	public static String clobToString(Clob data) {

		StringBuilder sb = new StringBuilder();
		String methodName = "clobToString";
		String responseMsg = null;
		Reader reader = null;
		BufferedReader br = null;
		String line = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD);

		try {

			if (data != null) {

				reader = data.getCharacterStream();
				br = new BufferedReader(reader);

				while (null != (line = br.readLine())) {
					sb.append(line);
				}

				br.close();

				responseMsg = sb.toString();
			} else {
				responseMsg = null;
			}

		} catch (SQLException e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			responseMsg = null;

		} catch (IOException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			responseMsg = null;

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			responseMsg = null;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD);

		return responseMsg;
	}

	/**
	 * <p>
	 * This method is used to Check if given Class package exist or not.
	 * </p>
	 * 
	 * @param classPath
	 * @return
	 */
	public static boolean isClassExist(String classPath) {

		boolean validFlg = false;

		String methodName = "isClassExist";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD);

		try {

			Class.forName(classPath);  //NOSONAR
			validFlg = true;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			validFlg = false;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD);

		return validFlg;
	}

	/**
	 * @author TCS
	 *         <h2>parseResponse</h2>
	 * @Created On : 03-May-2013
	 * @Description : This method is used Fetch the content of given Tag from Web
	 *              Service Respnse.
	 * @param response
	 * @param tagName
	 * @return
	 */
	public static String parseResponse(String response, String tagName) {
		String retMsg = null;

		String startTag = "<" + tagName + ">";
		String endTag = "</" + tagName + ">";

		if (response.contains(startTag)) {

			int startIndex = response.indexOf(startTag) + startTag.length();
			int endIndex = response.indexOf(endTag);

			retMsg = response.substring(startIndex, endIndex);

		} else {

			retMsg = null;
		}

		return retMsg;
	}

	/**
	 * <p>
	 * This Method is used to Split given String in given Size and return HashMap of
	 * Same.
	 * </p>
	 * 
	 * @param msgText   : Input Message.
	 * @param msgLength : Length of Characters of Which Set of Strings to prepare.
	 * @param limit     : Minimum Characters which should be present in Text. Always
	 *                  Less than or equal to msgLength.
	 * @return
	 */
	public static Map<String, String> splitMessage(String msgText, int msgLength, int limit) {

		String tmpStr = "";
		String msgTxt = msgText;
		HashMap<String, String> msgPartMap = new HashMap<>();
		String methodName = "splitMessage";

		int splitSize = 0;
		int start = 0;
		int msgParts = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName, "Entered Method");

		if (msgTxt.length() > limit) {

			splitSize = msgLength;

			while (msgTxt.trim().length() > 0) {

				msgParts = msgParts + 1;

				FLogger.debug(logger,  THIS_CLASS, methodName,
						MSG_PART_NUMBER + msgParts + " | msgTxt Length " + msgTxt.length());

				if (msgTxt.length() < splitSize) {

					tmpStr = msgTxt.substring(start, start + msgTxt.length());

				} else {

					tmpStr = msgTxt.substring(start, start + splitSize);
				}

				FLogger.debug(logger,  THIS_CLASS, methodName,
						MSG_PART_NUMBER + msgParts + " | tmpStr Length " + tmpStr.length());

				msgPartMap.put("" + msgParts, tmpStr);

				int length = msgTxt.length();

				if (tmpStr.length() < msgText.length()) {

					if (tmpStr.length() < splitSize) {

						msgTxt = msgTxt.substring(start + tmpStr.length(), length);

					} else {

						msgTxt = msgTxt.substring(start + splitSize, length);
					}
				} else {

					msgText = "";
				}
			}

		} else {

			msgPartMap.put("" + 1, msgTxt);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting Method : msgPartMap size : " + msgPartMap.size());

		return msgPartMap;
	}

	/**
	 * <h2>splitUpdatedMessage</h2>
	 * <p>
	 * This Method is used to Split given String in given Size and return HashMap of
	 * Same.
	 * </p>
	 * 
	 * @param msgText   : Input Message.
	 * @param msgLength : Length of Characters of Which Set of Strings to prepare.
	 * @param limit     : Minimum Characters which should be present in Text. Always
	 *                  Less than or equal to msgLength.
	 * @return
	 */
	public static Map<String, String> splitUpdatedMessage(String msgText, int msgLength, int limit) {

		String tmpStr = "";
		String msgTxt = msgText;
		HashMap<String, String> msgPartMap = new HashMap<>();
		String methodName = "splitUpdatedMessage";

		int splitSize = LoggerConstants.NUM_160; // var to account for UDH
		int start = 0;
		int msgParts = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		if (msgTxt.length() > limit) {

			splitSize = msgLength;

			while (msgTxt.trim().length() > 0) {

				msgParts = msgParts + 1;

				FLogger.debug(logger,  THIS_CLASS, methodName,
						MSG_PART_NUMBER + msgParts + " | msgTxt Length " + msgTxt.length());

				if (msgTxt.length() < splitSize) {

					tmpStr = msgTxt.substring(start, start + msgTxt.length());

				} else {

					tmpStr = msgTxt.substring(start, start + splitSize);
				}

				FLogger.debug(logger,  THIS_CLASS, methodName,
						MSG_PART_NUMBER + msgParts + " | tmpStr Length " + tmpStr.length());

				int len = tmpStr.length();
				boolean addFlag = false;

				String temp = null;
				boolean loopFlg = true;
				int counter = 1;

				while (loopFlg) {

					if (len >= LoggerConstants.NUM_2) {

						temp = tmpStr.substring((tmpStr.length() - LoggerConstants.NUM_2), (tmpStr.length()));

						FLogger.debug(logger,  THIS_CLASS, methodName,
								"temp : " + temp + " | Loop counter : " + counter);

						if (temp.contains("%")) {

							tmpStr = tmpStr.substring(0, (tmpStr.length() - LoggerConstants.NUM_2));

						} else {

							loopFlg = Boolean.FALSE;
						}

						counter++;

					} else {

						FLogger.error(logger, THIS_CLASS, methodName,
								"Message len is less than 2 so stopping loop");
						loopFlg = Boolean.FALSE;
					}
				}

				msgPartMap.put("" + msgParts, tmpStr); // Putting splitted Message in Map

				FLogger.debug(logger,  THIS_CLASS, methodName,
						MSG_PART_NUMBER + msgParts + " |addFlag : " + addFlag);

				int length = msgTxt.length();

				if (tmpStr.length() < msgText.length()) {

					if (tmpStr.length() < splitSize) {

						msgTxt = msgTxt.substring(start + tmpStr.length(), length);

					} else {

						/*
						 * if(addFlag){ msgTxt=msgTxt.substring(start+tmpStr.length(),length); }else{
						 * msgTxt=msgTxt.substring(start+splitSize,length); }
						 */

						msgTxt = msgTxt.substring(start + splitSize, length);
					}
				} else {

					msgText = "";
				}
			}

		} else {

			msgPartMap.put("" + 1, msgTxt);
		}

		for (Map.Entry<String, String> record : msgPartMap.entrySet()) {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					" Key : " + record.getKey() + " | Value : " + record.getValue());
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);

		return msgPartMap;
	}

	/**
	 * <p>
	 * This Method is used to Combine given List of String into Single String
	 * </p>
	 * 
	 * @param recordCount
	 * @param msgMap
	 * @return
	 */
	public static String combineMessage(int recordCount, Map<String, String> msgMap) {

		String responseMsg = null;
		String methodName = "combineMessage";
		StringBuilder sb = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, "Entered Method with record Count :" + recordCount);

		try {

			if (msgMap != null && msgMap.size() > 0) {

				sb = new StringBuilder();

				for (int i = 1; i <= recordCount; i++) {
					sb.append(msgMap.get(String.valueOf(i)));
				}

				if (sb.length() > 0) {
					responseMsg = sb.toString();
				} 

			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD);
		}

		return responseMsg;

	}

	/**
	 * <p>
	 * This Method is used to provide Time difference between Two timestamps.
	 * </p>
	 * 
	 * @param currentTime
	 * @param oldTime
	 * @return
	 */
	public static Map<String, Long> calculateTimeDifferece(Timestamp currentTime, Timestamp oldTime) {

		HashMap<String, Long> responseMap = null;
		String methodName = "calculateTimeDifferece";

		long milliseconds1 = 0;
		long milliseconds2 = 0;
		long diff = 0;

		long diffSeconds = 0;
		long diffMinutes = 0;
		long diffHours = 0;
		long diffDays = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName, "Entered Method");

		try {

			milliseconds1 = oldTime.getTime();
			milliseconds2 = currentTime.getTime();

			diff = milliseconds2 - milliseconds1;
			diffSeconds = diff / 1000;
			diffMinutes = diff / (60 * 1000);
			diffHours = diff / (60 * 60 * 1000);
			diffDays = diff / (24 * 60 * 60 * 1000);

			FLogger.debug(logger,  THIS_CLASS, methodName, "diff : " + diff + " | diffSeconds : " + diffSeconds
					+ " | diffMinutes : " + diffMinutes + " | diffHours : " + diffHours + " | diffDays : " + diffDays);

			responseMap = new HashMap<>();
			responseMap.put("diffMilliSeconds", diff);
			responseMap.put("diffSeconds", diffSeconds);
			responseMap.put("diffMinutes", diffMinutes);
			responseMap.put("diffHours", diffHours);
			responseMap.put("diffDays", diffDays);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		if (responseMap != null) {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting Method : responseMap :" + responseMap.size());
		} else {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD);
		}

		return responseMap;
	}

	/**
	 * Returns the message encoding (e.g. utf-8)
	 *
	 * @param msg
	 * @return
	 * @throws javax.xml.soap.SOAPException
	 */
	public static String getMessageEncoding(SOAPMessage msg) throws SOAPException {

		String encoding = "utf-8";

		if (msg.getProperty(SOAPMessage.CHARACTER_SET_ENCODING) != null) {
			encoding = msg.getProperty(SOAPMessage.CHARACTER_SET_ENCODING).toString();
		}
		return encoding;
	}

	/**
	 * <p>
	 * Fetch Connection based on Data Source Name
	 * </p>
	 * 
	 * @param p_jndi
	 * @return
	 */
	public static Connection fetchConnection(String p_jndi) {

		String methodName = "fetchConnection";
		Connection connection = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, "Entering method with JNDI : " + p_jndi);

		try {

			InitialContext context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup(p_jndi);
			connection = dataSource.getConnection();

		} catch (NamingException e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} catch (SQLException e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting method");

		return connection;

	}

	/**
	 * @param input
	 * @return
	 */
	public static boolean validateNumOrDot(String input) {

		String methodName = "validateNumOrDot";
		boolean returnValue = false;
		double amt = 0.0;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + input);

		Pattern p = Pattern.compile("((\\d{1,9})(((\\.)(\\d{0,2})){0,1}))");
		Matcher m = p.matcher(input);

		if (m.matches()) {

			amt = Double.parseDouble(input);

			if (amt >= 0) {

				returnValue = Boolean.TRUE;
			} else {

				returnValue = Boolean.FALSE;
			}

		} else {
			returnValue = Boolean.FALSE;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + returnValue);

		return returnValue;
	}

	/**
	 * @author Tata Consultancy Services Ltd.
	 *         <p>
	 *         This method is used to Get Soap Response Object from Soap Response
	 *         XML sent as Input.
	 *         </p>
	 * @param responseXml
	 * @param tagName
	 * @param classNme
	 * @param classObj
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object getSoapResponse(String responseXml, String tagName, Class classNme, Object classObj) {

		String methodName = "getSoapResponse";
		Reader reader = null;
		XMLInputFactory factory = null;
		XMLStreamReader xsr = null;
		Object returnValue = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			FLogger.debug(logger,  THIS_CLASS, methodName, "Entering Inputs :" + classObj);

			reader = new StringReader(responseXml);
			factory = XMLInputFactory.newInstance();

			factory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, ""); // Compliant
			factory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");  // compliant

			/** Added properties for Disabling Xml eXternal Entity (XXE) attack */
			factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
			factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);

			xsr = factory.createXMLStreamReader(reader);

			xsr.nextTag(); // Advance to Envelope tag

			while (!xsr.getLocalName().equals(tagName)) {
				xsr.nextTag();
			}

			JAXBContext jc = JAXBContext.newInstance(classNme);
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			JAXBElement<Object> je = unmarshaller.unmarshal(xsr, classNme);

			if (je != null) {
				returnValue = je.getValue();
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return returnValue;
	}

	/**
	 * @author Tata Consultancy Services Ltd.
	 *         <p>
	 *         This method is used to Get Soap Response Object from Soap Response
	 *         XML sent as Input.
	 *         </p>
	 * @param responseXml
	 * @param tagName
	 * @param classNme
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object getSoapResponse(String responseXml, String tagName, Class classNme) {

		String methodName = "getSoapResponse";
		Reader reader = null;
		XMLInputFactory factory = null;
		XMLStreamReader xsr = null;
		Object returnValue = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			reader = new StringReader(responseXml);
			factory = XMLInputFactory.newInstance();

			factory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, ""); // Compliant
			factory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");  // compliant

			/** Added properties for Disabling Xml eXternal Entity (XXE) attack */
			factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
			factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);

			xsr = factory.createXMLStreamReader(reader);
			
			xsr.nextTag(); // Advance to Envelope tag

			while (!xsr.getLocalName().equals(tagName)) {
				xsr.nextTag();
			}

			JAXBContext jc = JAXBContext.newInstance(classNme);
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			JAXBElement<Object> je = unmarshaller.unmarshal(xsr, classNme);

			if (je != null) {
				returnValue = je.getValue();
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return returnValue;
	}

	

	 /**
���� * @author Tata Consultancy Services Ltd.
���� *�������� <p>
���� *�������� This method is used to Check if given Url is Http or https. Checks
���� *�������� the beginning of a String for https. Returns true for Strings that
���� *�������� begin with https. Returns false otherwise.
���� *�������� </p>
���� * @param urlString : Url String
���� * @return true : if Url is https false : if Url is http
���� */
	public static Boolean connectionIsHttps(String urlString) {
		
		String methodName = "connectionIsHttps";
		boolean returnFlg = false;
		
		FLogger.debug(logger,THIS_CLASS, methodName, ENTERING_METHOD + methodName);
		
		if (urlString.contains("https")) {
			returnFlg = true;
		} else {
			returnFlg = false;
		}
		
		FLogger.debug(logger,THIS_CLASS, methodName,
				"ENTERING_METHOD" + methodName + " with returnFlg : " + returnFlg);
		return returnFlg;
	}



	/**
	 * @author Tata Consultancy Services Ltd.
	 *         <p>
	 *         Uses connectionIsHttps to determine whether the String starts with
	 *         https. If the string starts with https, it returns a substring
	 *         strating at index 8 and ending at the next occurrence of forward
	 *         slash. If not, it starts at index 7. This is to accomodate https://
	 *         versus http:// The host name is assumed to be located between :// and
	 *         the next occurrence of /
	 *         </p>
	 * @param urlString
	 * @return
	 */
	public static String getHostNameFromUrl(String urlString) {

		String methodName = "getHostNameFromUrl";
		String hostName = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		if (connectionIsHttps(urlString)) {
			hostName = urlString.substring(LoggerConstants.NUM_8, urlString.indexOf('/', LoggerConstants.NUM_8));
		} else {
			hostName = urlString.substring(LoggerConstants.NUM_7, urlString.indexOf('/', LoggerConstants.NUM_7));
		}

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERING_METHOD + methodName + " with hostName : " + hostName);

		return hostName;

	}

	/**
	 * @author Tata Consultancy Services Ltd.
	 *         <p>
	 *         This method is used to Convert given Java Object with Jaxb
	 *         annotations into XML.
	 *         </p>
	 * @param record
	 * @param objectClass
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static String soapObjToXmlConverter(Object record, Class objectClass) {

		String methodName = "soapObjToXmlConverter";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		String responseXML = "";

		try {
			if (record != null) {

				JAXBContext context = JAXBContext.newInstance(objectClass);
				responseXML = marshalAsString(context, record);

			} else {
				responseXML = null;
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting Method soapObjToXmlConverter");
		}

		return responseXML;
	}

	/**
	 * @author Tata Consultancy Services Ltd.
	 *         <p>
	 *         This method is used to Convert given Java Object with Jaxb
	 *         annotations into XML.
	 *         </p>
	 * @param record
	 * @param objectClass
	 * @return
	 */
	public static String soapObjToXmlConverter(Object record, JAXBContext context) {

		String methodName = "soapObjToXmlConverter";
		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		String responseXML = "";

		try {
			if (record != null) {

				responseXML = marshalAsString(context, record);

			} else {
				responseXML = null;
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting Method soapObjToXmlConverter");
		}

		return responseXML;
	}

	/**
	 * @author Tata Consultancy Services Ltd.
	 *         <p>
	 *         This method is used to Create Soap Request Message based on Xml
	 *         Passed of Object after marshalling it using jaxb & Header.
	 *         </p>
	 * @param messageFragment
	 * @param header          : If header needs to be Passed, pass in this field
	 *                        else pass null.
	 * @return
	 */
	public static String fixSOAPRequestMessage(String messageFragment, String header) {

		String methodName = "fixSOAPRequestMessage";
		String wholeMessage = null;
		String lvMessageFragment = null;
		String lvHeaderFragment = null;

		/** Start of Soap Envelope */
		String top = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
				+ "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">";

		/** Start of Soap Body */
		String bodyStart = "<soapenv:Body>";

		/** Start of Soap Body */
		String headerStart = "<soapenv:Header>";

		/** Start of Soap Body */
		String headerEnd = "</soapenv:Header>";

		/** End of Soap Body & Envelope */
		String bottom = "</soapenv:Body></soapenv:Envelope>";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (messageFragment!=null && !StringChecks.isFieldEmpty(messageFragment)) {

				if (messageFragment.contains("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")) {

					/**
					 * Removing Starting <?xml version="1.0" encoding=UTF_8 standalone="yes"?>
					 * String from Input Message
					 */
					lvMessageFragment = messageFragment.substring(55);

				} else if (messageFragment.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {

					/**
					 * Removing Starting <?xml version="1.0" encoding=UTF_8?> String from Input
					 * Message
					 */
					lvMessageFragment = messageFragment.substring(38);

				}

				FLogger.debug(logger,  THIS_CLASS, methodName, "lvMessageFragment : " + lvMessageFragment
						+ " | messageFragment : " + messageFragment + " | header : " + header);

				if (!StringChecks.isFieldEmpty(header)) {

					/**
					 * Removing Starting <?xml version="1.0" encoding=UTF_8 standalone="yes"?>
					 * String from Input Header Message
					 */

					if (header!=null && header.contains("<?xml version")) {

						if (header.contains("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")) {

							/**
							 * Removing Starting <?xml version="1.0" encoding=UTF_8 standalone="yes"?>
							 * String from Input Message
							 */
							lvHeaderFragment = header.substring(55);

						} else if (header.contains("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {

							/**
							 * Removing Starting <?xml version="1.0" encoding=UTF_8?> String from Input
							 * Message
							 */
							lvHeaderFragment = header.substring(38);

						}
					} else {
						lvHeaderFragment = header;
					}

					FLogger.debug(logger,  THIS_CLASS, methodName,
							"lvHeaderFragment : " + lvHeaderFragment + " | header : " + header);

					/** If Header is Passed then Adding Same before soap Body. */
					wholeMessage = top + headerStart + lvHeaderFragment + headerEnd + bodyStart + lvMessageFragment
							+ bottom;

				} else {
					wholeMessage = top + bodyStart + lvMessageFragment + bottom;
				}
			} else {

				FLogger.error(logger, THIS_CLASS, methodName, "Input is Empty or Null.");
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}finally {

			FLogger.debug(logger,  THIS_CLASS, methodName,
					ENTERING_METHOD + methodName + " with soap Req Msg : " + wholeMessage);
			
		}
		
		return wholeMessage;
	}

	/**
	 * @param messageFragment
	 * @return
	 * @throws IOException
	 */
	public static String stripSOAPReplyMessage(String messageFragment) throws IOException {

		String strippedMessage = messageFragment;
		String badString = "xsi:nil=\"true\"";
		strippedMessage = strippedMessage.replaceAll(badString, "");
		strippedMessage = strippedMessage.substring(216, strippedMessage.length() - 28);

		return strippedMessage;
	}

	/**
	 * @author TCS
	 *         <h2>timeStampGenerator</h2>
	 *         <p>
	 *         This method returns timestamp in 'yyyyMMddHHmmss' format which is 20
	 *         minutes before the current time.<br>
	 *         e.g : Current time : 20120426073033 <br>
	 *         Output TimeStamp : 20120426071033
	 *         </p>
	 * @return
	 */
	public static String timeStampGenerator(int minutes, String pattern) {

		String methodName = "timeStampGenerator";
		String transTimeStamp = "";

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, -minutes);

		Date transDate = cal.getTime();
		transTimeStamp = getStrFrmDate(transDate, pattern);

		FLogger.debug(logger,  THIS_CLASS, methodName, "TimeStamp Generated ::" + transTimeStamp);

		return transTimeStamp;

	}

	/**
	 * Applies the specified mask to the card number.
	 * 
	 * @param cardNumber The card number in plain format
	 * @param mask       The number mask pattern. Use # to include a digit from the
	 *                   card number at that position, use x to skip the digit at
	 *                   that position
	 *
	 * @return The masked card number
	 */
	public static String maskCardNumber(String cardNumber, String mask) {

		// format the number
		int index = 0;
		StringBuilder maskedNumber = new StringBuilder();

		for (int i = 0; i < mask.length(); i++) {

			char c = mask.charAt(i);
			if (c == '#') {
				maskedNumber.append(cardNumber.charAt(index));
				index++;
			} else if (c == 'x') {
				maskedNumber.append(c);
				index++;
			} else {
				maskedNumber.append(c);
			}
		}

		// return the masked number
		return maskedNumber.toString();
	}

	/**
	 * @param <T>
	 * @Description This Generic method will return true if Collection is empty else
	 *              return false if Collection is not empty
	 * @param Collection Object
	 * @return
	 */
	public static <T> boolean isCollectionEmpty(Collection<T> collection) {

		boolean validFlag = Boolean.FALSE;
		String methodName = "isCollectionEmpty";

		try {

			if (collection != null && !collection.isEmpty()) {
				validFlag = Boolean.FALSE;
			} else {
				validFlag = Boolean.TRUE;
			}
		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName,
					"Error in Checking for collection is empty or not");
			
		}

		return validFlag;

	}

	/**
	 * @param <T>
	 * @param <K>
	 * @param <V>
	 * @Description This Generic method will return true if Collection is empty else
	 *              return false if Collection is not empty
	 * @param values
	 * @param batchSize
	 * @return
	 */
	public static <T, K, V> boolean isMapEmpty(Map<K, V> collection) {

		boolean validFlag = Boolean.FALSE;
		String methodName = "isCollectionEmpty";

		try {

			if (collection != null && !collection.isEmpty()) {
				validFlag = Boolean.FALSE;
			} else {
				validFlag = Boolean.TRUE;
			}
		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName,
					"Error in Checking for Collection is empty or not");
			
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					EXITING_METHOD + methodName + " with validFlag : " + validFlag);
		}

		return validFlag;

	}

	/**
	 * @param <T>
	 * @Description This Generic method will return the Batches of List of Object in
	 *              Given batch size
	 * @param values
	 * @param batchSize
	 * @return
	 */
	public static <T> List<List<T>> generateGenericBatch(List<T> values, int batchSize) {

		int size = 0;
		List<List<T>> outputList = new ArrayList<>();
		int numOfItrations = 0;
		String methodName = "generateGenericBatch";
		int i = 0;
		int lowerLimit = 0;
		int upperLimit = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (values != null && !values.isEmpty()) {

				size = values.size();

				if (size > 0) {

					FLogger.debug(logger,  THIS_CLASS, methodName,
							"lowerLimit : " + lowerLimit + " | upperLimit : " + upperLimit);

					numOfItrations = size / batchSize;

					/**
					 * If Modulo division of Records size and batch Size is non-zero then increment
					 * number of Iterations.
					 */
					if (size % batchSize > 0) {
						numOfItrations += 1;
					}

					FLogger.debug(logger,  THIS_CLASS, methodName, "Number Of iterations :" + numOfItrations
							+ " for Batch Size : " + batchSize + " | values Size::" + size);

					/**
					 * For Start ,Upper limit will be set as Batch size which is passed and lower
					 * limit will be 0
					 */
					lowerLimit = 0;
					upperLimit = batchSize;

					while (i < numOfItrations) {

						if (i > 0) {

							/**
							 * After first Iteration, Lower limit =Upper Limit & UpperLimit = (Old Upper
							 * Limit)+Batch Size.
							 */
							lowerLimit = upperLimit;
							upperLimit += batchSize;

							/**
							 * Checking if upperLimit is greater than records size then set Upper limit will
							 * be set to Records Size.
							 */
							if (upperLimit > size) {
								upperLimit = size;
							}

						} else {

							/**
							 * Checking if Batch Size is greater than Records size then set Upper limit will
							 * be set to Records Size.
							 */

							if (upperLimit > size) {
								upperLimit = size;
							}
						}

						FLogger.debug(logger,  THIS_CLASS, methodName, "Iteration Num:: " + i + " LowerLimit:: "
								+ lowerLimit + " | UpperLimit::" + upperLimit);

						List<T> tempList = new ArrayList<>();

						for (; lowerLimit < upperLimit; lowerLimit++) {
							tempList.add(values.get(lowerLimit));
						}

						outputList.add(tempList);
						i++;
					}
				}
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.error(logger, THIS_CLASS, methodName,
					EXITING_METHOD + "" + methodName + " with outputList : " + outputList.size());
		}

		return outputList;
	}

	/**
	 * @author TCS
	 * @creationDate : 26-Mar-2015
	 *               <h2>listFilesForFolder</h2>
	 *               <p>
	 *               This method is used to Fetch Details of Files in given Folder
	 *               Directory
	 *               </p>
	 * @param folder    : Folder File Object in which search needs to be carried out
	 * @param extension : e.g 'csv'/'txt', <br/>
	 *                  provide this value if Search is required on basis of
	 *                  Extension of file.
	 * 
	 * @return HashMap containing : <br/>
	 *         <ul>
	 *         <li>Key : Folder Name</li>
	 *         <li>Value : List of File Objects.</li>
	 *         </ul>
	 */
	public static Map<String, List<File>> listFilesForFolder(File folder, String extension) {

		String methodName = "listFilesForFolder";

		HashMap<String, List<File>> fileMap = new HashMap<>();
		List<File> files = new ArrayList<>();

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (folder != null) {

				for (File fileEntry : folder.listFiles()) {

					if (fileEntry.isDirectory()) {

						FLogger.error(logger, THIS_CLASS, methodName, "" + fileEntry.getName()
								+ " is directory.Entering Directory for Fetching Files Details");
						fileMap.putAll(listFilesForFolder(fileEntry, extension));

					} else {

						FLogger.debug(logger,  THIS_CLASS, methodName, "" + fileEntry.getName() + " is File");

						if (!StringChecks.isFieldEmpty(extension)) {

							if (fileEntry.getName().endsWith("." + extension)) {

								if (fileMap.containsKey(folder.getName())) {

									files = fileMap.get(folder.getName());
									files.add(fileEntry.getAbsoluteFile());
									fileMap.put(folder.getName(), files);

								} else {

									files = new ArrayList<>();
									files.add(fileEntry.getAbsoluteFile());
									fileMap.put(folder.getName(), files);

								}
							}

						} else {

							if (fileMap.containsKey(folder.getName())) {

								files = fileMap.get(folder.getName());
								files.add(fileEntry.getAbsoluteFile());
								fileMap.put(folder.getName(), files);

							} else {

								files = new ArrayList<>();
								files.add(fileEntry.getAbsoluteFile());
								fileMap.put(folder.getName(), files);

							}
						}
					}
				}
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					EXITING_METHOD + "" + methodName + " with fileMap : " + fileMap.size());
		}

		return fileMap;
	}

	/**
	 * @author TCS
	 * @creationDate : 12-Dec-2015
	 *               <h2>getFilesFrmDir</h2>
	 *               <p>
	 *               This method is used to get the List of files created in
	 *               particular Directory of input extension.
	 *               </p>
	 * @param directory
	 * @param extension
	 * @return
	 */
	public static List<String> getFilesFrmDir(String directory, String extension) {

		List<String> fileNames = new ArrayList<>();

		ExtensionFilter2 filter = null;
		File dir = new File(directory);
		String methodName = "getFilesFrmDir";

		File[] list = null;

		try {

			FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

			if (StringChecks.isFieldEmpty(extension)) {
				list = dir.listFiles();
			} else {

				filter = new ExtensionFilter2(extension);
				list = dir.listFiles(filter);
			}

			if (list != null && list.length > 0) {

				Arrays.sort(list, Comparator.comparingLong(File::lastModified).reversed());

				FLogger.debug(logger,  THIS_CLASS, methodName, LIST_OF_FILES_IN_DIRECTORY + list.length);

				for (int i = 0; i < list.length; i++) {
					fileNames.add(list[i].getName());
				}
			}

			for (String s : fileNames) {
				FLogger.debug(logger,  THIS_CLASS, methodName, FILE_CREATED + s + "\n");
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return fileNames;

	}

	/**
	 * @author TCS
	 * @creationDate : 12-Dec-2015
	 *               <h2>fetchFilesFrmDir</h2>
	 *               <p>
	 *               This method is used to get the List of files created in
	 *               particular Directory containing given input text or extension.
	 *               </p>
	 * @param directory
	 * @param extension
	 * @return
	 */
	public static List<File> fetchFilesFrmDir(String directory, String extension) {

		List<File> filesList = new ArrayList<>();

		ExtensionFilter2 filter = null;
		File dir = new File(directory);
		String methodName = "fetchFilesFrmDir";

		File[] list = null;

		try {

			FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

			if (StringChecks.isFieldEmpty(extension)) {

				list = dir.listFiles();

			} else {

				filter = new ExtensionFilter2(extension);
				list = dir.listFiles(filter);
			}

			if (list != null && list.length > 0) {

				Arrays.sort(list, Comparator.comparingLong(File::lastModified).reversed());

				FLogger.debug(logger,  THIS_CLASS, methodName, LIST_OF_FILES_IN_DIRECTORY + list.length);

				for (int i = 0; i < list.length; i++) {
					filesList.add(list[i]);
				}
			}

			for (File s : filesList) {
				FLogger.debug(logger,  THIS_CLASS, methodName, FILE_CREATED + s.getName() + "\n");
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return filesList;
	}

	/**
	 * @author TCS
	 * @creationDate : 21-07-2020
	 *               <h2>fetchFilesFrmDirOrderBySizeDesc</h2>
	 *               <p>
	 *               This method is used to get the List of files created in
	 *               particular Directory containing given input text or extension.
	 *               </p>
	 * @param directory
	 * @param extension
	 * @return
	 */
	public static List<File> fetchFilesFrmDirOrderBySizeDesc(String directory, String extension) {

		List<File> filesList = new ArrayList<>();

		ExtensionFilter2 filter = null;
		File dir = new File(directory);
		String methodName = "fetchFilesFrmDirOrderBySizeDesc";

		File[] list = null;

		try {

			FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

			if (StringChecks.isFieldEmpty(extension)) {

				list = dir.listFiles();

			} else {

				filter = new ExtensionFilter2(extension);
				list = dir.listFiles(filter);
			}

			if (list != null && list.length > 0) {

				Arrays.sort(list, Comparator.comparingLong(File::length).reversed());

				FLogger.debug(logger,  THIS_CLASS, methodName, LIST_OF_FILES_IN_DIRECTORY + list.length);

				for (int i = 0; i < list.length; i++) {
					filesList.add(list[i]);
				}
			}

			for (File s : filesList) {
				FLogger.debug(logger,  THIS_CLASS, methodName, FILE_CREATED + s.getName() + "\n");
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return filesList;
	}

	/**
	 * @author TCS
	 * @creationDate : 21-07-2020
	 *               <h2>fetchFilesFrmDirOrderBySizeAsc</h2>
	 *               <p>
	 *               This method is used to get the List of files created in
	 *               particular Directory containing given input text or extension.
	 *               </p>
	 * @param directory
	 * @param extension
	 * @return
	 */
	public static List<File> fetchFilesFrmDirOrderBySizeAsc(String directory, String extension) {

		List<File> filesList = new ArrayList<>();

		ExtensionFilter2 filter = null;
		File dir = new File(directory);
		String methodName = "fetchFilesFrmDirOrderBySizeAsc";

		File[] list = null;

		try {

			FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

			if (StringChecks.isFieldEmpty(extension)) {

				list = dir.listFiles();

			} else {

				filter = new ExtensionFilter2(extension);
				list = dir.listFiles(filter);
			}

			if (list != null && list.length > 0) {

				Arrays.sort(list, Comparator.comparingLong(File::length));

				FLogger.debug(logger,  THIS_CLASS, methodName, LIST_OF_FILES_IN_DIRECTORY + list.length);

				for (int i = 0; i < list.length; i++) {
					filesList.add(list[i]);
				}
			}

			for (File s : filesList) {
				FLogger.debug(logger,  THIS_CLASS, methodName, FILE_CREATED + s.getName() + "\n");
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return filesList;
	}

	/**
	 * @author TCS
	 * @creationDate : 01-Apr-2015
	 *               <h2>getPaddedAmount</h2>
	 *               <p>
	 *               This method is used to get input Amount left padded with 0 of
	 *               given digits.
	 *               </p>
	 * @param amount
	 * @param paddedDigits
	 * @return
	 */
	public static String getPaddedAmount(int amount, int paddedDigits) {

		String methodName = "getPaddedAmount";
		String returnValue = null;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (!StringChecks.isFieldEmpty(String.valueOf(amount))) {

				if (paddedDigits > 0) {
					returnValue = String.format("%0" + paddedDigits + "d", amount);
				} else {
					returnValue = String.valueOf(amount);
				}
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					EXITING_METHOD + "" + methodName + " with returnValue : " + returnValue);
		}

		return returnValue;
	}

	/**
	 * @author TCS
	 *         <h2>getFilesNamesFrmDirectory</h2>
	 * @since 14-Oct-2015
	 *        <p>
	 *        This method is used to get the List of files present in particular
	 *        Directory with input extension.
	 *        </p>
	 * @param directory
	 * @param extension
	 * @return
	 */
	public static List<String> getFilesNamesFrmDirectory(String directory, String extension) {

		List<String> fileNames = new ArrayList<>();
		ExtensionFilter filter = new ExtensionFilter(extension);
		File dir = new File(directory);

		String methodName = "getFilesNamesFrmDirectory";
		String[] list = dir.list(filter);
		File file;

		if (list != null) {

			FLogger.debug(logger,  THIS_CLASS, methodName, LIST_OF_FILES_IN_DIRECTORY + list.length);

			for (int i = 0; i < list.length; i++) {
				file = new File(directory, list[i]);
				fileNames.add(file.getName());
			}
		}

		for (String s : fileNames) {
			FLogger.debug(logger,  THIS_CLASS, methodName, "File Fetched :: " + s + "\n");
		}

		return fileNames;
	}

	/**
	 * @author TCS
	 * @modifiedDate 31-Dec-2013
	 *               <h2>removeDirectory</h2>
	 *               <p>
	 *               This method is used to delete the Directory and its Contents.
	 *               </p>
	 * @param directory File Object
	 * @return
	 */
	public static boolean removeDirectory(File directory) {

		String methodName = "removeDirectory";

		FLogger.debug(logger,  THIS_CLASS, methodName, "Directory to be Removed:: " + directory);

		if (directory == null) {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Directory is Null");
			return false;
		}

		if (!directory.exists()) {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Directory does not exist");
			return true;
		}

		if (!directory.isDirectory()) {
			FLogger.debug(logger,  THIS_CLASS, methodName, "Input File is Not directory");
			return false;
		}

		String[] list = directory.list();

		if (list != null) {
			for (int i = 0; i < list.length; i++) {
				File entry = new File(directory, list[i]);

				FLogger.debug(logger,  THIS_CLASS, methodName, "removing entry " + entry);

				if (entry.isDirectory()) {
					if (!removeDirectory(entry))
						return false;
				} else {
					if (!entry.delete())
						return false;
				}
			}
		}

		return directory.delete();
	}

	/**
	 * @author TCS
	 * @since 09-Jan-2015
	 *        <h3>handleFileMovement</h3>
	 *        <p>
	 *        This Method moves the excel Files used for Data Upload to backup
	 *        directory.
	 *        </p>
	 * @param directoryPath : Folder name in which files to be moved.
	 * @param originalFile  : File which needs to be moved
	 * @param extension     : extension of the file.
	 * @throws IOException
	 */
	public static void handleFileMovement(String directoryPath, File originalFile, String extension) {

		String destinationFilePath = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DDMMYYYYHHMMSS);
		String fileName = null;
		String tmpFileNme = null;
		Boolean fileRename=Boolean.FALSE;
		String extensionNew = null;
		StringBuilder sb = null;

		String methodName = "handleFileMovement";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (originalFile != null) {

				destinationFilePath = directoryPath + File.separator;

				File file = new File(destinationFilePath);

				/** If given File does not exist then create it */
				if (!file.exists()) {
					file.mkdirs();
				}

				fileName = originalFile.getName(); // test.xls
				tmpFileNme = fileName.substring(0, fileName.lastIndexOf(".")); // test
				extensionNew = fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());

				sb = new StringBuilder();
				sb.append(tmpFileNme);
				sb.append("_");
				sb.append(simpleDateFormat.format(Calendar.getInstance().getTime()));
				sb.append('.');
				sb.append(extensionNew);

				destinationFilePath = destinationFilePath + sb.toString();

				FLogger.error(logger, THIS_CLASS, methodName, "Updated File Path : " + destinationFilePath);

				/** Renaming the Original File with new File path */
			 fileRename = originalFile.renameTo(new File(destinationFilePath));		
			
			FLogger.debug(logger,  THIS_CLASS, methodName, "fileRename :" + fileRename);
			 
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}
	}

	/**
	 * @author TCS
	 * @since 09-Jan-2015
	 *        <h3>handleFileMovement</h3>
	 *        <p>
	 *        This Method moves the excel Files used for Data Upload to backup
	 *        directory.
	 *        </p>
	 * @param directoryPath : Folder name in which files to be moved.
	 * @param originalFile  : File which needs to be moved
	 * @param extension     : extension of the file.
	 * @throws IOException
	 */
	public static void handleFileMovement(String directoryPath, File originalFile) {

		String destinationFilePath = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DDMMYYYYHHMMSS);
		String fileName = null;
		String tmpFileNme = null;
		Boolean fileRename=Boolean.FALSE;

		StringBuilder sb = null;

		String methodName = "handleFileMovement";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (originalFile != null) {

				destinationFilePath = directoryPath + File.separator;

				File file = new File(destinationFilePath);

				/** If given File does not exist then create it */
				if (!file.exists()) {
					file.mkdirs();
				}

				fileName = originalFile.getName(); // test.xls
				tmpFileNme = fileName.substring(0, fileName.lastIndexOf(".")); // test
				String extension = fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());

				sb = new StringBuilder();
				sb.append(tmpFileNme);
				sb.append("_");
				sb.append(simpleDateFormat.format(Calendar.getInstance().getTime()));
				sb.append('.');
				sb.append(extension);

				destinationFilePath = destinationFilePath + sb.toString();

				FLogger.error(logger, THIS_CLASS, methodName, "Updated File Path : " + destinationFilePath);

				/** Renaming the Original File with new File path */
				fileRename=	originalFile.renameTo(new File(destinationFilePath));
				FLogger.debug(logger,  THIS_CLASS, methodName, "fileRename :" + fileRename);
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}
	}

	/**
	 * @author TCS
	 *         <h2>createFolder</h2>
	 * @description This Method Creates the particular folder at particular
	 *              directory.
	 * @param folderDirectoryNme
	 * @param folderNme
	 * @return
	 */
	public static String createFolder(String folderDirectoryNme, String folderNme) {

		String folderPath = null;
		File f = null;
		boolean success = Boolean.FALSE;

		String methodName = "createFolder";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			folderPath = folderDirectoryNme + File.separator + folderNme;

			f = new File(folderPath);

			success = f.mkdir();

			FLogger.error(logger, THIS_CLASS, methodName, "Folder Creation is Successful? " + success);

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			folderPath = null;

		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					EXITING_METHOD + "" + methodName + " with folderPath : " + folderPath);
		}

		return folderPath;
	}

	/**
	 * @author TCS
	 * @since 14-Oct-2015
	 *        <h2>readFileContent</h2>
	 *        <p>
	 *        This Method Parses Content of the input File and Sends same in String
	 *        Object
	 *        </p>
	 * @param filePath : absolute Path of File to be Passed whose content needs to
	 *                 be fetched.
	 * @return String : Containing Content of file if file is not empty and exists.
	 */
	public static String readFileContent(String filePath) {

		FileInputStream fis = null;

		int content = 0;

		String methodName = READ_FILE_CONTENT;

		String fileContent = null;
		StringBuilder sb = null;

		try {

			if (!StringChecks.isFieldEmpty(filePath)) {

				fis = new FileInputStream(new File(filePath));

				sb = new StringBuilder();

				while ((content = fis.read()) != -1) {
					sb.append((char) content);
				}

				if (sb != null && sb.length() > 0) {
					fileContent = sb.toString();
				}

			} 

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			try {

				if (fis != null) {
					fis.close();
				}
			} catch (IOException ex) {
				StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);
			}

		}

		return fileContent;
	}

	/**
	 * @author TCS
	 * @since 14-Oct-2015
	 *        <h2>readFileContent</h2>
	 *        <p>
	 *        This Method Parses Content of the input File and Sends same in String
	 *        Object
	 *        </p>
	 * @param folderNme : Folder Name
	 * @param fileNme   : Name of file to be Read.
	 * @return String : Containing Content of file if file is not empty and exists.
	 */
	public static String readFileContent(String folderNme, String fileNme) {

		FileInputStream fis = null;

		int content = 0;

		String methodName = READ_FILE_CONTENT;

		String filePath = null;
		String fileContent = null;
		StringBuilder sb = null;

		try {

			if (!StringChecks.isFieldEmpty(fileNme) && !StringChecks.isFieldEmpty(folderNme)) {

				filePath = folderNme + File.separator + fileNme;

				fis = new FileInputStream(new File(filePath));

				sb = new StringBuilder();

				while ((content = fis.read()) != -1) {
					sb.append((char) content);
				}

				if (sb != null && sb.length() > 0) {
					fileContent = sb.toString();
				}

			}
		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			try {

				if (fis != null) {
					fis.close();
				}
			} catch (IOException ex) {
				StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);
			}

		}

		return fileContent;
	}

	/**
	 * @author TCS
	 * @since 14-Oct-2015
	 *        <h2>readFileContent</h2>
	 *        <p>
	 *        This Method Parses Content of the input File and Sends same in String
	 *        Object
	 *        </p>
	 * @param file : File Object which is needed to be processed
	 * @return String : Containing Content of file if file is not empty and exists.
	 */
	public static String readFileContent(File file) {

		FileInputStream fis = null;

		int content = 0;

		String methodName = READ_FILE_CONTENT;

		String fileContent = null;
		StringBuilder sb = null;

		try {

			if (file != null && file.exists()) {

				fis = new FileInputStream(file);

				sb = new StringBuilder();

				while ((content = fis.read()) != -1) {
					sb.append((char) content);
				}

				if (sb != null && sb.length() > 0) {
					fileContent = sb.toString();
				}

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			try {

				if (fis != null) {
					fis.close();
				}
			} catch (IOException ex) {
				StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);
			}

		}

		return fileContent;
	}

	/**
	 * @author TCS
	 * @since 14-Oct-2015
	 *        <h2>readFileContent</h2>
	 *        <p>
	 *        This Method Parses Content of the input File and Sends same in String
	 *        Object
	 *        </p>
	 * @param filePath : absolute Path of File to be Passed whose content needs to
	 *                 be fetched.
	 * @return String : Containing Content of file if file is not empty and exists.
	 */
	public static List<String> readFileLines(String filePath) {

		String methodName = READ_FILE_LINES;

		List<String> fileContent = null;

		BufferedReader br = null;
		String line = null;

		try {

			if (!StringChecks.isFieldEmpty(filePath)) {

				fileContent = new ArrayList<>();

				br = new BufferedReader(new FileReader(filePath));

				while ((line = br.readLine()) != null) {
					fileContent.add(line);
				}

			} 

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			try {

				if (br != null) {
					br.close();
				}

			} catch (IOException ex) {
				StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);
			}

		}

		return fileContent;
	}

	/**
	 * @author TCS
	 * @since 14-Apr-2016
	 *        <h2>readGzipFileLines</h2>
	 *        <p>
	 *        This Method Parses Content of the input File and Sends same in List of
	 *        String
	 *        </p>
	 * @param folderNme : Folder Name
	 * @param fileNme   : Name of file to be Read.
	 * @return String : Containing Content of file if file is not empty and exists.
	 */
	public static List<String> readFileLines(File file) {

		String methodName = READ_FILE_LINES;

		List<String> fileContent = null;

		BufferedReader br = null;
		String line = null;

		try {

			if (file != null && file.exists()) {

				fileContent = new ArrayList<>();

				br = new BufferedReader(new FileReader(file));

				while ((line = br.readLine()) != null) {
					fileContent.add(line);
				}

			} 

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			try {

				if (br != null) {
					br.close();
				}

			} catch (IOException ex) {
				StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);
			}

		}

		return fileContent;
	}

	public static List<String> readFileLinesForNull(File file) {

		String methodName = READ_FILE_LINES;

		List<String> fileContent = null;
		List<String> fileContentForNull = null;
		BufferedReader br = null;

		try {

			if (file != null && file.exists()) {

				fileContent = new ArrayList<>();

				br = new BufferedReader(new FileReader(file));
				fileContentForNull = new ArrayList<>();
				fileContentForNull.add(br.readLine());

				if (StringChecks.isCollectionEmpty(fileContentForNull)) {
					for (String itr : fileContentForNull) {
						fileContent.add(itr);
					}

				} else {
					FLogger.debug(logger,  THIS_CLASS, methodName, "fileContentForNull is empty");
				}

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			try {

				if (br != null) {
					br.close();
				}

			} catch (IOException ex) {
				StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);
			}

		}

		return fileContent;
	}

	/**
	 * @author TCS
	 * @since 14-Apr-2016
	 *        <h2>readGzipFileLines</h2>
	 *        <p>
	 *        This Method Parses Content of the input File and Sends same in List of
	 *        String
	 *        </p>
	 * @param folderNme : Folder Name
	 * @param fileNme   : Name of file to be Read.
	 * @return String : Containing Content of file if file is not empty and exists.
	 */
	public static List<String> readFileLines(String folderNme, String fileNme) {

		String methodName = READ_FILE_LINES;

		String filePath = null;
		List<String> fileContent = null;

		BufferedReader br = null;
		String line = null;

		try {

			if (!StringChecks.isFieldEmpty(fileNme) && !StringChecks.isFieldEmpty(folderNme)) {

				fileContent = new ArrayList<>();

				filePath = folderNme + File.separator + fileNme;

				br = new BufferedReader(new FileReader(new File(filePath)));

				while ((line = br.readLine()) != null) {
					fileContent.add(line);
				}

			} 

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			try {

				if (br != null) {
					br.close();
				}

			} catch (IOException ex) {
				StringChecks.printExceptionErrors(ex, logger, THIS_CLASS, methodName);
			}

		}

		return fileContent;
	}

	/**
	 * This methods takes filename as String ( Input parameter)
	 * 
	 * returns false if input string starts with - or _
	 * 
	 * else
	 * 
	 * returns true if input string starts with alphabet or numeric character and
	 * contains - or _ anywhere in the middle of the String before extension.
	 * 
	 * return type Boolean value
	 *
	 * @param fileName : This methods takes filename as String ( Input parameter)
	 * @return
	 */
	public static boolean validateFileNme(String fileName) {

		String methodName = "validateFileNme";
		boolean returnFlag = Boolean.FALSE;

		try {

			String pattern = "^(?!-)(?!_)[A-Za-z0-9_\\-]*([^_\\-])\\.[a-zA-Z]{1,5}$";
			// String pattern = "^(?!-)(?!_)[A-Za-z0-9_\-]*\.[a-zA-Z]{1,5}$";

			FLogger.error(logger, THIS_CLASS, methodName, ENTERING_METHOD + fileName);

			fileName = FilenameUtils.getName(fileName);
			FLogger.error(logger, THIS_CLASS, methodName, "File Name after Utils mehod -  :" + fileName);

			Pattern p = Pattern.compile(pattern);
			Matcher m = p.matcher(fileName);

			if (m.matches()) {

				FLogger.error(logger, THIS_CLASS, methodName, "Input file name matches pattern");

				returnFlag = Boolean.TRUE;

			} else {

				FLogger.error(logger, THIS_CLASS, methodName, "Input file name didn't match pattern");
			
			}

		} catch (Exception e) {

			FLogger.error(logger, THIS_CLASS, methodName, "Entered in catch block");
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + returnFlag);
		}

		return returnFlag;
	}

	/**
	 * <p>
	 * This method is used to fetch local/Destination machine IP address
	 * </p>
	 * 
	 * @param request
	 * @return
	 */
	public static String fetchLocalIpAddr() {

		String clientIp = null;
		InetAddress ip = null;

		String methodName = "fetchLocalIpAddr";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERED_METHOD + methodName);

		try {

			ip = InetAddress.getLocalHost();
			clientIp = ip.getHostAddress();

			try {
				FLogger.debug(logger,  THIS_CLASS, methodName, "CanonicalHostName " + ip.getCanonicalHostName()
						+ " | HostName :" + ip.getHostName() + " | HostAddress :" + ip.getHostAddress());
			} catch (Exception e) {

				FLogger.error(logger, THIS_CLASS, methodName,
						" Got Exception : " + e.getMessage() + DUE_TO + e.getCause(), e);

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, methodName);

		} finally {
			FLogger.debug(logger,  THIS_CLASS, methodName,
					EXITING_METHOD + methodName + " " + WITH_CLIENT_IP + clientIp);
		}

		return clientIp;
	}

	/**
	 * @param element
	 * @param maxLength
	 * @return
	 */
	public static boolean validateMaxLength(String element, int maxLength) {
		return (element != null && element.length() > maxLength);
	}

	/**
	 * @param conn
	 * @throws SQLException
	 */
	public static void closeConnection(Connection conn) throws SQLException {

		try {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		} catch (Exception e) {
			printExceptionErrors(e, logger, THIS_CLASS, CLOSE_CONNECTION);
		}

	}

	/**
	 * @param pStmt
	 * @param conn
	 * @throws SQLException
	 */
	public static void closeConnection(PreparedStatement pStmt, Connection conn) throws SQLException {

		try {

			if (pStmt != null) {
				pStmt.close();
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, CLOSE_CONNECTION);
		}

		try {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, CLOSE_CONNECTION);
		}

	}

	/**
	 * @param inputString
	 * @return
	 */
	public static String removeSpecialSymbols(String inputString) {

		String inputName = replaceSpaceWithSingleSpace(inputString);
		return inputName.replaceAll("[^a-zA-Z\\s]", "");
	}

	/**
	 * @param name
	 * @return
	 */
	public static String replaceSpaceWithSingleSpace(String name) {

		String respName = "";
		Pattern ptn = Pattern.compile("\\s+");
		Matcher mtch = ptn.matcher(name);
		respName = mtch.replaceAll(" ");

		return respName;
	}

	/**
	 * <p>
	 * <b>castInstanceOfObject</b> This method is used to cast given input object
	 * into provided Class instance Type. If invalid Object passed will return null.
	 * </p>
	 * 
	 * @param o
	 * @param clazz
	 * @return
	 */
	public static <T> T castInstanceOfObject(Object obj, Class<T> clazz) {

		try {
			return clazz.cast(obj);
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, "castInstanceOfObject");
			return null;
		}
	}

	/**
	 * <p>
	 * <b>getMacAddr</b> This method is used to to get MAC Address of the connected
	 * device.
	 * </p>
	 * 
	 * @return
	 */
	public static String getMacAddr() {

		String macAddr = "";
		InetAddress addr = null;
		String methodName = "getMacAddr";
		NetworkInterface dir = null;

		try {

			addr = InetAddress.getLocalHost();

			FLogger.debug(logger,  THIS_CLASS, methodName, "HostAddress :" + addr.getHostAddress());

			dir = NetworkInterface.getByInetAddress(addr);

			byte[] dirMac = dir.getHardwareAddress();

			int count = 0;

			for (int b : dirMac) {

				if (b < 0)
					b = 256 + b;

				if (b == 0) {
					macAddr = macAddr.concat("00");
				}

				if (b > 0) {

					int a = b / LoggerConstants.NUM_16;
					if (a == LoggerConstants.NUM_10)
						macAddr = macAddr.concat("A");
					else if (a == LoggerConstants.NUM_11)
						macAddr = macAddr.concat("B");
					else if (a == LoggerConstants.NUM_12)
						macAddr = macAddr.concat("C");
					else if (a == LoggerConstants.NUM_13)
						macAddr = macAddr.concat("D");
					else if (a == LoggerConstants.NUM_14)
						macAddr = macAddr.concat("E");
					else if (a == LoggerConstants.NUM_15)
						macAddr = macAddr.concat("F");
					else
						macAddr = macAddr.concat(String.valueOf(a));
					a = (b % LoggerConstants.NUM_16);
					if (a == LoggerConstants.NUM_10)
						macAddr = macAddr.concat("A");
					else if (a == LoggerConstants.NUM_11)
						macAddr = macAddr.concat("B");
					else if (a == LoggerConstants.NUM_12)
						macAddr = macAddr.concat("C");
					else if (a == LoggerConstants.NUM_13)
						macAddr = macAddr.concat("D");
					else if (a == LoggerConstants.NUM_14)
						macAddr = macAddr.concat("E");
					else if (a == LoggerConstants.NUM_15)
						macAddr = macAddr.concat("F");
					else
						macAddr = macAddr.concat(String.valueOf(a));
				}

				if (count < dirMac.length - 1)
					macAddr = macAddr.concat("-");

				count++;
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, "getMacAddr");
			macAddr = e.getMessage();
		}

		return macAddr;
	}

	// Check if it is a valid email id
	public static boolean isValidEmailId(String email) {
		boolean returnValue = false;

		Pattern p = Pattern.compile("^[a-zA-Z0-9._-]{1,}@[a-zA-Z0-9]{1,}.[a-zA-Z0-9]{2,}[a-zA-Z0-9.]{0,}$"); // Email id
																												// must
																												// of
																												// the
																												// form
																												// xyz@abc.def
		Matcher m = p.matcher(email);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	public static boolean validateAddressWithExtraCharacters(String submittedValue) {
		boolean returnValue = true;
		String allowedChars = "qwertyuiopasdfghjklmnbvcxzQWERTYUIOPASDFGHJKLMNBVCXZ1234567890()-.,/@&#$*?_+': ";
		for (char a : submittedValue.toCharArray()) {
			if (allowedChars.indexOf(a) == -1) {
				returnValue = false;
				break;
			}
		}
		return returnValue;
	}

	public static boolean validateAmtAdhoc(String input) {

		boolean returnValue = false;
		double amt;
		String methodName = VALIDATE_AMT;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD_WITH_INPUT + input);

		Pattern p = Pattern.compile("((\\d{1,12})(((\\.)(\\d{0,2})){0,1}))");

		Matcher m = p.matcher(input);

		if (m.matches()) {

			amt = Double.parseDouble(input);

			if (amt > 0) {

				returnValue = Boolean.TRUE;
			} else {

				returnValue = Boolean.FALSE;
			}

		} else {
			returnValue = false;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD_WITH_RETURN_VALUE + returnValue);

		return returnValue;
	}

	/**
	 * <p>
	 * Convert file object to Byte Array
	 * </p>
	 * 
	 * @param input
	 * @return
	 */
	public static byte[] fileToByteArray(File input) {

		String thisMethod = "fileToByteArray";
		byte[] fileArry = null;

		try {
			fileArry = IOUtils.toByteArray(new FileInputStream(input));
		} catch (FileNotFoundException e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, thisMethod);
		} catch (IOException e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, thisMethod);
		}

		return fileArry;
	}

	public static Date getDateFrmTimeStamp(Timestamp timestamp) {
		Date output = new Date();
		try {
			String time = timestamp.toString();
			output = getDateFrmString(time, "yyyy-MM-dd HH:mm:ss.SSS");
		} catch (Exception e) {
			printExceptionErrors(e,logger, THIS_CLASS, "getDateFrmTimeStamp");

		}
		return output;
	}

	public static boolean isArrayEmpty(String[] checkfield) {

		boolean isEmpty = Boolean.FALSE;

		for (int i = 0; i < checkfield.length; i++) {

			if (isFieldEmpty(checkfield[i])) {

				isEmpty = Boolean.TRUE;

			}
		}

		return isEmpty;
	}

	public static Timestamp getTimestampFromDate(Date date) {
		return new Timestamp(date.getTime());
	}

	/**
	 * <h2>getDiffMin</h2>
	 * <p>
	 * 
	 * @description : This function is used to get difference between two dates in
	 *              Min.
	 *              </p>
	 * @param first
	 * @param last
	 * @return
	 */
	public static int getDiffMin(Date first, Date last) {

		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		String methodName = "getDiffYears";
		int diffInMinute = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD_WITH_DATE_1 + first + DATE_2 + last);

		try {
			long miliSecondForDate1 = a.getTimeInMillis();
			long miliSecondForDate2 = b.getTimeInMillis();

			long diffinMilli = miliSecondForDate2 - miliSecondForDate1;

			diffInMinute = (int) (diffinMilli / (60 * 1000));
			if ((diffinMilli - diffInMinute) > 0) {
				FLogger.debug(logger,  THIS_CLASS, methodName,
						"Exiting method with diff in sec : " + (diffinMilli - diffInMinute));
				diffInMinute++;
			}

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD_WITH_DIFF + diffInMinute);

		return diffInMinute;
	}

	public static int getDiffMinNew(Date first, Date last) {

		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		String methodName = "getDiffMinNew";
		int diffInMinute = 0;

		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD_WITH_DATE_1 + first + DATE_2 + last);

		try {
			// in milliseconds
			long miliSecondForDate1 = a.getTimeInMillis();
			long miliSecondForDate2 = b.getTimeInMillis();

			long diffinMilli = miliSecondForDate2 - miliSecondForDate1;

			diffInMinute = (int) (diffinMilli / (60 * 1000));

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting method with diff in Minutes: " + diffInMinute);

		return diffInMinute;
	}

	public static int getDiffInSecs(Date first, Date last) {
		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		String methodName = "getDiffInSecs";
		int totalSecond = 0;
		try {

			FLogger.debug(logger,  THIS_CLASS, methodName,
					ENTERED_METHOD_WITH_DATE_1 + first + DATE_2 + last);
			long miliSecondForDate1 = a.getTimeInMillis();
			long miliSecondForDate2 = b.getTimeInMillis();

			long diffinMilli = miliSecondForDate2 - miliSecondForDate1;

			totalSecond = (int) (diffinMilli / (1000));
			FLogger.debug(logger,  THIS_CLASS, methodName, "totalSecond - " + totalSecond);
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}
		return totalSecond;
	}

	public static int getDiffInMonth(Date first, Date last) {
		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		String methodName = "getDiffInMonth";
		int totalSecond = 0;
		try {

			FLogger.debug(logger,  THIS_CLASS, methodName,
					ENTERED_METHOD_WITH_DATE_1 + first + DATE_2 + last);
			long miliSecondForDate1 = a.getTimeInMillis();
			long miliSecondForDate2 = b.getTimeInMillis();

			long diffinMilli = miliSecondForDate2 - miliSecondForDate1;

			totalSecond = (int) (diffinMilli / (1000));
			FLogger.debug(logger,  THIS_CLASS, methodName, "totalSecond - " + totalSecond);
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}
		return totalSecond;
	}

	public static String getDiffInhourMinuteSecond(Date first, Date last) {

		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		String methodName = "getDiffMinNew";
		String result = null;
		int totalSecond = 0;
		
		FLogger.debug(logger,  THIS_CLASS, methodName,
				ENTERED_METHOD_WITH_DATE_1 + first + DATE_2 + last);

		try {
			// in milliseconds
			long miliSecondForDate1 = a.getTimeInMillis();
			long miliSecondForDate2 = b.getTimeInMillis();

			long diffinMilli = miliSecondForDate2 - miliSecondForDate1;

			totalSecond = (int) (diffinMilli / (1000));

			Date d = new Date(totalSecond * 1000L);
			SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));
			result = df.format(d);

		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, "Exiting method with diff in Minutes: " + result);

		return result;
	}

	public static Date getDateFrmTmeStamp(Timestamp timestamp) throws Exception {
		Date output = new Date();
		try {
			String time = timestamp.toString();
			output = getDateFrmString(time, "yyyy-MM-dd hh:mm:ss.SSS");
		} catch (Exception e) {
			printExceptionErrors(e,logger, THIS_CLASS, "getCronExpression");
			throw e;
		}
		return output;
	}

	public static String maskString(String strText, int start, int end, char maskChar) {

		if (strText == null || "".equals(strText))
			return "";

		if (start < 0)
			start = 0;

		if (end > strText.length())
			end = strText.length();

		if (start > end)
			return "";

		int maskLength = end - start;

		if (maskLength == 0)
			return strText;

		StringBuilder sbMaskString = new StringBuilder(maskLength);

		for (int i = 0; i < maskLength; i++) {
			sbMaskString.append(maskChar);
		}

		return strText.substring(0, start) + sbMaskString.toString() + strText.substring(start + maskLength);
	}

	/**
	 * <h2>validateAmtwithZero</h2>
	 * <p>
	 * This Regex Check for Following conditions. Number should be of format :
	 * ####.## format. Number of Digits after Decimal Places should be from 0 to 2.
	 * Minimum digits should be 1 and maximum digits can be 9 on left hand side of
	 * decimal.
	 * </p>
	 * 
	 * @param input : Amount String which needs to be Validated.
	 * @return Boolean Value
	 *         <ul>
	 *         <li><b>true</b> : If valid Amount has been passed as input</li>
	 *         <li><b>false</b> : If invalid Amount has been passed as input.</li>
	 *         </ul>
	 */
	public static boolean validateAmtwithZero(String input) {

		boolean returnValue = false;
		double amt = 0.0;
		String methodName = VALIDATE_AMT;

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD_WITH_INPUT + input);

		Pattern p = Pattern.compile("((\\d{1,10})(((\\.)(\\d{0,2})){0,1}))");

		Matcher m = p.matcher(input);

		if (m.matches()) {

			amt = Double.parseDouble(input);

			if (amt >= 0) {

				returnValue = Boolean.TRUE;
			} else {

				returnValue = Boolean.FALSE;
			}

		} else {
			returnValue = false;
		}

		FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD_WITH_RETURN_VALUE + returnValue);

		return returnValue;
	}

	public static double getPercentage(double total, double input) {
		double percentage = 0.0;
		percentage = (input / total) * LoggerConstants.NUM_100;
		return percentage;
	}

	public static Date convertStrToDate(String str) {

		String thisMethod = "convertStrToDate";
		Date dte = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		try {
			dte = sdf.parse(str);
		} catch (ParseException e) {
			FLogger.error(logger, THIS_CLASS, thisMethod, "exception" + e);
		}
		return dte;
	}

	public static boolean checkDateRange(String startDate, String endDate, String givenDate) {

		Date d1 = null, d2 = null, d3 = null;

		boolean result = false;

		try {
			d1 = new SimpleDateFormat("MM/dd/yyyy").parse(startDate);
			d2 = new SimpleDateFormat("MM/dd/yyyy").parse(endDate);
			d3 = new SimpleDateFormat("dd/MM/yyyy").parse(givenDate);

			if ((d1.before(d3)) && (d3.before(d2))) {
				result = true;
			} else {
				result = false;
			}

		} catch (Exception e) {
			printExceptionErrors(e,logger, THIS_CLASS, "checkDateRange");
		}

		return result;

	}

	@SuppressWarnings({ "rawtypes" })
	public static Object convertJsonToObjectTypeRef(String jsonInput, Class classInput, Class paramterClass) {

		Object obj = null;
		String methodName = "convertJsonToObjectTypeRef";

		FLogger.debug(logger,  THIS_CLASS, methodName, ENTERING_METHOD + methodName);

		try {

			if (!StringChecks.isFieldEmpty(jsonInput)) {

				ObjectMapper mapper = new ObjectMapper();
				mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

				obj = mapper.readValue(jsonInput,
						mapper.getTypeFactory().constructParametricType(classInput, paramterClass));

			} else {

				FLogger.error(logger, THIS_CLASS, methodName, " Response Msg is Null.");
			
			}

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			
		} finally {

			FLogger.debug(logger,  THIS_CLASS, methodName, EXITING_METHOD + methodName);
		}

		return obj;
	}

	/**
	 * <h2>dateEqual</h2>
	 * <p>
	 * 
	 * @description : This function is used to compare two dates passed as input as
	 *              String in dd-MMM-yyyy format are equal or not.
	 *              </p>
	 * @param startDate
	 * @param endDate
	 * @return true
	 * @throws ParseException
	 */
	public static boolean dueDateCrossed(String startDate, String endDate) {

		Date d1;
		Date d2;
		boolean flag = true;
		String methodName = DATE_EQUAL;
		SimpleDateFormat df = new SimpleDateFormat(DDMMMYYYY);

		try {
			d1 = df.parse(startDate);
			d2 = df.parse(endDate);

			if (d1.before(d2) || d1.equals(d2)) {
				flag = false;
			} else {
				flag = true;
			}
		} catch (Exception e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
		}

		return flag;
	}

	public static Date getDesiredDate(Date givenDate, int days, boolean clearHMS) {
		Date outPut = new Date();

		Calendar calendar = Calendar.getInstance();
		if (clearHMS) {
			givenDate = clearHMS(givenDate);
		}
		calendar.setTime(givenDate);
		calendar.add(Calendar.DATE, days);
		outPut = calendar.getTime();
		return outPut;
	}

	public static Date getDayEnd(Date givenDate) {
		Date outPut = new Date();
		outPut = getDesiredSec(getDesiredDate(givenDate, 1, true), -1);
		return outPut;
	}

	public static Date getDayStart(Date givenDate) {
		return clearHMS(givenDate);
	}

	public static Date getDesiredTime(Date givenDate, int mins, boolean clearHMS) {
		Date outPut = new Date();

		Calendar calendar = Calendar.getInstance();
		if (clearHMS) {
			givenDate = clearHMS(givenDate);
		}
		calendar.setTime(givenDate);
		calendar.add(Calendar.MINUTE, mins);
		outPut = calendar.getTime();
		return outPut;
	}

	public static Date getDesiredSec(Date givenDate, int sec) {
		Date outPut = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(givenDate);
		calendar.add(Calendar.SECOND, sec);
		outPut = calendar.getTime();
		return outPut;
	}

	public static Date getDesiredMonth(Date givenDate, int month, boolean clearHMS) {
		Date outPut = new Date();

		Calendar calendar = Calendar.getInstance();
		if (clearHMS) {
			givenDate = clearHMS(givenDate);
		}
		calendar.setTime(givenDate);
		calendar.add(Calendar.MONTH, month);
		outPut = calendar.getTime();
		return outPut;
	}

	public static Date clearHMS(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		date = c.getTime();
		return date;
	}

	public static String getDateAsPerNamingConv(String date) {

		if (date!=null 
				&& !StringChecks.isFieldEmpty(date)) {
			date = date.substring(0, date.length() - LoggerConstants.NUM_4) + "'" + date.substring(date.length() - LoggerConstants.NUM_2, date.length());
		} else {
			date = "NA";
		}
		return date;
	}

	public static boolean isCurrentMonth(Date date) {
		boolean output = false;
		if (clearHMS(getFirstDateOfMonth(date)).equals(clearHMS(getFirstDateOfMonth(new Date())))) {
			output = true;
		}
		return output;
	}

	public static boolean isNextMonth(Date date) {
		boolean output = false;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(getFirstDateOfMonth(new Date()));
		calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + 1);
		if (calendar.getTime().equals(clearHMS(getFirstDateOfMonth(date)))) {
			output = true;
		}
		return output;
	}

	public static boolean isFutureMonth(Date date) {
		boolean output = false;
		if (clearHMS(getFirstDateOfMonth(date)).after(clearHMS(getFirstDateOfMonth(new Date())))) {
			output = true;
		}
		return output;
	}


	public static boolean isPastMonth(Date date) {
		boolean output = false;
		if (clearHMS(getFirstDateOfMonth(date)).before(clearHMS(getFirstDateOfMonth(new Date())))) {
			output = true;
		}
		return output;
	}

	public static Date getFirstDateOfMonth(Date d) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = GET_FIRST_DATE_OF_MONTH;

		Date formatDate = null;
		Calendar cal = Calendar.getInstance();

		try {
			sdf = new SimpleDateFormat(DDMMMYYYY);

			if (d != null) {
				cal.setTime(d);
			}

			cal.set(Calendar.DAY_OF_MONTH, 1);

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	public static Date getLastDateOfMonth(Date d) {
		try {
			return getDesiredDate(getDesiredMonth(getFirstDateOfMonth(d), 1, false), -1, false);
		} catch (Exception e) {
			EcomHelper.exceptionLog(e, LoggerConstants.NUM_10);
			return null;
		}
	}

	public static boolean isBetween(Date date, Date from, Date to, boolean onlyDateCompare) {
		if (onlyDateCompare) {
			date = StringChecks.clearHMS(date);
			from = StringChecks.clearHMS(from);
			to = StringChecks.clearHMS(to);
		}
		if ((date.equals(from) || date.after(from)) && (date.before(to) || date.equals(to))) {
			return true;
		}
		return false;
	}

	public static Date getfirstDateAccordingCounter(String counterPrd) {
		Calendar cal = Calendar.getInstance();
		int CrMnth = cal.get(Calendar.MONTH);

		if ("M".equalsIgnoreCase(counterPrd)) {
			cal.set(Calendar.DATE, 1);
		} else if ("Y".equalsIgnoreCase(counterPrd)) {
			cal.set(Calendar.DATE, 1);
			cal.set(Calendar.MONTH, LoggerConstants.NUM_3);

			if (CrMnth == 0 || CrMnth == 1 || CrMnth == LoggerConstants.NUM_2)
				cal.add(Calendar.YEAR, -1);

		} else if ("Q".equalsIgnoreCase(counterPrd)) {
			cal.set(Calendar.DATE, 1);
			if (CrMnth == 0 || CrMnth == 1 || CrMnth == LoggerConstants.NUM_2)
				cal.set(Calendar.MONTH, 0);
			else if (CrMnth == LoggerConstants.NUM_3 || CrMnth == LoggerConstants.NUM_4 || CrMnth == LoggerConstants.NUM_5)
				cal.set(Calendar.MONTH, LoggerConstants.NUM_3);
			else if (CrMnth == LoggerConstants.NUM_6 || CrMnth == LoggerConstants.NUM_7 || CrMnth == LoggerConstants.NUM_8)
				cal.set(Calendar.MONTH, 6);
			else if (CrMnth == LoggerConstants.NUM_9 || CrMnth == LoggerConstants.NUM_10 || CrMnth == LoggerConstants.NUM_11)
				cal.set(Calendar.MONTH, 9);
		} else if ("H".equalsIgnoreCase(counterPrd)) {
			cal.set(Calendar.DATE, 1);
			if (CrMnth == 0 || CrMnth == 1 || CrMnth == LoggerConstants.NUM_2 || CrMnth == LoggerConstants.NUM_3 || CrMnth == LoggerConstants.NUM_4 || CrMnth == LoggerConstants.NUM_5)
				cal.set(Calendar.MONTH, 0);
			else if (CrMnth == LoggerConstants.NUM_6 || CrMnth == LoggerConstants.NUM_7 || CrMnth == LoggerConstants.NUM_8 || CrMnth == LoggerConstants.NUM_9 || CrMnth == LoggerConstants.NUM_10 || CrMnth == LoggerConstants.NUM_11)
				cal.set(Calendar.MONTH, 6);
		}

		Date date = cal.getTime();
		FLogger.error(logger, THIS_CLASS, "getfirstDateAccordingCounter", "Date " + date);
		return date;

	}

	public static String removeTrailingZero(String str) {
		if (str.contains(".")) {
			String[] temp = str.split("\\.");
			if (LoggerConstants.NUM_2 == temp.length) {
				str = temp[0];
				try {
					int k = Integer.parseInt(temp[1]);
					if (0 < k) {
						str = str + "." + k;
					}
				} catch (Exception e) {
					EcomHelper.exceptionLog(e);
					str = "NAN";
				}
			} else {
				str = "NAN";
			}
		}
		return str;
	}

	public static String addLeftPadding(String input, char paddingChar, int paddingLimit) {
		return StringUtils.leftPad(input, paddingLimit, paddingChar);
	}

	public static String addRightPadding(String input, char paddingChar, int paddingLimit) {
		return StringUtils.leftPad(input, paddingLimit, paddingChar);
	}

	public static String convertStrDatePattern(String date, String fromPattern, String toPattern) {
		return getStrFrmDate(getDateFrmString(date, fromPattern), toPattern);
	}


	public static String randomNumbers(int length) {
		StringBuilder op = new StringBuilder();
		String methodNme = "randomNumbers";
		SecureRandom random = new SecureRandom();
		try {
			List<String> numberList = Arrays.asList("0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
			if (length > 0) {
				for (int i = 0; i < length; i++) {
					Collections.shuffle(numberList, new SecureRandom());
					op.append(numberList.get(random.nextInt(LoggerConstants.NUM_10)));
				}
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodNme);
		}
		return op.toString();
	}

	public static String randomNumbers(int length, String... numberList) {
		StringBuilder op = new StringBuilder();
		String methodNme = "randomNumbers";
		SecureRandom random = new SecureRandom();
		try {
			if (length > 0) {
				for (int i = 0; i < length; i++) {
					op.append(numberList[random.nextInt(numberList.length)]);
				}
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodNme);
		}
		return op.toString();
	}

	public static String randomAlphaNumeric(int length) {
		StringBuilder op = new StringBuilder();
		String methodNme = "randomAlphaNumeric";
		SecureRandom random = new SecureRandom();
		try {
			List<String> numberList = Arrays.asList("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C",
					"D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W",
					"X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",
					"r", "s", "t", "u", "v", "w", "x", "y", "z");
			if (length > 0) {
				for (int i = 0; i < length; i++) {
					op.append(numberList.get(random.nextInt(62)));
				}
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodNme);
		}
		return op.toString();
	}

	public static String randomAlphaNumeric(int length, String... numberList) {
		StringBuilder op = new StringBuilder();
		String methodNme = "randomAlphaNumeric";
		SecureRandom random = new SecureRandom();
		try {
			if (length > 0) {
				for (int i = 0; i < length; i++) {
					op.append(numberList[random.nextInt(numberList.length)]);
				}
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodNme);
		}
		return op.toString();
	}

	public static Date dateFromMilliseconds(Long milliseconds) {
		return new Date(milliseconds);
	}

	public static Date dateFromMilliseconds(String milliseconds) {
		return dateFromMilliseconds(Long.parseLong(milliseconds));
	}

	public static String dataSizecalc(Long bytes) {
		StringBuilder builder = new StringBuilder();
		Long l =Long.valueOf(1024);
		Double dBytes = Double.valueOf(bytes);
		if (l > bytes) {
			builder.append(bytes).append(" B");
		} else if ((l * l) > bytes) {
			builder.append(BigDecimal.valueOf((dBytes / l)).setScale(LoggerConstants.NUM_2, RoundingMode.FLOOR).stripTrailingZeros()
					.toPlainString()).append(" KB");
		} else if ((l * l * l) > bytes) {
			builder.append(BigDecimal.valueOf((dBytes / (l * l))).setScale(LoggerConstants.NUM_2, RoundingMode.FLOOR)
					.stripTrailingZeros().toPlainString()).append(" MB");
		} else if ((l * l * l * l) > bytes) {
			builder.append(BigDecimal.valueOf((dBytes / (l * l * l))).setScale(LoggerConstants.NUM_2, RoundingMode.FLOOR)
					.stripTrailingZeros().toPlainString()).append(" GB");
		} else if ((l * l * l * l * l) > bytes) {
			builder.append(BigDecimal.valueOf((dBytes / (l * l * l * l))).setScale(LoggerConstants.NUM_2, RoundingMode.FLOOR)
					.stripTrailingZeros().toPlainString()).append(" TB");
		} else if ((l * l * l * l * l * l) > bytes) {
			builder.append(BigDecimal.valueOf((dBytes / (l * l * l * l * l))).setScale(LoggerConstants.NUM_2, RoundingMode.FLOOR)
					.stripTrailingZeros().toPlainString()).append(" PB");
		} else if ((l * l * l * l * l * l) < bytes) {
			Double pb = (dBytes / (l * l * l * l * l));
			if ((l * l) > pb) {
				builder.append(BigDecimal.valueOf(pb / (l)).setScale(LoggerConstants.NUM_2, RoundingMode.FLOOR).stripTrailingZeros()
						.toPlainString()).append(" EB");
			}
			/** ZB and YB not included. Long's max value is 7.99 EB only */
		}
		return builder.toString();
	}

	public static String cleanMsisdn(String msisdn) {
		if (msisdn.length() > LoggerConstants.NUM_10) {
			msisdn = msisdn.substring(msisdn.length() - LoggerConstants.NUM_10, msisdn.length());
		}
		return msisdn;
	}

	/**
	 * @author MeenalJ This method is used to Fetch Future Date from Current Day by
	 *         adding no of hours.
	 * @param range   : Number of hours to go in future
	 * @param pattern : Pattern used for Simple Date format e.g dd-MMM-yyyy
	 * @return
	 */
	public static Date getFutureTime(int range, Calendar cal) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm");
		String methodName = GET_FUTURE_DATE;

		Date formatDate = null;
		// Calendar cal=Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.MINUTE, range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	public static Date getFutureDay(int range, Calendar cal) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = GET_FUTURE_DATE;

		Date formatDate = null;
		// Calendar cal=Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.DATE, -range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	public static Date getFutureHour(int range, Calendar cal) {

		SimpleDateFormat sdf = new SimpleDateFormat(DDMMMYYYY);
		String methodName = GET_FUTURE_DATE;

		Date formatDate = null;
		// Calendar cal=Calendar.getInstance();

		try {

			if (range > 0) {
				cal.add(Calendar.HOUR, range);
			}

			formatDate = cal.getTime();
			formatDate = sdf.parse(sdf.format(formatDate));

			return formatDate;

		} catch (ParseException e) {
			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;

		} catch (Exception e) {

			printExceptionErrors(e, logger,THIS_CLASS, methodName);
			return null;
		}
	}

	public static String fetchJbossServerPort() {

		String port = "8080";
		String methodName = "fetchJbossServerPort";

		try {

			String jbossServerName = System.getProperty("jboss.server.name");
			FLogger.debug(logger,  THIS_CLASS, methodName, "jbossServerName " + jbossServerName);

		} catch (Exception e) {

			FLogger.error(logger, THIS_CLASS, methodName,
					" Got Exception while fetching Jboss Port so setting Port as 8080 : " + e.getMessage() + DUE_TO
							+ e.getCause(),
					e);

			port = "8080";
		}

		return port;
	}

	public static boolean getValiddatePattern(String daystr, String monthstr, String yearstr) {
		boolean isTrueDate = true;
		try {

			int month;
			int day = Integer.parseInt(daystr);

			Date date = new SimpleDateFormat("MMM").parse(monthstr);// put your month name here
			
			Format f = new SimpleDateFormat("M");
		    String strMonth = f.format(date);
		    month=Integer.parseInt(strMonth);		     

			Date date1 = new SimpleDateFormat("yy").parse(yearstr);// put your month name here

			f = new SimpleDateFormat("yy");
		    String stryr = f.format(date1);
		    int year =Integer.parseInt(stryr);	
		    int four=LoggerConstants.NUM_4;	
		    int six=LoggerConstants.NUM_6;	
		    int nine=LoggerConstants.NUM_9;	
		    int eleven=LoggerConstants.NUM_11;	
		    		
			if (month > LoggerConstants.NUM_12) {
				isTrueDate = false;
			} else if (month == 1 || month == LoggerConstants.NUM_3 || month == LoggerConstants.NUM_5 || month == LoggerConstants.NUM_7 || month == LoggerConstants.NUM_8 || month == LoggerConstants.NUM_10
					|| month == LoggerConstants.NUM_12) {
				if (day <= LoggerConstants.NUM_31 && day >= 1) {
					
				} else if (day <= 0) {
					isTrueDate = false;
				} else if (day >= LoggerConstants.NUM_31) {
					isTrueDate = false;
				}
			} else if (month == four || month == six || month == nine || month == eleven) {
				if (day <= LoggerConstants.NUM_30 && day >= 1) {
					
				} else if (day <= 0) {
					isTrueDate = false;
				} else if (day >= LoggerConstants.NUM_30) {
					isTrueDate = false;
				}

			} else if (month == LoggerConstants.NUM_2) // February check
			{

				if (year % four == 0) // Leap year check for February
				{
					if (day <= LoggerConstants.NUM_29 && day >= 1) {
						
					} else if (day <= 0) {
						isTrueDate = false;
					} else if (day >= LoggerConstants.NUM_29) {
						isTrueDate = false;
					}
				} else if (year % four != 0) {
					if (day <= LoggerConstants.NUM_28 && day >= 1) {
						
					} else if (day <= 0) {
						isTrueDate = false;
					} else if (day >= LoggerConstants.NUM_28) {
						isTrueDate = false;
					}
				}

			}

		} catch (ParseException e) {
			isTrueDate = false;
		}
		return isTrueDate;
	}

	// Check url
	public static boolean checkUrlPattern(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern
				.compile("^(http:\\/\\/|https:\\/\\/)?(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	// Check alphabet hyphen underscore
	public static boolean checkAlphabetHyphenUndescoreSpance(String submittedValue) {
		boolean returnValue = false;
		Pattern p = Pattern.compile("^[0-9A-Za-z\\s\\-_]+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;

		}
		return returnValue;
	}

	// Check url
	public static boolean checkAllowedUrlPattern(String submittedValue) {
		boolean returnValue = true;
		// Pattern p =
		// Pattern.compile("^(http:\\/\\/|https:\\/\\/)?(www.)?([a-zA-Z0-9]+).[a-zA-Z0-9]*.[a-z]{3}.?([a-z]+)?$");
		// // the pattern to search for
		Pattern p = Pattern.compile("\\b(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]",
				Pattern.CASE_INSENSITIVE);

		Matcher m = p.matcher(submittedValue);

		// if we find a match, get the group
		while (m.find()) {
			// we're only looking for one group, so get it
			String theGroup = m.group(0);
			if (!theGroup.contains("bit.ly")) {
				// System.out.format("'%s' matches", theGroup);
				return false;
			}
			// print the group out for verification
			// System.out.format("'%s'\n", theGroup);
		}

		return returnValue;

	}

	/**
	 * @param resultSet java.sql.resultset
	 * @return set of all column names in capital letters
	 */
	public static Set<String> getColumnNamesFromResultSet(ResultSet resultSet) {
		Set<String> output = new HashSet<>();
		try {
			ResultSetMetaData metaData = resultSet.getMetaData();
			int k = metaData.getColumnCount();
			for (int l = 1; l <= k; l++) {
				output.add(metaData.getColumnLabel(l).toUpperCase());
			}
		} catch (Exception e) {
			EcomHelper.exceptionLog(e);
		}
		return output;
	}

	/**
	 * @param inputDte
	 * @return
	 */
	public static Date convertStringToDate(String inputDte) {

		Date convertedDte = null;
		Set<String> patterns = new LinkedHashSet<>();

		try {

			patterns.addAll(Arrays.asList(BaseConstants.RESTWS.DATE_PATTERN8,
					BaseConstants.RESTWS.DATE_PATTERN7,
					BaseConstants.RESTWS.DATE_PATTERN1,
					BaseConstants.RESTWS.DATE_PATTERN6, "dd-MM-yyyy HH:mm:ss",
					BaseConstants.RESTWS.TNPS_AON_DATE_FILE_DATE_PATTERN,
					BaseConstants.RESTWS.DATE_PATTERN3, DDMMYYYYHHMMSS,
					BaseConstants.RESTWS.DATE_PATTERN5,
					BaseConstants.RESTWS.DATE_PATTERN10,
					BaseConstants.RESTWS.DATE_PATTERN11,
					BaseConstants.RESTWS.GET_IN_BAL_TIMEZONE_DATE_PATTERN,
					"dd-MM-yy", "MM-dd-yyyy HH:mm:ss",
					"yyyy-MM-dd HH:mm:ss", "dd MMM yy",
					BaseConstants.RESTWS.DATE_PATTERN14));

			if (!StringChecks.isFieldEmpty(inputDte)) {

				for (String pat : patterns) {

					if (StringChecks.validateDate(inputDte, pat)) {
						convertedDte = StringChecks.getDateFrmString(inputDte, pat);
						break;
					}
				}
			}

		} catch (Exception e) {
			EcomHelper.exceptionLog(e);
		}

		return convertedDte;
	}

	public static String shuffleString(String input) {
		try {
			List<String> temp = Arrays.asList(input.split(""));
			Collections.shuffle(temp);
			StringBuilder builder = new StringBuilder();
			for (String string : temp) {
				builder.append(string);
			}
			input = builder.toString();
		} catch (Exception e) {
			EcomHelper.exceptionLog(e);
		}
		return input;
	}

	public static String replaceChars(String input, List<String> stringToReplace, String replaceTo) {
		for (String k : stringToReplace) {
			input = input.replace(k, replaceTo);
		}
		return input;
	}

	/**
	 * @return true : if input String is alphaNumeric and having - character, false:
	 *         if input String is not alphaNumeric and having - character
	 * @param submittedValue
	 * @return
	 */
	public static boolean checkAlphaNumbericWithDash(String submittedValue) {

		boolean returnValue = false;

		Pattern p = Pattern.compile("^[a-zA-Z0-9-]+$");
		Matcher m = p.matcher(submittedValue);
		if (m.matches()) {
			returnValue = true;
		} else {
			returnValue = false;
		}
		return returnValue;
	}

	public static <K> List<List<K>> splitList(List<K> input, int chunkSize) {
		List<List<K>> output = new ArrayList<>();
		try {
			if(null!=input && !input.isEmpty()) {
				if(chunkSize >= input.size()) {
					output.add(input);
				}else {
					int total = input.size()/chunkSize;
					int reminder = input.size()%chunkSize;
					for (int i = 0; i < total; i++) {
						output.add(input.subList(i*chunkSize, ((i*chunkSize)+chunkSize)));						
					}
					if (reminder>0) {
						output.add(input.subList(input.size()-reminder,input.size()));
					}
				}
			}
		} catch (Exception e) {
			EcomHelper.exceptionLog(e);
		}
		return output;
	}

	public static String cleanEmptyString(String input) {
		return cleanEmptyString(input, "");
	}

	public static String cleanEmptyString(String input, String defaultValue) {
		if (null == defaultValue || defaultValue.trim().isEmpty()) {
			defaultValue = "";
		}
		String output = defaultValue;
		try {
			if (null != input && !input.trim().isEmpty()) {
				output = input;
			}
		} catch (Exception e) {
			EcomHelper.exceptionLog(e);
		}
		return output;
	}

	/**
	 * @param filename
	 * @return
	 * @throws IOException
	 */
	public static byte[] readFileBytes(String filename) throws IOException {
		Path path = Paths.get(filename);
		return Files.readAllBytes(path);
	}
	
	/**
	 * 
	 * @param confMap
	 * @return Map&#60;String, List&#60;String&#62;&#62s;
	 */
	public static Map<String, List<String>> httpErrorCodesExctraction(Map<String, Object> confMap) {
		
		String methodNme = "httpErrorCodesExctraction";
		
		Map<String, List<String>> codes = new HashMap<>();
		
		String successCodes = (String) confMap.get(BaseConstants.RESTWS.REST_SUCCESS_CDES);
		String failureCodes = (String) confMap.get(BaseConstants.RESTWS.REST_FAILURE_CDES);
		
		List<String> successCodesList = new ArrayList<>();
		List<String> failureCodesList = new ArrayList<>();
		
		try {

			if (!StringChecks.isFieldEmpty(successCodes)) {
				successCodesList = Arrays.asList(successCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(failureCodes)) {
				failureCodesList = Arrays.asList(failureCodes.split("[\\|]+"));
			}
			codes.put("successCodes", successCodesList);
			codes.put("failureCodes", failureCodesList);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodNme);
		}
		
		return codes;

	}

}
