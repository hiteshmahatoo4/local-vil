
package com.vil.ecom.fulfillmentOrderSttsQuery.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"code",
    "description",
    "status",
    "auditId"
})
public class ResponseStts implements Serializable {
	
	@JsonProperty("code")
	private String code;
	@JsonProperty("description")
	private String description;
	@JsonProperty("status")
	private String status;
	@JsonProperty("auditId")
	private String auditId;
	
	private final static long serialVersionUID = -7100060739212621182L;

	@JsonProperty("code")
	public String getCode() {
		return code;
	}

	@JsonProperty("code")
	public void setCode(String code) {
		this.code = code;
	}

	public ResponseStts withCode(String code) {
		this.code = code;
		return this;
	}

	@JsonProperty("description")
	public String getDescription() {
		return description;
	}

	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}

	public ResponseStts withDescription(String description) {
		this.description = description;
		return this;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	public ResponseStts withStatus(String status) {
		this.status = status;
		return this;
	}
	
	@JsonProperty("auditId")
	public String getAuditId() {
		return auditId;
	}

	@JsonProperty("auditId")
	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public ResponseStts withAuditId(String auditId) {
		this.auditId = auditId;
		return this;
	}

}
