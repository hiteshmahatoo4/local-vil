package com.vil.ecom.eai.verifyOtpCreditInsight.pojo;
import java.io.Serializable;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "expired_at", "id", "max_usages", "used_count" })

	public class ConsentInfo implements Serializable {

		@JsonProperty("expired_at")
		private String expiredAt;
		@JsonProperty("id")
		private int id;
		@JsonProperty("max_usages")
		private int maxUsages;
		@JsonProperty("used_count")
		private int usedCount;
		private final static long serialVersionUID = -2006859715822164905L;

		@JsonProperty("expired_at")
		public String getExpiredAt() {
			return expiredAt;
		}

		@JsonProperty("expired_at")
		public void setExpiredAt(String expiredAt) {
			this.expiredAt = expiredAt;
		}

		@JsonProperty("id")
		public int getId() {
			return id;
		}

		@JsonProperty("id")
		public void setId(int id) {
			this.id = id;
		}

		@JsonProperty("max_usages")
		public int getMaxUsages() {
			return maxUsages;
		}

		@JsonProperty("max_usages")
		public void setMaxUsages(int maxUsages) {
			this.maxUsages = maxUsages;
		}

		@JsonProperty("used_count")
		public int getUsedCount() {
			return usedCount;
		}

		@JsonProperty("used_count")
		public void setUsedCount(int usedCount) {
			this.usedCount = usedCount;
		}

	}



