package com.vil.ecom.logger.srvc;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.db.custommodel.EcomSmsDataMstrCustomModel;
import com.vil.ecom.db.model.EcomSmsDataMstr;
import com.vil.ecom.db.service.EcomSmsDataMstrLocalServiceUtil;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntSmsLogVO;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EcomMrchntSmsLogHelper {
	
	
	private static final Log logger = LogFactoryUtil.getLog(EcomMrchntSmsLogHelper.class);
	private static final String THIS_CLASS = EcomMrchntSmsLogHelper.class.toString();
	
	
	/**
	 * @param confMap
	 * @param srvcNme
	 * @return
	 */
	public static Map<String, String> populateDummyResp(Map<String, Object> confMap, String srvcNme) {

		HashMap<String, String> dummyMap = new HashMap<>();
		String methodName = "populateDummyResp";

		boolean dummyFlg = Boolean.parseBoolean((String) confMap.get("REST_DUMMY_RESP_FLG"));

		if (dummyFlg) {

			String dummyResp = (String) confMap.get("REST_DUMMY_RESP");
			String dummyStts = (String) confMap.get("REST_DUMMY_STTS");
			String dummyErrMsg = (String) confMap.get("REST_DUMMY_ERR_MSG");

			if (!StringChecks.isFieldEmpty(dummyResp)) {

				FLogger.info(logger, THIS_CLASS, methodName, "Dummy Response Set for Service " + srvcNme);

				dummyMap.put("respCode", "200");

				if (StringChecks.isFieldEmpty(dummyStts)) {
					dummyMap.put("status", BaseConstants.SUCCESS_MSG);
				} else {
					dummyMap.put("status", dummyStts);
				}

				if (StringChecks.isFieldEmpty(dummyErrMsg)) {
					dummyMap.put("statusDesc", BaseConstants.SUCCESS_MSG);
				} else {
					dummyMap.put("statusDesc", dummyErrMsg);
				}

				dummyMap.put("respMsg", dummyResp);

			}

		} else {
			FLogger.info(logger, THIS_CLASS, methodName, "No Dummy Response Set.");
		}

		return dummyMap;
	}
	
	public static void logRequestForSmsData(EcomMrchntSmsLogVO logVO) {
		
		String methodName = "logRequestForSmsData";
		EcomSmsDataMstrCustomModel obj;
		
		
		FLogger.info(logger, THIS_CLASS, methodName, "Entering Method " + methodName);
		
		try {
			obj = new EcomSmsDataMstrCustomModel();
			
			obj.setCrtn_on(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			obj.setCircle_nme(logVO.getCircleId());
			obj.setCrtd_by(LoggerConstants.LOGGER_CAT);

			if (!StringChecks.isFieldEmpty(logVO.getMsisdn())) {
				obj.setMsisdn(logVO.getMsisdn());
			}

			if (!StringChecks.isFieldEmpty(logVO.getEvent())) {
				obj.setEvent_nme(logVO.getEvent());
			}


			if (!StringChecks.isFieldEmpty(logVO.getSmsTxt())) {
				obj.setText_desc(logVO.getSmsTxt());
			}

			if (!StringChecks.isFieldEmpty(logVO.getStts())) {
				obj.setStts(logVO.getStts());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller1())) {
				obj.setFiller1(logVO.getFiller1());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller2())) {
				obj.setFiller2(logVO.getFiller2());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller3())) {
				obj.setFiller3(logVO.getFiller3());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller4())) {
				obj.setFiller4(logVO.getFiller4());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller5())) {
				obj.setFiller5(logVO.getFiller5());
			}

			if (!StringChecks.isFieldEmpty(logVO.getSenderId())) {
				obj.setSender_id(logVO.getSenderId());
			}
			

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName, "Exiting Method " + methodName);
		}
		
	}
	
	public static Long logResponseForSmsData(EcomMrchntSmsLogVO logVO) {

		String methodName = "logResponseForSmsData";

		EcomSmsDataMstrCustomModel obj = null;
		Long recordId = null;

		FLogger.info(logger, THIS_CLASS, methodName, "Entering Method " + methodName);

		try {

			obj = new EcomSmsDataMstrCustomModel();

			obj.setStts(logVO.getStts());
			
			obj.setCrtn_on(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			obj.setCircle_nme(logVO.getCircleId());
			obj.setCrtd_by(LoggerConstants.LOGGER_CAT);
			

			if (!StringChecks.isFieldEmpty(logVO.getMsisdn())) {
				obj.setMsisdn(logVO.getMsisdn());
			}

			if (!StringChecks.isFieldEmpty(logVO.getEvent())) {
				obj.setEvent_nme(logVO.getEvent());
				
			}
			
			
			if (!StringChecks.isFieldEmpty(logVO.getSmsTxt())) {
				obj.setText_desc(logVO.getSmsTxt());
			}


			if (!StringChecks.isFieldEmpty(logVO.getStts())) {
				obj.setStts(logVO.getStts());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller1())) {
				obj.setFiller1(logVO.getFiller1());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller2())) {
				obj.setFiller2(logVO.getFiller2());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller3())) {
				obj.setFiller3(logVO.getFiller3());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller4())) {
				obj.setFiller4(logVO.getFiller4());
			}

			if (!StringChecks.isFieldEmpty(logVO.getFiller5())) {
				obj.setFiller5(logVO.getFiller5());
			}

			if (!StringChecks.isFieldEmpty(logVO.getSenderId())) {
				obj.setSender_id(logVO.getSenderId());
			}
			
			EcomSmsDataMstr obj1 = EcomSmsDataMstrLocalServiceUtil.addMrchntSmsLogRecord(obj);

			if(obj1!=null) {
				recordId = obj1.getId();
			}

			FLogger.info(logger, THIS_CLASS, methodName,
					"Response Saved in DB with Record Id : " + (recordId != null ? recordId.intValue() : 0));

			

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		} finally {
			FLogger.info(logger, THIS_CLASS, methodName, "Exiting Method " + methodName);
		}

		return recordId;
	}


}
