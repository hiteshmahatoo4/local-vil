package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomCreateConsentRequestReq;
import com.vil.ecom.integration.pojo.EcomCreateConsentRequestResp;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomCreateConsentRequestProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomCreateConsentRequestUtil {
	
	private static final Log logger = LogFactoryUtil.getLog(EcomCreateConsentRequestUtil.class);
	private static final String THIS_CLASS = "EcomCreateConsentRequestUtil";
	
	
	/**
	 * 
	 * @author Jeswanth
	 * 
	 * <p>CreateConsentRequest API : creates consent request</p>
	 * 
	 * @param processorInput : EcomCreateConsentRequestReq pojo to be set. Mandatory
	 * <p>
	 * <h2>EcomCreateConsentRequestReq Pojo Details</h2>
	 * @param vilMsisdn : vil msisdn to be set. Mandatory
	 * @param airtelMsisdn : airtel msisdn to be set.
	 * </p>
	 * 
	 * @return EcomCreateConsentRequestResp createConsentRequestResponse : EcomCreateConsentRequestResp API response details
	 * <p>  request_id -  EcomCreateConsentRequestResp->createConsentRequestResponse->request_id
	 * 		request id for OTP sent,need to be passed as input 
	 * 		in EcomVerifyOtpCreditInsightUtil-> getCreditInsight method
	 * </p>
	 */
	public static EcomCreateConsentRequestResp createConsentRequest(EcomCreateConsentRequestReq processorInput) {
		
		String methodName =  "createConsentRequest";
		StopWatch stopwatch = null;
		EcomCreateConsentRequestResp response = null;
		MrchntRespStts respStts = null;
		
		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();
			
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.EAI_CREATE_CONSENT_REQUEST);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
			
			if(processorInput != null){
				
				FLogger.debug(logger, THIS_CLASS, methodName, "Entered method to createConsentRequest");
				
				respStts = validateInputs(processorInput);
				
				if(respStts == null) {
					
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.EAI_CREATE_CONSENT_REQUEST);
					srvcRequest.setCrtCnsntReqReq(processorInput);
					
					EcomCreateConsentRequestProcessor processor = new EcomCreateConsentRequestProcessor(srvcRequest);
					EcomMrchntServiceResponse srvcResp = processor.execute();
					
					if(srvcResp != null) {
						
						if(srvcResp.getCrtCnsntReqResp()!= null) {
							
							FLogger.info(logger, THIS_CLASS, methodName, "Successful with auditId : "+srvcResp.getResponseStatus().getAuditId());

					        FLogger.error(logger, THIS_CLASS, methodName, "Successful with request_id to be passed for verification : "
					        		+srvcResp.getCrtCnsntReqResp().getCreateConsentRequestResponse().getRequest_id());

							response = srvcResp.getCrtCnsntReqResp();
						
						}else {
							
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
							
							response = new EcomCreateConsentRequestResp();
							response.setResponseStatus(respStts);
						}
						
					}else {
						
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
						
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
						
						response = new EcomCreateConsentRequestResp();
						response.setResponseStatus(respStts);
					}
					
				}else {
					
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
					
					response = new EcomCreateConsentRequestResp();
					response.setResponseStatus(respStts);
				}
				
			}else {
				FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");
				
				respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
				
				response = new EcomCreateConsentRequestResp();
				response.setResponseStatus(respStts);
				
			}
			
		}catch (Exception e) {
			
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);			
			
			response = new EcomCreateConsentRequestResp();
			response.setResponseStatus(respStts);
			
		}finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		
		}
		
		return response;
		
	}

	private static MrchntRespStts validateInputs(EcomCreateConsentRequestReq processorInput) {

		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName);
		
		try {
			
			FLogger.info(logger, THIS_CLASS, methodName, "Payload: "+StringChecks.convertObjectToJson(processorInput));
			
			if(processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}	
			
			if(!StringChecks.isAnyFieldEmpty(processorInput.getVilMsisdn())) {
				
				if(!StringChecks.checkMsisdn(processorInput.getVilMsisdn())) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Vil msisdn");
					return respStts;
				}
			
			}
			
			if(!StringChecks.isAnyFieldEmpty(processorInput.getAirtelMsisdn())) {
				
				if(!StringChecks.checkMsisdn(processorInput.getAirtelMsisdn())) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Airtel msisdn");
					return respStts;
				}
			}
			
		}catch (Exception e) {
			
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
		}
		
		return respStts;
	}

}
