package com.vil.ecom.dxl.processPayment.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"order_id",
	"fulfillmentTransactionId",
	"fulfillmentTransactionStatus",
	"fulfillmentTransactionStatusCode",
	"fulfillmentFailureReason"
})

public class ProcessPaymentScssResp {

	@JsonProperty("order_id")
	private String order_id;
	@JsonProperty("fulfillmentTransactionId")
	private String fulfillmentTransactionId;
	@JsonProperty("fulfillmentTransactionStatus")
	private String fulfillmentTransactionStatus;
	@JsonProperty("fulfillmentTransactionStatusCode")
	private String fulfillmentTransactionStatusCode;
	@JsonProperty("fulfillmentFailureReason")
	private String fulfillmentFailureReason;
	
	@JsonProperty("order_id")
	public String getOrder_id() {
	return order_id;
	}
	
	@JsonProperty("order_id")
	public void setOrder_id(String orderId) {
	this.order_id = orderId;
	}
	
	@JsonProperty("fulfillmentTransactionId")
	public String getFulfillmentTransactionId() {
	return fulfillmentTransactionId;
	}
	
	@JsonProperty("fulfillmentTransactionId")
	public void setFulfillmentTransactionId(String fulfillmentTransactionId) {
	this.fulfillmentTransactionId = fulfillmentTransactionId;
	}
	
	@JsonProperty("fulfillmentTransactionStatus")
	public String getFulfillmentTransactionStatus() {
	return fulfillmentTransactionStatus;
	}
	
	@JsonProperty("fulfillmentTransactionStatus")
	public void setFulfillmentTransactionStatus(String fulfillmentTransactionStatus) {
	this.fulfillmentTransactionStatus = fulfillmentTransactionStatus;
	}
	
	@JsonProperty("fulfillmentTransactionStatusCode")
	public String getFulfillmentTransactionStatusCode() {
	return fulfillmentTransactionStatusCode;
	}
	
	@JsonProperty("fulfillmentTransactionStatusCode")
	public void setFulfillmentTransactionStatusCode(String fulfillmentTransactionStatusCode) {
	this.fulfillmentTransactionStatusCode = fulfillmentTransactionStatusCode;
	}
	
	@JsonProperty("fulfillmentFailureReason")
	public String getFulfillmentFailureReason() {
	return fulfillmentFailureReason;
	}
	
	@JsonProperty("fulfillmentFailureReason")
	public void setFulfillmentFailureReason(String fulfillmentFailureReason) {
	this.fulfillmentFailureReason = fulfillmentFailureReason;
	}

}