
package com.vil.ecom.fulfillmentOrderSttsQuery.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "common_service_request",
    "order"
})
public class RequestMessage implements Serializable
{

    @JsonProperty("common_service_request")
    private CommonServiceRequest commonServiceRequest;
    @JsonProperty("order")
    private Order order;
    private final static long serialVersionUID = 8717823111867766664L;

    @JsonProperty("common_service_request")
    public CommonServiceRequest getCommonServiceRequest() {
        return commonServiceRequest;
    }

    @JsonProperty("common_service_request")
    public void setCommonServiceRequest(CommonServiceRequest commonServiceRequest) {
        this.commonServiceRequest = commonServiceRequest;
    }

    @JsonProperty("order")
    public Order getOrder() {
        return order;
    }

    @JsonProperty("order")
    public void setOrder(Order order) {
        this.order = order;
    }

}
