
package com.vil.ecom.dxl.additionalBenefits.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "msisdn",
    "parentMSISDN",
    "Promotion"
})
public class AdditionalBenefitsReq {

    @JsonProperty("msisdn")
    private String msisdn;
    @JsonProperty("parentMSISDN")
    private String parentMSISDN;
    @JsonProperty("Promotion")
    private List<Promotion> Promotion = null;
    

    @JsonProperty("msisdn")
    public String getMsisdn() {
        return msisdn;
    }

    @JsonProperty("msisdn")
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    @JsonProperty("parentMSISDN")
    public String getParentMSISDN() {
        return parentMSISDN;
    }

    @JsonProperty("parentMSISDN")
    public void setParentMSISDN(String parentMSISDN) {
        this.parentMSISDN = parentMSISDN;
    }

    @JsonProperty("Promotion")
	public List<Promotion> getPromotion() {
		return Promotion;
	}

    @JsonProperty("Promotion")
	public void setPromotion(List<Promotion> promotion) {
		Promotion = promotion;
	}



	


	
	

	

   

    


}
