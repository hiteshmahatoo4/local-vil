package com.vil.ecom.dxl.initiateRefund.pojo;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"action",
	"transactionType",
	"description",
	"pgOrderId",
	"signature",
	"correlatorId",
	"refundOrderId",
	"amount"
})

public class InitiateRefundReq {

	@JsonProperty("action")
	private String action;
	@JsonProperty("transactionType")
	private String transactionType;
	@JsonProperty("description")
	private String description;
	@JsonProperty("pgOrderId")
	private String pgOrderId;
	@JsonProperty("signature")
	private String signature;
	@JsonProperty("correlatorId")
	private String correlatorId;
	@JsonProperty("refundOrderId")
	private String refundOrderId;
	@JsonProperty("amount")
	private Amount amount;
	
	@JsonProperty("action")
	public String getAction() {
		return action;
	}
	
	@JsonProperty("action")
	public void setAction(String action) {
		this.action = action;
	}
	
	@JsonProperty("transactionType")
	public String getTransactionType() {
		return transactionType;
	}
	
	@JsonProperty("transactionType")
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	@JsonProperty("description")
	public String getDescription() {
		return description;
	}
	
	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}
	
	@JsonProperty("pgOrderId")
	public String getPgOrderId() {
		return pgOrderId;
	}
	
	@JsonProperty("pgOrderId")
	public void setPgOrderId(String pgOrderId) {
		this.pgOrderId = pgOrderId;
	}
	
	@JsonProperty("signature")
	public String getSignature() {
		return signature;
	}
	
	@JsonProperty("signature")
	public void setSignature(String signature) {
		this.signature = signature;
	}
	
	@JsonProperty("correlatorId")
	public String getCorrelatorId() {
		return correlatorId;
	}
	
	@JsonProperty("correlatorId")
	public void setCorrelatorId(String correlatorId) {
		this.correlatorId = correlatorId;
	}
	
	@JsonProperty("refundOrderId")
	public String getRefundOrderId() {
		return refundOrderId;
	}
	
	@JsonProperty("refundOrderId")
	public void setRefundOrderId(String refundOrderId) {
		this.refundOrderId = refundOrderId;
	}
	
	@JsonProperty("amount")
	public Amount getAmount() {
		return amount;
	}
	
	@JsonProperty("amount")
	public void setAmount(Amount amount) {
		this.amount = amount;
	}

}