package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomFulfillmentTransactionStatusReq;
import com.vil.ecom.integration.pojo.EcomFulfillmentTransactionStatusResp;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomFulfillmentTransactionStatusProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomFulfillmentTransactionStatusUtil {

	private static final Log logger = LogFactoryUtil.getLog(EcomFulfillmentTransactionStatusUtil.class);
	private static final String THIS_CLASS = EcomFulfillmentTransactionStatusUtil.class.toString();
	
	/**
	 * @author Ishita
	 * <p>Telco Fulfillment Transaction Status API : fetchTransactionStatus </p>
	 * @param processorInput : EcomFulfillmentTransactionStatusReq pojo to be set for input paramater . Mandatory
	 * <h2>EcomFulfillmentTransactionStatusReq pojo details:</h2>
	 * @param pgOrderId : dxl pgOrder Id to be passed . Mandatory
	 * @param circleId : circle id to be passed. Optional
	 * @param subscriberType : SubscriberType PREPAID / POSTPAID to be passed. Optional
	 * @param provider : Provider type to be passed. Optional
	 * @return EcomFulfillmentTransactionStatusResp : EcomFulfillmentTransactionStatus API response
	 * <ul>
	 * <li>responseStatus : response status of the process call</li>
	 * <li>
	 * 	statusList
	 *  <ul>	  
	 * 		<li> msisdn : Beneficiary msisdn</li>
	 * 		<li> parentMSISDN : Beneficiary msisdn</li>
	 *      <li> pgOrderId : DXL order ID-Fulfillment order id</li>
	 * 		<li> amount : Pack amount</li>
	 * 		<li> fulfillmentTransactionId : from ETOPUP system Txn ID</li>
	 * 		<li> fulfillmentTransactionStatus : from ETOPUP system -SUCCESS,FAILURE,INPROGRESS</li>
	 * 		<li> fulfillmentTransactionStatusCode : from ETOPUP system txn Code</li>
	 * 		<li> fulfillmentFailureReason : from ETOPUP system Failure Reason</li>
	 * 		<li> servicefulfillmentCorreleationID : Ecomm Line Item Order ID - Fulfillment</li>
	 *  </ul>
	 *  </li></ul>
	 */
	public static  EcomFulfillmentTransactionStatusResp fetchTransactionStatus(EcomFulfillmentTransactionStatusReq processorInput) {
		
		String methodName = "fetchTransactionStatus";
		StopWatch stopwatch = null;
		EcomFulfillmentTransactionStatusResp response = null;
		MrchntRespStts respStts = null;
			
		try {
				
			stopwatch = new StopWatch();
			stopwatch.start();
				
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}
	
			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_FULFILLMENT_TRANSACTION_STATUS);
			}
				
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
	
		
			if (processorInput != null) {
				FLogger.debug(logger, THIS_CLASS, methodName,"Entered Method to fetch transaction status details for PgOrderId " + processorInput.getPgOrderID());
	
				respStts=validateInputs(processorInput);
				
				if(respStts==null) {
					
					EcomMrchntServiceRequest srvcRqst = new EcomMrchntServiceRequest();
					srvcRqst.setServiceNme(BaseConstants.API_SERVICES.DXL_FULFILLMENT_TRANSACTION_STATUS);
					srvcRqst.setFulfillmentTxnSttsReq(processorInput);
		
					EcomFulfillmentTransactionStatusProcessor processor = new EcomFulfillmentTransactionStatusProcessor(srvcRqst);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();
					
					if (srvcResp != null) {
						if (srvcResp.getFulfillmentTxnSttsResp()!= null) {
							FLogger.debug(logger, THIS_CLASS, methodName,"Got Reponse from the API ");
									
							response = new EcomFulfillmentTransactionStatusResp();
							response = srvcResp.getFulfillmentTxnSttsResp();
						} else {
						
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
						
							response = new EcomFulfillmentTransactionStatusResp();
							response.setStatusList(null);
							response.setResponseStatus(respStts);
						}
					} else {
						
						FLogger.error(logger, THIS_CLASS, methodName, "service response is null");
						respStts = RsValiatorResponse.errorResponse(null,BaseConstants.errorInProcessingReq);
						
						response = new EcomFulfillmentTransactionStatusResp();
						response.setStatusList(null);
						response.setResponseStatus(respStts);
					}
				} else {
					
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
					
					response = new EcomFulfillmentTransactionStatusResp();
					response.setStatusList(null);
					response.setResponseStatus(respStts);
					
					FLogger.debug(logger, THIS_CLASS, methodName, "Returning response: "+StringChecks.convertObjectToJson(response));
					
				}
			} else {
				FLogger.error(logger, THIS_CLASS, methodName, "processorInput is Null");
				
				respStts = RsValiatorResponse.errorResponse(null,BaseConstants.errorInProcessingReq);
			
				response = new EcomFulfillmentTransactionStatusResp();
				response.setStatusList(null);
				response.setResponseStatus(respStts);
				
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = RsValiatorResponse.errorResponse(null,BaseConstants.errorInProcessingReq);
				
			response = new EcomFulfillmentTransactionStatusResp();
			response.setStatusList(null);
			response.setResponseStatus(respStts);
		} finally {
			
			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName, "Exiting Method " + methodName );
			}
					
			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
			
		}
		
		return response;
	}
	
	/**
	 * 
	 * @param processorInput
	 * @return
	 */
	public static MrchntRespStts validateInputs(EcomFulfillmentTransactionStatusReq request){		
		
		String methodNme = "validateInputs";
	    MrchntRespStts respStts = null;
	
	    FLogger.info(logger, THIS_CLASS, methodNme, "Entered Method " + methodNme);
	    try {
	    	if(request==null) {
	    		respStts=RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
	    		return respStts;
	    	}
	    	
	    	respStts = RsValiatorResponse.validateStrInput(request.getPgOrderID(), null,"PgOrderID is not valid");
			
			if (respStts != null) {
				return respStts;
			}
	    	
	    	if(!StringChecks.isFieldEmpty(request.getCircleId())) {
	    		respStts = RsValiatorResponse.checkCircleResponse(request.getCircleId(),null);
		    	if(respStts!=null) {
		    		return respStts;
		    	}
	    	}

	    	if(!StringChecks.isFieldEmpty(request.getSubscriberType())) {
	    		if(!(request.getSubscriberType().equalsIgnoreCase("PREPAID") || request.getSubscriberType().equalsIgnoreCase("POSTPAID")) ) {
	    			respStts = RsValiatorResponse.invalidParamsResponse(null, "not a valid SubscriberType");
	    			return respStts;
	    		}
	    	}
	    } catch (Exception e) {
	    	StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodNme);
	    } finally {
			FLogger.debug(logger, THIS_CLASS, methodNme, "Exiting: "+methodNme);
		}
	    
	    return respStts;
	}
}
