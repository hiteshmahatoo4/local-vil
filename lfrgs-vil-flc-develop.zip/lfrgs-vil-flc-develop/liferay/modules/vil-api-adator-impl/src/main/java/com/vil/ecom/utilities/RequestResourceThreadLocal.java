package com.vil.ecom.utilities;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class RequestResourceThreadLocal {

	private static final int DIVISOR = 1000000;
	
	/**
	private static final ThreadLocal<String> uriThreadLocal = new ThreadLocal<String>() {
		@Override
		protected String initialValue() {
			return URIGenerator.generateURI();
		}
	};
	*/
	
	private static final ThreadLocal<String> uriThreadLocal = ThreadLocal.withInitial(new Supplier<String>() {
	    @Override
	    public String get() {
	    	return URIGenerator.generateURI();
	    }
	});
	
	private static final ThreadLocal<Map<String, List<String>>> requestStatisticsThreadLocal = new ThreadLocal<>();
	private static final ThreadLocal<String> serviceThreadLocal = new ThreadLocal<>();
	private static final ThreadLocal<String> requestThreadLocal = new ThreadLocal<>();
	private static final ThreadLocal<String> ipAddrssThreadLocal = new ThreadLocal<>();
	private static final ThreadLocal<String> webSrvcNmeThreadLocal = new ThreadLocal<>();
	private static final ThreadLocal<String> moduleNmeThreadLocal = new ThreadLocal<>();
	private static final ThreadLocal<String> loggedInUsrNmeThreadLocal = new ThreadLocal<>();
	private static final ThreadLocal<String> oauthTokenThreadLocal = new ThreadLocal<>();

	public static String getURI() {
		return uriThreadLocal.get();
	}

	public static void unsetURI() {
		uriThreadLocal.remove();
	}

	/**
	 * @param module
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	public static long addModuleResponseStatistic(String module, long startTime, long endTime) {
		long elapsedTime;
		if (requestStatisticsThreadLocal.get() == null) {
			
			Map<String, List<String>> statisticMap = new LinkedHashMap<>();
			List<String> moduleTimings = new ArrayList<>();
			elapsedTime = (endTime - startTime) / DIVISOR;
			moduleTimings.add(String.valueOf(elapsedTime));
			statisticMap.put(module, moduleTimings);
			
			requestStatisticsThreadLocal.set(statisticMap);
			
		} else {
			
			Map<String, List<String>> statisticMap = requestStatisticsThreadLocal.get();
			List<String> moduleTimings = null;
			elapsedTime = (endTime - startTime) / DIVISOR;
			
			if (statisticMap != null && !statisticMap.isEmpty()) {

				if (statisticMap.containsKey(module)) {

					moduleTimings = statisticMap.get(module);
					moduleTimings.add(String.valueOf(elapsedTime));

					statisticMap.put(module, moduleTimings);

				} else {

					moduleTimings = new ArrayList<>();
					moduleTimings.add(String.valueOf(elapsedTime));

					statisticMap.put(module, moduleTimings);
				}

			} else {

				moduleTimings = new ArrayList<>();
				moduleTimings.add(String.valueOf(elapsedTime));

				statisticMap = new LinkedHashMap<>();
				statisticMap.put(module, moduleTimings);
			}

			requestStatisticsThreadLocal.set(statisticMap);
		}
		return elapsedTime;
	}

	/**
	 * @param module : Module name for which statistics needed to be added.
	 * @param elapsedTime : in milliseconds
	 */
	public static void addModuleResponseStatistic(String module, long elapsedTime) {

		if (requestStatisticsThreadLocal.get() == null) {

			Map<String, List<String>> statisticMap = new LinkedHashMap<>();
			List<String> moduleTimings = new ArrayList<>();
			moduleTimings.add(String.valueOf(elapsedTime));
			statisticMap.put(module, moduleTimings);

			requestStatisticsThreadLocal.set(statisticMap);

		} else {

			Map<String, List<String>> statisticMap = requestStatisticsThreadLocal.get();
			List<String> moduleTimings = null;

			if (statisticMap != null && !statisticMap.isEmpty()) {

				if (statisticMap.containsKey(module)) {

					moduleTimings = statisticMap.get(module);
					moduleTimings.add(String.valueOf(elapsedTime));

					statisticMap.put(module, moduleTimings);

				} else {

					moduleTimings = new ArrayList<>();
					moduleTimings.add(String.valueOf(elapsedTime));

					statisticMap.put(module, moduleTimings);
				}

			} else {

				moduleTimings = new ArrayList<>();
				moduleTimings.add(String.valueOf(elapsedTime));

				statisticMap = new LinkedHashMap<>();
				statisticMap.put(module, moduleTimings);
			}
			
			requestStatisticsThreadLocal.set(statisticMap);
		}

	}

	public static Map<String, List<String>> getRequestStatistics() {
		return requestStatisticsThreadLocal.get();
	}

	public static void unsetRequestStatistics() {
		requestStatisticsThreadLocal.remove();
	}

	public static void addServiceForCurrentThread(String service) {
		if (serviceThreadLocal.get() == null) {
			serviceThreadLocal.set(service);
		}
	}

	public static String getServiceForCurrentThread() {
		return serviceThreadLocal.get();
	}

	public static void unsetServiceForCurrentThread() {
		serviceThreadLocal.remove();
	}

	public static void addRequestIdForCurrentThread(String requestId) {
		requestThreadLocal.set(requestId);
	}

	public static String getRequestIdForCurrentThread() {
		return requestThreadLocal.get();
	}

	public static void unsetRequestIdForCurrentThread() {
		requestThreadLocal.remove();
	}

	public static void addIpAddrssForCurrentThread(String ipAddrss) {
		ipAddrssThreadLocal.set(ipAddrss);
	}

	public static String getIpAddrssForCurrentThread() {
		return ipAddrssThreadLocal.get();
	}

	public static void unsetIpAddrssForCurrentThread() {
		ipAddrssThreadLocal.remove();
	}

	public static void addWebSrvcNmeForCurrentThread(String srvcNme) {
		webSrvcNmeThreadLocal.set(srvcNme);
	}

	public static String getWebSrvcNmeForCurrentThread() {
		return webSrvcNmeThreadLocal.get();
	}

	public static void unsetWebSrvcNmeForCurrentThread() {
		webSrvcNmeThreadLocal.remove();
	}

	public static void addModuleNmeForCurrentThread(String srvcNme) {
		moduleNmeThreadLocal.set(srvcNme);
	}

	public static String getModuleNmeForCurrentThread() {
		return moduleNmeThreadLocal.get();
	}

	public static void unsetModuleNmeForCurrentThread() {
		moduleNmeThreadLocal.remove();
	}

	public static void addloggedInUsrNmeThread(String srvcNme) {
		loggedInUsrNmeThreadLocal.set(srvcNme);
	}

	public static String getloggedInUsrNmeThread() {
		return loggedInUsrNmeThreadLocal.get();
	}

	public static void unsetloggedInUsrNmeThread() {
		loggedInUsrNmeThreadLocal.remove();
	}
	
	public static void addOauthTokenThread(String srvcNme) {
		oauthTokenThreadLocal.set(srvcNme);
	}

	public static String getOauthTokenThread() {
		return oauthTokenThreadLocal.get();
	}

	public static void unsetOauthTokenThread() {
		oauthTokenThreadLocal.remove();
	}

}
