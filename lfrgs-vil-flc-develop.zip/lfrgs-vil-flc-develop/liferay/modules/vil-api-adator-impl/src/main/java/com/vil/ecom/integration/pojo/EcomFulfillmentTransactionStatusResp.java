package com.vil.ecom.integration.pojo;

import com.vil.ecom.fulfillmentTransactionStts.pojo.Response;

import java.io.Serializable;
import java.util.List;

public class EcomFulfillmentTransactionStatusResp implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus; 
	
	private List<Response> statusList;
	
	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	public List<Response> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<Response> statusList) {
		this.statusList = statusList;
	}

}
