package com.vil.ecom.integration.helper;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.utilities.JAXBInterface;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Document;

public class SOAPUtil extends JAXBInterface {

	private static final Log logger = LogFactoryUtil.getLog(SOAPUtil.class);
	
	private static final String THIS_CLASS = SOAPUtil.class.toString();
	private static final String JAXB_FRAGMENT = "jaxb.fragment";
	private static final String OBJ_TO_SOAP_XML_HEADER_STRING = "objToSOAPXMLHeaderString";

	// unmarshal SOAP response XML to Object
	public static <T> Object unmarshal(Class<T> classType, String xml) {

		Object respObj = null;

		try {
			SOAPMessage message = MessageFactory.newInstance().createMessage(null,
					new ByteArrayInputStream(xml.getBytes()));
			SOAPBody sb = message.getSOAPBody();
			Document d = sb.extractContentAsDocument();
			DOMSource source = new DOMSource(d);
			JAXBContext context = getJaxBInstance(classType);

			respObj = context.createUnmarshaller().unmarshal((Source) source, classType).getValue();

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, "unmarshal");
		}

		return respObj;

	}

	@SuppressWarnings("rawtypes")
	public static String objToSOAPXMLString(Object record, Class objectClass) {

		String responseXML = "";

		try {
			if (record != null) {
				JAXBContext context = getJaxBInstance(objectClass);
				responseXML = marshalAsString(context, record, true);
			} else {
				responseXML = null;
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger,THIS_CLASS, "unmarshal");
		}

		return responseXML;
	}

	private static String marshalAsString(JAXBContext pContext, Object pObject, boolean formatOutputFlg)
			throws JAXBException, ParserConfigurationException, SOAPException, IOException {

		String soapEnvelope = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<soapenv:Header /><soapenv:Body>%s</soapenv:Body></soapenv:Envelope>";

		FLogger.debug(logger, THIS_CLASS, "marshalAsString", "formatOutputFlg : " + formatOutputFlg);

		Marshaller marshaller = pContext.createMarshaller();
		marshaller.setProperty(JAXB_FRAGMENT, Boolean.TRUE);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		marshaller.marshal(pObject, outputStream);
		String payload = new String(outputStream.toByteArray());

		return String.format(soapEnvelope, payload);

	}

	private static String marshalAsString(String headPayload, JAXBContext pContext, Object pObject,
			boolean formatOutputFlg, String Headerxml)
			throws JAXBException, ParserConfigurationException, SOAPException, IOException {

		String soapEnvelope = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<soapenv:Header >" + Headerxml + "</soapenv:Header>"
				+ "<soapenv:Body>%s</soapenv:Body></soapenv:Envelope>";

		FLogger.debug(logger, THIS_CLASS, "marshalAsString",
				"headPayload : " + headPayload + " | formatOutputFlg : " + formatOutputFlg);

		Marshaller marshaller = pContext.createMarshaller();
		marshaller.setProperty(JAXB_FRAGMENT, Boolean.TRUE);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		marshaller.marshal(pObject, outputStream);
		String payload = new String(outputStream.toByteArray());

		return String.format(soapEnvelope, payload);

	}

	@SuppressWarnings("rawtypes")
	public static String objToSOAPXMLHeaderString(Object head, Object body, Class objectClass, Class headobjectClass) {

		String responseXML = "";
		String headPayload = null;

		try {

			FLogger.debug(logger, THIS_CLASS, OBJ_TO_SOAP_XML_HEADER_STRING,
					"headobjectClass : " + (headobjectClass != null ? headobjectClass.getName() : null));

			if (head != null) {

				// JAXBContext context = JAXBContext.newInstance(headobjectClass);
				JAXBContext context = getJaxBInstance(objectClass);
				Marshaller marshaller = context.createMarshaller();
				marshaller.setProperty(JAXB_FRAGMENT, Boolean.TRUE);
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				marshaller.marshal(head, outputStream);
				headPayload = new String(outputStream.toByteArray());

				FLogger.debug(logger, THIS_CLASS, OBJ_TO_SOAP_XML_HEADER_STRING, "headPayload : " + headPayload);

			}

			if (body != null) {
				// JAXBContext context = JAXBContext.newInstance(objectClass);
				JAXBContext context = getJaxBInstance(objectClass);
				Marshaller marshaller = context.createMarshaller();
				marshaller.setProperty(JAXB_FRAGMENT, Boolean.TRUE);
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				marshaller.marshal(body, outputStream);
				responseXML = new String(outputStream.toByteArray());
			} else {
				responseXML = null;
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger,THIS_CLASS, OBJ_TO_SOAP_XML_HEADER_STRING);
		}

		return responseXML;
	}

	@SuppressWarnings("rawtypes")
	public static String objToSOAPXMLString(Object body, Class objectClass, Class headerObjectClass, String Headerxml) {

		String responseXML = "";

		try {

			String headPayload = null;

			FLogger.debug(logger, THIS_CLASS, OBJ_TO_SOAP_XML_HEADER_STRING,
					"headobjectClass : " + (headerObjectClass != null ? headerObjectClass.getName() : null));

			if (body != null) {
				// JAXBContext context = JAXBContext.newInstance(objectClass);
				JAXBContext context = getJaxBInstance(objectClass);
				responseXML = marshalAsString(headPayload, context, body, true, Headerxml);
			} else {
				responseXML = null;
			}
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger,THIS_CLASS, "objToSOAPXMLString");
		}
		return responseXML;
	}
}
