
package com.vil.ecom.createFulfillmentOrder.request.pojo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "first_name",
    "last_name",
    "gender",
    "age",
    "dob",
    "mobile_number",
    "emailid",
    "address",
    "employment_type",
    "salary",
    "father_name",
    "mother_name",
    "marital_status",
    "education",
    "bank_name",
    "bank_account_type",
    "bank_account_number",
    "property1",
    "property2",
    "identity_proof"
})
public class Customer implements Serializable
{

    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("age")
    private String age;
    @JsonProperty("dob")
    private String dob;
    @JsonProperty("mobile_number")
    private String mobileNumber;
    @JsonProperty("emailid")
    private String emailid;
    @JsonProperty("address")
    private Address address;
    @JsonProperty("employment_type")
    private String employmentType;
    @JsonProperty("salary")
    private String salary;
    @JsonProperty("father_name")
    private String fatherName;
    @JsonProperty("mother_name")
    private String motherName;
    @JsonProperty("marital_status")
    private String maritalStatus;
    @JsonProperty("education")
    private String education;
    @JsonProperty("bank_name")
    private String bankName;
    @JsonProperty("bank_account_type")
    private String bankAccountType;
    @JsonProperty("bank_account_number")
    private String bankAccountNumber;
    @JsonProperty("property1")
    private String property1;
    @JsonProperty("property2")
    private String property2;
    @JsonProperty("identity_proof")
    private List<IdentityProof> identityProof;
    private final static long serialVersionUID = 8021241347458437475L;

    @JsonProperty("first_name")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("first_name")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("last_name")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("last_name")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonProperty("age")
    public String getAge() {
        return age;
    }

    @JsonProperty("age")
    public void setAge(String age) {
        this.age = age;
    }

    @JsonProperty("dob")
    public String getDob() {
        return dob;
    }

    @JsonProperty("dob")
    public void setDob(String dob) {
        this.dob = dob;
    }

    @JsonProperty("mobile_number")
    public String getMobileNumber() {
        return mobileNumber;
    }

    @JsonProperty("mobile_number")
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    @JsonProperty("emailid")
    public String getEmailid() {
        return emailid;
    }

    @JsonProperty("emailid")
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("employment_type")
    public String getEmploymentType() {
        return employmentType;
    }

    @JsonProperty("employment_type")
    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    @JsonProperty("salary")
    public String getSalary() {
        return salary;
    }

    @JsonProperty("salary")
    public void setSalary(String salary) {
        this.salary = salary;
    }

    @JsonProperty("father_name")
    public String getFatherName() {
        return fatherName;
    }

    @JsonProperty("father_name")
    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    @JsonProperty("mother_name")
    public String getMotherName() {
        return motherName;
    }

    @JsonProperty("mother_name")
    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    @JsonProperty("marital_status")
    public String getMaritalStatus() {
        return maritalStatus;
    }

    @JsonProperty("marital_status")
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    @JsonProperty("education")
    public String getEducation() {
        return education;
    }

    @JsonProperty("education")
    public void setEducation(String education) {
        this.education = education;
    }

    @JsonProperty("bank_name")
    public String getBankName() {
        return bankName;
    }

    @JsonProperty("bank_name")
    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    @JsonProperty("bank_account_type")
    public String getBankAccountType() {
        return bankAccountType;
    }

    @JsonProperty("bank_account_type")
    public void setBankAccountType(String bankAccountType) {
        this.bankAccountType = bankAccountType;
    }

    @JsonProperty("bank_account_number")
    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    @JsonProperty("bank_account_number")
    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    @JsonProperty("property1")
    public String getProperty1() {
        return property1;
    }

    @JsonProperty("property1")
    public void setProperty1(String property1) {
        this.property1 = property1;
    }

    @JsonProperty("property2")
    public String getProperty2() {
        return property2;
    }

    @JsonProperty("property2")
    public void setProperty2(String property2) {
        this.property2 = property2;
    }

    @JsonProperty("identity_proof")
    public List<IdentityProof> getIdentityProof() {
        return identityProof;
    }

    @JsonProperty("identity_proof")
    public void setIdentityProof(List<IdentityProof> identityProof) {
        this.identityProof = identityProof;
    }

}
