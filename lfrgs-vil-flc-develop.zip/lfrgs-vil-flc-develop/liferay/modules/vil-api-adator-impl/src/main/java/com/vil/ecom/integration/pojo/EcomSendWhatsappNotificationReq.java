package com.vil.ecom.integration.pojo;


import com.vil.ecom.dxl.whatsappNotification.pojo.Characteristic;

import java.io.Serializable;
import java.util.List;

public class EcomSendWhatsappNotificationReq implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	    private String msisdn;
	    
	    private String whatsappUseCase;
	   
		private List<Characteristic> characteristic;

		/**
		 * @return the msisdn
		 */
		public String getMsisdn() {
			return msisdn;
		}

		/**
		 * @param msisdn the msisdn to set
		 */
		public void setMsisdn(String msisdn) {
			this.msisdn = msisdn;
		}

		/**
		 * @return the characteristic
		 */
		public List<Characteristic> getCharacteristic() {
			return characteristic;
		}

		/**
		 * @param characteristic the characteristic to set
		 */
		public void setCharacteristic(List<Characteristic> characteristic) {
			this.characteristic = characteristic;
		}

		/**
		 * @return the whatsappUseCase
		 */
		public String getWhatsappUseCase() {
			return whatsappUseCase;
		}

		/**
		 * @param whatsappUseCase the whatsappUseCase to set
		 */
		public void setWhatsappUseCase(String whatsappUseCase) {
			this.whatsappUseCase = whatsappUseCase;
		}
		
		
		
} 