package com.vil.ecom.dxl.processPayment.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"phoneNumber"
})
public class Payer {

	@JsonProperty("phoneNumber")
	private String phoneNumber;
	
	@JsonProperty("phoneNumber")
	public String getPhoneNumber() {
	return phoneNumber;
	}
	
	@JsonProperty("phoneNumber")
	public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
	}

}
