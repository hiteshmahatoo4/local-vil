package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomRefundStatusReq;
import com.vil.ecom.integration.pojo.EcomRefundStatusResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomRefundStatusProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomRefundStatusUtil {
	
	private static final Log logger = LogFactoryUtil.getLog(EcomRefundStatusUtil.class);
	private static final String THIS_CLASS = "EcomRefundStatusUtil";
	
	
	/**
	 * 
	 * @author Jeswanth
	 * <p>Refund Status API: Returns Refund Status Details</p>
	 * 
	 * @param processorInput : EcomRefundStatusReq pojo to be set . Mandatory
	 * <h2>EcomRefundStatusReq pojo details</h2>
	 * <p>
	 * @param circleId : circle id to be passed . Optional
	 * @param pgOrderId : DXL ORDER ID to be passed .<b> Mandatory</b>
	 * @param subscriptionType : Subscription type &#34;PREPAID&#34; or &#34;POSTPAID&#34; . Optional
	 * @param provider : Provider type to be passed . Optional
	 * </p>
	 * @return EcomRefundStatusResp : refundStatus details
	 * <ul>
	 * <li>responseStatus : response status for the process call</li>
	 * <li>
	 * 	refundStatus  : list of refund status details.
	 * 	<ul>
	 * 		<li>pgOrderId : DXL ORDER ID</li>
	 * 		<li>correlatorId : ECOMMOrderID for telco/NON TELCO parent ID</li>
	 * 		<li>refundOrderId : RefundOrder ID - Ecom Line item order id </li>
	 * 		<li>refundOrderStatus : DXL REFUND order status</li>
	 * 		<li>amount : Refund request amount from liferay</li>
	 * 		<li>srNumber : Refund Request instance X-BusinessTx-ID saved in DXL to track multiple requests on same Ecom Line item order id</li>
	 * 	</ul>
	 * </li>
	 * </ul>
	 */
	public static EcomRefundStatusResp getRefundStatus(EcomRefundStatusReq processorInput) {
		
		String methodName =  "getRefundStatus";
		StopWatch stopwatch = null;
		EcomRefundStatusResp response = null;
		MrchntRespStts respStts = null;
		
		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();
			
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_REFUND_STATUS);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
			
			if(processorInput != null) {
				
				FLogger.debug(logger, THIS_CLASS, methodName, "Entered method to get RefundStatus for pgOrderId: "+processorInput.getPgOrderId()+
						" | circle id: "+processorInput.getCircleId());
				
				respStts = validateInputs(processorInput);
				
				if(respStts == null) {
					
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.DXL_REFUND_STATUS);
					srvcRequest.setRefundStatusReq(processorInput);
					
					EcomRefundStatusProcessor processor = new EcomRefundStatusProcessor(srvcRequest);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();
					
					if(srvcResp != null) {
						
						if(srvcResp.getRefundStatusResp() != null) {
							
							FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API");
							
							response = new EcomRefundStatusResp();
							response = srvcResp.getRefundStatusResp();
						}else {
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = new MrchntRespStts();
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
							
							response = new EcomRefundStatusResp();
							response.setRefundStatus(null);
							response.setResponseStatus(respStts);
						}
						
					}else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
						
						respStts = new MrchntRespStts();
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
						
						
						response = new EcomRefundStatusResp();
						response.setRefundStatus(null);
						response.setResponseStatus(respStts);
					}
					
				}else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
					
					response = new EcomRefundStatusResp();
					response.setRefundStatus(null);
					response.setResponseStatus(respStts);
				}
				
			}else {
				FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");
				
				respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
				
				response = new EcomRefundStatusResp();
				response.setRefundStatus(null);
				response.setResponseStatus(respStts);
			}
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			response = new EcomRefundStatusResp();
			response.setRefundStatus(null);;
			response.setResponseStatus(respStts);
			
		}finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
			
			FLogger.debug(logger, THIS_CLASS, methodName, "Returning Response: "+StringChecks.convertObjectToJson(response));
		}

		
		return response;
	}

	private static MrchntRespStts validateInputs(EcomRefundStatusReq processorInput) {
		
		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName);
		
		try {
			
			FLogger.info(logger, THIS_CLASS, methodName, "Payload: "+StringChecks.convertObjectToJson(processorInput));
			if(processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getCircleId())) {
				respStts = RsValiatorResponse.checkCircleResponse(processorInput.getCircleId(),null);
				if(respStts != null) {
					return respStts;
				}
			}		
			
			respStts = RsValiatorResponse.validateStrInput(processorInput.getPgOrderId(), null, "PgOrderId is not valid");
			if(respStts != null) {
				return respStts;
			}
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}
		return respStts;
	}

}
