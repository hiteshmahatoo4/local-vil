package com.vil.ecom.eai.verifyOtpCreditInsight.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "client_code", "requested_msisdns", "otp", "request_id" })

public class VerifyOtpCreditInsightRequest {

	@JsonProperty("client_code")
	private String clientCode;
	@JsonProperty("requested_msisdns")
	private RequestedMsisdns requestedMsisdns;
	@JsonProperty("otp")
	private String otp;
	@JsonProperty("request_id")
	private String requestId;

	@JsonProperty("client_code")
	public String getClientCode() {
		return clientCode;
	}

	@JsonProperty("client_code")
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	@JsonProperty("requested_msisdns")
	public RequestedMsisdns getRequestedMsisdns() {
		return requestedMsisdns;
	}

	@JsonProperty("requested_msisdns")
	public void setRequestedMsisdns(RequestedMsisdns requestedMsisdns) {
		this.requestedMsisdns = requestedMsisdns;
	}

	@JsonProperty("otp")
	public String getOtp() {
		return otp;
	}

	@JsonProperty("otp")
	public void setOtp(String otp) {
		this.otp = otp;
	}

	@JsonProperty("request_id")
	public String getRequestId() {
		return requestId;
	}

	@JsonProperty("request_id")
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	

}
