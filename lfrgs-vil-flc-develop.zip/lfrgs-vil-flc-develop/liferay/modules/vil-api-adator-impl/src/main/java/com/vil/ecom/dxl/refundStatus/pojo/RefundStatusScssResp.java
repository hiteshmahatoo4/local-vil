
package com.vil.ecom.dxl.refundStatus.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "responseList"
})

public class RefundStatusScssResp implements Serializable{

    @JsonProperty("responseList")
    private List<Response> responseList;
    private final static long serialVersionUID = -506830846748827165L;
   
    @JsonProperty("responseList")
    public List<Response> getResponseList() {
        return responseList;
    }

    @JsonProperty("responseList")
    public void setResponseList(List<Response> responseList) {
        this.responseList = responseList;
    }


}
