package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomProcessPaymentReq;
import com.vil.ecom.integration.pojo.EcomProcessPaymentResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.utilities.RequestResourceThreadLocal;
import com.vil.ecom.integration.processor.EcomProcessPaymentProcessor;

import org.apache.commons.lang.time.StopWatch;

public class EcomProcessPaymentUtil {

	private static final Log logger = LogFactoryUtil.getLog(EcomProcessPaymentUtil.class);
	private static final String THIS_CLASS = "EcomProcessPaymentUtil";


	/**
	 * @author Ishita
	 * <p>Process Payment API : Prepaid Telco Recharges</p>
	 * @param processorInput : EcomProcessPaymentReq pojo to be set for input paramater . Mandatory
	 * <h2>EcomProcessPaymentReq pojo details:</h2>
	 * @param msisdn : Beneficiary MSISDN to be passed. Mandatory;
	 * @param paymentGatewayId : paymentGatewayId sent by Juspay-From initial payment details available at Liferay sent by DXL in updateorder API. Mandatory
	 * @param amount : RECHARGE PACK amount to be passed. Mandatory;
	 * @param pgOrderID : original base DXL OrderID on which payment was collected to be passed. Mandatory;
	 * @param ecommOrderId : original base Liferay ecommOrderId on which payment was collected to be passed. Mandatory;
	 * @param paymentDateTime : Payment Date Time from initial payment details available at Liferay. Optional
	 * @param gatewayTransactionId : Gateway Transaction id from initial payment details available at Liferay. Optional 
	 * @param paymentMode : Payment Mode from initial payment details available at Liferay. Optional
	 * @param paymentMethodType : payment method type like UPI, netbanking, wallet etc from initial payment details available at Liferay. Optional
	 * @param paymentGateway : payment gateway like BillDesk,Paytm  from initial payment details available at Liferay to be passed. Optional
	 * @param cardIssuer : bank name from initial payment details available at Liferay. Optional
	 * @param paymentMethod : payment method name like wallet name, upi method, netbanking bank name. Optional
	 * @param cardType : cardType like visa,mastercard etc from initial payment details available at Liferay. Optional
	 * @param paymentAmount : Total Amount Paid by Customer from initial payment details available at Liferay. Optional
	 * @return EcomProcessPaymentResp : EcomProcessPayment API response
	 * 	<ul>	  
	 * 		<li>order_id - DXL order ID-Fulfillment order id</li>
	 * 		<li>fulfillmentTransactionId - from ETOPUP system Txn ID</li>
	 * 		<li>fulfillmentTransactionStatus - from ETOPUP system -SUCCESS,FAILURE,INPROGRESS</li>
	 * 		<li>fulfillmentTransactionStatusCode - from ETOPUP system txn Code</li>
	 * 		<li>fulfillmentFailureReason - from ETOPUP system Failure Reason</li>
	 *  </ul>
	 */
	public static EcomProcessPaymentResp processPayment(EcomProcessPaymentReq processorInput) {

		String methodName = "processPayment";
		StopWatch stopwatch = null;
		EcomProcessPaymentResp response = null;
		MrchntRespStts respStts = null;
		
		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			if (RequestResourceThreadLocal.getRequestIdForCurrentThread() == null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if (RequestResourceThreadLocal.getServiceForCurrentThread() == null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_PROCESS_PAYMENT);
			}

			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);

			if (processorInput != null) {

				FLogger.debug(logger, THIS_CLASS, methodName, "Entered method to process payment for msisdn: "
						+ processorInput.getMsisdn());
				
				respStts = validateInputs(processorInput);

				if (respStts == null) {
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.DXL_PROCESS_PAYMENT);
					srvcRequest.setProcessPaymentReq(processorInput);

					EcomProcessPaymentProcessor processor = new EcomProcessPaymentProcessor(srvcRequest);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();

					if (srvcResp != null) {
						if (srvcResp.getProcessPaymentResp() != null) {
							FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API");

							response = new EcomProcessPaymentResp();
							response = srvcResp.getProcessPaymentResp();
						} else {
							FLogger.error(logger, THIS_CLASS, methodName,
									"Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);

							response = new EcomProcessPaymentResp();
							response.setProcessPaymentResponse(null);
							response.setResponseStatus(respStts);
						}
					} else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

						response = new EcomProcessPaymentResp();
						response.setProcessPaymentResponse(null);
						response.setResponseStatus(respStts);
					}
				} else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");

					response = new EcomProcessPaymentResp();
					response.setProcessPaymentResponse(null);
					response.setResponseStatus(respStts);

					FLogger.debug(logger, THIS_CLASS, methodName,
							"Returning response: " + StringChecks.convertObjectToJson(response));

				}

			} else {
				FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");

				respStts = new MrchntRespStts();
				respStts.setStatus(BaseConstants.FAILED_MSG);
				respStts.setDescription(BaseConstants.errorInProcessingReq);
				respStts.setStatusCde(BaseConstants.FAILED_MSG);

				response = new EcomProcessPaymentResp();
				response.setProcessPaymentResponse(null);
				response.setResponseStatus(respStts);

				FLogger.debug(logger, THIS_CLASS, methodName,
						"Returning response: " + StringChecks.convertObjectToJson(response));

			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			response = new EcomProcessPaymentResp();
			response.setProcessPaymentResponse(null);
			response.setResponseStatus(respStts);

		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();

		}

		return response;
	}

	/**
	 * 
	 * @param processorInput
	 * @return
	 */
	private static MrchntRespStts validateInputs(EcomProcessPaymentReq processorInput) {

		String methodName = "validateInputs";
		
		MrchntRespStts respStts = null;
		
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: " + methodName);
		
		try {

			FLogger.info(logger, THIS_CLASS, methodName,
					"Payload: " + StringChecks.convertObjectToJson(processorInput));

			if (processorInput == null) {
			
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}

			if (!(StringChecks.checkMsisdn(processorInput.getMsisdn()))) {
				
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Msisdn is not valid");
				return respStts;
			}

			if (!(StringChecks.validateAmt(processorInput.getAmount()))) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Amount is not valid");
				return respStts;
			}

			respStts = RsValiatorResponse.validateStrInput(processorInput.getPaymentGatewayId(), null,"Payment Gateway Id is not valid");
			
			if (respStts != null) {
				return respStts;
			}
			
			respStts = RsValiatorResponse.validateStrInput(processorInput.getPgOrderID(), null,"PgOrderID is not valid");
			
			if (respStts != null) {
				return respStts;
			}

			respStts = RsValiatorResponse.validateStrInput(processorInput.getEcommOrderId(), null,
						"Ecom Order id is not valid");
			if (respStts != null) {
				return respStts;
			}

			if(!StringChecks.isFieldEmpty(processorInput.getPaymentDateTime())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getPaymentDateTime(), null, "Payment Date Time is not valid");
				if (respStts != null) {
					return respStts;
				}
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getGatewayTransactionId())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getGatewayTransactionId(),
						null, "Gateway Transaction Id is not valid");
				if (respStts != null) {
					return respStts;
				}
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getPaymentMode())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getPaymentMode(),
						null, "Payment Mode is not valid");
				if (respStts != null) {
					return respStts;
				}
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getPaymentMethodType())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getPaymentMethodType(),
						null, "Payment Method type is not valid");
				if (respStts != null) {
					return respStts;
				}
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getPaymentGateway())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getPaymentGateway(),
						null, "Payment Gateway is not valid");
				if (respStts != null) {
					return respStts;
				}
			}

			if(!StringChecks.isFieldEmpty(processorInput.getCardIssuer())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getCardIssuer(),
						null, "Card Issuer is not valid");
				if (respStts != null) {
					return respStts;
				}
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getPaymentMethod())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getPaymentMethod(),
						null, "Payment Method is not valid");
				if (respStts != null) {
					return respStts;
				}
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getCardType())) {
				respStts = RsValiatorResponse.validateStrInput(processorInput.getCardType(),
						null, "Card Type is not valid");
				if (respStts != null) {
					return respStts;
				}
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getPaymentAmount())) {
				if (!(StringChecks.validateAmt(processorInput.getPaymentAmount()))) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Payment amount is not valid");
					return respStts;
				}
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}

		return respStts;
	}
}
