
package com.vil.ecom.createFulfillmentOrder.request.pojo;

import java.io.Serializable;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "encryptedPyload"
})

public class FulfillmentOrderReq implements Serializable
{

    @JsonProperty("encryptedPyload")
    private String encryptedPyload;
    private final static long serialVersionUID = -1265224954661383958L;

    @JsonProperty("encryptedPyload")
    public String getEncryptedPyload() {
        return encryptedPyload;
    }

    @JsonProperty("encryptedPyload")
    public void setEncryptedPyload(String encryptedPyload) {
        this.encryptedPyload = encryptedPyload;
    }

}
