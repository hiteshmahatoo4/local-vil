package com.vil.ecom.dxl.processPayment.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"totalAmount",
	"item"
})

public class PaymentItem {

	@JsonProperty("totalAmount")
	private TotalAmount totalAmount;
	@JsonProperty("item")
	private Item item;
	
	@JsonProperty("totalAmount")
	public TotalAmount getTotalAmount() {
	return totalAmount;
	}
	
	@JsonProperty("totalAmount")
	public void setTotalAmount(TotalAmount totalAmount) {
	this.totalAmount = totalAmount;
	}
	
	@JsonProperty("item")
	public Item getItem() {
	return item;
	}
	
	@JsonProperty("item")
	public void setItem(Item item) {
	this.item = item;
	}

}