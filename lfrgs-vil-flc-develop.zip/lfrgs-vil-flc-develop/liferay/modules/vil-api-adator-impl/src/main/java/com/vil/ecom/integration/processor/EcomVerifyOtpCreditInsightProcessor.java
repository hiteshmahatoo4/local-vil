 package com.vil.ecom.integration.processor;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.vil.ecom.adaptors.http.RestUtilVo;
import com.vil.ecom.adaptors.http.RestUtility;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.eai.verifyOtpCreditInsight.pojo.RequestedMsisdns;
import com.vil.ecom.eai.verifyOtpCreditInsight.pojo.VerifyOtpCreditInsightRequest;
import com.vil.ecom.eai.verifyOtpCreditInsight.pojo.VerifyOtpCreditInsightResponse;
import com.vil.ecom.integration.config.AppServiceProcessor;
import com.vil.ecom.integration.helper.EcomHelper;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomCreditInsightsLoginResp;
import com.vil.ecom.integration.pojo.EcomMrchntLogVO;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomVerifyOtpCreditInsightReq;
import com.vil.ecom.integration.pojo.EcomVerifyOtpCreditInsightResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.logger.srvc.EcomMrchntLogHelper;
import com.vil.ecom.service.EcomCreditInsightsLoginUtil;
import com.vil.ecom.service.EcomIntegrationUtils;
import com.vil.ecom.service.EcomSrvcConfigCnstntsServiceImpl;
import com.vil.ecom.utilities.EncDecutil;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EcomVerifyOtpCreditInsightProcessor implements AppServiceProcessor {
	
	
	private static final Log logger = LogFactoryUtil.getLog(EcomVerifyOtpCreditInsightProcessor.class);
	private static final String THIS_CLASS = EcomVerifyOtpCreditInsightProcessor.class.toString();

	/** Processor input and output pojo. */
	private EcomMrchntServiceRequest srvcRequest;
	private EcomMrchntServiceResponse srvcResponse;

	/**
	 * Application defined Inputs and output Pojo for given API which will be used
	 * by calling party.
	 */
	private EcomVerifyOtpCreditInsightReq request;
	private EcomVerifyOtpCreditInsightResp response;

	/**
	 * API request and response which needs to be sent/Received to/from 3rd party
	 * API Call.
	 */
	private VerifyOtpCreditInsightRequest apiReq;
	private VerifyOtpCreditInsightResponse apiResp;

	/** Map consisting API specific configurations stored in DB. */
	private Map<String, Object> confMap;

	/** Map consisting Url response received after connecting to 3rd party api. */
	private Map<String, String> urlResponseMap;

	/** API Name for which processor is implemented. */
	private String serviceNme;

	/** Pojo for logging of API request and response. */
	private EcomMrchntLogVO logVO;

	public EcomVerifyOtpCreditInsightProcessor(EcomMrchntServiceRequest srvcRequest) {
		this.srvcRequest = srvcRequest;
	}

	@Override
	public void preSrvcInputProcessor() {
	
		String thisMethod = "preSrvcInputProcessor";
	    String clientCode = null;
	    String path = null;
	    
	    
	  try {
	  
		if (srvcRequest != null && srvcRequest.getVerifyOtpCreditInsightReq()!= null) {
			
			if(RequestResourceThreadLocal.getModuleNmeForCurrentThread()==null) {
				RequestResourceThreadLocal.addModuleNmeForCurrentThread("api-adaptor");
			}
			
			request = srvcRequest.getVerifyOtpCreditInsightReq();
			serviceNme = srvcRequest.getServiceNme();

			if (request != null) {

				FLogger.info(logger,THIS_CLASS, thisMethod,srvcRequest.getServiceNme());
				
				confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap(srvcRequest.getServiceNme());
			
				FLogger.info(logger,THIS_CLASS, thisMethod, "Fetched Service Specific API Configurations for Service " + serviceNme + " | confMap : "
						+ confMap.size());

				FLogger.debug(logger,THIS_CLASS, thisMethod,
						"Populating API Specific Request Object for Service " + serviceNme);
				
				if(confMap.get(BaseConstants.API_SERVICES.CLIENT_CODE) != null) {

					clientCode = (String) confMap.get(BaseConstants.API_SERVICES.CLIENT_CODE);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "clientCode is " + clientCode);
				}
				
				if(confMap.get(BaseConstants.RESTWS.REST_ENC_PUBLIC_KEY) != null) {

					path = (String) confMap.get(BaseConstants.RESTWS.REST_ENC_PUBLIC_KEY);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "path is " + path);
				}
				
				FLogger.debug(logger,THIS_CLASS, thisMethod, "Encrypting the Phone Number ");
		
				if(clientCode!=null) {
					
					RequestedMsisdns msisdns=new RequestedMsisdns();
					
                    if(!StringChecks.isAnyFieldEmpty(request.getVilMsisdn())) {
						
                    	FLogger.debug(logger,THIS_CLASS, thisMethod, "Encrypting the vil Phone Number ");
						msisdns.setVil(EncDecutil.EncryptDecrypt(request.getVilMsisdn(), path, BaseConstants.ENCRYPT));
					}
					
					if(!StringChecks.isAnyFieldEmpty(request.getAirtelMsisdn())) {
						
						FLogger.debug(logger,THIS_CLASS, thisMethod, "Encrypting the Airtel Phone Number ");
						msisdns.setAirtel(EncDecutil.EncryptDecrypt(request.getAirtelMsisdn(),path, BaseConstants.ENCRYPT));	
					}
					
					apiReq = new VerifyOtpCreditInsightRequest();

					apiReq.setRequestedMsisdns(msisdns);
					apiReq.setOtp(request.getOtp());
					apiReq.setRequestId(request.getRequestId());
					apiReq.setClientCode(clientCode);
					
			    }else {
					FLogger.error(logger, THIS_CLASS, thisMethod, "ClientCode constant not set in dB");
				 }
				
				
				}else {
					FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is null");
				}
			}else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is null");
		    }
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}finally {
			FLogger.debug(logger, THIS_CLASS, thisMethod, "Exiting this method");
		}
		
	}

	@Override
	public EcomMrchntServiceResponse execute() {
	
		String thisMethod = "execute";

		String payload = null;

		String serviceProtocol = null;

		String apiUrl = null;

		int readTimeout = LoggerConstants.NUM_45000;
		int connTimeout = LoggerConstants.NUM_30000;

		String userId = null;
		String password = null;
		String authKey = null;
		
		boolean proxyFlg = false;
		boolean disableSslValidation = false;
		boolean disableHostNmeVerification = false;

		String trustStorePath = null;
		String trustStorePwd = null;
		String tlsVersion = null;
		
		String requestedId = null;
		String access_token =null;
		String token= null;
		
		FLogger.debug(logger, THIS_CLASS, thisMethod,"START");

		
		try {

			/** Formatting Input received into API specific pojo */
			preSrvcInputProcessor();

			/**
			 * Checking if input Object is not null and configurations are fetched from DB
			 * for given Service
			 */
			if (!StringChecks.isMapEmpty(confMap)) {

				FLogger.debug(logger, THIS_CLASS, thisMethod, "confMap fetched -> " + confMap.size());

				serviceProtocol = (String) (confMap.get(BaseConstants.RESTWS.REST_REQ_PROTOCOL));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "serviceProtocol is " + serviceProtocol);

				proxyFlg = Boolean.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_PROXY_FLG));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "proxy Flg is " + proxyFlg);

				if(confMap.get(BaseConstants.RESTWS.REST_USR_ID) != null) {

					userId = (String) confMap.get(BaseConstants.RESTWS.REST_USR_ID);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "userId is " + userId);
				}
   
				if (confMap.get(BaseConstants.RESTWS.REST_USR_PSWD) != null) {

					password = (String) confMap.get(BaseConstants.RESTWS.REST_USR_PSWD);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "password is " + password);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY) != null) {

					authKey = (String) confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "authKey is " + authKey);
				}			 

				if (confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT) != null) {
					connTimeout = Integer.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT) != null) {
					readTimeout = Integer.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT));
				}

				/** SSL Related properties Start */
				if (confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE) != null) {
					disableSslValidation = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY) != null) {
					disableHostNmeVerification = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION) != null) {
					tlsVersion = (String) confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH) != null) {
					trustStorePath = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD) != null) {
					trustStorePwd = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD);
				}
				
				/** SSL Related properties End */

				FLogger.debug(logger,THIS_CLASS, thisMethod,
						"connTimeout is " + connTimeout + " | readTimeout is " + readTimeout
								+ " | disableSslValidation is " + disableSslValidation
								+ " | disableHostNmeVerification is " + disableHostNmeVerification);

				/** 3rd Party API url to which requests needs to be submitted */
				
				if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTP_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTP_URL));

				} else if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTPS_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));

				} else {
					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));
				}

				FLogger.error(logger,THIS_CLASS, thisMethod, "API URl to Connect : " + apiUrl);
               
				payload = StringChecks.convertObjectToJson(apiReq);

				FLogger.debug(logger,THIS_CLASS, thisMethod, "Generated payload For API : " + payload);

				FLogger.error(logger,THIS_CLASS, thisMethod,  "Storing Request in DB");

				/** logging Request in DB for API before connection */
				logVO = new EcomMrchntLogVO();
				logVO.setServiceNme(srvcRequest.getServiceNme());
				logVO.setSourceIp(StringChecks.fetchLocalIpAddr());
				logVO.setIpAddr(StringChecks.fetchLocalIpAddr());
				logVO.setRequestParams(payload);
				logVO.setRequestType(BaseConstants.RESTWS.REST_OUTWARD_REQ);
				logVO.setFiller6(RequestResourceThreadLocal.getRequestIdForCurrentThread());
				logVO.setFiller4(apiUrl);
				logVO.setFiller3(BaseConstants.APIMODES.HTTP);
				logVO.setRequestTime(Calendar.getInstance().getTime());
				
				if(!StringChecks.isAnyFieldEmpty(request.getVilMsisdn())) {
					logVO.setMsisdn(request.getVilMsisdn());
				}if(!StringChecks.isAnyFieldEmpty(request.getAirtelMsisdn()))
					logVO.setMsisdn(request.getAirtelMsisdn());
				}
					
				String threadId = RequestResourceThreadLocal.getURI(); // Unique Thread ID generated for each processor
				 // request, used for tracking logs.

               if (!StringChecks.isFieldEmpty(threadId)) {
                     logVO.setFiller5(threadId);
                 }

                
			   if (confMap != null && confMap.get("REST_DUMMY_RESP_FLG") != null
								              && Boolean.parseBoolean((String) confMap.get("REST_DUMMY_RESP_FLG"))) {

					  logVO.setFiller2(BaseConstants.API_SERVICES.DUMMY_CALL);
				      EcomHelper.errorLog(logger,"Dummy Response Enabled for Service : " + serviceNme);
				      urlResponseMap = EcomMrchntLogHelper.populateDummyResp(confMap, serviceNme);
				      

			  }else {
				     
				  FLogger.info(logger, THIS_CLASS, thisMethod, "No Dummy Response Set.");
				  
					/**
					 * Header if any needs to be sent during API Url Connection For Web Service API
					 * call, Content-type needs to be set as text/xml For Rest API Calls,
					 * Content-type will be application/json or application/x-www-url-encoded as per
					 * API IDD document
					 */
				  
				  FLogger.error(logger,THIS_CLASS, thisMethod, "Calling fetchCreditInsightsLogin utility method to get access token");
				  
					EcomCreditInsightsLoginResp creditLogin = EcomCreditInsightsLoginUtil.creditInsightLogin();
					FLogger.info(logger, THIS_CLASS, thisMethod,"Response from CreditInsightsLogin utility method: "+StringChecks.convertObjectToJson(creditLogin));
  			        
					if(creditLogin.getCreditInsightsLoginResponse()!= null) {
						access_token = creditLogin.getCreditInsightsLoginResponse().getAccessToken();
					}
			
					if(access_token !=null) {
						FLogger.error(logger, THIS_CLASS, thisMethod,"access_token : "+access_token);
						access_token = creditLogin.getCreditInsightsLoginResponse().getAccessToken();
					    token = String.format("Bearer %s", access_token);
				        
					    requestedId =  EcomIntegrationUtils.generateAppId(); 
				
				        HashMap<String, String> headerParameters = new HashMap<>();
				        headerParameters.put(HttpHeaders.CONTENT_TYPE, "application/json");
			            headerParameters.put(HttpHeaders.AUTHORIZATION,token);
				        headerParameters.put(BaseConstants.HTTPHEADERS.X_REQUEST_ID, requestedId);
						
						
						/** Calling Url Connection Utility to Connect to API url with given payload */
					    RestUtilVo requestVo = new RestUtilVo();
	   				    requestVo.setpURL(apiUrl);
					    requestVo.setHeaderParameters(headerParameters);
					    requestVo.setPayload(payload);
					    requestVo.setUrlParameters(null); // No Form Data needs to be sent in this request so its null.
					    requestVo.setConnectionTimeOut(connTimeout);
					    requestVo.setConnectReadTimeout(readTimeout);
					    requestVo.setDisableHostNmeVerification(disableHostNmeVerification);
					    requestVo.setDisableSslValidation(disableSslValidation);
					    requestVo.setProxyFlag(proxyFlg);
					    requestVo.setTlsVersion(tlsVersion);
					    requestVo.setTrustStorePath(trustStorePath);
					    requestVo.setTrustStorePwd(trustStorePwd);
					    requestVo.setRequestType(BaseConstants.POST_REQUEST);
					    requestVo.setServiceNme(srvcRequest.getServiceNme());
					    requestVo.setConfMap(confMap);
						
						FLogger.error(logger, THIS_CLASS, thisMethod,"Calling RestUtility for the servicename : " + serviceNme);
						urlResponseMap = RestUtility.doConnectUrl(requestVo);
					}
				    
			        else {
						
						FLogger.error(logger, THIS_CLASS, thisMethod,"Unable to get response from CreditLoginResponse Api");
						srvcResponse = new EcomMrchntServiceResponse();
						srvcResponse.setVerifyOtpCreditInsightResp(response);
							
						MrchntRespStts respStts = new MrchntRespStts();
						respStts = RsValiatorResponse.errorResponse(requestedId, BaseConstants.errorInProcessingReq);
					    srvcResponse.setResponseStatus(respStts);
						
			       } 
			   }
		           /** Parse Response Received in Url Connection From API */
			    parseResponse();
			     if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {
					    srvcResponse.getResponseStatus().setResponseId(requestedId);
							
					   FLogger.error(logger, THIS_CLASS, thisMethod,
						     "Exiting Method " + thisMethod + " with Stts " +srvcResponse.getResponseStatus().getResponseId());	
					   
					   
					   
			     }
          else {
   				FLogger.error(logger, THIS_CLASS, thisMethod, "No Configurations Fetched, No Processing");
   		   }	
			
		 }catch (Exception e) {
		
			StringChecks.printExceptionErrors(e, logger,THIS_CLASS, thisMethod,
					"Exception scenario in processing service : " + serviceNme);
			
			
			MrchntRespStts respSts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setVerifyOtpCreditInsightResp(null);
			srvcResponse.setResponseStatus(respSts);
		
		}finally {
			FLogger.error(logger, THIS_CLASS, thisMethod, "Exting this Method");
		}
		
		return postSrvcOutputProcessor();
		
	}

	@Override
	
	public void parseResponse() {
 		
		String thisMethod = "parseResponse";
		String status = null;
		String respMsg = null;

		String errCde = null;
		String errDesc = null;
		String errStts = null;
		String score = null;
		Long auditId = null;
		String privateKey = null;

		try {

			status = urlResponseMap.get("status");
			respMsg = urlResponseMap.get("respMsg");
			String respCde = urlResponseMap.get("respCode");
			
			if(confMap.get(BaseConstants.RESTWS.REST_ENC_PRIVATE_KEY) != null) {

				privateKey = (String) confMap.get(BaseConstants.RESTWS.REST_ENC_PRIVATE_KEY);
				FLogger.debug(logger, THIS_CLASS, thisMethod, "privateKey is " + privateKey);
			}

			if (BaseConstants.SUCCESS_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger,THIS_CLASS, thisMethod,"Success In API Url Connection");

				apiResp = (VerifyOtpCreditInsightResponse) StringChecks.convertJsonToObject(respMsg,
						VerifyOtpCreditInsightResponse.class);
				
				if(apiResp != null) {
					
					FLogger.info(logger,THIS_CLASS, thisMethod,
							"Successful API Call :Got UPI Response from API," + " processing Response.");
	
					errCde = respCde;
					errStts = BaseConstants.STTS_MSG_SUCCESS;
					errDesc = BaseConstants.SUCCESS_MSG;

					FLogger.debug(logger,THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
					
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
					
					response = new EcomVerifyOtpCreditInsightResp();
					
					response.setVerifyOtpResponse(apiResp);
					
					FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
					if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
							
						score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
						FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
						response.setCreditInsightsScore(score);
					}else {		
						response.setCreditInsightsScore(null);
					 }
					
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);	
					
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse));
				}else {
					
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Successful API Connection but No proper Response from API," + " Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
					
					response = new EcomVerifyOtpCreditInsightResp();
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					
					FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
					if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
							
						score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
						FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
						response.setCreditInsightsScore(score);
					}else {						
						response.setCreditInsightsScore(null);
					}
                    
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);	
				}	
				FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");
				
				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);
				
					
		    }else if (BaseConstants.ERROR_MSG.equalsIgnoreCase(status)
					        || BaseConstants.FAILED_MSG.equalsIgnoreCase(status)
					        || BaseConstants.FAILURE_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger,THIS_CLASS, thisMethod, "Failure Scenario in Url Connection to API");

				apiResp = (VerifyOtpCreditInsightResponse) StringChecks.convertJsonToObject(respMsg,
						VerifyOtpCreditInsightResponse.class);
				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");
				
					errCde = respCde;
					errStts = BaseConstants.STTS_MSG_FAIL;
					errDesc = BaseConstants.FAILURE_MSG;

					FLogger.debug(logger,THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
				
					
				    MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
				 
				    response = new EcomVerifyOtpCreditInsightResp();
				    response.setVerifyOtpResponse(apiResp);
				    FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
				    
				    if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
						
						score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
						response.setCreditInsightsScore(score);
						FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
					}else {
						response.setCreditInsightsScore(null);
					}
					
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);		
                   
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse));
					
			    }else {
				  
					 FLogger.error(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection , Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
	   
					response = new EcomVerifyOtpCreditInsightResp();
					FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
					 if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
						  FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
						  score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
						  response.setCreditInsightsScore(score);
					}else {					
						response.setCreditInsightsScore(null);
						}
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);	
					
			    }
				FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");
				
				logVO.setResponseParams(respMsg);
				logVO.setRespStts(errStts);
				logVO.setRespSttsCde(errCde);
				logVO.setRespSttsDesc(errDesc);
				
				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);
				
				
			}else if (BaseConstants.TIMEOUT_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger,THIS_CLASS, thisMethod, "TimeOut Scenario in Url Connection to API");

				apiResp = (VerifyOtpCreditInsightResponse) StringChecks.convertJsonToObject(respMsg,
						VerifyOtpCreditInsightResponse.class);	
				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");
					
			
				    errCde = respCde;
				    errStts =BaseConstants.TIMEOUT_MSG;
					errDesc = BaseConstants.NO_RESP;
						
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
				    
					
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
				 
					response = new EcomVerifyOtpCreditInsightResp();
					
					FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
					
                    if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
					
						score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
						response.setCreditInsightsScore(score);
						FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
					}else {
						
						response.setCreditInsightsScore(null);
					}
                    
                    
					response.setVerifyOtpResponse(apiResp);
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);	
					
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse));
				
				}else {
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"TIMEOUT in Url Connection , Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
					
					response = new EcomVerifyOtpCreditInsightResp();
					
					FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
					
					 if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
							
							score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
							response.setCreditInsightsScore(score);
							FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
						}else {
							
							response.setCreditInsightsScore(null);
						}
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);
	 
				}		
				    FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");
				
					logVO.setResponseParams(respMsg);
					logVO.setRespStts(errStts);
					logVO.setRespSttsCde(errCde);
					logVO.setRespSttsDesc(errDesc);
				
					auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);
			}else {
				
				FLogger.error(logger,THIS_CLASS, thisMethod, "Unknown Scenario in Url Connection to API");

				apiResp = (VerifyOtpCreditInsightResponse) StringChecks.convertJsonToObject(respMsg,
						VerifyOtpCreditInsightResponse.class);
               
				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");

					errCde = BaseConstants.STTS_CODE_FAILURE;
					errStts = BaseConstants.STTS_MSG_FAIL;
					errDesc = BaseConstants.FAILURE_MSG;
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
					
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
					
					response = new EcomVerifyOtpCreditInsightResp();
					
					FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
					if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
							
						score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
						response.setCreditInsightsScore(score);
						FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
					}else {
						FLogger.info(logger, THIS_CLASS, thisMethod,"setting the Response3");
						response.setCreditInsightsScore(null);
						}

					response.setVerifyOtpResponse(apiResp);
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);	
					
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse));
					
			    }else {
			    	
			    	FLogger.error(logger, THIS_CLASS, thisMethod,
							"TIMEOUT in Url Connection , Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
					
					response = new EcomVerifyOtpCreditInsightResp();
					
					FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+apiResp.getData().getScoreInfo().getScore());
					if(!StringChecks.isFieldEmpty(apiResp.getData().getScoreInfo().getScore())) {
							
						score = EncDecutil.EncryptDecrypt(apiResp.getData().getScoreInfo().getScore(), privateKey, BaseConstants.DECRYPT);
						response.setCreditInsightsScore(score);
						FLogger.debug(logger,THIS_CLASS, thisMethod, "score value: "+score);
						
					}else {
						
						response.setCreditInsightsScore(null);
						}
					response.setResponseStatus(respStts);
					
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setVerifyOtpCreditInsightResp(response);
					srvcResponse.setResponseStatus(respStts);
	 			
			    }
				
				FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");
					
				logVO.setResponseParams(respMsg);
				logVO.setRespStts(errStts);
				logVO.setRespSttsCde(errCde);
				logVO.setRespSttsDesc(errDesc);
				
				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);
			}
				
		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
			
			MrchntRespStts respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
		
			FLogger.error(logger,THIS_CLASS, thisMethod, "Storing Response in DB");
			response = new EcomVerifyOtpCreditInsightResp();
			response.setResponseStatus(respStts);
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setVerifyOtpCreditInsightResp(response);
			srvcResponse.setResponseStatus(respStts);		
			
			logVO.setResponseParams(respMsg);
			logVO.setRespStts(errStts);
			logVO.setRespSttsCde(errCde);
			logVO.setRespSttsDesc(errDesc);
			
			auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);				
		}finally {
			
			if(srvcResponse!=null && srvcResponse.getResponseStatus()!=null) {
				srvcResponse.getResponseStatus().setAuditId(auditId);
			}
		}	
	}

	@Override
	public EcomMrchntServiceResponse postSrvcOutputProcessor() {
		FLogger.debug(logger, THIS_CLASS, "postSrvcOutputProcessor", "Returning response: "+StringChecks.convertObjectToJson(srvcResponse.getVerifyOtpCreditInsightResp()));
		return srvcResponse;
	}
	
	/**
	 * @param serviceNme
	 * @param confMap
	 * @param errCde
	 * @param errStts
	 * @param errDesc
	 * @return
	 */
	public static MrchntRespStts parseErrorCode(String serviceNme, Map<String, Object> confMap, String errCde,
			String errStts, String errDesc) {

		MrchntRespStts respStts = null;
		String thisMethod = "parseErrorCode";

		String successCodes = null;
		String pendingSuccessCodes = null;
		String failureCodes = null;

		String status = null;
		String statusDesc = null;

		List<String> successCodesList = new ArrayList<>();
		List<String> pendingSuccessCodesList = new ArrayList<>();
		List<String> failureCodesList = new ArrayList<>();

		try {
			
			
			successCodes = (String) confMap.get(BaseConstants.RESTWS.REST_SUCCESS_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "successCodes is " + successCodes);

			pendingSuccessCodes = (String) confMap.get(BaseConstants.RESTWS.REST_PENDING_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "pendingCodes is " + pendingSuccessCodes);

			failureCodes = (String) confMap.get(BaseConstants.RESTWS.REST_FAILURE_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "failureCodes is " + failureCodes);

			if (!StringChecks.isFieldEmpty(successCodes)) {
				successCodesList = Arrays.asList(successCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(pendingSuccessCodes)) {
				pendingSuccessCodesList = Arrays.asList(pendingSuccessCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(failureCodes)) {
				failureCodesList = Arrays.asList(failureCodes.split("[\\|]+"));
			}

			if (successCodesList != null && !successCodesList.contains(errCde)) {

				FLogger.error(logger, THIS_CLASS, thisMethod,
						"Non-Success Scenario for Service :: " + serviceNme);

				if (pendingSuccessCodesList != null && pendingSuccessCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Timeout Scenario for " + " as Response Code is : " + errStts + " is timeout code.");

					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				} else if (failureCodesList != null && failureCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"FAILURE Scenario for " + " as Response Code is : " + errStts + " is FAILURE code.");

					status = BaseConstants.FAILED_MSG;

					if (StringChecks.isFieldEmpty(errDesc)) {
						statusDesc = BaseConstants.FAILURE_MSG;
					} else {
						statusDesc = errDesc;
					}
				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Unknown/Deemed-Success Scenario for Service ::" + serviceNme);
					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				}

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success Scenario for Service :: " + serviceNme);
				status = BaseConstants.SUCCESS_MSG;

				if (StringChecks.isFieldEmpty(errDesc)) {
					statusDesc = BaseConstants.SUCCESS_MSG;
				} else {
					statusDesc = errDesc;
				}
			}

			respStts = new MrchntRespStts();
			respStts.setStatus(status);
			respStts.setStatusCde(errCde);
			respStts.setDescription(statusDesc);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
			
		}finally {
			FLogger.error(logger, THIS_CLASS, thisMethod, "Returning the MrchntRespStts");
		}
		return respStts;
	}	

}
