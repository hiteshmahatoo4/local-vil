package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class EcomSendMailServiceImpl {

	private static final Log logger = LogFactoryUtil.getLog(EcomSendMailServiceImpl.class);
	private static final String THIS_CLASS = EcomSendMailServiceImpl.class.toString();

	/**
	 * @author: GovindK
	 *          <p>
	 *          This function is used to send Email with Given Inputs.
	 *          </p>
	 * @param emailRecipients : comma separated list of email Ids
	 * @param emailCC         : comma separated list of email Ids
	 * @param emailBody       : Email Content
	 * @param emailFrom       : email Id of from where Email is sent.
	 * @param emailSubject    : Subject of email.
	 * @param blockCCMail     : boolean value to block sending mail to CC
	 *                        recepients.
	 * @return
	 */
	public Map<String, Object> sendMail(String emailRecipients, String emailCC, String emailBody, String emailFrom,
			String emailSubject, boolean blockCCMail, Map<String, Object> confMap) {

		String methodName = "sendMail";

		String emailText = emailBody;
		String emailHostName = null;
		String emailPort = null;

		int emailConnTimeout = 0;
		int emailReadTimeout = 0;

		boolean blockMail = false;
		boolean emailFlag = false;
		boolean reTriggerEmailFlag = false;

		// HashMap<String,Object> confMap=new HashMap<>();
		Map<String, Object> statusMap = new HashMap<>();

		List<String> errorMsgs = new ArrayList<>();

		FLogger.info(logger, THIS_CLASS, methodName, "Entered SendMailServiceImpl : Method sendMail");

		try {

			FLogger.debug(logger, THIS_CLASS, methodName,
					"SendMailServiceImpl : Method sendMail with Input Params : emailRecipients : " + emailRecipients
							+ " | emailCC :" + emailCC + " | emailFrom :" + emailFrom + " | emailSubject :"
							+ emailSubject);

			errorMsgs = validateMailInputs(emailRecipients, emailSubject, emailBody, emailFrom, null, false);

			if (errorMsgs != null && !errorMsgs.isEmpty()) {

				statusMap.put("status", BaseConstants.ERROR_MSG);
				statusMap.put("errorMsgs", errorMsgs);
				statusMap.put("statusDesc", errorMsgs.get(0));

			} else {

				if (confMap != null) {

					blockMail = Boolean.parseBoolean((String) confMap.get(BaseConstants.EMAIL.BLOCK_MAIL));
					emailHostName = (String) confMap.get(BaseConstants.EMAIL.EMAIL_HOST_NAME);
					emailPort = (String) confMap.get(BaseConstants.EMAIL.EMAIL_PORT);
					emailConnTimeout = Integer.parseInt((String) confMap.get(BaseConstants.EMAIL.EMAIL_CONN_TIMEOUT));
					emailReadTimeout = Integer.parseInt((String) confMap.get(BaseConstants.EMAIL.EMAIL_READ_TIMEOUT));

					FLogger.info(logger, THIS_CLASS, methodName,
							"emailConnTimeout :" + emailConnTimeout + "emailReadTimeout :" + emailReadTimeout);

					if (blockMail) {

						FLogger.error(logger,THIS_CLASS, methodName,
								"SendMailServiceImpl : Method sendMail : Email Sending is blocked.");

						emailFlag = Boolean.FALSE;

						statusMap.put("status", BaseConstants.ERROR_MSG);
						statusMap.put("errorMsgs", errorMsgs.add("Email Sending is blocked"));
						statusMap.put("statusDesc", errorMsgs.get(0));
						statusMap.put("processStts", emailFlag);

					} else {

						FLogger.debug(logger, THIS_CLASS, methodName,
								"SendMailServiceImpl : Method sendMail : About to send email with " + emailHostName
										+ ":" + emailPort + " | " + emailFrom);

						Properties properties = new Properties();
						properties.put(BaseConstants.EMAIL.MAIL_HOST_PROPERTY, emailHostName);
						properties.put(BaseConstants.EMAIL.MAIL_PORT_PROPERTY, emailPort);

						/** Added Connection timeout Property set in milliseconds */
						properties.put(BaseConstants.EMAIL.MAIL_CONN_TIMEOUT_PROPERTY, emailConnTimeout);

						javax.mail.Session session = javax.mail.Session.getInstance(properties, null);
						InternetAddress[] recipients;
						InternetAddress[] ccRecipients;

						recipients = InternetAddress.parse(emailRecipients);

						FLogger.debug(logger, THIS_CLASS, methodName,
								"SendMailServiceImpl : Method sendMail : Recipients of the mail:" + recipients);

						try {

							MimeMessage message = new MimeMessage(session);

							message.setFrom(new InternetAddress(emailFrom));

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail : Email From : " + message.getFrom());

							message.setRecipients(Message.RecipientType.TO, recipients);

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail Email To : "
											+ message.getRecipients(Message.RecipientType.TO));

							if (!blockCCMail) {

								if (!StringChecks.isFieldEmpty(emailCC)) {

									ccRecipients = InternetAddress.parse(emailCC);

									message.setRecipients(Message.RecipientType.CC, ccRecipients);

									FLogger.debug(logger, THIS_CLASS, methodName,
											"SendMailServiceImpl : Method sendMail Email CC : "
													+ message.getRecipients(Message.RecipientType.CC));

								} else {

									FLogger.error(logger,THIS_CLASS, methodName,
											"SendMailServiceImpl : Method sendMail Email CC is not set as null");

								}

							} else {

								FLogger.debug(logger, THIS_CLASS, methodName,
										"SendMailServiceImpl : Method sendMail Email Sending to CC is Blocked.");

							}

							message.setSubject(emailSubject);

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail :Subject set to: " + emailSubject);

							message.setSentDate(Calendar.getInstance().getTime());

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail Mail Sent date set to: "
											+ message.getSentDate());

							message.setContent(emailText, "text/html"); // to provide html support. e.g. Table

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail Email Body set to: " + emailText);

							Transport.send(message);

							FLogger.info(logger, THIS_CLASS, methodName,
									"Email was sent on: " + Calendar.getInstance().getTime());

							emailFlag = Boolean.TRUE;

							statusMap.put("status", BaseConstants.SUCCESS_MSG);
							statusMap.put("errorMsgs", null);
							statusMap.put("processStts", emailFlag);
							statusMap.put("reTrigger", reTriggerEmailFlag);

						} catch (Exception e) {

							StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

							emailFlag = Boolean.FALSE;
							reTriggerEmailFlag = Boolean.TRUE;

							statusMap.put("status", BaseConstants.ERROR_MSG);
							statusMap.put("errorMsgs", errorMsgs.add("Error in Sending Mail"));
							statusMap.put("processStts", emailFlag);
							statusMap.put("statusDesc", errorMsgs.get(0));
							statusMap.put("reTrigger", reTriggerEmailFlag);
						}
					}

				} else {

					FLogger.error(logger,THIS_CLASS, methodName,
							"No configuration fetched so Email Sending is blocked.");

					emailFlag = Boolean.FALSE;

					statusMap.put("status", BaseConstants.ERROR_MSG);
					statusMap.put("errorMsgs", errorMsgs.add("Email Sending is blocked"));
					statusMap.put("statusDesc", "Email Sending is blocked");
					statusMap.put("processStts", emailFlag);

				}

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
			reTriggerEmailFlag = Boolean.TRUE;

			statusMap.put("status", BaseConstants.ERROR_MSG);
			statusMap.put("errorMsgs", errorMsgs.add(e.getMessage()));
			statusMap.put("processStts", emailFlag);
			statusMap.put("statusDesc", errorMsgs.get(0));
			statusMap.put("reTrigger", reTriggerEmailFlag);

		} finally {
			FLogger.error(logger,THIS_CLASS, methodName,
					"Exiting Method " + methodName + " with StatusMap : " + statusMap.size());
		}

		return statusMap;

	}

	/**
	 * @author: GovindK
	 *          <p>
	 *          This function is used to send Email with Given Inputs.
	 *          </p>
	 * @param attachment      : File Object of attachment. Max 5 mb file will be
	 *                        pushed in mail.
	 * @param emailRecipients : comma separated list of email Ids
	 * @param emailCC         : comma separated list of email Ids
	 * @param emailBody       : Email Content
	 * @param emailFrom       : email Id of from where Email is sent.
	 * @param emailSubject    : Subject of email.
	 * @param blockCCMail     : boolean value to block sending mail to CC
	 *                        recipients.
	 * @return
	 */
	public Map<String, Object> sendMailWithAttachment(File attachment, String emailRecipients, String emailCC,
			String emailBody, String emailFrom, String emailSubject, boolean blockCCMail, Map<String, Object> confMap) {

		String methodName = "sendMailWithAttachment";

		String emailText = emailBody;
		String emailHostName = null;
		String emailPort = null;

		int emailConnTimeout = 0;
		int emailReadTimeout = 0;

		boolean blockMail = false;
		boolean emailFlag = false;
		boolean attachmentFlg = false;
		boolean reTriggerEmailFlag = false;

		Map<String, Object> statusMap = new HashMap<>();
		List<String> errorMsgs = new ArrayList<>();

		FLogger.info(logger, THIS_CLASS, methodName, "Entered SendMailServiceImpl : Method sendMail");

		try {

			FLogger.debug(logger, THIS_CLASS, methodName,
					"SendMailServiceImpl : Method sendMail with Input Params : emailRecipients : " + emailRecipients
							+ " | emailCC :" + emailCC + " | emailFrom :" + emailFrom + " | emailSubject :"
							+ emailSubject);

			errorMsgs = validateMailInputs(emailRecipients, emailSubject, emailBody, emailFrom, attachment, true);

			if (errorMsgs != null && !errorMsgs.isEmpty()) {

				statusMap.put("status", BaseConstants.ERROR_MSG);
				statusMap.put("errorMsgs", errorMsgs);
				statusMap.put("statusDesc", errorMsgs.get(0));

			} else {

				if (confMap != null) {

					blockMail = Boolean.parseBoolean((String) confMap.get(BaseConstants.EMAIL.BLOCK_MAIL));
					emailHostName = (String) confMap.get(BaseConstants.EMAIL.EMAIL_HOST_NAME);
					emailPort = (String) confMap.get(BaseConstants.EMAIL.EMAIL_PORT);
					emailConnTimeout = Integer.parseInt((String) confMap.get(BaseConstants.EMAIL.EMAIL_CONN_TIMEOUT));
					emailReadTimeout = Integer.parseInt((String) confMap.get(BaseConstants.EMAIL.EMAIL_READ_TIMEOUT));

					FLogger.info(logger, THIS_CLASS, methodName,
							"emailConnTimeout :" + emailConnTimeout + "emailReadTimeout :" + emailReadTimeout);

					if (blockMail) {

						FLogger.error(logger,THIS_CLASS, methodName,
								"SendMailServiceImpl : Method sendMail : Email Sending is blocked.");

						emailFlag = Boolean.FALSE;

						statusMap.put("status", BaseConstants.ERROR_MSG);
						statusMap.put("errorMsgs", errorMsgs.add("Email Sending is blocked"));
						statusMap.put("statusDesc", errorMsgs.get(0));
						statusMap.put("processStts", emailFlag);

					} else {

						FLogger.debug(logger, THIS_CLASS, methodName,
								"SendMailServiceImpl : Method sendMail : About to send email with " + emailHostName
										+ ":" + emailPort + " | " + emailFrom);

						Properties properties = new Properties();
						properties.put(BaseConstants.EMAIL.MAIL_HOST_PROPERTY, emailHostName);
						properties.put(BaseConstants.EMAIL.MAIL_PORT_PROPERTY, emailPort);

						/** Added Connection timeout Property set in milliseconds */
						properties.put(BaseConstants.EMAIL.MAIL_CONN_TIMEOUT_PROPERTY, emailConnTimeout);

						javax.mail.Session session = javax.mail.Session.getInstance(properties, null);
						InternetAddress[] recipients;
						InternetAddress[] ccRecipients;

						recipients = InternetAddress.parse(emailRecipients);

						FLogger.debug(logger, THIS_CLASS, methodName,
								"SendMailServiceImpl : Method sendMail : Recipients of the mail:" + recipients);

						try {

							MimeMessage message = new MimeMessage(session);

							message.setFrom(new InternetAddress(emailFrom));

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail : Email From : " + message.getFrom());

							message.setRecipients(Message.RecipientType.TO, recipients);

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail Email To : "
											+ message.getRecipients(Message.RecipientType.TO));

							if (!blockCCMail) {

								if (!StringChecks.isFieldEmpty(emailCC)) {

									ccRecipients = InternetAddress.parse(emailCC);

									message.setRecipients(Message.RecipientType.CC, ccRecipients);

									FLogger.debug(logger, THIS_CLASS, methodName,
											"SendMailServiceImpl : Method sendMail Email CC : "
													+ message.getRecipients(Message.RecipientType.CC));

								} else {

									FLogger.error(logger,THIS_CLASS, methodName,
											"SendMailServiceImpl : Method sendMail Email CC is not set as null");

								}

							} else {

								FLogger.debug(logger, THIS_CLASS, methodName,
										"SendMailServiceImpl : Method sendMail Email Sending to CC is Blocked.");

							}

							message.setSubject(emailSubject);

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail :Subject set to: " + emailSubject);

							message.setSentDate(Calendar.getInstance().getTime());

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail Mail Sent date set to: "
											+ message.getSentDate());

							message.setContent(emailText, "text/html"); // to provide html support. e.g. Table

							FLogger.debug(logger, THIS_CLASS, methodName,
									"SendMailServiceImpl : Method sendMail Email Body set to: " + emailText);

							MimeBodyPart messagePart = new MimeBodyPart();

							messagePart.setContent(emailText, "text/html");// to provide html support. e.g. Table

							FLogger.debug(logger, THIS_CLASS, methodName, "Email Text set to: " + emailText);

							Multipart multipart = new MimeMultipart();
							multipart.addBodyPart(messagePart);

							MimeBodyPart attachmentPart = null;
							attachmentPart = new MimeBodyPart();
							FileDataSource dailyFileDataSource = new FileDataSource(attachment);
							attachmentPart.setDataHandler(new DataHandler(dailyFileDataSource));
							attachmentPart.setFileName(attachment.getName());
							multipart.addBodyPart(attachmentPart);

							message.setContent(multipart);
							attachmentFlg = true;

							if (attachmentFlg) {

								Transport.send(message);

								FLogger.info(logger, THIS_CLASS, methodName,
										": Mail Sent to :" + emailRecipients + " | email Subject : " + emailSubject
												+ " | email Body : " + emailBody);

							} else {

								FLogger.error(logger,THIS_CLASS, methodName,
										": Email not sent as error in attaching attachment.");
							}

							FLogger.info(logger, THIS_CLASS, methodName,
									"Email was sent on: " + Calendar.getInstance().getTime());

							emailFlag = Boolean.TRUE;

							statusMap.put("status", BaseConstants.SUCCESS_MSG);
							statusMap.put("errorMsgs", null);
							statusMap.put("processStts", emailFlag);
							statusMap.put("reTrigger", reTriggerEmailFlag);

						} catch (Exception e) {

							StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);

							emailFlag = Boolean.FALSE;
							reTriggerEmailFlag = Boolean.TRUE;

							statusMap.put("status", BaseConstants.ERROR_MSG);
							statusMap.put("errorMsgs", errorMsgs.add("Error in Sending Mail"));
							statusMap.put("processStts", emailFlag);
							statusMap.put("statusDesc", errorMsgs.get(0));
							statusMap.put("reTrigger", reTriggerEmailFlag);
						}
					}

				} else {

					FLogger.error(logger,THIS_CLASS, methodName,
							"No configuration fetched so Email Sending is blocked.");

					emailFlag = Boolean.FALSE;

					statusMap.put("status", BaseConstants.ERROR_MSG);
					statusMap.put("errorMsgs", errorMsgs.add("Email Sending is blocked"));
					statusMap.put("statusDesc", "Email Sending is blocked");
					statusMap.put("processStts", emailFlag);

				}

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
			reTriggerEmailFlag = Boolean.TRUE;

			statusMap.put("status", BaseConstants.ERROR_MSG);
			statusMap.put("errorMsgs", errorMsgs.add(e.getMessage()));
			statusMap.put("processStts", emailFlag);
			statusMap.put("statusDesc", errorMsgs.get(0));
			statusMap.put("reTrigger", reTriggerEmailFlag);

		} finally {
			FLogger.error(logger,THIS_CLASS, methodName,
					"Exiting Method " + methodName + " with StatusMap : " + statusMap.size());
		}

		return statusMap;

	}

	/**
	 * @param emailTo
	 * @param emailSubject
	 * @param emailTxt
	 * @param emailFrom
	 * @param attachment
	 * @param validateAttachment
	 * @return
	 */
	public List<String> validateMailInputsWithoutEmailContent(String emailTo, String emailSubject, String emailTxt,
			String emailFrom, File attachment, boolean validateAttachment) {

		List<String> errorMsgs = new ArrayList<>();
		String methodName = "validateMailInputs";

		FLogger.info(logger, THIS_CLASS, methodName,
				"Entered SendMailServiceImpl : method validateMailInputs");

		if (StringChecks.isFieldEmpty(emailFrom)) {

			errorMsgs.add("Input Param Email From should not be empty");
		}

		if (StringChecks.isFieldEmpty(emailSubject)) {

			errorMsgs.add("Input Param Email Subject should not be empty");
		}

		if (StringChecks.isFieldEmpty(emailTxt)) {

			errorMsgs.add("Input Param Email Txt should not be empty");
		}

		if (StringChecks.isFieldEmpty(emailTo)) {

			errorMsgs.add("Input Param Email To Recepients List should not be empty");
		}

		if (validateAttachment) {

			if (attachment != null) {
				FLogger.debug(logger, THIS_CLASS, methodName, "Attachment present");
			} else {
				errorMsgs.add("Attachment file to be sent on mail should not be null.");
			}
		}

		FLogger.info(logger, THIS_CLASS, methodName,
				"Exiting SendMailServiceImpl : method validateMailInputs : error Msg List : " + errorMsgs.size());

		return errorMsgs;

	}

	/**
	 * <p>
	 * Validate Inputs Passed to The email Utility.
	 * </p>
	 * 
	 * @param emailTo
	 * @param emailSubject
	 * @param emailTxt
	 * @param emailFrom
	 * @param attachment
	 * @param validateAttachment
	 * @return
	 */
	public List<String> validateMailInputs(String emailTo, String emailSubject, String emailTxt, String emailFrom,
			File attachment, boolean validateAttachment) {

		List<String> errorMsgs = new ArrayList<>();
		String methodName = "validateMailInputs";

		FLogger.info(logger, THIS_CLASS, methodName,
				"Entered SendMailServiceImpl : method validateMailInputs");

		if (StringChecks.isFieldEmpty(emailFrom)) {

			errorMsgs.add("Input Param Email From should not be empty");
		}

		if (StringChecks.isFieldEmpty(emailSubject)) {

			errorMsgs.add("Input Param Email Subject should not be empty");
		}

		if (StringChecks.isFieldEmpty(emailTxt)) {

			errorMsgs.add("Input Param Email Body should not be empty");
		}

		if (StringChecks.isFieldEmpty(emailTo)) {

			errorMsgs.add("Input Param Email To Recepients List should not be empty");
		}

		if (validateAttachment) {

			if (attachment != null) {
				FLogger.debug(logger, THIS_CLASS, methodName," empty IF block");
			} else {
				errorMsgs.add("Attachment file to be sent on mail should not be null.");
			}
		}

		FLogger.info(logger, THIS_CLASS, methodName,
				"Exiting SendMailServiceImpl : method validateMailInputs : error Msg List : " + errorMsgs.size());

		return errorMsgs;

	}

}