package com.vil.ecom.integration.pojo;

import com.vil.ecom.createFulfillmentOrder.request.pojo.EcomCreateFulfillmentOrderRequest;
import com.vil.ecom.fulfillmentOrderSttsQuery.request.EcomFulfillmentOrderSttsQueryReq;

public class EcomMrchntServiceRequest {

	private boolean apiCheckerFlg;

	private String serviceNme;

	private EcomSendSmsReqDtls sendSmsReqDtls;

	private EcomSendMailReqDtls sendMailReqDtls;
	
	private EcomAdditionalBenefitsReq additionalBenefitsReq;
	
	private EcomProcessPaymentReq processPaymentReq;
	
	private EcomCreateConsentRequestReq crtCnsntReqReq;
	
	private EcomCustomerLookupReq cstmrLookupReq;	
	
	private EcomSendSmsNotificationReq sendSmsNtfReq;
	
	private EcomSendWhatsappNotificationReq whatsappNotificationReq;
	
	private EcomCreditInsightsInternalConsentReq creditInsightsInternalConsentReq;
	
	private EcomVerifyOtpCreditInsightReq verifyOtpCreditInsightReq;
	
	private EcomRefundStatusReq refundStatusReq;
	
	private EcomUploadEventsReq uploadEventsReq;
	
	private EcomInitiateRefundReq intiateRefundReq;
	
	private EcomFulfillmentTransactionStatusReq fulfillmentTxnSttsReq;
	
	private EcomCreateFulfillmentOrderRequest createFulfillmentOrderReq;
	
	private EcomFulfillmentOrderSttsQueryReq fulfillmentOrderSttsQueryReq;
    
	public boolean isApiCheckerFlg() {
		return apiCheckerFlg;
	}

	public void setApiCheckerFlg(boolean apiCheckerFlg) {
		this.apiCheckerFlg = apiCheckerFlg;
	}

	public String getServiceNme() {
		return serviceNme;
	}

	public void setServiceNme(String serviceNme) {
		this.serviceNme = serviceNme;
	}

	public EcomSendSmsReqDtls getSendSmsReqDtls() {
		return sendSmsReqDtls;
	}

	public void setSendSmsReqDtls(EcomSendSmsReqDtls sendSmsReqDtls) {
		this.sendSmsReqDtls = sendSmsReqDtls;
	}

	public EcomSendMailReqDtls getSendMailReqDtls() {
		return sendMailReqDtls;
	}

	public void setSendMailReqDtls(EcomSendMailReqDtls sendMailReqDtls) {
		this.sendMailReqDtls = sendMailReqDtls;
	}

	public EcomAdditionalBenefitsReq getAdditionalBenefitsReq() {
		return additionalBenefitsReq;
	}

	public void setAdditionalBenefitsReq(EcomAdditionalBenefitsReq additionalBenefitsReq) {
		this.additionalBenefitsReq = additionalBenefitsReq;
	}

	public EcomProcessPaymentReq getProcessPaymentReq() {
		return processPaymentReq;
	}

	public void setProcessPaymentReq(EcomProcessPaymentReq processPaymentReq) {
		this.processPaymentReq = processPaymentReq;
	}

	public EcomCreateConsentRequestReq getCrtCnsntReqReq() {
		return crtCnsntReqReq;
	}

	public void setCrtCnsntReqReq(EcomCreateConsentRequestReq crtCnsntReqReq) {
		this.crtCnsntReqReq = crtCnsntReqReq;
	}

	public EcomCustomerLookupReq getCstmrLookupReq() {
		return cstmrLookupReq;
	}

	public void setCstmrLookupReq(EcomCustomerLookupReq cstmrLookupReq) {
		this.cstmrLookupReq = cstmrLookupReq;
	}

	
	public EcomSendSmsNotificationReq getSendSmsNtfReq() {
		return sendSmsNtfReq;
	}

	public void setSendSmsNtfReq(EcomSendSmsNotificationReq sendSmsNtfReq) {
		this.sendSmsNtfReq = sendSmsNtfReq;
	}

	public EcomSendWhatsappNotificationReq getWhatsappNotificationReq() {
		return whatsappNotificationReq;
	}

	
	public void setWhatsappNotificationReq(EcomSendWhatsappNotificationReq whatsappNotificationReq) {
		this.whatsappNotificationReq = whatsappNotificationReq;
	}

	/**
	 * @return the creditInsightsInternalConsentReq
	 */
	public EcomCreditInsightsInternalConsentReq getCreditInsightsInternalConsentReq() {
		return creditInsightsInternalConsentReq; 
	}

	/**
	 * @param creditInsightsInternalConsentReq the creditInsightsInternalConsentReq to set
	 */
	public void setCreditInsightsInternalConsentReq(EcomCreditInsightsInternalConsentReq creditInsightsInternalConsentReq) {
		this.creditInsightsInternalConsentReq = creditInsightsInternalConsentReq;
	}

	
	public EcomVerifyOtpCreditInsightReq getVerifyOtpCreditInsightReq() {
		return verifyOtpCreditInsightReq;
	}

	
	public void setVerifyOtpCreditInsightReq(EcomVerifyOtpCreditInsightReq verifyOtpCreditInsightReq) {
		this.verifyOtpCreditInsightReq = verifyOtpCreditInsightReq;
	}

	public EcomRefundStatusReq getRefundStatusReq() {
		return refundStatusReq;
	}

	public void setRefundStatusReq(EcomRefundStatusReq refundStatusReq) {
		this.refundStatusReq = refundStatusReq;
	}

	public EcomUploadEventsReq getUploadEventsReq() {
		return uploadEventsReq;
	}

	public void setUploadEventsReq(EcomUploadEventsReq uploadEventsReq) {
		this.uploadEventsReq = uploadEventsReq;
	}

	public EcomInitiateRefundReq getIntiateRefundReq() {
		return intiateRefundReq;
	}

	public void setIntiateRefundReq(EcomInitiateRefundReq intiateRefundReq) {
		this.intiateRefundReq = intiateRefundReq;
	}

	public EcomFulfillmentTransactionStatusReq getFulfillmentTxnSttsReq() {
		return fulfillmentTxnSttsReq;
	}

	public void setFulfillmentTxnSttsReq(EcomFulfillmentTransactionStatusReq fulfillmentTxnSttsReq) {
		this.fulfillmentTxnSttsReq = fulfillmentTxnSttsReq;
	}

	public EcomCreateFulfillmentOrderRequest getCreateFulfillmentOrderReq() {
		return createFulfillmentOrderReq;
	}

	public void setCreateFulfillmentOrderReq(EcomCreateFulfillmentOrderRequest createFulfillmentOrderReq) {
		this.createFulfillmentOrderReq = createFulfillmentOrderReq;
	}

	public EcomFulfillmentOrderSttsQueryReq getFulfillmentOrderSttsQueryReq() {
		return fulfillmentOrderSttsQueryReq;
	}

	public void setFulfillmentOrderSttsQueryReq(EcomFulfillmentOrderSttsQueryReq fulfillmentOrderSttsQueryReq) {
		this.fulfillmentOrderSttsQueryReq = fulfillmentOrderSttsQueryReq;
	}
	
}
