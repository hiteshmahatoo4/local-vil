/**
 * 
 */
package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomCreditInsightsInternalConsentReq;
import com.vil.ecom.integration.pojo.EcomCreditInsightsInternalConsentResp;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomCreditInsightsInternalConsentProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

/**
 * @author 1856895
 *
 */
public class EcomCreditInsightsInternalConsentUtil {
	private static final Log logger = LogFactoryUtil.getLog(EcomCreditInsightsInternalConsentUtil.class);
	private static final String THIS_CLASS = "EcomCreditInsightsInternalConsentUtil";

	
	
	/**
	 * @author Monika
	 *         <p>
	 *         Credit Insights Internal Consent API
	 *         </p>
	 * @param processorInput   : EcomCreditInsightsInternalConsentReq pojo to be set
	 *                         for input paramater . Mandatory
	 *                         <p>
	 *                         <h2>EcomCreditInsightsInternalConsentReq pojo
	 *                         details:</h2>
	 * @param vilMsisdn  : vil msisdn to be passed.
	 * @param airtelMsisdn  : airtel msisdn to be passed.
	 * 
	 *                         </p>
	 * @return EcomCreditInsightsInternalConsentResp :
	 *         EcomCreditInsightsInternalConsent API response
	 */
	public static EcomCreditInsightsInternalConsentResp getCreditInsightsInternalConsent(
			EcomCreditInsightsInternalConsentReq processorInput) {

		String methodName = "getCreditInsightsInternalConsent";
		StopWatch stopwatch = null;
		EcomCreditInsightsInternalConsentResp response = null;
		MrchntRespStts respStts = null;
		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			if (RequestResourceThreadLocal.getRequestIdForCurrentThread() == null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if (RequestResourceThreadLocal.getServiceForCurrentThread() == null) {
				RequestResourceThreadLocal
						.addServiceForCurrentThread(BaseConstants.API_SERVICES.EAI_CREDIT_INSIGHTS_INTERNAL_CONSENT);
			}

			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);

			if (processorInput != null) {

				FLogger.debug(logger, THIS_CLASS, methodName, "Entered :" + methodName);

				respStts = validateInputs(processorInput);

				if (respStts == null) {
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.EAI_CREDIT_INSIGHTS_INTERNAL_CONSENT);
					srvcRequest.setCreditInsightsInternalConsentReq(processorInput);

					EcomCreditInsightsInternalConsentProcessor processor = new EcomCreditInsightsInternalConsentProcessor(
							srvcRequest);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();

					if (srvcResp != null) {
						if (srvcResp.getCreditInsightsInternalConsentResp() != null) {
							FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API");

							response = new EcomCreditInsightsInternalConsentResp();
							response = srvcResp.getCreditInsightsInternalConsentResp();
						} else {
							FLogger.error(logger, THIS_CLASS, methodName,
									"Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = new MrchntRespStts();
							respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
					
							response = new EcomCreditInsightsInternalConsentResp();
							response.setInternalConsentDetails(null);
							response.setResponseStatus(respStts);
						}
					} else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");

						respStts = new MrchntRespStts();
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
						
						response = new EcomCreditInsightsInternalConsentResp();
						response.setInternalConsentDetails(null);
						response.setResponseStatus(respStts);
					}
				} else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");

					response = new EcomCreditInsightsInternalConsentResp();
					response.setInternalConsentDetails(null);
					response.setResponseStatus(respStts);
				}

			} else {
				FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");

				respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
				
				response = new EcomCreditInsightsInternalConsentResp();
				response.setInternalConsentDetails(null);
				response.setResponseStatus(respStts);
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			response = new EcomCreditInsightsInternalConsentResp();
			response.setInternalConsentDetails(null); 
			response.setResponseStatus(respStts);

		} finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();

		}

		return response;
	}

	/**
	 * 
	 * @param processorInput
	 * @return
	 */
	public static MrchntRespStts validateInputs(EcomCreditInsightsInternalConsentReq processorInput) {

		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: " + methodName);
		try {

			if (processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}
			
			if(!StringChecks.isAnyFieldEmpty(processorInput.getVilMsisdn())) {
				if(!StringChecks.checkMsisdn(processorInput.getVilMsisdn())) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Vil msisdn");
					return respStts;
				}
			}
			
			if(!StringChecks.isAnyFieldEmpty(processorInput.getAirtelMsisdn())) {
				if(!StringChecks.checkMsisdn(processorInput.getAirtelMsisdn())) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Airtel msisdn");
					return respStts;
				}
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}

		return respStts;
	}
}
