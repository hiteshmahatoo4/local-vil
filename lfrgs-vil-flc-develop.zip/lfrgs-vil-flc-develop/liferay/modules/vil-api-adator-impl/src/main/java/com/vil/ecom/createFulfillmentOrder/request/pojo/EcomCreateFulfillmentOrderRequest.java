
package com.vil.ecom.createFulfillmentOrder.request.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "request_message"
})
public class EcomCreateFulfillmentOrderRequest implements Serializable
{

    @JsonProperty("request_message")
    private RequestMessage requestMessage;
    private final static long serialVersionUID = 7205265823115599871L;

    @JsonProperty("request_message")
    public RequestMessage getRequestMessage() {
        return requestMessage;
    }

    @JsonProperty("request_message")
    public void setRequestMessage(RequestMessage requestMessage) {
        this.requestMessage = requestMessage;
    }

}
