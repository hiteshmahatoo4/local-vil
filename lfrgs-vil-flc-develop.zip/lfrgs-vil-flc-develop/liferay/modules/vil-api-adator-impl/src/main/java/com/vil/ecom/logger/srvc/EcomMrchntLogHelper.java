package com.vil.ecom.logger.srvc;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.StopWatch;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.db.custommodel.EcomMrchntSrvcApiRestReqRespCustomModel;
import com.vil.ecom.db.model.EcomMrchntSrvcApiRestReqResp;
import com.vil.ecom.db.service.EcomMrchntSrvcApiRestReqRespLocalServiceUtil;
import com.vil.ecom.integration.helper.EcomHelper;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntLogVO;
import com.vil.ecom.service.EcomIntegrationUtils;
import com.vil.ecom.service.EcomSrvcConfigCnstntsServiceImpl;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

public class EcomMrchntLogHelper {

	private static final Log logger = LogFactoryUtil.getLog(EcomMrchntLogHelper.class);
	private static final String THIS_CLASS = EcomMrchntLogHelper.class.toString();
	
	private static final List<String> AUDIT_LOGGING_ALLOWED=Arrays.asList();

	/**
	 * @param confMap
	 * @param srvcNme
	 * @return
	 */
	public static Map<String, String> populateDummyResp(Map<String, Object> confMap,String srvcNme){
		
		HashMap<String, String> dummyMap=new HashMap<>();
		String methodName="populateDummyResp";

		boolean dummyFlg=Boolean.parseBoolean((String)confMap.get("REST_DUMMY_RESP_FLG"));
		
		if(dummyFlg) {
			
			
			String dummyResp=(String)confMap.get("REST_DUMMY_RESP");
			String dummyStts=(String)confMap.get("REST_DUMMY_STTS");
			String dummyErrMsg=(String)confMap.get("REST_DUMMY_ERR_MSG");
			
			if(!StringChecks.isFieldEmpty(dummyResp)) {
				
				FLogger.info(logger, THIS_CLASS, methodName, "Dummy Response Set for Service "+srvcNme);
				
				dummyMap.put("respCode", "200");
				
				if(StringChecks.isFieldEmpty(dummyStts)) {
					dummyMap.put("status", BaseConstants.SUCCESS_MSG);
				}else {
					dummyMap.put("status", dummyStts);
				}

				if(StringChecks.isFieldEmpty(dummyErrMsg)) {
					dummyMap.put("statusDesc", BaseConstants.SUCCESS_MSG);
				}else {
					dummyMap.put("statusDesc", dummyErrMsg);
				}
				
				dummyMap.put("respMsg", dummyResp);
				
			}
			
		}else {
			 FLogger.info(logger, THIS_CLASS, methodName, "No Dummy Response Set.");
		}
		
		
		return dummyMap;
	}
	
	
	/**
	 * <h2>logRequestForRestWS</h2>
	 * 
	 * @param logVO
	 * @param txnRequired
	 * @return
	 */
	public static void logRequestForRestWS(EcomMrchntLogVO logVO) {

		String methodName = "logRequestForRestWS";
		boolean enableRequestlogging=false;

		StopWatch stopwatch =null;
		 
		FLogger.info(logger, THIS_CLASS, methodName, "Entering Method " + methodName);

		try {

			stopwatch=new StopWatch();
			stopwatch.start();
			
			if(LoggerConstants.REST_WS.REST_OUTWARD_REQ.equalsIgnoreCase(logVO.getRequestType())) { 
				
				FLogger.error(logger, THIS_CLASS, methodName,"As its OW request so logging is disabled");
				enableRequestlogging = Boolean.FALSE;
				
			}else {
				
				FLogger.error(logger, THIS_CLASS, methodName,"As No Request Type found so logging is enabled");
				enableRequestlogging = Boolean.FALSE;
			}

			if (!BaseConstants.SUCCESS_MSG.equalsIgnoreCase(logVO.getRespStts())
					 && !EcomHelper.getBoolean(enableRequestlogging)) {

				enableRequestlogging = Boolean.TRUE;
				FLogger.error(logger, THIS_CLASS, methodName,"Enabling DB logging for Service "
						+logVO.getServiceNme()+" as its Failure Scenario ? "+enableRequestlogging);
				
			}
			
			if(!enableRequestlogging) {
				
				FLogger.error(logger, THIS_CLASS, methodName,"Inward Rest API calls logging disabled as enableRequestlogging : "+enableRequestlogging);
				RequestResourceThreadLocal.addWebSrvcNmeForCurrentThread(String.valueOf(Calendar.getInstance().getTimeInMillis()));
				
			}else {
				
				FLogger.error(logger, THIS_CLASS, methodName,"Inward Rest API calls logging enable as enableRequestlogging : "+enableRequestlogging);
				RequestResourceThreadLocal.addWebSrvcNmeForCurrentThread(String.valueOf(Calendar.getInstance().getTimeInMillis()));
			}
			
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			String logStr=new StringBuilder()
					.append(RequestResourceThreadLocal.getModuleNmeForCurrentThread())
					.append(" | ServiceName : ")
					.append(logVO.getServiceNme())
					.append(" | LOG_TYPE : BAC ")
					.append(" | REQ_TYPE : ")
					.append(logVO.getRequestType())
					.append(" | API_CALL_TYPE : ")
					.append(logVO.getFiller3())
					.append(" | msisdn : ")
					.append(logVO.getMsisdn())
					.append(" | circle : ")
					.append(logVO.getChannelId())
					.append(" | REQ_ID : ")
					.append(logVO.getRequestId())
					.append(" | RemoteIp : ")
					.append(logVO.getIpAddr())
					.append(" | SourceIp : ")
					.append(logVO.getSourceIp())
					.append(" | URI : ")
					.append(logVO.getFiller4())
					.append(" | ThreadID : ")
					.append(logVO.getFiller5())
					.append(" | LoggerId : ")
					.append(logVO.getFiller6())
					.toString();
				
			FLogger.error(logger, THIS_CLASS, methodName,"Logging Params "+logStr);

		}

	}

	/**
	 * <h2>logResponseForRestWs</h2>
	 * 
	 * @param logVO
	 * @param txnRequired
	 * @return
	 */
	public static Long logResponseForRestWs(EcomMrchntLogVO logVO) {

		String methodName = "logResponseForRestWs";

		EcomMrchntSrvcApiRestReqRespCustomModel obj = null;
		Long recordId=null;
		Map<String, Object> confMap=null;
		
		boolean enableResponselogging = false;
		Long timeTaken=null;
		
		Date reqDate=null;
		Date respDate=null;
		
		StopWatch stopwatch =null;
		 
		FLogger.info(logger, THIS_CLASS, methodName, "Entering Method " + methodName);

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap("APP_WS");

			if(LoggerConstants.REST_WS.REST_OUTWARD_REQ.equalsIgnoreCase(logVO.getRequestType())) { 
				
				FLogger.error(logger, THIS_CLASS, methodName,"As is OW Response so logging of is enabled");

				if (StringChecks.isMapEmpty(confMap)) {

					FLogger.error(logger, THIS_CLASS, methodName,
							"enableResponselogging for response logging for OW flow in DB is set to false as confMap is Null");
					enableResponselogging = Boolean.TRUE;

				} else {

					FLogger.debug(logger, THIS_CLASS, methodName,"Checking with ConfMap for enableResponselogging Flag "+confMap);

					if ((String) confMap.get("BLOCK_API_RESP_DB_LOGGING") != null) {
						
						FLogger.debug(logger, THIS_CLASS, methodName,"BLOCK_API_RESP_DB_LOGGING Flag "
								+!(Boolean.parseBoolean((String) confMap.get("BLOCK_API_RESP_DB_LOGGING"))));
						
						enableResponselogging = !(Boolean.parseBoolean((String) confMap.get("BLOCK_API_RESP_DB_LOGGING")));
					} else {
						enableResponselogging = Boolean.TRUE;
					}
				}
				
			}else {
				
				FLogger.error(logger, THIS_CLASS, methodName,"As No Request Type found so logging is enabled ");
				enableResponselogging = Boolean.TRUE;
			}
			
			if(enableResponselogging
					&& LoggerConstants.REST_WS.REST_OUTWARD_REQ.equalsIgnoreCase(logVO.getRequestType())) {
				
				Boolean loggingFlg=EcomIntegrationUtils.isApiDBLoggingEnabled(logVO.getChannelId(), logVO.getServiceNme());
				
				FLogger.error(logger, THIS_CLASS, methodName,"As is OW Response so logging of "+logVO.getServiceNme()+" is enabled ? "+loggingFlg);
				
				if (loggingFlg != null) {
					enableResponselogging = loggingFlg;
				}
				
				if (!BaseConstants.SUCCESS_MSG.equalsIgnoreCase(logVO.getRespStts())
						 && !EcomHelper.getBoolean(enableResponselogging)) {

					enableResponselogging = Boolean.TRUE;
					FLogger.error(logger, THIS_CLASS, methodName,"Enabling DB logging for Service "
							+logVO.getServiceNme()+" as its Failure Scenario ? "+enableResponselogging);
					
				}
			}
			
			if(!enableResponselogging) {
			
				FLogger.error(logger, THIS_CLASS, methodName, "DB Response logging is disabled " + enableResponselogging
						+" for service "+logVO.getServiceNme());

			}else {
				
				FLogger.error(logger, THIS_CLASS, methodName, "DB Response logging is Enabled as enableResponselogging is " + enableResponselogging);

					FLogger.error(logger, THIS_CLASS, methodName, "New Record creation for Api Response for "+logVO.getServiceNme());

					obj = new EcomMrchntSrvcApiRestReqRespCustomModel();

					if(!StringChecks.isFieldEmpty(RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread())) {
						
						FLogger.debug(logger, THIS_CLASS, methodName,
								"RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread()" + RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread());
						obj.setReq_timestamp(new Timestamp(Long.parseLong(RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread())));
						
					}else if(logVO.getRequestTime()!=null){
						obj.setReq_timestamp(logVO.getRequestTime());
					}else {
						obj.setReq_timestamp(Calendar.getInstance().getTime());
					}
					
					obj.setResp_timestamp(Calendar.getInstance().getTime());

					reqDate = obj.getReq_timestamp();
					respDate = obj.getResp_timestamp();
					
					timeTaken =calculateDiff(obj.getReq_timestamp(),obj.getResp_timestamp());
					FLogger.debug(logger, THIS_CLASS, methodName, "timeTaken " + timeTaken);
					
					if (!StringChecks.isFieldEmpty(logVO.getRequestParams())) {

						Map<String, String> responseMap = StringChecks.splitMessage(logVO.getRequestParams(), 
								LoggerConstants.NUM_20000, LoggerConstants.NUM_20000);

						if (responseMap != null && responseMap.size() > 0) {

							for (int i = 1; i <= responseMap.size(); i++) {

								switch (i) {

								case 1:
									FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml1 " + i);
									obj.setRest_req1(responseMap.get(String.valueOf(i)));
									break;

								case LoggerConstants.NUM_2:
									FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml2 " + i);
									obj.setRest_req3(responseMap.get(String.valueOf(i)));
									break;

								case LoggerConstants.NUM_3:
									FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml3 " + i);
									obj.setRest_req3(responseMap.get(String.valueOf(i)));
									break;

								case LoggerConstants.NUM_4:
									FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml4 " + i);
									obj.setRest_resp4(responseMap.get(String.valueOf(i)));
									break;

								default:
									break;
								}

							}
						}
					}

				if (!StringChecks.isFieldEmpty(logVO.getResponseParams())) {

					Map<String, String> responseMap = StringChecks.splitMessage(logVO.getResponseParams(),
							LoggerConstants.NUM_20000, LoggerConstants.NUM_20000);

					if (responseMap != null && responseMap.size() > 0) {

						for (int i = 1; i <= responseMap.size(); i++) {

							switch (i) {

							case 1:
								FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml1 " + i);
								obj.setRest_resp1(responseMap.get(String.valueOf(i)));
								break;

							case LoggerConstants.NUM_2:
								FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml2 " + i);
								obj.setRest_resp2(responseMap.get(String.valueOf(i)));
								break;

							case LoggerConstants.NUM_3:
								FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml3 " + i);
								obj.setRest_resp3(responseMap.get(String.valueOf(i)));
								break;

							case LoggerConstants.NUM_4:
								FLogger.debug(logger, THIS_CLASS, methodName, "Storing RequestXml4 " + i);
								obj.setRest_resp4(responseMap.get(String.valueOf(i)));
								break;

							default:
								break;
							}

						}
					}
				}

				if (!StringChecks.isFieldEmpty(logVO.getServiceNme())) {
					obj.setService_nme(logVO.getServiceNme());
				}

				if (!StringChecks.isFieldEmpty(logVO.getAmt())) {
					obj.setAmt(logVO.getAmt());
				}

				if (!StringChecks.isFieldEmpty(logVO.getChannelId())) {
					obj.setChnnl_id(logVO.getChannelId());
				}

				if (!StringChecks.isFieldEmpty(logVO.getRequestId())) {
					obj.setReq_id(logVO.getRequestId());
				}

				if (!StringChecks.isFieldEmpty(RequestResourceThreadLocal.getIpAddrssForCurrentThread())) {
					obj.setIp_addr(RequestResourceThreadLocal.getIpAddrssForCurrentThread());
				} else {
					obj.setIp_addr(logVO.getIpAddr());
				}

				if (!StringChecks.isFieldEmpty(logVO.getSourceIp())) {
					obj.setSrce_systm(logVO.getSourceIp());
				}

				if (!StringChecks.isFieldEmpty(logVO.getMsisdn())) {
					obj.setMsisdn(logVO.getMsisdn());
				}

				if (!StringChecks.isFieldEmpty(logVO.getRequestType())) {
					obj.setRqst_type(logVO.getRequestType());
				}

				if (!StringChecks.isFieldEmpty(logVO.getRespStts())) {
					obj.setStts(logVO.getRespStts());
				}

				if (!StringChecks.isFieldEmpty(logVO.getRespSttsCde())) {
					obj.setError_code(logVO.getRespSttsCde());
				}

				if (!StringChecks.isFieldEmpty(logVO.getRespSttsDesc())) {
					obj.setError_msg(logVO.getRespSttsDesc());
				}

				if (!StringChecks.isFieldEmpty(logVO.getFiller1())) {

					obj.setFiller1(logVO.getFiller1());

				} else if ("swift-portal".equalsIgnoreCase(RequestResourceThreadLocal.getModuleNmeForCurrentThread())
						|| "swift-scheduler"
								.equalsIgnoreCase(RequestResourceThreadLocal.getModuleNmeForCurrentThread())) {

					logVO.setFiller1(RequestResourceThreadLocal.getURI());
					obj.setFiller1(logVO.getFiller1());

				}

				if (!StringChecks.isFieldEmpty(logVO.getFiller2())) {
					obj.setFiller2(logVO.getFiller2());
				}

				if (!StringChecks.isFieldEmpty(logVO.getFiller3())) {
					obj.setFiller3(logVO.getFiller3());
				}

				if (!StringChecks.isFieldEmpty(logVO.getFiller4())) {
					obj.setFiller4(logVO.getFiller4());
				}

				if (!StringChecks.isFieldEmpty(logVO.getFiller5())) {
					obj.setFiller5(logVO.getFiller5());
				}

				if (!StringChecks.isFieldEmpty(logVO.getFiller6())) {
					obj.setFiller6(logVO.getFiller6());
				}

				if (!StringChecks.isFieldEmpty(logVO.getFiller7())) {
					obj.setUser_id(logVO.getFiller7());
				}

				EcomMrchntSrvcApiRestReqResp obj1 = EcomMrchntSrvcApiRestReqRespLocalServiceUtil.addMrchntLogRecord(obj);
				
				if(obj1!=null) {
					recordId = obj1.getId();
				}
				
				FLogger.error(logger, THIS_CLASS, methodName,
						"Response Saved in DB with Record Id : " + (recordId != null ? recordId.intValue() : 0));

			}
			
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		} finally {

			if(!enableResponselogging
					&& timeTaken==null) {
				
				Date startTime = null;
				Date endTime = null;
				
				if(!StringChecks.isFieldEmpty(RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread())) {
					
					FLogger.debug(logger, THIS_CLASS, methodName,
							"RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread()" + RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread());
					startTime = (new Timestamp(Long.parseLong(RequestResourceThreadLocal.getWebSrvcNmeForCurrentThread())));
					
				}else {
					startTime = (new Timestamp(Calendar.getInstance().getTimeInMillis()));
				}
				
				endTime = (new Timestamp(Calendar.getInstance().getTimeInMillis()));

				timeTaken =calculateDiff(startTime,endTime);
			
				reqDate = startTime;
				respDate = endTime;
				
			}
			
			RequestResourceThreadLocal.unsetWebSrvcNmeForCurrentThread();
			
			String logStr=new StringBuilder()
					.append(RequestResourceThreadLocal.getModuleNmeForCurrentThread())
					.append(" | Application Type : ")
					.append("API_CALL")
					.append(" | ServiceName : ")
					.append(logVO.getServiceNme())
					.append(" | LOG_TYPE : AAC ")
					.append(" | REQ_TYPE : ")
					.append(logVO.getRequestType())
					.append(" | API_CALL_TYPE : ")
					.append(logVO.getFiller3())
					.append(" | msisdn : ")
					.append(logVO.getMsisdn())
					.append(" | circle : ")
					.append(logVO.getChannelId())
					.append(" | REQ_ID : ")
					.append(logVO.getRequestId())
					.append(" | URI : ")
					.append(logVO.getFiller4())
					.append(" | ThreadID : ")
					.append(logVO.getFiller5())
					.append(" | LoggerId : ")
					.append(logVO.getFiller6())
					.append(" | Source ThreadID : ")
					.append(logVO.getFiller1())
					.append(" | recordId : ")
					.append(recordId)
					.append(" | stts : ")
					.append(logVO.getRespStts())
					.append(" | errCde : ")
					.append(logVO.getRespSttsCde())
					.append(" | errDesc : ")
					.append(logVO.getRespSttsDesc())
					.append(" | RemoteIp : ")
					.append(logVO.getIpAddr())
					.append(" | SourceIp : ")
					.append(logVO.getSourceIp())
					.append(" | REQ_TIME : ")
					.append(reqDate)
					.append(" | RESP_TIME : ")
					.append(respDate)
					.append(" | REQUEST : ")
					.append(logVO.getRequestParams())
					.append(" | RESPONSE : ")
					.append(logVO.getResponseParams())
					.append(" | TimeTaken : ")
					.append(timeTaken)
					.toString();
				
			FLogger.info(logger, THIS_CLASS, methodName,"Logging Params "+logStr);

			if (LoggerConstants.REST_WS.REST_OUTWARD_REQ.equalsIgnoreCase(logVO.getRequestType())) {

				FLogger.debug(logger, THIS_CLASS, methodName,"log : " + logStr);

			} else if (LoggerConstants.REST_WS.REST_INWARD_REQ.equalsIgnoreCase(logVO.getRequestType())
					&& AUDIT_LOGGING_ALLOWED.contains(logVO.getServiceNme())) {

				FLogger.debug(logger, THIS_CLASS, methodName,
						"For inward mode: selective logging for service : " + logVO.getServiceNme());

			}

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

		}

		return recordId;

	}
	
	public static  long calculateDiff(Date d1, Date d2) {
		long diff = 0;
		try {
			diff = d2.getTime() - d1.getTime();
		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, "calculateDiff");
		}
		return diff;
	}
	
}
