package com.vil.ecom.integration.helper;

import com.liferay.portal.kernel.log.Log;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

public class FLogger {

	private static final String LOGGER1 = "[%s][%s][%s][%s] %s";
	private static final String LOGGER2 = "[%s][%s][%s][%s][%s] - %s";
	private static final String LOGGER3 = "[%s][%s][%s]%s";
	private static final String LOGGER4 = "[%s][%s][%s][%s][%s][%s] - %s%s";

	/**
	 * can be invoked at application startup
	 * 
	 * @param pStrlogConfigFile full path for the log4j configuration file
	 */

	private FLogger() {
	}

	/**
	 * This method is used to create a info message from a user for a category.
	 * 
	 * @param theCategory Specifies the category
	 * @param theMessage  Specifies the the info message to be created
	 */
	public static void auditInfo(Log logger, Object pStrtheMessage) {
		logger.info(pStrtheMessage);
	}

	/**
	 * This method is used to create a info message from a user for a category.
	 * 
	 * @param theCategory Specifies the category
	 * @param theMessage  Specifies the the info message to be created
	 */
	public static void info(Log logger, Object pStrtheMessage) {

		logger.info(String.format(LOGGER1, Thread.currentThread().getName(),
				RequestResourceThreadLocal.getRequestIdForCurrentThread(), RequestResourceThreadLocal.getURI(),
				RequestResourceThreadLocal.getServiceForCurrentThread(), pStrtheMessage));
	}

	public static void info(Log logger, String pStrtheClass, String pStrtheMethod, Object pStrtheMessage) {
		if (pStrtheClass != null && pStrtheClass.length() > 0) {
			int dot = pStrtheClass.indexOf('.');
			if (dot != -1) {
				pStrtheClass = pStrtheClass.substring(pStrtheClass.lastIndexOf('.') + 1, pStrtheClass.length());
			}
		}

		logger.info(String.format(LOGGER2, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
				RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
				pStrtheClass, pStrtheMethod, pStrtheMessage));
	}

	public static boolean isInfoEnabled(Log logger) {
		return logger.isInfoEnabled();
	}

	/**
	 * Create a debug message from a user for a category.
	 * 
	 * @param theCategory Specifies the category
	 * @param theMessage  Specifies the the debug message
	 */
	public static void debug(Log logger, Object pStrtheMessage) {
		if (isDebugEnabled(logger)) {

			logger.debug(String.format(LOGGER3, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
					RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
					pStrtheMessage));

		}
	}

	public static void debug(Log logger, String pStrtheClass, String pStrtheMethod, Object pStrtheMessage) {

		if (isDebugEnabled(logger)) {

			if (pStrtheClass != null && pStrtheClass.length() > 0) {
				int dot = pStrtheClass.indexOf('.');
				if (dot != -1) {
					pStrtheClass = pStrtheClass.substring(pStrtheClass.lastIndexOf('.') + 1, pStrtheClass.length());
				}
			}

			logger.debug(String.format(LOGGER2, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
					RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
					pStrtheClass, pStrtheMethod, pStrtheMessage));
		}
	}

	public static boolean isDebugEnabled(Log logger) {
		/*
		 * hard coded here since we have a single category, client code passing
		 * different value unnecessarily creates a new category
		 */
		return logger.isDebugEnabled();
	}

	/**
	 * Create a warn message from a user for a category.
	 * 
	 * @param theCategory Specifies the category
	 * @param theMessage  Specifies the the debug message
	 * 
	 */
	public static void warn(Log logger, Object pStrtheMessage) {

		logger.warn(String.format(LOGGER3, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
				RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
				pStrtheMessage));
	}

	public static void warn(Log logger, String pStrtheClass, String pStrtheMethod, Object pStrtheMessage) {
		if (pStrtheClass != null && pStrtheClass.length() > 0) {
			int dot = pStrtheClass.indexOf('.');
			if (dot != -1) {
				pStrtheClass = pStrtheClass.substring(pStrtheClass.lastIndexOf('.') + 1, pStrtheClass.length());
			}
		}

		logger.warn(String.format(LOGGER2, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
				RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
				pStrtheClass, pStrtheMethod, pStrtheMessage));

	}

	/**
	 * Create a error message from a user for a category.
	 * 
	 * @param theCategory Specifies the category
	 * @param theMessage  Specifies the the error message
	 */
	public static void error(Log logger, Object pStrtheMessage) {

		logger.warn(String.format(LOGGER3, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
				RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
				pStrtheMessage));

	}

	public static void error(Log logger, String pStrtheClass, String pStrtheMethod, Object pStrtheMessage) {
		if (pStrtheClass != null && pStrtheClass.length() > 0) {
			int dot = pStrtheClass.indexOf('.');
			if (dot != -1) {
				pStrtheClass = pStrtheClass.substring(pStrtheClass.lastIndexOf('.') + 1, pStrtheClass.length());
			}
		}

		logger.error(String.format(LOGGER2, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
				RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
				pStrtheClass, pStrtheMethod, pStrtheMessage));
	}

	public static void error(Log logger, String pStrtheClass, String pStrtheMethod, Object pStrtheMessage,
            Throwable throwable) {
        if (pStrtheClass != null && pStrtheClass.length() > 0) {
            int dot = pStrtheClass.indexOf('.');
            if (dot != -1) {
                pStrtheClass = pStrtheClass.substring(pStrtheClass.lastIndexOf('.') + 1, pStrtheClass.length());
            }
        }
        logger.error(String.format(LOGGER2, RequestResourceThreadLocal.getRequestIdForCurrentThread(),
                RequestResourceThreadLocal.getURI(), RequestResourceThreadLocal.getServiceForCurrentThread(),
                pStrtheClass, pStrtheMethod, pStrtheMessage), throwable);
    }

}
