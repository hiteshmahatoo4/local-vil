package com.vil.ecom.integration.pojo;

import com.vil.ecom.eai.verifyOtpCreditInsight.pojo.VerifyOtpCreditInsightResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;

import java.io.Serializable;



public class EcomVerifyOtpCreditInsightResp implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
	
	private String creditInsightsScore;
	
	private VerifyOtpCreditInsightResponse  verifyOtpResponse;

	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	/**
	 * @return the verifyOtpResponse
	 */
	public VerifyOtpCreditInsightResponse getVerifyOtpResponse() {
		return verifyOtpResponse;
	}

	/**
	 * @param verifyOtpResponse the verifyOtpResponse to set
	 */
	public void setVerifyOtpResponse(VerifyOtpCreditInsightResponse verifyOtpResponse) {
		this.verifyOtpResponse = verifyOtpResponse;
	}

	/**
	 * @return the creditInsightsScore
	 */
	public String getCreditInsightsScore() {
		return creditInsightsScore;
	}

	/**
	 * @param creditInsightsScore the creditInsightsScore to set
	 */
	public void setCreditInsightsScore(String creditInsightsScore) {
		this.creditInsightsScore = creditInsightsScore;
	}
      
}
	
	