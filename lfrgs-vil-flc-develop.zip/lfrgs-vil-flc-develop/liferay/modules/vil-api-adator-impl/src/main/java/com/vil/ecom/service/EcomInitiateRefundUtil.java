package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomInitiateRefundReq;
import com.vil.ecom.integration.pojo.EcomInitiateRefundResp;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomInitiateRefundProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class EcomInitiateRefundUtil {
	private static final Log logger = LogFactoryUtil.getLog(EcomInitiateRefundUtil.class);
	private static final String THIS_CLASS = "EcomInitiateRefundUtil";
	
	/**
	 * @author Avinash
	 * <p>Initiate Refund API : initiateRefund</p>
	 * @param processorInput : EcomInitiateRefundReq pojo to be set for input paramater . Mandatory
	 * <p>
	 * <h2>EcomInitiateRefundReq pojo details:</h2>
	 * @param circleId : circle is to be passed . Optional
	 * @param provider : Provider type is to be passed . Optional
	 * @param subscriberType  : Subsriber type PREPAID / POSTPAID is to be passed. Optional
	 * @param refundType : refund type PARTIAL / FULL is to be passed . Mandatory
	 * @param refundOrderId : RefundOrder ID - Ecommerce Lineitem order id . Mandatory
	 * <ul>
	 * <li>if refundType is "PARTIAL" refundOrderId is Mandatory</li>
	 * <li>if refundType is "FULL" then refundOrderId is not required</li>
	 * </ul>
	 * @param dxlPgOrderId : dxlPgOrderId to be passed . Mandatory
	 * @param amount : Order amount(should be <= Total Order amount) . Mandatory
	 * @param ecommOrderId : Liferay Ecommerce Order ID is to be passed. Mandatory
	 *
	 * 
	 * </p>
	 * @return EcomInitiateRefundResp : EcomInitiateRefund API response
	 * <ul>
	 * <li>responseStatus : response status of the process call</li>
	 * <li>message : response message for initiate refund request </li>
	 * </ul>
	 */
	public static EcomInitiateRefundResp initiateRefund(EcomInitiateRefundReq processorInput) {
		
		String methodName =  "initiateRefund";
		StopWatch stopwatch = null;
		EcomInitiateRefundResp response = null;
		MrchntRespStts respStts = null;
		try {
			
			stopwatch = new StopWatch();
			stopwatch.start();
			
			if(RequestResourceThreadLocal.getRequestIdForCurrentThread()==null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if(RequestResourceThreadLocal.getServiceForCurrentThread()==null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.DXL_INITIATE_REFUND);
			}
			
			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName);
			
			if(processorInput != null) {
				
				
				respStts = validateInputs(processorInput);
				
				if(respStts == null) {
					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.DXL_INITIATE_REFUND);
					srvcRequest.setIntiateRefundReq(processorInput);
					
					
					EcomInitiateRefundProcessor processor = new EcomInitiateRefundProcessor(srvcRequest);
					EcomMrchntServiceResponse srvcResp = new EcomMrchntServiceResponse();
					srvcResp = processor.execute();
					
					if(srvcResp != null) {
						if(srvcResp.getInitiateRefundResp()!= null) {
							FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API");
							
							response = new EcomInitiateRefundResp();
							response = srvcResp.getInitiateRefundResp();
						}else {
							FLogger.error(logger, THIS_CLASS, methodName, "Got Reply from Processor but no API reply received,setting TIMEOUT Scenario ");
							respStts = new MrchntRespStts();
							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);
							
							response = new EcomInitiateRefundResp();
							response.setMessage(null);
							response.setResponseStatus(respStts);
						}
					}else {
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");
						
						respStts = new MrchntRespStts();
						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
						
						response = new EcomInitiateRefundResp();
						response.setMessage(null);
						response.setResponseStatus(respStts);
					}
				}else {
					FLogger.error(logger, THIS_CLASS, methodName, "Processor Inputs are not valid");
					
					response = new EcomInitiateRefundResp();
					response.setMessage(null);
					response.setResponseStatus(respStts);
				}
				
			}else {
				FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");
				
				respStts = new MrchntRespStts();
				respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
				
				response = new EcomInitiateRefundResp();
				response.setMessage(null);
				response.setResponseStatus(respStts);
			}
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			response = new EcomInitiateRefundResp();
			response.setMessage(null);
			response.setResponseStatus(respStts);
			
		}finally {

			if (stopwatch != null) {
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();
		
			FLogger.debug(logger, THIS_CLASS, methodName, "Returning Response: "+StringChecks.convertObjectToJson(response));
		}

		
		return response;
	}
	
	/**
	 * 
	 * @param processorInput
	 * @return
	 */
	public static MrchntRespStts validateInputs(EcomInitiateRefundReq processorInput) {
		
		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: "+methodName);
		try {
			
			
			
			FLogger.info(logger, THIS_CLASS, methodName, "Payload: "+StringChecks.convertObjectToJson(processorInput));
			if(processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				return respStts;
			}
			
			if(!StringChecks.isFieldEmpty(processorInput.getCircleId())) {
				respStts = RsValiatorResponse.checkCircleResponse(processorInput.getCircleId(),null);
				if(respStts != null) {
					return respStts;
					}
				}
			
			if(!StringChecks.isFieldEmpty(processorInput.getSubscriberType())) {
				if(!(processorInput.getSubscriberType().equalsIgnoreCase("PREPAID") || processorInput.getSubscriberType().equalsIgnoreCase("POSTPAID")) ) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "not a valid SubscriberType");
					return respStts;
					}
			}
			
			if(!(processorInput.getRefundType().equalsIgnoreCase("PARTIAL") || processorInput.getRefundType().equalsIgnoreCase("FULL"))) {
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Refund Type");
				return respStts;
			}
			
			if(processorInput.getRefundType().equalsIgnoreCase("PARTIAL")){
				respStts = RsValiatorResponse.validateStrInput(processorInput.getRefundOrderId(), null, "RefundOrderId");
				if(respStts != null) {
					FLogger.error(logger, THIS_CLASS,methodName,"RefundOrderId is not valid");
					return respStts;
				}
			}
			
			
			respStts = RsValiatorResponse.validateStrInput(processorInput.getDxlPgOrderId(), null, "dxlPgOderId");
			if(respStts != null) {
				FLogger.error(logger, THIS_CLASS,methodName,"DxlPgOrderId is not valid");
				return respStts;
			}

			if(!StringChecks.validateAmt(processorInput.getAmount())) {
				FLogger.error(logger, THIS_CLASS, methodName, "Amount is not valid  Amount: "+processorInput.getAmount());
				respStts = RsValiatorResponse.invalidParamsResponse(null, "Amount");
				return respStts;
			}
			
			respStts = RsValiatorResponse.validateStrInput(processorInput.getEcomOrderId(), null, "ecomOrderId");
			if(respStts != null) {
				FLogger.error(logger, THIS_CLASS,methodName,"EcomOrderId is not valid");
				return respStts;
			}
			
			}catch (Exception e) {
				StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
				}
		return respStts;
		}
	}