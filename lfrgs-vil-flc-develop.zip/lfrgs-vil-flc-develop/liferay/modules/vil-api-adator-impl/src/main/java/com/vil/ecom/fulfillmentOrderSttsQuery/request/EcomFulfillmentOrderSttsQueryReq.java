
package com.vil.ecom.fulfillmentOrderSttsQuery.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "request_message"
})
public class EcomFulfillmentOrderSttsQueryReq implements Serializable
{

    @JsonProperty("request_message")
    private RequestMessage requestMessage;
    private final static long serialVersionUID = 9050172597915099349L;

    @JsonProperty("request_message")
    public RequestMessage getRequestMessage() {
        return requestMessage;
    }

    @JsonProperty("request_message")
    public void setRequestMessage(RequestMessage requestMessage) {
        this.requestMessage = requestMessage;
    }

}
