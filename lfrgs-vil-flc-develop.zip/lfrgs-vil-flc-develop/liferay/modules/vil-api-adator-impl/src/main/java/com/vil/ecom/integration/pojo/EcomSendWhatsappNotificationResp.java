package com.vil.ecom.integration.pojo;


import java.io.Serializable;

public class EcomSendWhatsappNotificationResp implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
	
	private String description;
	
	
	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}
	
	
	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}


	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}


	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	
}