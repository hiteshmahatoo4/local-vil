package com.vil.ecom.integration.pojo;

import com.vil.ecom.createFulfillmentOrder.response.pojo.EcomCreateFulfillmentOrderResponse;
import com.vil.ecom.fulfillmentOrderSttsQuery.response.EcomFulfillmentOrderSttsQueryResp;

public class EcomMrchntServiceResponse {

	private MrchntRespStts responseStatus;

	private EcomSendMailRespDtls sendMailRespDtls;

	private EcomSendSmsRespDtls sendSmsRespDtls;
	
	private EcomAdditionalBenefitsResp additionalBenefitsResp;
	
	private EcomProcessPaymentResp processPaymentResp;
	
	private EcomCreditInsightsLoginResp creditInsightsLoginResp;
	
	private EcomCreateConsentRequestResp crtCnsntReqResp;
	
	private EcomCustomerLookupResp cstmrLookupResp;	
	
	private EcomSendSmsNotificationResp sendSmsNtfResp;
	
	private EcomSendWhatsappNotificationResp whatsappNotificationResp;
	
	private EcomCreditInsightsInternalConsentResp creditInsightsInternalConsentResp;
	
	private EcomVerifyOtpCreditInsightResp verifyOtpCreditInsightResp;
	
	private EcomRefundStatusResp refundStatusResp;
	
	private EcomUploadEventsResp uploadEventsResp;
	
	private EcomInitiateRefundResp initiateRefundResp;
	
	private EcomFulfillmentTransactionStatusResp fulfillmentTxnSttsResp;
	
	private EcomCreateFulfillmentOrderResponse createFulfillmentOrderResp;
	
	private EcomFulfillmentOrderSttsQueryResp fulfillmentOrderSttsQueryResp;

	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	public EcomSendMailRespDtls getSendMailRespDtls() {
		return sendMailRespDtls;
	}

	public void setSendMailRespDtls(EcomSendMailRespDtls sendMailRespDtls) {
		this.sendMailRespDtls = sendMailRespDtls;
	}

	public EcomSendSmsRespDtls getSendSmsRespDtls() {
		return sendSmsRespDtls;
	}

	public void setSendSmsRespDtls(EcomSendSmsRespDtls sendSmsRespDtls) {
		this.sendSmsRespDtls = sendSmsRespDtls;
	}

	public EcomAdditionalBenefitsResp getAdditionalBenefitsResp() {
		return additionalBenefitsResp;
	}

	public void setAdditionalBenefitsResp(EcomAdditionalBenefitsResp additionalBenefitsResp) {
		this.additionalBenefitsResp = additionalBenefitsResp;
	}
	
	public EcomProcessPaymentResp getProcessPaymentResp() {
		return processPaymentResp;
	}

	public void setProcessPaymentResp(EcomProcessPaymentResp processPaymentResp) {
		this.processPaymentResp = processPaymentResp;
	}
	
	public EcomCreditInsightsLoginResp getCreditInsightsLoginResp() {
		return creditInsightsLoginResp;
	}

	public void setCreditInsightsLoginResp(EcomCreditInsightsLoginResp creditInsightsLoginResp) {
		this.creditInsightsLoginResp = creditInsightsLoginResp;
	}

	
	public EcomCreateConsentRequestResp getCrtCnsntReqResp() {
		return crtCnsntReqResp;
	}

	
	public void setCrtCnsntReqResp(EcomCreateConsentRequestResp crtCnsntReqResp) {
		this.crtCnsntReqResp = crtCnsntReqResp;
	}

	public EcomCustomerLookupResp getCstmrLookupResp() {
		return cstmrLookupResp;
	}

	public void setCstmrLookupResp(EcomCustomerLookupResp cstmrLookupResp) {
		this.cstmrLookupResp = cstmrLookupResp;
	}


	public EcomSendSmsNotificationResp getSendSmsNtfResp() {
		return sendSmsNtfResp;
	}

	public void setSendSmsNtfResp(EcomSendSmsNotificationResp sendSmsNtfResp) {
		this.sendSmsNtfResp = sendSmsNtfResp;
	}

	
	public EcomSendWhatsappNotificationResp getWhatsappNotificationResp() {
		return whatsappNotificationResp;
	}

	
	public void setWhatsappNotificationResp(EcomSendWhatsappNotificationResp whatsappNotificationResp) {
		this.whatsappNotificationResp = whatsappNotificationResp;
	}

	public EcomCreditInsightsInternalConsentResp getCreditInsightsInternalConsentResp() {
		return creditInsightsInternalConsentResp; 
	}

	public void setCreditInsightsInternalConsentResp(
			EcomCreditInsightsInternalConsentResp creditInsightsInternalConsentResp) {
		this.creditInsightsInternalConsentResp = creditInsightsInternalConsentResp;
	}
	
	public EcomVerifyOtpCreditInsightResp getVerifyOtpCreditInsightResp() {
		return verifyOtpCreditInsightResp;
	}

	public void setVerifyOtpCreditInsightResp(EcomVerifyOtpCreditInsightResp verifyOtpCreditInsightResp) {
		this.verifyOtpCreditInsightResp = verifyOtpCreditInsightResp;
	}

	public EcomRefundStatusResp getRefundStatusResp() {
		return refundStatusResp;
	}

	public void setRefundStatusResp(EcomRefundStatusResp refundStatusResp) {
		this.refundStatusResp = refundStatusResp;
	}

	public EcomUploadEventsResp getUploadEventsResp() {
		return uploadEventsResp;
	}

	public void setUploadEventsResp(EcomUploadEventsResp uploadEventsResp) {
		this.uploadEventsResp = uploadEventsResp;
	}

	public EcomInitiateRefundResp getInitiateRefundResp() {
		return initiateRefundResp;
	}

	public void setInitiateRefundResp(EcomInitiateRefundResp initiateRefundResp) {
		this.initiateRefundResp = initiateRefundResp;
	}

	public EcomFulfillmentTransactionStatusResp getFulfillmentTxnSttsResp() {
		return fulfillmentTxnSttsResp;
	}

	public void setFulfillmentTxnSttsResp(EcomFulfillmentTransactionStatusResp fulfillmentTxnSttsResp) {
		this.fulfillmentTxnSttsResp = fulfillmentTxnSttsResp;
	}

	public EcomCreateFulfillmentOrderResponse getCreateFulfillmentOrderResp() {
		return createFulfillmentOrderResp;
	}

	public void setCreateFulfillmentOrderResp(EcomCreateFulfillmentOrderResponse createFulfillmentOrderResp) {
		this.createFulfillmentOrderResp = createFulfillmentOrderResp;
	}

	public EcomFulfillmentOrderSttsQueryResp getFulfillmentOrderSttsQueryResp() {
		return fulfillmentOrderSttsQueryResp;
	}

	public void setFulfillmentOrderSttsQueryResp(EcomFulfillmentOrderSttsQueryResp fulfillmentOrderSttsQueryResp) {
		this.fulfillmentOrderSttsQueryResp = fulfillmentOrderSttsQueryResp;
	}

	
}
