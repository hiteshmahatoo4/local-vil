package com.vil.ecom.integration.processor;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.adaptors.http.RestUtilVo;
import com.vil.ecom.adaptors.http.RestUtility;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.eai.UploadEvents.pojo.D;
import com.vil.ecom.eai.UploadEvents.pojo.UploadEventsRequest;
import com.vil.ecom.eai.UploadEvents.pojo.UploadEventsResponse;
import com.vil.ecom.integration.config.AppServiceProcessor;
import com.vil.ecom.integration.helper.EcomHelper;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntLogVO;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomUploadEventsReq;
import com.vil.ecom.integration.pojo.EcomUploadEventsResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.logger.srvc.EcomMrchntLogHelper;
import com.vil.ecom.service.EcomIntegrationUtils;
import com.vil.ecom.service.EcomSrvcConfigCnstntsServiceImpl;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.HttpHeaders;

public class EcomUploadEventsProcessor implements AppServiceProcessor {
	
	private static final Log logger = LogFactoryUtil.getLog(EcomUploadEventsProcessor.class);
	private static final String THIS_CLASS = EcomUploadEventsProcessor.class.toString();
	
	/** Processor input and output pojo. */
	private EcomMrchntServiceRequest srvcRequest = null;
	private EcomMrchntServiceResponse srvcResponse;
	
	/**
	 * Application defined Inputs and output Pojo for given API which will be used
	 * by calling party.
	 */
	private EcomUploadEventsReq request;
	private EcomUploadEventsResp response;
	
	/**
	 * API response which needs to be Received from 3rd party
	 * API Call.
	 */
	private UploadEventsRequest apiReq;
	private UploadEventsResponse apiResp;
	
	/** Map consisting API specific configurations stored in DB. */
	private Map<String, Object> confMap = null;

	/** Map consisting Url response received after connecting to 3rd party api. */
	private Map<String, String> urlResponseMap = null;

	/** API Name for which processor is implemented. */
	private String serviceNme = null;

	/** Pojo for logging of API request and response. */
	private EcomMrchntLogVO logVO = null;
	
	private Long auditId = null;
	
	public EcomUploadEventsProcessor(EcomMrchntServiceRequest srvcRequest) {
		this.srvcRequest = srvcRequest;
	}
	
	
	
	@Override
	public void preSrvcInputProcessor() {
		
		String thisMethod = "preSrvcInputProcessor";

		FLogger.debug(logger, THIS_CLASS, thisMethod, "Entered " + thisMethod);
		
		if(srvcRequest != null && srvcRequest.getUploadEventsReq()!=null) {
			
			if(RequestResourceThreadLocal.getModuleNmeForCurrentThread()==null) {
				RequestResourceThreadLocal.addModuleNmeForCurrentThread("api-adaptor");
			}
			
			serviceNme = srvcRequest.getServiceNme();

			FLogger.debug(logger, THIS_CLASS, thisMethod,
					"Setting Request Data for Service : " + srvcRequest.getServiceNme()
					+" | serviceNme : "+serviceNme);
			
			request = srvcRequest.getUploadEventsReq();
			
			if(request != null) {
				
				confMap = EcomSrvcConfigCnstntsServiceImpl.fetchConfMap(srvcRequest.getServiceNme());
				
				FLogger.debug(logger, THIS_CLASS, thisMethod,"Fetched Service Specific API Configurations for Service " + serviceNme + " | confMap : "
						+ confMap.size());
				
				FLogger.debug(logger, THIS_CLASS, thisMethod,"Populating API Specific Request Object for Service " + serviceNme);
				
				
				
				D data = new D();
				
				data.setEvtData(request.getEventData());
				data.setType((String) confMap.get(BaseConstants.RESTWS.REST_EVENT_TYPE));
				data.setEvtName(request.getEventName());
				data.setIdentity(request.getCustomerMsisdn());
				data.setTs(StringChecks.getCurrentEpochTime());
				
				String startEpoch = String.format("$D_%d", StringChecks.convertDateToEpoch(request.getEventData().getStartDate(), BaseConstants.YYYYMMDDHHMMSS));
				String endEpoch = String.format("$D_%d", StringChecks.convertDateToEpoch(request.getEventData().getEndDate(), BaseConstants.YYYYMMDDHHMMSS));
				data.getEvtData().setStartDate(startEpoch);
				data.getEvtData().setEndDate(endEpoch);
				
				List<D> dataList = new ArrayList<>();
				dataList.add(data);
				
				apiReq = new UploadEventsRequest();
				apiReq.setD(dataList);
				
				
				
			}else {
				 FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is null");
			}
			

		}else {
			 FLogger.error(logger, THIS_CLASS, thisMethod, "Request Object is null");
		}
		
	}

	@Override
	public EcomMrchntServiceResponse execute() {

		String thisMethod = "execute";
		
		String payload = null;

		MrchntRespStts respStts = null;

		String serviceProtocol = null;

		String apiUrl = null;

		int readTimeout = LoggerConstants.NUM_45000;
		int connTimeout = LoggerConstants.NUM_30000;

		String userId = null;
		String password = null;
		String authKey = null;
		String userChannel = null;

		boolean proxyFlg = false;
		boolean disableSslValidation = false;
		boolean disableHostNmeVerification = false;

		String trustStorePath = null;
		String trustStorePwd = null;
		String tlsVersion = null;


		String applicationRequestId = null;
		
		FLogger.debug(logger, THIS_CLASS, thisMethod, "START");
		
		try {
			/** Formatting Input received into API specific pojo */
			preSrvcInputProcessor();
			
			/**
			 * Checking if input Object is not null and configurations are fetched from DB
			 * for given Service
			 */
			if(!StringChecks.isMapEmpty(confMap)) {
				FLogger.debug(logger, THIS_CLASS, thisMethod, "confMap fetched -> " + confMap.size());

				serviceProtocol = (String) (confMap.get(BaseConstants.RESTWS.REST_REQ_PROTOCOL));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "serviceProtocol is " + serviceProtocol);

				proxyFlg = Boolean.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_PROXY_FLG));
				FLogger.debug(logger, THIS_CLASS, thisMethod, "proxy Flg is " + proxyFlg);
				
				if (confMap.get(BaseConstants.RESTWS.REST_USR_ID) != null) {

					userId = (String) confMap.get(BaseConstants.RESTWS.REST_USR_ID);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "userId is " + userId);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_USR_PSWD) != null) {

					password = (String) confMap.get(BaseConstants.RESTWS.REST_USR_PSWD);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "password is " + password);
				}


				if (confMap.get(BaseConstants.RESTWS.REST_USR_CHNNL) != null) {

					userChannel = (String) confMap.get(BaseConstants.RESTWS.REST_USR_CHNNL);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "userChannel is " + userChannel);
				}

				if (confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY) != null) {

					authKey = (String) confMap.get(BaseConstants.RESTWS.REST_AUTH_KEY);
					FLogger.debug(logger, THIS_CLASS, thisMethod, "authKey is " + authKey);
				}


				if (confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT) != null) {
					connTimeout = Integer
							.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_TIMEOUT));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT) != null) {
					readTimeout = Integer
							.parseInt((String) confMap.get(BaseConstants.RESTWS.REST_CONN_READ_TIMEOUT));
				}

				/** SSL Related properties Start */

				if (confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE) != null) {
					disableSslValidation = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_SSL_DISABLE));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY) != null) {
					disableHostNmeVerification = Boolean
							.parseBoolean((String) confMap.get(BaseConstants.RESTWS.REST_HOST_NME_VERIFY));
				}

				if (confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION) != null) {
					tlsVersion = (String) confMap.get(BaseConstants.RESTWS.REST_TLS_VERSION);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH) != null) {
					trustStorePath = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PATH);
				}

				if (confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD) != null) {
					trustStorePwd = (String) confMap.get(BaseConstants.RESTWS.TRUST_STORE_PSWD);
				}

				/** SSL Related properties End */

				FLogger.debug(logger, THIS_CLASS, thisMethod,
						"connTimeout is " + connTimeout + " | readTimeout is " + readTimeout
								+ " | disableSslValidation is " + disableSslValidation
								+ " | disableHostNmeVerification is " + disableHostNmeVerification);

				/** 3rd Party API url to which requests needs to be submitted */
				if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTP_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTP_URL));

				} else if (serviceProtocol.equalsIgnoreCase(BaseConstants.HTTPS_PROTOCOL)) {

					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));

				} else {
					apiUrl = (String) (confMap.get(BaseConstants.RESTWS.REST_HTTPS_URL));
				}
				
				
				FLogger.error(logger, THIS_CLASS, thisMethod, "API URl to Connect : " + apiUrl);
				
				/**
				 * Generating API specific payload in Json/XML Here as its Soap Web Service,
				 * payload is in XML
				 */
				
				payload = StringChecks.convertObjectToJson(apiReq);
				FLogger.debug(logger, THIS_CLASS, thisMethod, "Generated payload For API : " + payload);
				applicationRequestId = EcomIntegrationUtils.generateAppId();
				
				logVO = new EcomMrchntLogVO();
				logVO.setRequestType(BaseConstants.RESTWS.REST_OUTWARD_REQ);
				logVO.setFiller6(RequestResourceThreadLocal.getRequestIdForCurrentThread());
				logVO.setServiceNme(srvcRequest.getServiceNme());
				logVO.setSourceIp(StringChecks.fetchLocalIpAddr());
				logVO.setIpAddr(StringChecks.fetchLocalIpAddr());
				logVO.setMsisdn(srvcRequest.getUploadEventsReq().getCustomerMsisdn());
				logVO.setRequestParams(payload);
				logVO.setRequestTime(Calendar.getInstance().getTime());
				logVO.setFiller4(apiUrl);
				logVO.setFiller3(BaseConstants.APIMODES.HTTP);
				
				String threadId = RequestResourceThreadLocal.getURI(); // Unique Thread ID generated for each processor
																	  // request, used for tracking logs.

				if (!StringChecks.isFieldEmpty(threadId)) {
					logVO.setFiller5(threadId);
				}
				/**
				 * Header if any needs to be sent during API Url Connection For Web Service API
				 * call, Content-type needs to be set as text/xml For Rest API Calls,
				 * Content-type will be application/json or application/x-www-url-encoded as per
				 * API IDD document
				 */
				
				
				if (confMap != null && confMap.get("REST_DUMMY_RESP_FLG") != null
						&& Boolean.parseBoolean((String) confMap.get("REST_DUMMY_RESP_FLG"))) {

					logVO.setFiller2(BaseConstants.API_SERVICES.DUMMY_CALL);
					EcomHelper.errorLog(logger,"Dummy Response Enabled for Service : " + serviceNme);
					urlResponseMap = EcomMrchntLogHelper.populateDummyResp(confMap, serviceNme);

				} else {

					FLogger.info(logger, THIS_CLASS, thisMethod, "No Dummy Response Set.");
					
					
					HashMap<String, String> headerParameters = new HashMap<>();
					
					headerParameters.put(BaseConstants.HTTPHEADERS.X_CleverTap_Account_Id, (String) confMap.get(BaseConstants.RESTWS.REST_ACCOUNT_ID));
					headerParameters.put(BaseConstants.HTTPHEADERS.X_CleverTap_Passcode, (String) confMap.get(BaseConstants.RESTWS.REST_PASSCODE));
					headerParameters.put(HttpHeaders.CONTENT_TYPE, "application/json");
					
					/** Calling Url Connection Utility to Connect to API url with given payload */
					RestUtilVo requestVo = new RestUtilVo();
					requestVo.setpURL(apiUrl);
					requestVo.setHeaderParameters(headerParameters);
					requestVo.setPayload(payload);
					requestVo.setUrlParameters(null); // No Form Data needs to be sent in this request so its null.
					requestVo.setConnectionTimeOut(connTimeout);
					requestVo.setConnectReadTimeout(readTimeout);
					requestVo.setDisableHostNmeVerification(disableHostNmeVerification);
					requestVo.setDisableSslValidation(disableSslValidation);
					requestVo.setProxyFlag(proxyFlg);
					requestVo.setTlsVersion(tlsVersion);
					requestVo.setTrustStorePath(trustStorePath);
					requestVo.setTrustStorePwd(trustStorePwd);
					requestVo.setRequestType(BaseConstants.POST_REQUEST);
					requestVo.setServiceNme(BaseConstants.API_SERVICES.EAI_UPLOAD_EVENTS);
					requestVo.setConfMap(confMap);
					
					FLogger.error(logger, THIS_CLASS, thisMethod,"Calling HTTP client for the servicename : " + serviceNme);
					urlResponseMap = RestUtility.doConnectUrl(requestVo);
					
				}
				
				/** Parse Response Received in Url Connection From API */
				parseResponse();
				
				if (srvcResponse != null && srvcResponse.getResponseStatus() != null) {
					
					srvcResponse.getResponseStatus().setResponseId(applicationRequestId);
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Exiting Method " + thisMethod + " with Stts " + srvcResponse.getResponseStatus().getStatus());
				}
				
			} else {
				FLogger.error(logger, THIS_CLASS, thisMethod, "No Configurations Fetched, No Processing");
			}
			
		}catch (Exception e) {
			
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod,"Exception scenario in processing service : " + serviceNme);
			
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
			
			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setUploadEventsResp(null);
			srvcResponse.setResponseStatus(respStts);	
		}
		
		return postSrvcOutputProcessor();
	}

	@Override
	public void parseResponse() {
		String thisMethod = "parseResponse";
		String status = null;
		String respMsg = null;

		String errCde = null;
		String errDesc = null;
		String errStts = null;

		try {

			status = urlResponseMap.get("status");
			respMsg = urlResponseMap.get("respMsg");
			String respCde = urlResponseMap.get("respCode");
			
			apiResp =  (UploadEventsResponse) StringChecks.convertJsonToObject(respMsg,UploadEventsResponse.class);
			
			if (BaseConstants.SUCCESS_MSG.equalsIgnoreCase(status) && BaseConstants.SUCCESS_MSG.equalsIgnoreCase(apiResp.getStatus())) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success In API Url Connection");

				

				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Successful API Call :Got UPI Response from API," + " processing Response.");
	
					errCde = respCde;
					errStts = BaseConstants.STTS_MSG_SUCCESS;
					errDesc = BaseConstants.SUCCESS_MSG;
					
					if(apiResp.getError() != null) {
						errDesc = apiResp.getError();
					}
					
					if(apiResp.getCode() != null) {
						errCde = apiResp.getCode().toString();
					}
					
					if(!StringChecks.isCollectionEmpty(apiResp.getUnprocessed())) {
						errCde = apiResp.getUnprocessed().get(0).getCode();
						errStts = apiResp.getUnprocessed().get(0).getStatus();
						errDesc = extractErrorDesc(apiResp.getUnprocessed().get(0).getError());
					}
	
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
	
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);	
					
					respStts.setStatus(apiResp.getStatus());
					
					response = new EcomUploadEventsResp();				
					response.setResponseStatus(respStts);
	
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
					
				
				}else {
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Successful API Connection but No proper Response from API," + " Failure scenario.");
					
					MrchntRespStts respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
					

					response = new EcomUploadEventsResp();
					response.setResponseStatus(respStts);

					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
				}
				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.ERROR_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAILED_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAILURE_MSG.equalsIgnoreCase(status)
					|| BaseConstants.FAIL_MSG.equalsIgnoreCase(apiResp.getStatus())) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Failure Scenario in Url Connection to API");

				
				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");
				
				
					errCde = respCde;
					errStts = BaseConstants.STTS_MSG_FAIL;
					errDesc = BaseConstants.FAILURE_MSG;
					
					if(apiResp.getError() != null) {
						errDesc = apiResp.getError();
					}
					
					if(apiResp.getCode() != null) {
						errCde = apiResp.getCode().toString();
					}
					
					if(!StringChecks.isCollectionEmpty(apiResp.getUnprocessed())) {
						errCde = apiResp.getUnprocessed().get(0).getCode();
						errStts = apiResp.getUnprocessed().get(0).getStatus();
						errDesc = extractErrorDesc(apiResp.getUnprocessed().get(0).getError());
					}
	
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
	
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
					
					response = new EcomUploadEventsResp();				
					response.setResponseStatus(respStts);
	
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
					
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse.getUploadEventsResp()));
					
	
					
				}else {
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection , Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

					response = new EcomUploadEventsResp();				
					response.setResponseStatus(respStts);
	
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
				}
				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");
				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else if (BaseConstants.TIMEOUT_MSG.equalsIgnoreCase(status)) {

				FLogger.error(logger, THIS_CLASS, thisMethod, "TimeOut Scenario in Url Connection to API");


				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");
					errCde = respCde;
					errStts = BaseConstants.STTS_MSG_FAIL;
					errDesc = BaseConstants.FAILURE_MSG;
					
					if(apiResp.getError() != null) {
						errDesc = apiResp.getError();
					}
					
					if(apiResp.getCode() != null) {
						errCde = apiResp.getCode().toString();
					}
					
					if(!StringChecks.isCollectionEmpty(apiResp.getUnprocessed())) {
						errCde = apiResp.getUnprocessed().get(0).getCode();
						errStts = apiResp.getUnprocessed().get(0).getStatus();
						errDesc = extractErrorDesc(apiResp.getUnprocessed().get(0).getError());
					}
	
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
	
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
					
					response = new EcomUploadEventsResp();				
					response.setResponseStatus(respStts);
	
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
					
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse.getUploadEventsResp()));
					
				}else {
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"TIMEOUT in Url Connection , Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);

					response = new EcomUploadEventsResp();				
					response.setResponseStatus(respStts);
	
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
				}
				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Unknown Scenario in Url Connection to API");

				

				if(apiResp != null) {
					FLogger.info(logger, THIS_CLASS, thisMethod,
							"Failure in Url Connection but got API Response from API, so checking");

					errCde = BaseConstants.STTS_CODE_FAILURE;
					errStts = BaseConstants.STTS_MSG_FAIL;
					errDesc = BaseConstants.FAILURE_MSG;
					
					if(apiResp.getError() != null) {
						errDesc = apiResp.getError();
					}
					
					if(apiResp.getCode() != null) {
						errCde = apiResp.getCode().toString();
					}
					
					if(!StringChecks.isCollectionEmpty(apiResp.getUnprocessed())) {
						errCde = apiResp.getUnprocessed().get(0).getCode();
						errStts = apiResp.getUnprocessed().get(0).getStatus();
						errDesc = extractErrorDesc(apiResp.getUnprocessed().get(0).getError());
					}
					
					FLogger.debug(logger, THIS_CLASS, thisMethod,
							"errCde : " + errCde + " | errStts : " + errStts + " | errDesc : " + errDesc);
	
					MrchntRespStts respStts = parseErrorCode(serviceNme, confMap, errCde, errStts,  errDesc);
					
					response = new EcomUploadEventsResp();				
					response.setResponseStatus(respStts);
	
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
					
					FLogger.error(logger, THIS_CLASS, thisMethod,"Response is"+ StringChecks.convertObjectToJson(srvcResponse.getUploadEventsResp()));
					
				}else {
					FLogger.error(logger, THIS_CLASS, thisMethod,
							"TIMEOUT in Url Connection , Failure scenario.");
					
					MrchntRespStts respStts = new MrchntRespStts();
					respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);

					response = new EcomUploadEventsResp();				
					response.setResponseStatus(respStts);
	
					srvcResponse = new EcomMrchntServiceResponse();
					srvcResponse.setUploadEventsResp(response);
					srvcResponse.setResponseStatus(respStts);
				}
				FLogger.error(logger, THIS_CLASS, thisMethod, "Storing Response in DB");

				logVO.setResponseParams(respMsg);
				logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
				logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
				logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());

				auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);

			MrchntRespStts respStts = new MrchntRespStts();
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			response = new EcomUploadEventsResp();				
			response.setResponseStatus(respStts);

			srvcResponse = new EcomMrchntServiceResponse();
			srvcResponse.setUploadEventsResp(response);
			srvcResponse.setResponseStatus(respStts);

			logVO.setResponseParams(respMsg);
			logVO.setRespStts(srvcResponse.getResponseStatus().getStatus());
			logVO.setRespSttsCde(srvcResponse.getResponseStatus().getStatusCde());
			logVO.setRespSttsDesc(srvcResponse.getResponseStatus().getDescription());
			auditId = EcomMrchntLogHelper.logResponseForRestWs(logVO);

		}finally {
			
			if(srvcResponse!=null && srvcResponse.getResponseStatus()!=null) {
				srvcResponse.getResponseStatus().setAuditId(auditId);
			}
		}
	}
		


	@Override
	public EcomMrchntServiceResponse postSrvcOutputProcessor() {
		
		FLogger.error(logger, THIS_CLASS, "postSrvcOutputProcessor", "Returning response :"+StringChecks.convertObjectToJson(srvcResponse.getUploadEventsResp()));
		return srvcResponse;
	}
	
	

	
	
	/**
	 * @param serviceNme
	 * @param confMap
	 * @param errCde
	 * @param errStts
	 * @param errDesc
	 * @return
	 */
	public static MrchntRespStts parseErrorCode(String serviceNme, Map<String, Object> confMap, String errCde,
			String errStts, String errDesc) {

		MrchntRespStts respStts = null;
		String thisMethod = "parseErrorCode";

		String successCodes = null;
		String pendingSuccessCodes = null;
		String failureCodes = null;

		String status = null;
		String statusDesc = null;

		List<String> successCodesList = new ArrayList<>();
		List<String> pendingSuccessCodesList = new ArrayList<>();
		List<String> failureCodesList = new ArrayList<>();

		try {
			
			
			successCodes = (String) confMap.get(BaseConstants.RESTWS.REST_SUCCESS_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "successCodes is " + successCodes);

			pendingSuccessCodes = (String) confMap.get(BaseConstants.RESTWS.REST_PENDING_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "pendingCodes is " + pendingSuccessCodes);

			failureCodes = (String) confMap.get(BaseConstants.RESTWS.REST_FAILURE_CDES);
			FLogger.debug(logger, THIS_CLASS, thisMethod, "failureCodes is " + failureCodes);

			if (!StringChecks.isFieldEmpty(successCodes)) {
				successCodesList = Arrays.asList(successCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(pendingSuccessCodes)) {
				pendingSuccessCodesList = Arrays.asList(pendingSuccessCodes.split("[\\|]+"));
			}

			if (!StringChecks.isFieldEmpty(failureCodes)) {
				failureCodesList = Arrays.asList(failureCodes.split("[\\|]+"));
			}
			
			if (successCodesList != null && !successCodesList.contains(errCde)) {

				FLogger.error(logger, THIS_CLASS, thisMethod,
						"Non-Success Scenario for Service :: " + serviceNme);

				if (pendingSuccessCodesList != null && pendingSuccessCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Timeout Scenario for " + " as Response Code is : " + errStts + " is timeout code.");

					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				} else if (failureCodesList != null && failureCodesList.contains(errCde)) {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"FAILURE Scenario for " + " as Response Code is : " + errStts + " is FAILURE code.");

					status = BaseConstants.FAILED_MSG;

					if (StringChecks.isFieldEmpty(errDesc)) {
						statusDesc = BaseConstants.FAILURE_MSG;
					} else {
						statusDesc = errDesc;
					}
				} else {

					FLogger.error(logger, THIS_CLASS, thisMethod,
							"Unknown/Deemed-Success Scenario for Service ::" + serviceNme);
					status = BaseConstants.TIMEOUT_MSG;
					statusDesc = BaseConstants.NO_RESP;

				}

			} else {

				FLogger.error(logger, THIS_CLASS, thisMethod, "Success Scenario for Service :: " + serviceNme);
				status = BaseConstants.SUCCESS_MSG;

				if (StringChecks.isFieldEmpty(errDesc)) {
					statusDesc = BaseConstants.SUCCESS_MSG;
				} else {
					statusDesc = errDesc;
				}
			}

			respStts = new MrchntRespStts();
			respStts.setStatus(status);
			respStts.setStatusCde(errCde);
			respStts.setDescription(statusDesc);

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, thisMethod);
		}
		return respStts;
	}

	public static String extractErrorDesc(String error) {
		String methodName = "extractErrorDesc";
		String errDesc = null;
		try {
			
			
			FLogger.debug(logger, THIS_CLASS, methodName, "Entered method: "+methodName+" with error description: "+error);
			int pos = error.indexOf(".");
			errDesc = error.substring(0, pos);
			
		}catch (Exception e) {
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
		}finally {
			FLogger.debug(logger, THIS_CLASS, methodName,"Exiting method with error description: "+errDesc);
		}
		
		return errDesc;
	}
	

}
