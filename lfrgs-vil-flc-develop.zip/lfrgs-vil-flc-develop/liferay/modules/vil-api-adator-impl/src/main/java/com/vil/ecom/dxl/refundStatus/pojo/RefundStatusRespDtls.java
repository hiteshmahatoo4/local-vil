package com.vil.ecom.dxl.refundStatus.pojo;

public class RefundStatusRespDtls {
	
	
    private String pgOrderId;
    
    private String correlatorId;
    
    private String refundOrderId;
    
    private String refundOrderStatus;
    
    private String amount;
    
    private String srNumber;

	/**
	 * @return the pgOrderId
	 */
	public String getPgOrderId() {
		return pgOrderId;
	}

	/**
	 * @param pgOrderId the pgOrderId to set
	 */
	public void setPgOrderId(String pgOrderId) {
		this.pgOrderId = pgOrderId;
	}

	/**
	 * @return the correlatorId
	 */
	public String getCorrelatorId() {
		return correlatorId;
	}

	/**
	 * @param correlatorId the correlatorId to set
	 */
	public void setCorrelatorId(String correlatorId) {
		this.correlatorId = correlatorId;
	}

	/**
	 * @return the refundOrderId
	 */
	public String getRefundOrderId() {
		return refundOrderId;
	}

	/**
	 * @param refundOrderId the refundOrderId to set
	 */
	public void setRefundOrderId(String refundOrderId) {
		this.refundOrderId = refundOrderId;
	}

	/**
	 * @return the refundOrderStatus
	 */
	public String getRefundOrderStatus() {
		return refundOrderStatus;
	}

	/**
	 * @param refundOrderStatus the refundOrderStatus to set
	 */
	public void setRefundOrderStatus(String refundOrderStatus) {
		this.refundOrderStatus = refundOrderStatus;
	}

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getSrNumber() {
		return srNumber;
	}

	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}

    
}
