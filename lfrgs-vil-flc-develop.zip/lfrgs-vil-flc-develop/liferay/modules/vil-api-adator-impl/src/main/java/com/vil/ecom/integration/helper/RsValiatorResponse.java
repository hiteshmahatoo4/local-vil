package com.vil.ecom.integration.helper;

import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.pojo.MrchntRespStts;

import java.util.List;

public class RsValiatorResponse {

	private RsValiatorResponse() {
		throw new IllegalStateException("Utility class");
	}

	public static final String DESC_INVALID_PARAM = "Invalid parameter passed: ";
	public static final String DESC_PARAM_NP = "Mandatory parameter not passed: ";

	public static final String DESC_REQ_ID = "requestId";
	public static final String DESC_CHNNL_ID = "channelId";
	public static final String DESC_MSISDN = "msisdn";
	public static final String DESC_CRCLE_ID = "circleId";
	public static final String DESC_BRAND_ID = "brand";
	public static final String DESC_ACCNT_ID = "accountId";
	public static final String DESC_IMEI = "imei";
	
	public static final String STTS_CODE_SUCCESS = "100";
	public static final String STTS_CODE_AUTH_FAIL = "101";
	public static final String STTS_CODE_INVALID_MANDATORY_PARAMS = "103";
	public static final String STTS_CODE_MANDATORY_PARAMS_NOT_PASSED = "105";
	public static final String STTS_CODE_FAILURE = "106";

	public static final String TIMEOUT_MSG = "TIMEOUT";

	public static final String STTS_MSG_SUCCESS = "SUCCESS";
	public static final String STTS_MSG_FAIL = "FAILURE";
	
	public static MrchntRespStts invalidParamsResponse(String requestId, String descField){
	
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(STTS_CODE_INVALID_MANDATORY_PARAMS);
		response.setStatus(STTS_MSG_FAIL);
		response.setDescription(DESC_INVALID_PARAM+ descField);
		response.setResponseId(requestId);
		
		return response;
	}

	public static MrchntRespStts paramsNotPassedResponse(String requestId, String descField){
		
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(STTS_CODE_MANDATORY_PARAMS_NOT_PASSED);
		response.setStatus(STTS_MSG_FAIL);
		response.setDescription(DESC_PARAM_NP + descField);
		response.setResponseId(requestId);
		
		return response;
	}

	public static MrchntRespStts invalidMSISDNResponse(String requestId){
		
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(STTS_CODE_INVALID_MANDATORY_PARAMS);
		response.setStatus(STTS_MSG_FAIL);
		response.setDescription(DESC_INVALID_PARAM + DESC_MSISDN);
		response.setResponseId(requestId);
		
		return response;
	}

	
	public static MrchntRespStts checkRequestIDResponse(String reqId){

		MrchntRespStts response = null;
		String descField = DESC_REQ_ID;
		
		if(StringChecks.isFieldEmpty(reqId)){
			response= paramsNotPassedResponse(reqId, descField);
		}else if(!StringChecks.checkAlphaNumericWithSpacialChars(reqId)){
			response=  invalidParamsResponse(reqId, descField);
		}else if(reqId.trim().length() > LoggerConstants.NUM_20){
			response=  invalidParamsResponse(reqId, descField);
		}
		
		return response;
	}

	public static MrchntRespStts checkMSISDNResponse(String msisdn, String reqId){

		MrchntRespStts response = null;
		String descField = DESC_MSISDN;
		
		if(StringChecks.isFieldEmpty(msisdn)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		else if(!StringChecks.isNumber(msisdn)){
			response=  invalidMSISDNResponse(reqId);
		}
		else if(!(msisdn.trim().length() == LoggerConstants.NUM_10 || msisdn.trim().length() == LoggerConstants.NUM_12 )){
			response=  invalidMSISDNResponse(reqId);
		}

		return response;
	}
	

	public static MrchntRespStts checkImeiResponse(String imei, String reqId){

		MrchntRespStts response = null;
		String descField = DESC_IMEI;
		
		if(StringChecks.isFieldEmpty(imei)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		else if(!StringChecks.isNumber(imei)){
			response=  invalidParamsResponse(reqId,descField);
		}

		return response;
	}
	
	public static MrchntRespStts checkCircleResponse(String circle, String reqId){

		MrchntRespStts response = null;
		String descField = DESC_CRCLE_ID;
		
		if(StringChecks.isFieldEmpty(circle)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		else if(!StringChecks.isNumber(circle)){
			response=  invalidParamsResponse(reqId,descField);
		}

		return response;
	}
	
	public static MrchntRespStts checkNumberParamResponse(String accountId, String reqId,String descField){

		MrchntRespStts response = null;
		
		if(StringChecks.isFieldEmpty(accountId)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		else if(!StringChecks.isNumber(accountId)){
			response=  invalidParamsResponse(reqId,descField);
		}

		return response;
	}
	
	public static MrchntRespStts checkDateResponse(String date, String reqId,String descField,String datePattern){

		MrchntRespStts response = null;
		String descFieldWithPattern = descField+",Format required :"+datePattern;
		
		if(StringChecks.isFieldEmpty(date)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		else if(!StringChecks.isValidDate(date,datePattern)){			
			response=  invalidParamsResponse(reqId,descFieldWithPattern);
		}

		return response;
	}
	
	public static MrchntRespStts validateStrInputList(List<String> input, String reqId,String descField){

		MrchntRespStts response = null;
		
		if(StringChecks.isNullOrSpace(input)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		
		return response;
	}
	

	public static MrchntRespStts checkChannelIDResponse(String channelID, String reqId){

		MrchntRespStts response = null;
		String descField = DESC_CHNNL_ID;
		
		if(StringChecks.isFieldEmpty(channelID)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		else if(!StringChecks.isNumber(channelID)){
			response= invalidParamsResponse(reqId, descField);
		}
		
		return response;
	}

	public static MrchntRespStts validateNumericInput(String input, String reqId,String descField){

		MrchntRespStts response = null;
		
		if(StringChecks.isFieldEmpty(input)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		else if(!StringChecks.isNumber(input)){
			response= invalidParamsResponse(reqId, descField);
		}
		
		return response;
	}

	public static MrchntRespStts validateStrInput(String input, String reqId,String descField){

		MrchntRespStts response = null;
		
		if(StringChecks.isFieldEmpty(input)){
			response= paramsNotPassedResponse(reqId, descField);
		}
		
		return response;
	}

	/**
	 * @param requestId
	 * @param descField
	 * @return
	 */
	public static MrchntRespStts scssResponse(String requestId, String descField){
	
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(STTS_CODE_SUCCESS);
		response.setStatus(STTS_MSG_SUCCESS);
		response.setDescription(descField);
		response.setResponseId(requestId);
		
		return response;
	}

	/**
	 * @param requestId
	 * @param descField
	 * @return
	 */
	public static MrchntRespStts errorResponse(String requestId, String descField){
	
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(STTS_CODE_FAILURE);
		response.setStatus(STTS_MSG_FAIL);
		response.setDescription(descField);
		response.setResponseId(requestId);
		
		return response;
	}

	/**
	 * @param requestId
	 * @param descField
	 * @return
	 */
	public static MrchntRespStts errorResponse(String requestId,String errCde, String descField){
	
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(errCde);
		response.setStatus(STTS_MSG_FAIL);
		response.setDescription(descField);
		response.setResponseId(requestId);
		
		return response;
	}
	/**
	 * @param requestId
	 * @param descField
	 * @return
	 */
	public static MrchntRespStts timeoutResponse(String requestId, String descField){
	
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(TIMEOUT_MSG);
		response.setStatus(TIMEOUT_MSG);
		response.setDescription(descField);
		response.setResponseId(requestId);
		
		return response;
	}

	/**
	 * @param requestId
	 * @param descField
	 * @return
	 */
	public static MrchntRespStts authFailResponse(String requestId, String descField){
	
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(STTS_CODE_AUTH_FAIL);
		response.setStatus(STTS_MSG_FAIL);
		response.setDescription(descField);
		response.setResponseId(requestId);
		
		return response;
	}

	/**
	 * @param requestId
	 * @param errorCde
	 * @param descField
	 * @return
	 */
	public static MrchntRespStts authFailResponse(String requestId,String errorCde, String descField){
	
		MrchntRespStts response = new MrchntRespStts();
		response.setStatusCde(errorCde);
		response.setStatus(STTS_MSG_FAIL);
		response.setDescription(descField);
		response.setResponseId(requestId);
		
		return response;
	}

}
