package com.vil.ecom.eai.CreateConsentRequest.pojo;


public class CreateConsentRequestRespDtls {
	
	private String verdict;
	private String message;
	private String time;
	private String request_id;
	/**
	 * @return the verdict
	 */
	public String getVerdict() {
		return verdict;
	}
	/**
	 * @param verdict the verdict to set
	 */
	public void setVerdict(String verdict) {
		this.verdict = verdict;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}
	/**
	 * @return the request_id
	 */
	public String getRequest_id() {
		return request_id;
	}
	/**
	 * @param request_id the request_id to set
	 */
	public void setRequest_id(String request_id) {
		this.request_id = request_id;
	}
	
	
}
