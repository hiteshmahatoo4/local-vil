package com.vil.ecom.integration.pojo;

import java.io.File;
import java.io.Serializable;

public class EcomSendMailReqDtls implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String frmEmailId;

	private String toEmailId;

	private String ccEmailId;

	private String subject;

	private String emailBody;

	private String refNo;

	private String requestId;

	private String msisdn;

	private String entityTypeId;

	private String channelID;

	private String srNo;

	private File attachment;

	/**
	 * @return the attachment
	 */
	public File getAttachment() {
		return attachment;
	}

	/**
	 * @param attachment the attachment to set
	 */
	public void setAttachment(File attachment) {
		this.attachment = attachment;
	}

	/**
	 * @return the srNo
	 */
	public String getSrNo() {
		return srNo;
	}

	/**
	 * @param srNo the srNo to set
	 */
	public void setSrNo(String srNo) {
		this.srNo = srNo;
	}

	/**
	 * @return the toEmailId
	 */
	public String getToEmailId() {
		return toEmailId;
	}

	/**
	 * @param toEmailId the toEmailId to set
	 */
	public void setToEmailId(String toEmailId) {
		this.toEmailId = toEmailId;
	}

	/**
	 * @return the ccEmailId
	 */
	public String getCcEmailId() {
		return ccEmailId;
	}

	/**
	 * @param ccEmailId the ccEmailId to set
	 */
	public void setCcEmailId(String ccEmailId) {
		this.ccEmailId = ccEmailId;
	}

	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the emailBody
	 */
	public String getEmailBody() {
		return emailBody;
	}

	/**
	 * @param emailBody the emailBody to set
	 */
	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}

	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the entityTypeId
	 */
	public String getEntityTypeId() {
		return entityTypeId;
	}

	/**
	 * @param entityTypeId the entityTypeId to set
	 */
	public void setEntityTypeId(String entityTypeId) {
		this.entityTypeId = entityTypeId;
	}

	/**
	 * @return the channelID
	 */
	public String getChannelID() {
		return channelID;
	}

	/**
	 * @param channelID the channelID to set
	 */
	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}

	/**
	 * @return the frmEmailId
	 */
	public String getFrmEmailId() {
		return frmEmailId;
	}

	/**
	 * @param frmEmailId the frmEmailId to set
	 */
	public void setFrmEmailId(String frmEmailId) {
		this.frmEmailId = frmEmailId;
	}

}
