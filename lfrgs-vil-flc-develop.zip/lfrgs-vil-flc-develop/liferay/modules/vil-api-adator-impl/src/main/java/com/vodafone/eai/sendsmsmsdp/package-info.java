@javax.xml.bind.annotation.XmlSchema(namespace = "http://eai.vodafone.com/sendSmsMSDP", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.vodafone.eai.sendsmsmsdp;
