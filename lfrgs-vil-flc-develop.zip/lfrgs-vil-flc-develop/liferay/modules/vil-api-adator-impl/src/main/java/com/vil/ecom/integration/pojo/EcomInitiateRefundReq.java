package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class EcomInitiateRefundReq implements Serializable {
	
	/**
	 *
	 */
	 private static final long serialVersionUID = 1L;
	 
	 private String circleId;
	 
	 private String provider;
	 
	 private String subscriberType;
	 
	 private String refundType;
	 
	 private String refundOrderId;
	 
	 private String dxlPgOrderId;
	 
	 private String amount;
	 
	 private String ecomOrderId;

	public String getCircleId() {
		return circleId;
	}

	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getSubscriberType() {
		return subscriberType;
	}

	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}

	public String getRefundType() {
		return refundType;
	}

	public void setRefundType(String refundType) {
		this.refundType = refundType;
	}

	public String getRefundOrderId() {
		return refundOrderId;
	}

	public void setRefundOrderId(String refundOrderId) {
		this.refundOrderId = refundOrderId;
	}

	public String getDxlPgOrderId() {
		return dxlPgOrderId;
	}

	public void setDxlPgOrderId(String dxlPgOrderId) {
		this.dxlPgOrderId = dxlPgOrderId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getEcomOrderId() {
		return ecomOrderId;
	}

	public void setEcomOrderId(String ecomOrderId) {
		this.ecomOrderId = ecomOrderId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	 

	 
	
	 
	 
	 
	 
	

}
