
package com.vodafone.eai.sendsmsmsdp;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.vodafone.eai.metainforesp.UDHMetaInfoResp;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MetaInfo" type="{http://eai.vodafone.com/MetaInfoResp}UDHMetaInfoResp"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "metaInfo"
})
@XmlRootElement(name = "SendSmsMSDPResponse")
public class SendSmsMSDPResponse {

    @XmlElement(name = "MetaInfo", required = true)
    protected UDHMetaInfoResp metaInfo;

    /**
     * Gets the value of the metaInfo property.
     * 
     * @return
     *     possible object is
     *     {@link UDHMetaInfoResp }
     *     
     */
    public UDHMetaInfoResp getMetaInfo() {
        return metaInfo;
    }

    /**
     * Sets the value of the metaInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link UDHMetaInfoResp }
     *     
     */
    public void setMetaInfo(UDHMetaInfoResp value) {
        this.metaInfo = value;
    }

}
