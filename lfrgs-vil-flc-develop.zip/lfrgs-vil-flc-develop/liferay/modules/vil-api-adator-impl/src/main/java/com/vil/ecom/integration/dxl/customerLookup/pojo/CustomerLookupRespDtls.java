package com.vil.ecom.integration.dxl.customerLookup.pojo;

public class CustomerLookupRespDtls {
	
	private String msisdn;
	
	private String circleId;
	
	private String segment;
	
	private String brandIdentifier;
	
	private String status;
	
	private String isMigrated;
	
	private String subscriptionType;
	
	private String provider;
	
	private String statusCode;

	/**
	 * @return the msisdn
	 */
	public String getMsisdn() {
		return msisdn;
	}

	/**
	 * @param msisdn the msisdn to set
	 */
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the segment
	 */
	public String getSegment() {
		return segment;
	}

	/**
	 * @param segment the segment to set
	 */
	public void setSegment(String segment) {
		this.segment = segment;
	}

	/**
	 * @return the brandIdentifier
	 */
	public String getBrandIdentifier() {
		return brandIdentifier;
	}

	/**
	 * @param brandIdentifier the brandIdentifier to set
	 */
	public void setBrandIdentifier(String brandIdentifier) {
		this.brandIdentifier = brandIdentifier;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the isMigrated
	 */
	public String getIsMigrated() {
		return isMigrated;
	}

	/**
	 * @param isMigrated the isMigrated to set
	 */
	public void setIsMigrated(String isMigrated) {
		this.isMigrated = isMigrated;
	}

	/**
	 * @return the subscriptionType
	 */
	public String getSubscriptionType() {
		return subscriptionType;
	}

	/**
	 * @param subscriptionType the subscriptionType to set
	 */
	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	/**
	 * @return the provider
	 */
	public String getProvider() {
		return provider;
	}

	/**
	 * @param provider the provider to set
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
