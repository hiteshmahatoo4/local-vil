package com.vil.ecom.constants;

import java.math.BigDecimal;

/**
 * This Interface contains all the constants required  for reading log configuration
 * and implementing logger
 * @author TCS
 *
 */
public class LoggerConstants {
	
	public static final String LOGGER_INIT = "LOGGER_INIT_FILE";
	public static final String LOGGER_CAT = "ECOM";
	public static final String LOGGER_AUDIT_CAT = "Audit";
	public static final String LOGGER_OAUTH_AUDIT_CAT = "Oauth2Audit";
	public static final String LOGGER_MONITOR_CAT = "AppMonitor";
	public static final String LOGGER_DB_AUDIT_MONITOR_CAT = "QueryAudit";

	public static final String LOGGED_IN_USER = "LoggedInUser";
	public static final String LOGGED_IN_USER_NAME = "loggedInUserName";
	public static final String LOGGED_IN_USER_ID = "loggedInUserId";
	
	public static final String errorInProcessingReq = "Error in Processing Request.Kindly try after Some time";

	public static final String ERR_LOG_PRFIX = " Error Log : ";
	public static final String GOT_EXCEPTION_PREFIX = " Got Exception : ";
	public static final String GOT_EXCEPTION_DUE_TO_SUFFIX = " due to: ";

	public static final String HEADER_LOGGER = "Inputs Received Header : ";
	public static final String BDY_LOGGER = "Inputs Received Input : ";

	public static final String VALID_PASS = "Validation Credentials Passed";
	public static final String VALID_FAIL = "Validation for Credentials Failed";

	public static final BigDecimal ZERO_VAL = BigDecimal.valueOf(0D);

	public static final String ENTERED_MTD = "Entered Method ";
	public static final String EXITING_MTD = "Exiting Method ";
	public static final String IN = " in ";
	
	public static final long SECOND = 1000L;
	public static final long MINUTE = 60 * SECOND;
	public static final long HOUR = 60 * MINUTE;

	public static final int NUM_NEGATIVE_2 =-2;
	public static final int NUM_0 =0;
	public static final int NUM_1 =1;
	public static final int NUM_2 =2;
	public static final int NUM_3 =3;
	public static final int NUM_4 =4;
	public static final int NUM_5 =5;
	public static final int NUM_6 =6;
	public static final int NUM_7 =7;
	public static final int NUM_8 =8;
	public static final int NUM_9 =9;
	public static final int NUM_10 =10;
	public static final int NUM_11 =11;
	public static final int NUM_12 =12;
	public static final int NUM_13 =13;
	public static final int NUM_14 =14;
	public static final int NUM_15 =15;
	public static final int NUM_16 =16;
	public static final int NUM_17 =17;
	public static final int NUM_18 =18;
	public static final int NUM_19 =19;
	public static final int NUM_20 =20;
	public static final int NUM_21 =21;
	public static final int NUM_22 =22;
	public static final int NUM_23 =23;
	public static final int NUM_24 =24;
	public static final int NUM_25 =25;
	public static final int NUM_26 =26;
	public static final int NUM_27 =27;
	public static final int NUM_28 =28;
	public static final int NUM_29 =29;
	public static final int NUM_30 =30;
	public static final int NUM_31 =31;
	public static final int NUM_32 =32;
	public static final int NUM_33 =33;
	public static final int NUM_34 =34;
	public static final int NUM_35 =35;
	public static final int NUM_36 =36;
	public static final int NUM_37 =37;
	public static final int NUM_38 =38;
	public static final int NUM_39 =39;
	public static final int NUM_40 =40;
	public static final int NUM_41 =41;
	public static final int NUM_42 =42;
	public static final int NUM_43 =43;
	public static final int NUM_44 =44;
	public static final int NUM_45 =45;
	public static final int NUM_46 =46;
	public static final int NUM_47 =47;
	public static final int NUM_48 =48;
	public static final int NUM_49 =49;
	public static final int NUM_50 =50;
	public static final int NUM_51 =51;
	public static final int NUM_52 =52;
	public static final int NUM_53 =53;
	public static final int NUM_54 =54;
	public static final int NUM_55 =55;
	public static final int NUM_56 =56;
	public static final int NUM_57 =57;
	public static final int NUM_58 =58;
	public static final int NUM_59 =59;
	public static final int NUM_60 =60;
	public static final int NUM_61 =61;
	public static final int NUM_62 =62;
	public static final int NUM_63 =63;
	public static final int NUM_64 =64;
	public static final int NUM_65 =65;
	public static final int NUM_66 =66;
	public static final int NUM_67 =67;
	public static final int NUM_68 =68;
	public static final int NUM_69 =69;
	public static final int NUM_70 =70;
	public static final int NUM_71 =71;
	public static final int NUM_72 =72;
	public static final int NUM_73 =73;
	public static final int NUM_74 =74;
	public static final int NUM_75 =75;
	public static final int NUM_76 =76;
	public static final int NUM_77 =77;
	public static final int NUM_78 =78;
	public static final int NUM_79 =79;	
	public static final int NUM_80 =80;
	
	public static final int NUM_90 =90;
	
	public static final int NUM_100 =100;

	public static final int NUM_120 =120;
	
	public static final int NUM_160 =160;

	public static final int NUM_200 =200;
	
	public static final int NUM_256 =256;
	
	public static final int NUM_400 =400;
	
	public static final int NUM_511 =511;
	
	public static final int NUM_1000 =1000;
	
	public static final int NUM_2500 =2500;
	
	public static final int NUM_3000 =3000;
	
	public static final int NUM_5000 =5000;
	
	public static final int NUM_1024 =1024;
	
	public static final int NUM_65536 =65536;
	
	public static final int NUM_10000 =10000;
	public static final int NUM_15000 =15000;
	public static final int NUM_20000 =20000;
	public static final int NUM_30000 =30000;
	public static final int NUM_45000 =45000;
	public static final int NUM_50000 =50000;
	public static final int NUM_100000 =100000;
	
	public static final class LOGEVENTS {

		public static final String RS_VALIDATION = "RS_VALIDATION";
		public static final String RS_SRVC = "RS_SRVC";
		public static final String RS_CONTROLLER = "RS_CONTROLLER";
		public static final String DB_CALL_EXT = "DB_CALL_EXT";
		public static final String DB_CALL = "DB_CALL";
		
		public static final String PLTFRM_SRVC = "PLTFM_SRVC";
		public static final String PLTFM_PROCESSOR = "PLTFM_PROCESSOR";
		public static final String SW_MVC_CONTROLLER = "MVC_CONTROLLER";
		public static final String SW_DB_REPOSITORY = "DB_REPO";
		
		public static final String SEPARATOR = " | ";
		public static final String ADT_SRVC_NME = "ServiceName : ";
		public static final String ADT_LOG_TYPE = "LOG_TYPE : AAC ";
		public static final String ADT_REQ_TYPE = "REQ_TYPE : ";
		public static final String ADT_API_CALL_TYPE = "API_CALL_TYPE : ";
		public static final String ADT_MSISDN = "msisdn : ";
		public static final String ADT_CRCLE = "circle : ";
		public static final String ADT_CHNNL = "Channel : ";
		public static final String ADT_REQ_ID = "REQ_ID : ";
		public static final String ADT_URI = "URI : ";
		public static final String ADT_THREAD_ID = "ThreadID : ";
		public static final String ADT_LOGGERID = "LoggerId : ";
		public static final String ADT_STTS = "stts : ";
		public static final String ADT_ERR_CDE = "errCde : ";
		public static final String ADT_ERR_DESC = "errDesc : ";
		public static final String ADT_REMOTE_IP = "RemoteIp : ";
		public static final String ADT_SRC_IP = "SourceIp : ";
		public static final String ADT_PAYLOAD = "Payload : ";
		public static final String ADT_TIME_TAKEN = "TimeTaken : ";
		
		
	}

	/** Added Inner class for Rest Services related Constants */
	public static final class REST_WS {

		public static final String APP_ENABLE_SPRING_JMS = "ENABLE_SPRING_JMS";
		public static final String APP_ENABLE_HTTP_CLIENT = "ENABLE_HTTP_CLIENT";
		public static final String APP_ENABLE_REST_TEMPLATE = "ENABLE_REST_TEMPLATE";

		public static final String APP_ENABLE_SSL_HANDSHAKE = "ENABLE_SSL_HANDSHAKE";
		public static final String APP_TRUSTSTORE_PATH = "TRUSTSTORE.PATH";
		public static final String APP_TRUSTSTORE_PAWD = "TRUSTSTORE.PWD";

		public static final String REST_INVALID_PAYLOAD_ERR_MSG = "Invalid Request Passed";
		public static final String REST_MANDATORY_PARAM_ERR_MSG = "Mandatory Parameters not Passed";
		public static final String REST_INVALID_PARAM_ERR_MSG = "Invalid Parameters Passed";

		public static final String REST_MS_SUCCESS_CDE = "100";
		public static final String REST_MS_FAILURE_CDE = "106";
		public static final String REST_MANDATORY_PARAM_ERR_CDE = "105";
		public static final String REST_INVALID_PARAM_ERR_CDE = "103";

		public static final String EAI_segment_prepaid = "PREPAID";
		public static final String EAI_segment_postpaid = "POSTPAID";
		public static final String EAI_segment_PRE = "Prepaid";
		public static final String EAI_segment_POST = "Postpaid";
		public static final String EAI_segment_VER = "1.0";
		public static final String REST_DEFAULT_CHNNL = "DCRM";

		public static final String URL_TIMEOUT = "URI Time out Occurred";
		public static final String NO_RESP = "No response from API";

		public static final String UPSS_DATE_PATTERN = "dd/MM/yyyy";
		public static final String UPSS_DATE_PATTERN2 = "dd-MM-yyyy";
		public static final String UPSS_DATE_PATTERN8 = "dd-MMM-yyyy";
		public static final String EAI_DATE_PATTERN3 = "yyyy-MM-dd";
		public static final String EAI_DATE_PATTERN4 = "dd-MM-yyyy HH:MM:SS";
		public static final String EAI_DATE_PATTERN5 = "yyyy-MM-dd HH:mm:ss.SSS";
		public static final String EAI_DATE_PATTERN6 = "yyyy-MM-dd HH:mm:ss";
		public static final String EAI_DATE_PATTERN7 = "dd-MM-yyyy";
		public static final String UPSS_DATE_PATTERN9 = "dd-MMM-YY HH:mm:ss";
		public static final String UPSS_DATE_PATTERN10 = "dd/MM/yyyy HH:mm:ss";
		public static final String WS_DATE_PATTERN = "MM/dd/yyyy HH:mm:ss";
		public static final String UNBAR_REQ_DATE_PATTERN = "dd-MMM-yy";
		public static final String EAI_DATE_PATTERN_NOTIFY_SR_DETAILS="YYYY/MM/DD";

		public static final String CRM_UPC_DATE_PATTERN4 = "MM-dd-yyyy HH:mm:ss";

		public static final String CT_SONG_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss ZZZ";

		public static final String GET_IN_BAL_DATE_PATTERN = "dd-MM-yyyy HH:mm:ss";
		public static final String GET_IN_BAL_TIMEZONE_DATE_PATTERN = "yyyyMMdd'T'hh:mm:ss";

		public static final String TNPS_DATE_PATTERN = "dd-MMM-yyyy HH:mm:ss";
		public static final String TNPS_DATE_FILE_DATE_PATTERN = "ddMMyyyyHHmmss";
		public static final String TNPS_AON_DATE_FILE_DATE_PATTERN = "E MMM dd HH:mm:ss Z yyyy";
		
		public static final String CAD_API_DATE_PATTERN = "MM/dd/yyyy";

		/** Send SMS SERVICES Constants */
		public static final String REST_DEFAULT_GET_MSDP_VIEW_APP_SERVICE_NAME = "MSDPViewApp";
		public static final String REST_GET_MSDP_VIEW_APP_SERVICE_NAME = "REST_GET_MSDP_VIEW_APP_SERVICE_NAME";

		/** MODIFY SERVICES Constants */
		public static final String EAI_MODFY_SRV_KEY = "4-HRHSNK7";
		public static final String EAI_MODFY_SRV_VERSION = "1";

		/** DB Constants */
		public static final String REST_HOST_NME_VERIFY = "REST_HOST_NME_VERIFY";
		public static final String REST_SSL_DISABLE = "REST_SSL_DISABLE";
		public static final String REST_PROXY_FLG = "REST_PROXY_FLG";

		public static final String REST_INTERFACE_TYPE = "REST_INTERFACE_TYPE";
		public static final String REST_INTERFACE_KEY = "REST_INTERFACE_KEY";

		public static final String REST_USR_ID = "REST_USR_ID";
		public static final String REST_USR_PSWD = "REST_USR_PWD";
		public static final String REST_MRCNT_ID = "REST_MRCNT_ID";
		public static final String REST_REQ_PROTOCOL = "REST_REQ_PROTOCOL";
		public static final String REST_METHOD_PROTOCOL = "REST_METHOD_PROTOCOL";
		public static final String REST_USR_CHNNL = "REST_USR_CHNNL";
		public static final String REST_WS_SEC_USR_CHNNL = "REST_WS_SEC_USR_CHNNL";
		public static final String REST_REQ_MDE = "REST_REQ_MDE";
		public static final String REST_SRV_NME = "REST_SRV_NME";
		public static final String REST_FROM = "REST_FROM";
		public static final String REST_segment_prepaid = "REST_segment_prepaid";
		public static final String REST_SERVICE_NME = "REST_SERVICE_NME";
		public static final String REST_SOURCE_INDICATOR = "REST_SOURCE_INDICATOR";
		public static final String REST_FLASH_REQ_NME = "REST_FLASH_REQ_NME";

		public static final String REST_HTTP_URL = "REST_HTTP_URL";
		public static final String REST_HTTPS_URL = "REST_HTTPS_URL";
		public static final String REST_HTTP_URL_LOCAL = "REST_HTTP_URL_LOCAL";
		public static final String REST_NO_AUTH_URL = "REST_NO_AUTH_URL";
		public static final String REST_NO_AUTH_HTTPS_URL = "REST_NO_AUTH_HTTPS_URL";

		public static final String REST_SUCCESS_CDES = "REST_SUCCESS_CDES";
		public static final String REST_PENDING_CDES = "REST_PENDING_CDES";
		public static final String REST_FAILURE_CDES = "REST_FAILURE_CDES";
		public static final String MQ_ENABLE_CORRELATION_ID = "MQ_ENABLE_CORRELATION_ID";

		public static final String REST_CONN_TIMEOUT = "REST_CONN_TIMEOUT";
		public static final String REST_CONN_READ_TIMEOUT = "REST_CONN_READ_TIMEOUT";
		public static final String REST_SOAP_HEADER = "REST_SOAP_HEADER";
		public static final String REST_SMS_ORIGIN_ADDRSS = "REST_SMS_ORIGIN_ADDRSS";
		public static final String REST_AUTH_TOKEN = "REST_AUTH_TOKEN";

		public static final String REST_TLS_VERSION = "REST_TLS_VERSION";
		public static final String TRUST_STORE_PATH = "TRUST_STORE_PATH";
		public static final String TRUST_STORE_PSWD = "TRUST_STORE_PWD";

		public static final String PROXY_IP = "PROXY_IP";
		public static final String PROXY_PORT = "PROXY_PORT";
		public static final String PROXY_USR_NME = "PROXY_USR_NME";
		public static final String PROXY_PSWD = "PROXY_PSWD";

		public static final String CALL_REST_WS_API = "CALL_REST_WS_API";
		public static final String CRTD_BY = "SWIFT";
		public static final String UPDTD_BY = "SWIFT";

		public static final String REST_SUCCESS_CDE = "100";
		public static final String REST_AUTH_FAILURE_CDE = "101";
		public static final String REST_FAILURE_CDE = "106";
		public static final String REST_INVALID_PARAM_CDE = "103";
		public static final String REST_INVALID_USR_CDE = "104";
		public static final String REST_MANDATORY_PARAM_CDE = "105";
		public static final String REST_SR_ERROR_CDE = "1";
		public static final String REST_SR_SCSS_CDE = "0";

		public static final String REST_INVALID_PARAM_MSG = "Invalid mandatory parameters passed";
		public static final String REST_MANDATORY_PARAM_MSG = "All Mandatory parameters not passed";
		public static final String REST_INVALID_USR_MSG = "Invalid Hierarchy User Details Passed";
		public static final String REST_NO_SECRET_QSTN_SET = "No Secret Questions set for input User";
		public static final String REST_SRVC_NOT_ALLOWED_MSG = "Service is not allowed for Input Channel";
		public static final String REST_NO_HRRCHY_MSG = "No hierrachy Records found for input";
		public static final String REST_RQST_SUBMIT_SCSS_MSG = "Request Submitted Successfully";
		public static final String REST_RQST_EXCEPTION_MSG = "Technical error occured. Please try again";

		public static final String BEARER_HEADER = "Bearer";
		public static final String SOAP_ACTION_HEADER = "SOAPAction";
		public static final String REST_AUTH_HEADER = "Authorization";

		public static final String REST_APP_ID = "REST_APP_ID";
		public static final String REST_AUTH_KEY = "REST_AUTH_KEY";
		public static final String REST_SOAP_ACTION = "REST_SOAP_ACTION";
		public static final String REST_OUTWARD_REQ = "OW";
		public static final String REST_INWARD_REQ = "IW";
		public static final String JMS_INWARD_REQ = "JMS";

		public static final String REST_CLIENT_ID = "CLIENT_ID";
		public static final String REST_CLIENT_SECRET = "CLIENT_SECRET";
		public static final String REST_OAUTH_GRANT_TYPE_PSWD = "password";
		public static final String REST_OAUTH_REFRESH_GRANT_TYPE = "refresh_token";
		public static final String REFRESH_TOKEN_HEADER = "refresh_token";
		public static final String REST_GRANT_TYPE = "grant_type";
		public static final String REST_USERNAME = "username";

		public static final String REST_DEFAULT_MODIFY_SERVICES_SERVICE_NAME = "MODIFYSERVICES";
		public static final String REST_MODIFY_SERVICES_SERVICE_NAME = "REST_MODIFY_SERVICES_SERVICE_NAME";

	}

	/** Added Inner class for DB Constants */
	public static final class DB {

		public static final String DB_PROFILE ="db.profileNme";
		public static final String DB_URL ="db.url";
		public static final String DB_DRIVER ="db.driver";
		public static final String DB_USR_NME ="db.username";
		public static final String DB_PSWD ="db.password";
		
		public static final String DB_JNDI ="db.jndi-name";
		public static final String DB_USE_DS ="db.useDataSource";
		public static final String APP_DS_ENABLED ="app.ds.enabled";
		
	}
	

}
