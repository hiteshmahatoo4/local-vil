/**
 * 
 */
package com.vil.ecom.integration.creditInsightLogin.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

/**
 * @author 1993872
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "user_name", "password" })

public class CreditInsightsLoginRequest implements Serializable {
	@JsonProperty("user_name")
	private String userName;
	@JsonProperty("password")
	private String password;
	private final static long serialVersionUID = 8572654725222373570L;

	@JsonProperty("user_name")
	public String getUserName() {
		return userName;
	}

	@JsonProperty("user_name")
	public void setUserName(String userName) {
		this.userName = userName;
	}

	@JsonProperty("password")
	public String getPassword() {
		return password;
	}

	@JsonProperty("password")
	public void setPassword(String password) {
		this.password = password;
	}

}
