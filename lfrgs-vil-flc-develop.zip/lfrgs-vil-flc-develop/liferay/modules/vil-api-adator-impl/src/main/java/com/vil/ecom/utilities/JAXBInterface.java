package com.vil.ecom.utilities;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.integration.helper.FLogger;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

public class JAXBInterface {

	private static final Log logger = LogFactoryUtil.getLog(JAXBInterface.class);

	protected static final Map<String, JAXBContext> cache = new ConcurrentHashMap<>();

	protected static final JAXBContext getJaxBInstance(Class<?> objClass) throws JAXBException {

		if (cache.containsKey(objClass.getName())) {
			return cache.get(objClass.getName());
		} else {
			synchronized (JAXBInterface.class) {
				if (!cache.containsKey(objClass.getName())) {
					JAXBContext context = JAXBContext.newInstance(objClass);
					cache.put(objClass.getName(), context);

					FLogger.debug(logger, "Added now as " + "NOT found JAXBContext in cache for " + objClass.getName());
					return context;
				} else {
					return cache.get(objClass.getName());
				}
			}

		}
	}
}
