package com.vil.ecom.integration.pojo;

/**
 * 
 */

import java.io.Serializable;

import com.vil.ecom.integration.creditInsightsInternalConsent.CreditInsightsInternalConsentRespDtls;

/**
 * @author 1856895
 *
 */
public class EcomCreditInsightsInternalConsentResp implements Serializable {
	private static final long serialVersionUID = 1L; 
	private MrchntRespStts responseStatus;
	private CreditInsightsInternalConsentRespDtls internalConsentDetails;

	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	public CreditInsightsInternalConsentRespDtls getInternalConsentDetails() {
		return internalConsentDetails;
	}

	public void setInternalConsentDetails(CreditInsightsInternalConsentRespDtls internalConsentDetails) {
		this.internalConsentDetails = internalConsentDetails;
	}
}
