package com.vil.ecom.eai.UploadEvents.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "identity",
    "ts",
    "type",
    "evtName",
    "evtData"
})

public class D implements Serializable
{

    @JsonProperty("identity")
    private String identity;
    @JsonProperty("ts")
    private Long ts;
    @JsonProperty("type")
    private String type;
    @JsonProperty("evtName")
    private String evtName;
    @JsonProperty("evtData")
    private EvtData evtData;
    private final static long serialVersionUID = -9180640016511355895L;

    @JsonProperty("identity")
    public String getIdentity() {
        return identity;
    }

    @JsonProperty("identity")
    public void setIdentity(String identity) {
        this.identity = identity;
    }

    @JsonProperty("ts")
    public Long getTs() {
        return ts;
    }

    @JsonProperty("ts")
    public void setTs(Long ts) {
        this.ts = ts;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("evtName")
    public String getEvtName() {
        return evtName;
    }

    @JsonProperty("evtName")
    public void setEvtName(String evtName) {
        this.evtName = evtName;
    }

    @JsonProperty("evtData")
    public EvtData getEvtData() {
        return evtData;
    }

    @JsonProperty("evtData")
    public void setEvtData(EvtData evtData) {
        this.evtData = evtData;
    }

}
