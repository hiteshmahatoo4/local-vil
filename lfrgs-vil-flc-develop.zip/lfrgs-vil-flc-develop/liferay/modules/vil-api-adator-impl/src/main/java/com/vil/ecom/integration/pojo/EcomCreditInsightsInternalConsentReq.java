/**
 * 
 */
package com.vil.ecom.integration.pojo;

import java.io.Serializable;

/**
 * @author 1856895 
 *
 */
public class EcomCreditInsightsInternalConsentReq implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String vilMsisdn;

	private String airtelMsisdn;

	/**
	 * @return the vilMsisdn
	 */
	public String getVilMsisdn() {
		return vilMsisdn;
	}

	/**
	 * @param vilMsisdn the vilMsisdn to set
	 */
	public void setVilMsisdn(String vilMsisdn) {
		this.vilMsisdn = vilMsisdn;
	}

	/**
	 * @return the airtelMsisdn
	 */
	public String getAirtelMsisdn() {
		return airtelMsisdn;
	}

	/**
	 * @param airtelMsisdn the airtelMsisdn to set
	 */
	public void setAirtelMsisdn(String airtelMsisdn) {
		this.airtelMsisdn = airtelMsisdn;
	}
}
