package com.vil.ecom.integration.config;

import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;

public interface AppServiceProcessor {

	/** Process Input received and convert it to required input for calling API */
	void preSrvcInputProcessor();
	
	/** Call respective external API and get response*/
	EcomMrchntServiceResponse execute();

	/** parse response received from execute and convert it to required response object*/
	void parseResponse();
	
	/** return final response object*/
	EcomMrchntServiceResponse postSrvcOutputProcessor();
	
}

