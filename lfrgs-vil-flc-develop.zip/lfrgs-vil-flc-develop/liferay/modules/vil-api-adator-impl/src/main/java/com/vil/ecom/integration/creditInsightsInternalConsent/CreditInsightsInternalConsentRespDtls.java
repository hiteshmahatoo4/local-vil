package com.vil.ecom.integration.creditInsightsInternalConsent;

import java.io.Serializable;

public class CreditInsightsInternalConsentRespDtls implements Serializable {

	private final static long serialVersionUID = 1494376529680245813L; 

	private String verdict;
	private String message;
	private String time;
	private String requestId;
	private String creditScore;
	private String telcoCode;
	
	/**
	 * @return the verdict
	 */
	public String getVerdict() {
		return verdict;
	}

	/**
	 * @param verdict the verdict to set
	 */
	public void setVerdict(String verdict) {
		this.verdict = verdict;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the creditScore
	 */
	public String getCreditScore() {
		return creditScore;
	}

	/**
	 * @param creditScore the creditScore to set
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}

	/**
	 * @return the telcoCode
	 */
	public String getTelcoCode() {
		return telcoCode;
	}

	/**
	 * @param telcoCode the telcoCode to set
	 */
	public void setTelcoCode(String telcoCode) {
		this.telcoCode = telcoCode;
	}

	
}
