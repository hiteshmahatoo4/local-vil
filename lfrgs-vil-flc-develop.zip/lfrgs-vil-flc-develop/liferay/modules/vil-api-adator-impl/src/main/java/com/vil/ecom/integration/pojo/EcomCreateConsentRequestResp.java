package com.vil.ecom.integration.pojo;

import com.vil.ecom.eai.CreateConsentRequest.pojo.CreateConsentRequestRespDtls;

import java.io.Serializable;

public class EcomCreateConsentRequestResp implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private MrchntRespStts responseStatus;
	
	private CreateConsentRequestRespDtls createConsentRequestResponse;
	

	/**
	 * @return the responseStatus
	 */
	public MrchntRespStts getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(MrchntRespStts responseStatus) {
		this.responseStatus = responseStatus;
	}

	/**
	 * @return the createConsentRequestResponse
	 */
	public CreateConsentRequestRespDtls getCreateConsentRequestResponse() {
		return createConsentRequestResponse;
	}

	/**
	 * @param createConsentRequestResponse the createConsentRequestResponse to set
	 */
	public void setCreateConsentRequestResponse(CreateConsentRequestRespDtls createConsentRequestResponse) {
		this.createConsentRequestResponse = createConsentRequestResponse;
	}



	
	
}
