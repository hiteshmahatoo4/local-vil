package com.vil.ecom.integration.creditInsightsInternalConsent;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * 
 */
import java.io.Serializable;

/**
 * @author 1856895 
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ 
	"client_code",
	"requested_msisdns" 
})
public class CreditInsightsInternalConsentRequest implements Serializable {

	private final static long serialVersionUID = -7514931367746482281L;
	
	@JsonProperty("client_code")
	private String clientCode;
	@JsonProperty("requested_msisdns")
	private RequestedMsisdns requestedMsisdns;

	@JsonProperty("client_code")
	public String getClientCode() {
		return clientCode;
	}

	@JsonProperty("client_code")
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	@JsonProperty("requested_msisdns")
	public RequestedMsisdns getRequestedMsisdns() {
		return requestedMsisdns;
	}

	@JsonProperty("requested_msisdns")
	public void setRequestedMsisdns(RequestedMsisdns requestedMsisdns) {
		this.requestedMsisdns = requestedMsisdns;
	}
}
