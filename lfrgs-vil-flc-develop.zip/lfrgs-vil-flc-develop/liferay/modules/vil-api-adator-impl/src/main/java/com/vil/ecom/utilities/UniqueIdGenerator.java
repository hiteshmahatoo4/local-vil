package com.vil.ecom.utilities;

import java.util.concurrent.atomic.AtomicLong;

public enum UniqueIdGenerator {
	 INSTANCE;

    private AtomicLong instance = new AtomicLong(System.currentTimeMillis());

    public long incrementAndGet() {
        return instance.incrementAndGet();
    }
}
