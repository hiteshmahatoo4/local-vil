
package com.vil.ecom.createFulfillmentOrder.response.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "message",
    "response_status"
})
public class EcomCreateFulfillmentOrderResponse implements Serializable
{

    @JsonProperty("message")
    private Message message;
    @JsonProperty("response_status")
    private ResponseStatus responseStatus;
    private final static long serialVersionUID = -7882516096289546349L;

    @JsonProperty("message")
    public Message getMessage() {
        return message;
    }

    @JsonProperty("message")
    public void setMessage(Message message) {
        this.message = message;
    }

    @JsonProperty("response_status")
    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    @JsonProperty("response_status")
    public void setResponseStatus(ResponseStatus responseStatus) {
        this.responseStatus = responseStatus;
    }

}
