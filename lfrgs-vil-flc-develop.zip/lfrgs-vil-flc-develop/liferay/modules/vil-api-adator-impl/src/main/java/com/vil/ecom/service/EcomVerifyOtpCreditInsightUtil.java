package com.vil.ecom.service;


import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.constants.BaseConstants;
import com.vil.ecom.constants.LoggerConstants;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.RsValiatorResponse;
import com.vil.ecom.integration.helper.StringChecks;
import com.vil.ecom.integration.pojo.EcomMrchntServiceRequest;
import com.vil.ecom.integration.pojo.EcomMrchntServiceResponse;
import com.vil.ecom.integration.pojo.EcomVerifyOtpCreditInsightReq;
import com.vil.ecom.integration.pojo.EcomVerifyOtpCreditInsightResp;
import com.vil.ecom.integration.pojo.MrchntRespStts;
import com.vil.ecom.integration.processor.EcomVerifyOtpCreditInsightProcessor;
import com.vil.ecom.utilities.RequestResourceThreadLocal;

import org.apache.commons.lang.time.StopWatch;

public class  EcomVerifyOtpCreditInsightUtil {
	
	private static final Log logger = LogFactoryUtil.getLog(EcomVerifyOtpCreditInsightUtil.class);
	private static final String THIS_CLASS = "EcomVerifyOtpCreditInsightUtil";
		
	/**
	 * @author TCS
	 * <p>Verify OTP and get Credit Insight API : fetchCreditInsight</p>
	 * @param processorInput : EcomVerifyOtpCreditInsightReq pojo to be set for input parameter . Mandatory
	 * <p>
	 * <h2>EcomVerifyOtpCreditInsightReq pojo details:</h2>
	 * @param vilMsisdn : vil msisdn to be passed. Mandatory
	 * @param airtelMsisdn : airtel msisdn to be passed, Optional
	 * @param otp : otp  which is sent to Customer for getting Consent, Mandatory
	 * @param requestId: requestId received in response of EcomCreateConsentRequestUtil-->createConsentRequest() to be passed ; Mandatory
	 * </p>
	 * @return EcomVerifyOtpCreditInsightResp : EcomVerifyOtpCreditInsightResp API response
	 *  <ul>
	 *  	<li>creditInsightsScore - Credit insights score value for given vil number</li>
	 *  </ul>
	 */
	public static EcomVerifyOtpCreditInsightResp fetchCreditInsight(EcomVerifyOtpCreditInsightReq processorInput) {

		String methodName = "fetchCreditInsight";
		StopWatch stopwatch = null;
		EcomVerifyOtpCreditInsightResp response = null;
		MrchntRespStts respStts = null;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			if (RequestResourceThreadLocal.getRequestIdForCurrentThread() == null) {
				RequestResourceThreadLocal.addRequestIdForCurrentThread(EcomIntegrationUtils.generateLoggerId());
			}

			if (RequestResourceThreadLocal.getServiceForCurrentThread() == null) {
				RequestResourceThreadLocal.addServiceForCurrentThread(BaseConstants.API_SERVICES.EAI_VERIFY_OTP_CREDIT_INSIGHTS);
			}

			FLogger.info(logger, THIS_CLASS, methodName, "Entered Method " + methodName
						+"With processorInput " + StringChecks.convertObjectToJson(processorInput));

			if (processorInput != null) {

				respStts = validateInputs(processorInput);

				if (respStts == null) {

					EcomMrchntServiceRequest srvcRequest = new EcomMrchntServiceRequest();
					srvcRequest.setServiceNme(BaseConstants.API_SERVICES.EAI_VERIFY_OTP_CREDIT_INSIGHTS);

					FLogger.debug(logger, THIS_CLASS, methodName, "given Service to srvcRequest ");

					srvcRequest.setVerifyOtpCreditInsightReq(processorInput);
					
					FLogger.debug(logger, THIS_CLASS, methodName, "given processorInput to SrvcRequest");

					EcomVerifyOtpCreditInsightProcessor processor = new EcomVerifyOtpCreditInsightProcessor(srvcRequest);
					EcomMrchntServiceResponse srvcResp = processor.execute();

					if (srvcResp != null) {
						
						if (srvcResp.getVerifyOtpCreditInsightResp() != null) {
							
							FLogger.debug(logger, THIS_CLASS, methodName, "Got Response from the API"
									+ StringChecks.convertObjectToJson(srvcResp.getVerifyOtpCreditInsightResp()));

							response = srvcResp.getVerifyOtpCreditInsightResp();
						
						} else {
							
							FLogger.error(logger, THIS_CLASS, methodName,
									"Got Reply from Processor but no API reply received,setting TIMEOUT Scenario");

							respStts = RsValiatorResponse.timeoutResponse(null, BaseConstants.errorInProcessingReq);

							response = new EcomVerifyOtpCreditInsightResp();
							response.setResponseStatus(respStts);
						}
					
					} else {
						
						FLogger.error(logger, THIS_CLASS, methodName, "Processor response is null");

						respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

						response = new EcomVerifyOtpCreditInsightResp();
						response.setResponseStatus(respStts);
					}
				} else {
					
					FLogger.error(logger, THIS_CLASS, methodName, "Request object is null");

					respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

					response = new EcomVerifyOtpCreditInsightResp();
					response.setResponseStatus(respStts);
				}
			}
			
		} catch (Exception e) {
			
			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);

			response = new EcomVerifyOtpCreditInsightResp();
			response.setResponseStatus(respStts);

		} finally {

			if (stopwatch != null) {
				
				stopwatch.stop();
				FLogger.info(logger, THIS_CLASS, methodName,
						"Exiting Method with " + " in " + (stopwatch != null ? stopwatch.getTime() : 0));
			}

			RequestResourceThreadLocal.unsetRequestIdForCurrentThread();
			RequestResourceThreadLocal.unsetServiceForCurrentThread();

		}

		return response;
	}
			
	/**
	 * 
	 * @param processorInput
	 * @return  MrchntRespStts
	 */		
	private static MrchntRespStts validateInputs(EcomVerifyOtpCreditInsightReq processorInput) {
		
		String methodName = "validateInputs";
		MrchntRespStts respStts = null;
		FLogger.info(logger, THIS_CLASS, methodName, "Enter method: " + methodName);

		try {

			if (processorInput == null) {
				respStts = RsValiatorResponse.errorResponse(null, LoggerConstants.REST_WS.REST_INVALID_PAYLOAD_ERR_MSG);
				FLogger.info(logger, THIS_CLASS, methodName, "processorInput is NULL");
				return respStts;
			}

			if(!StringChecks.isAnyFieldEmpty(processorInput.getVilMsisdn())) {
				
				if(!StringChecks.checkMsisdn(processorInput.getVilMsisdn())) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Vil msisdn");
					return respStts;
				}
			
			}
			
			if(!StringChecks.isAnyFieldEmpty(processorInput.getAirtelMsisdn())) {
				
				if(!StringChecks.checkMsisdn(processorInput.getAirtelMsisdn())) {
					respStts = RsValiatorResponse.invalidParamsResponse(null, "Airtel msisdn");
					return respStts;
				}
			}
			
			respStts = RsValiatorResponse.validateNumericInput(processorInput.getOtp(), null, null);

			if (respStts != null) {
				FLogger.info(logger, THIS_CLASS, methodName, "Otp is not valid");
				return respStts;
			}

			respStts = RsValiatorResponse.validateStrInput(processorInput.getRequestId(), null, null);

			if (respStts != null) {
				FLogger.info(logger, THIS_CLASS, methodName, "requested Id is not valid");
				return respStts;
			}

		} catch (Exception e) {

			StringChecks.printExceptionErrors(e, logger, THIS_CLASS, methodName);
			respStts = RsValiatorResponse.errorResponse(null, BaseConstants.errorInProcessingReq);
		}

		return respStts;
	}
	
}
