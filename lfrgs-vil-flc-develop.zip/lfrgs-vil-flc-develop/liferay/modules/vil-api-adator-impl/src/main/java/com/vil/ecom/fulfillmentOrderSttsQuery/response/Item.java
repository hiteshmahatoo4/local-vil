
package com.vil.ecom.fulfillmentOrderSttsQuery.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "quantity",
    "unit_price",
    "total_price",
    "sku_id",
    "description",
    "product_category",
    "fulfilment_reference_id",
    "state",
    "product_start_date",
    "product_end_date"
})
public class Item implements Serializable {

	@JsonProperty("id")
	private String id;
	@JsonProperty("quantity")
	private String quantity;
	@JsonProperty("unit_price")
	private String unitPrice;
	@JsonProperty("total_price")
	private String totalPrice;
	@JsonProperty("sku_id")
	private String skuId;
	@JsonProperty("description")
	private String description;
	@JsonProperty("product_category")
	private String productCategory;
	@JsonProperty("fulfilment_reference_id")
	private String fulfilmentReferenceId;
	@JsonProperty("state")
	private String state;
	@JsonProperty("product_start_date")
	private String productStartDate;
	@JsonProperty("product_end_date")
	private String productEndDate;
	private final static long serialVersionUID = -4530867600655684434L;

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	public Item withId(String id) {
		this.id = id;
		return this;
	}

	@JsonProperty("quantity")
	public String getQuantity() {
		return quantity;
	}

	@JsonProperty("quantity")
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public Item withQuantity(String quantity) {
		this.quantity = quantity;
		return this;
	}

	@JsonProperty("unit_price")
	public String getUnitPrice() {
		return unitPrice;
	}

	@JsonProperty("unit_price")
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public Item withUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
		return this;
	}

	@JsonProperty("total_price")
	public String getTotalPrice() {
		return totalPrice;
	}

	@JsonProperty("total_price")
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Item withTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
		return this;
	}

	@JsonProperty("sku_id")
	public String getSkuId() {
		return skuId;
	}

	@JsonProperty("sku_id")
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public Item withSkuId(String skuId) {
		this.skuId = skuId;
		return this;
	}

	@JsonProperty("description")
	public String getDescription() {
		return description;
	}

	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}

	public Item withDescription(String description) {
		this.description = description;
		return this;
	}

	@JsonProperty("product_category")
	public String getProductCategory() {
		return productCategory;
	}

	@JsonProperty("product_category")
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public Item withProductCategory(String productCategory) {
		this.productCategory = productCategory;
		return this;
	}

	@JsonProperty("fulfilment_reference_id")
	public String getFulfilmentReferenceId() {
		return fulfilmentReferenceId;
	}

	@JsonProperty("fulfilment_reference_id")
	public void setFulfilmentReferenceId(String fulfilmentReferenceId) {
		this.fulfilmentReferenceId = fulfilmentReferenceId;
	}

	public Item withFulfilmentReferenceId(String fulfilmentReferenceId) {
		this.fulfilmentReferenceId = fulfilmentReferenceId;
		return this;
	}

	@JsonProperty("state")
	public String getState() {
		return state;
	}

	@JsonProperty("state")
	public void setState(String state) {
		this.state = state;
	}

	public Item withState(String state) {
		this.state = state;
		return this;
	}

	@JsonProperty("product_start_date")
	public String getProductStartDate() {
		return productStartDate;
	}

	@JsonProperty("product_start_date")
	public void setProductStartDate(String productStartDate) {
		this.productStartDate = productStartDate;
	}

	public Item withProductStartDate(String productStartDate) {
		this.productStartDate = productStartDate;
		return this;
	}

	@JsonProperty("product_end_date")
	public String getProductEndDate() {
		return productEndDate;
	}

	@JsonProperty("product_end_date")
	public void setProductEndDate(String productEndDate) {
		this.productEndDate = productEndDate;
	}

	public Item withProductEndDate(String productEndDate) {
		this.productEndDate = productEndDate;
		return this;
	}

}
