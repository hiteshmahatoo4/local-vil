package com.vil.ecom.integration.dxl.customerLookup.pojo;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "msisdn",
    "circleId",
    "segment",
    "brandIdentifier",
    "status",
    "isMigrated",
    "subscriptionType",
    "provider",
    "statusCode"
})

public class CustomerLookupSuccessResp {

    @JsonProperty("msisdn")
    private String msisdn;
    @JsonProperty("circleId")
    private String circleId;
    @JsonProperty("segment")
    private String segment;
    @JsonProperty("brandIdentifier")
    private String brandIdentifier;
    @JsonProperty("status")
    private String status;
    @JsonProperty("isMigrated")
    private String isMigrated;
    @JsonProperty("subscriptionType")
    private String subscriptionType;
    @JsonProperty("provider")
    private String provider;
    @JsonProperty("statusCode")
    private String statusCode;

    @JsonProperty("msisdn")
    public String getMsisdn() {
        return msisdn;
    }

    @JsonProperty("msisdn")
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    @JsonProperty("circleId")
    public String getCircleId() {
        return circleId;
    }

    @JsonProperty("circleId")
    public void setCircleId(String circleId) {
        this.circleId = circleId;
    }

    @JsonProperty("segment")
    public String getSegment() {
        return segment;
    }

    @JsonProperty("segment")
    public void setSegment(String segment) {
        this.segment = segment;
    }

    @JsonProperty("brandIdentifier")
    public String getBrandIdentifier() {
        return brandIdentifier;
    }

    @JsonProperty("brandIdentifier")
    public void setBrandIdentifier(String brandIdentifier) {
        this.brandIdentifier = brandIdentifier;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("isMigrated")
    public String getIsMigrated() {
        return isMigrated;
    }

    @JsonProperty("isMigrated")
    public void setIsMigrated(String isMigrated) {
        this.isMigrated = isMigrated;
    }

    @JsonProperty("subscriptionType")
    public String getSubscriptionType() {
        return subscriptionType;
    }

    @JsonProperty("subscriptionType")
    public void setSubscriptionType(String subscriptionType) {
        this.subscriptionType = subscriptionType;
    }

    @JsonProperty("provider")
    public String getProvider() {
        return provider;
    }

    @JsonProperty("provider")
    public void setProvider(String provider) {
        this.provider = provider;
    }

    @JsonProperty("statusCode")
    public String getStatusCode() {
        return statusCode;
    }

    @JsonProperty("statusCode")
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }


}
