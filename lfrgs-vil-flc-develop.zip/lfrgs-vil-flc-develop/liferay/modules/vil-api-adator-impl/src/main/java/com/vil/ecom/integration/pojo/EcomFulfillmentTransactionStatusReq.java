package com.vil.ecom.integration.pojo;

import java.io.Serializable;

public class EcomFulfillmentTransactionStatusReq implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String pgOrderID;
	
	private String circleId;
	
	private String provider;
	
	private String subscriberType;

	/**
	 * @return the pgOrderID
	 */
	public String getPgOrderID() {
		return pgOrderID;
	}

	/**
	 * @param pgOrderID the pgOrderID to set
	 */
	public void setPgOrderID(String pgOrderID) {
		this.pgOrderID = pgOrderID;
	}

	/**
	 * @return the circleId
	 */
	public String getCircleId() {
		return circleId;
	}

	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	/**
	 * @return the provider
	 */
	public String getProvider() {
		return provider;
	}

	/**
	 * @param provider the provider to set
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}

	/**
	 * @return the subscriberType
	 */
	public String getSubscriberType() {
		return subscriberType;
	}

	/**
	 * @param subscriberType the subscriberType to set
	 */
	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}
	
}
