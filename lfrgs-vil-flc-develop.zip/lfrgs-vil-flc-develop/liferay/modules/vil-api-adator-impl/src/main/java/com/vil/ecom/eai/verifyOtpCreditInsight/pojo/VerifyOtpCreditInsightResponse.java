package com.vil.ecom.eai.verifyOtpCreditInsight.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ 
	"data",
	"message",
	"time",
	"verdict" 
})
public class VerifyOtpCreditInsightResponse implements Serializable{

	private final static long serialVersionUID = 1494376529680245813L;
	
	@JsonProperty("data")
	private Data data;
	@JsonProperty("message")
	private String message;
	@JsonProperty("time")
	private String time;
	@JsonProperty("verdict")
	private String verdict;

	@JsonProperty("data")
	public Data getData() {
		return data;
	}

	@JsonProperty("data")
	public void setData(Data data) {
		this.data = data;
	}

	@JsonProperty("message")
	public String getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(String message) {
		this.message = message;
	}

	@JsonProperty("time")
	public String getTime() {
		return time;
	}

	@JsonProperty("time")
	public void setTime(String time) {
		this.time = time;
	}

	@JsonProperty("verdict")
	public String getVerdict() {
		return verdict;
	}

	@JsonProperty("verdict")
	public void setVerdict(String verdict) {
		this.verdict = verdict;
	}

}

