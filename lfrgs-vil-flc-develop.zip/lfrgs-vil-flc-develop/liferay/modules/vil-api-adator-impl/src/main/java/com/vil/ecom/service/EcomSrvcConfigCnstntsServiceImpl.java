package com.vil.ecom.service;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.vil.ecom.db.model.EcomSrvcConfigCnstnts;
import com.vil.ecom.db.service.EcomSrvcConfigCnstntsLocalServiceUtil;
import com.vil.ecom.integration.helper.FLogger;
import com.vil.ecom.integration.helper.StringChecks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.StopWatch;

public class EcomSrvcConfigCnstntsServiceImpl {

	private static final Log logger = LogFactoryUtil.getLog(EcomSrvcConfigCnstntsServiceImpl.class);
	private static final String THIS_CLASS = EcomSrvcConfigCnstntsServiceImpl.class.toString();
	private static final String CONFIGURATIONS_FETCHED = "Configurations Fetched : ";

	public static Map<String, Object> fetchConfMap(String serviceNme) {

		String methodName = "fetchConfMap";
		HashMap<String, Object> confMap = new HashMap<>();
		List<EcomSrvcConfigCnstnts> records = new ArrayList<>();

		StopWatch stopwatch = null;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			records=EcomSrvcConfigCnstntsLocalServiceUtil.findBySrvcType(serviceNme);

			if (records != null && !StringChecks.isCollectionEmpty(records)) {

				FLogger.debug(logger, THIS_CLASS, methodName, CONFIGURATIONS_FETCHED + (records.size()));

				for (EcomSrvcConfigCnstnts record : records) {
					confMap.put(record.getSrvc_key(), record.getValue());
				}
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		}finally {
			if(stopwatch!=null) {
				stopwatch.stop();
				FLogger.debug(logger, THIS_CLASS, methodName, "time taken : "+stopwatch.getTime());
			}
		}

		return confMap;

	}

	public static List<EcomSrvcConfigCnstnts> fetchConfRecords(String serviceNme) {

		String methodName = "fetchConfRecords";
		List<EcomSrvcConfigCnstnts> records = new ArrayList<>();

		StopWatch stopwatch = null;

		try {

			stopwatch = new StopWatch();
			stopwatch.start();

			records = EcomSrvcConfigCnstntsLocalServiceUtil.findBySrvcType(serviceNme);

			if (records != null && !StringChecks.isCollectionEmpty(records)) {
				FLogger.debug(logger, THIS_CLASS, methodName, CONFIGURATIONS_FETCHED + (records.size()));
			}

		} catch (Exception e) {
			StringChecks.printExceptionErrors(e,logger, THIS_CLASS, methodName);
		}finally {
			if(stopwatch!=null) {
				stopwatch.stop();
				FLogger.debug(logger, THIS_CLASS, methodName, "time taken : "+stopwatch.getTime());
			}
		}

		return records;

	}
	
}
