
package com.vil.ecom.createFulfillmentOrder.request.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "transaction_id",
    "transaction_status",
    "amount",
    "currency",
    "property1",
    "property2",
    "payment_mode",
    "status",
    "timestamp",
    "collected_by"
})
public class Payment implements Serializable
{

    @JsonProperty("transaction_id")
    private String transactionId;
    @JsonProperty("transaction_status")
    private String transactionStatus;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("property1")
    private String property1;
    @JsonProperty("property2")
    private String property2;
    @JsonProperty("payment_mode")
    private String paymentMode;
    @JsonProperty("status")
    private String status;
    @JsonProperty("timestamp")
    private String timestamp;
    @JsonProperty("collected_by")
    private String collectedBy;
    private final static long serialVersionUID = 4862061486917360403L;

    @JsonProperty("transaction_id")
    public String getTransactionId() {
        return transactionId;
    }

    @JsonProperty("transaction_id")
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    @JsonProperty("transaction_status")
    public String getTransactionStatus() {
        return transactionStatus;
    }

    @JsonProperty("transaction_status")
    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    @JsonProperty("amount")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("property1")
    public String getProperty1() {
        return property1;
    }

    @JsonProperty("property1")
    public void setProperty1(String property1) {
        this.property1 = property1;
    }

    @JsonProperty("property2")
    public String getProperty2() {
        return property2;
    }

    @JsonProperty("property2")
    public void setProperty2(String property2) {
        this.property2 = property2;
    }

    @JsonProperty("payment_mode")
    public String getPaymentMode() {
        return paymentMode;
    }

    @JsonProperty("payment_mode")
    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("timestamp")
    public String getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @JsonProperty("collected_by")
    public String getCollectedBy() {
        return collectedBy;
    }

    @JsonProperty("collected_by")
    public void setCollectedBy(String collectedBy) {
        this.collectedBy = collectedBy;
    }

}
