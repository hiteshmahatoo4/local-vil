package com.vil.ecom.dxl.additionalBenefits.pojo;

public class AdditionalBenefitsRespDtls {
	
	private String statusMessage;
	
	private String description;
	
	private String lastUpdate;

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	

}
