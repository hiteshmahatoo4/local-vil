package com.vil.asset.categories.portlet;

import com.liferay.asset.kernel.model.AssetCategory;
import com.liferay.asset.kernel.service.AssetCategoryLocalService;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.Portal;
import com.vil.asset.categories.constants.VilAssetCategoriesPortletKeys;
import com.vil.asset.categories.displaycontext.UsersManagementToolbarDisplayContext;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Chinmay Abhyankar
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.hidden",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=false",
		"javax.portlet.display-name=Categories DeActivated",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + VilAssetCategoriesPortletKeys.VILASSETCATEGORIES,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user",
		"javax.portlet.version=3.0"
	},
	service = Portlet.class
)
public class VilAssetCategoriesPortlet extends MVCPortlet {
	
	/**
	 * This method is used to display deleted categories list.
	 *
	 * @param renderRequest  : holds and sets the attributes and renders when page
	 *                       is loading
	 * 
	 * @param renderResponse : holds the html and displays it to the end users
	 * 
	 * @throws IOException
	 * @throws PortletException : Hold detail of exception if there is problem while
	 *                          fetching the logs
	 */
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		
		try {
			categoryListAttributes(renderRequest);
			
			addtToolbarAttributes(renderRequest, renderResponse);
			
		}catch (Exception e) {
			_log.error("Error in getting category list:" + e);
		}
		super.render(renderRequest, renderResponse);
	}
	
	/**
	 * 
	 * This method is used to get deleted categories list
	 *
	 * @param renderRequest : request param
	 */
	private void categoryListAttributes(RenderRequest renderRequest) {
		List<AssetCategory> deletedEntries = new ArrayList<AssetCategory>();
		try {
			DynamicQuery dynamicQuery = assetCategoryLocalService.dynamicQuery();
			Criterion criterion = RestrictionsFactoryUtil.eq("groupId",-1L);
			dynamicQuery.add(criterion);
			deletedEntries = assetCategoryLocalService.dynamicQuery(dynamicQuery);
		}catch (Exception e) {
			_log.error(e);
		}
		renderRequest.setAttribute("deletedEntries", deletedEntries);
		renderRequest.setAttribute("totalUsers", deletedEntries.size());
	
	}
	
	/**
	 * This method is used to add the liferay toolbar
	 * 
	 */
	private void addtToolbarAttributes(RenderRequest renderRequest, RenderResponse renderResponse) {
		try {
			LiferayPortletRequest liferayPortletRequest = portal.getLiferayPortletRequest(renderRequest);
			LiferayPortletResponse liferayPortletResponse = portal.getLiferayPortletResponse(renderResponse);
			HttpServletRequest httpServletRequest = portal.getHttpServletRequest(renderRequest);

			UsersManagementToolbarDisplayContext memberRegManagementToolbarDisplayContext = new UsersManagementToolbarDisplayContext(
					liferayPortletRequest, liferayPortletResponse, httpServletRequest);

			renderRequest.setAttribute("usersManagementToolbarDisplayContext",
					memberRegManagementToolbarDisplayContext);
		} catch (Exception e) {
			_log.error(e);
		}
	}
	
	@Reference
	private Portal portal;
	@Reference
	private AssetCategoryLocalService assetCategoryLocalService;
	
	private static final Log _log = LogFactoryUtil.getLog(VilAssetCategoriesPortlet.class.getName());
}