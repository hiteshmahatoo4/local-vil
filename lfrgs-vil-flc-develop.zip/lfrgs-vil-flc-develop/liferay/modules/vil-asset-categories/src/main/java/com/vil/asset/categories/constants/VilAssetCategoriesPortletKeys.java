package com.vil.asset.categories.constants;

/**
 * @author Chinmay Abhyankar
 */
public class VilAssetCategoriesPortletKeys {

	public static final String VILASSETCATEGORIES =
		"com_vil_asset_categories_VilAssetCategoriesPortlet";

	public static final String CONTROL_PANEL_CATEGORY = "VilAssetCategoryConfiguratorControlPanel";
	
}