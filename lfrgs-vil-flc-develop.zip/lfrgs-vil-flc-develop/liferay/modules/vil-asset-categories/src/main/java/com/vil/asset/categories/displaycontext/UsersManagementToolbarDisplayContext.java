package com.vil.asset.categories.displaycontext;

import com.liferay.frontend.taglib.clay.servlet.taglib.display.context.BaseManagementToolbarDisplayContext;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.LiferayPortletRequest;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.portlet.PortalPreferences;
import com.liferay.portal.kernel.portlet.PortletPreferencesFactoryUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;

import javax.portlet.PortletURL;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Reference;

/**
 * The purpose of this class is to extend BaseManagementToolbarDisplayContext
 * and create our own Management Toolbar Display Context
 *
 * @author Chinmay Abhyankar 
 */

public class UsersManagementToolbarDisplayContext extends BaseManagementToolbarDisplayContext {

	Log log = LogFactoryUtil.getLog(UsersManagementToolbarDisplayContext.class.getName());

	public UsersManagementToolbarDisplayContext(LiferayPortletRequest liferayPortletRequest,
			LiferayPortletResponse liferayPortletResponse, HttpServletRequest httpServletRequest) {
		super(httpServletRequest, liferayPortletRequest, liferayPortletResponse);
		portalPreferences = PortletPreferencesFactoryUtil.getPortalPreferences(liferayPortletRequest);
		themeDisplay = (ThemeDisplay) httpServletRequest.getAttribute(WebKeys.THEME_DISPLAY);
	}

	/**
	 * This method is used to call the method to clear the search results.
	 */
	@Override
	public String getClearResultsURL() {
		return getSearchActionURL();
	}

	/**
	 * This method is used to clear the search results.
	 */
	@Override
	public String getSearchActionURL() {
		// We Have Created An Empty Render URL
		PortletURL searchURL = liferayPortletResponse.createRenderURL();
				
		// Setting Up The Parameter For The Created URL
		String navigation = ParamUtil.getString(request, "usersEntries");
		searchURL.setParameter("navigation", navigation);
		return searchURL.toString();
	}

	@Reference
	private final PortalPreferences portalPreferences;
	@Reference
	private final ThemeDisplay themeDisplay;
}
