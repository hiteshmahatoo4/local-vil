create table VIL_ApiLogging (
	uuid_ VARCHAR(75) null,
	apiLoggingId LONG not null primary key,
	ipAddress VARCHAR(75) null,
	channelName VARCHAR(75) null,
	requestId VARCHAR(75) null,
	userID LONG,
	callingTime DATE null,
	responseTime LONG,
	url VARCHAR(75) null,
	request STRING null,
	responseData STRING null,
	response STRING null,
	status VARCHAR(75) null,
	statusMessage VARCHAR(75) null
);