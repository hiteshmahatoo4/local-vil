/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.auditing.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUID;

import com.vil.auditing.exception.NoSuchApiLoggingException;
import com.vil.auditing.model.ApiLogging;
import com.vil.auditing.model.ApiLoggingTable;
import com.vil.auditing.model.impl.ApiLoggingImpl;
import com.vil.auditing.model.impl.ApiLoggingModelImpl;
import com.vil.auditing.service.persistence.ApiLoggingPersistence;
import com.vil.auditing.service.persistence.ApiLoggingUtil;
import com.vil.auditing.service.persistence.impl.constants.VILPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.sql.DataSource;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the api logging service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = ApiLoggingPersistence.class)
public class ApiLoggingPersistenceImpl
	extends BasePersistenceImpl<ApiLogging> implements ApiLoggingPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>ApiLoggingUtil</code> to access the api logging persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		ApiLoggingImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;
	private FinderPath _finderPathWithPaginationFindByUuid;
	private FinderPath _finderPathWithoutPaginationFindByUuid;
	private FinderPath _finderPathCountByUuid;

	/**
	 * Returns all the api loggings where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching api loggings
	 */
	@Override
	public List<ApiLogging> findByUuid(String uuid) {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the api loggings where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @return the range of matching api loggings
	 */
	@Override
	public List<ApiLogging> findByUuid(String uuid, int start, int end) {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the api loggings where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching api loggings
	 */
	@Override
	public List<ApiLogging> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator) {

		return findByUuid(uuid, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the api loggings where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching api loggings
	 */
	@Override
	public List<ApiLogging> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator,
		boolean useFinderCache) {

		uuid = Objects.toString(uuid, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByUuid;
				finderArgs = new Object[] {uuid};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByUuid;
			finderArgs = new Object[] {uuid, start, end, orderByComparator};
		}

		List<ApiLogging> list = null;

		if (useFinderCache) {
			list = (List<ApiLogging>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (ApiLogging apiLogging : list) {
					if (!uuid.equals(apiLogging.getUuid())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_APILOGGING_WHERE);

			boolean bindUuid = false;

			if (uuid.isEmpty()) {
				sb.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				sb.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(ApiLoggingModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindUuid) {
					queryPos.add(uuid);
				}

				list = (List<ApiLogging>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	@Override
	public ApiLogging findByUuid_First(
			String uuid, OrderByComparator<ApiLogging> orderByComparator)
		throws NoSuchApiLoggingException {

		ApiLogging apiLogging = fetchByUuid_First(uuid, orderByComparator);

		if (apiLogging != null) {
			return apiLogging;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("uuid=");
		sb.append(uuid);

		sb.append("}");

		throw new NoSuchApiLoggingException(sb.toString());
	}

	/**
	 * Returns the first api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	@Override
	public ApiLogging fetchByUuid_First(
		String uuid, OrderByComparator<ApiLogging> orderByComparator) {

		List<ApiLogging> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	@Override
	public ApiLogging findByUuid_Last(
			String uuid, OrderByComparator<ApiLogging> orderByComparator)
		throws NoSuchApiLoggingException {

		ApiLogging apiLogging = fetchByUuid_Last(uuid, orderByComparator);

		if (apiLogging != null) {
			return apiLogging;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("uuid=");
		sb.append(uuid);

		sb.append("}");

		throw new NoSuchApiLoggingException(sb.toString());
	}

	/**
	 * Returns the last api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	@Override
	public ApiLogging fetchByUuid_Last(
		String uuid, OrderByComparator<ApiLogging> orderByComparator) {

		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<ApiLogging> list = findByUuid(
			uuid, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the api loggings before and after the current api logging in the ordered set where uuid = &#63;.
	 *
	 * @param apiLoggingId the primary key of the current api logging
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next api logging
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	@Override
	public ApiLogging[] findByUuid_PrevAndNext(
			long apiLoggingId, String uuid,
			OrderByComparator<ApiLogging> orderByComparator)
		throws NoSuchApiLoggingException {

		uuid = Objects.toString(uuid, "");

		ApiLogging apiLogging = findByPrimaryKey(apiLoggingId);

		Session session = null;

		try {
			session = openSession();

			ApiLogging[] array = new ApiLoggingImpl[3];

			array[0] = getByUuid_PrevAndNext(
				session, apiLogging, uuid, orderByComparator, true);

			array[1] = apiLogging;

			array[2] = getByUuid_PrevAndNext(
				session, apiLogging, uuid, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected ApiLogging getByUuid_PrevAndNext(
		Session session, ApiLogging apiLogging, String uuid,
		OrderByComparator<ApiLogging> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_APILOGGING_WHERE);

		boolean bindUuid = false;

		if (uuid.isEmpty()) {
			sb.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			sb.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(ApiLoggingModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindUuid) {
			queryPos.add(uuid);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(apiLogging)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<ApiLogging> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the api loggings where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	@Override
	public void removeByUuid(String uuid) {
		for (ApiLogging apiLogging :
				findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(apiLogging);
		}
	}

	/**
	 * Returns the number of api loggings where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching api loggings
	 */
	@Override
	public int countByUuid(String uuid) {
		uuid = Objects.toString(uuid, "");

		FinderPath finderPath = _finderPathCountByUuid;

		Object[] finderArgs = new Object[] {uuid};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_APILOGGING_WHERE);

			boolean bindUuid = false;

			if (uuid.isEmpty()) {
				sb.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				sb.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindUuid) {
					queryPos.add(uuid);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_2 =
		"apiLogging.uuid = ?";

	private static final String _FINDER_COLUMN_UUID_UUID_3 =
		"(apiLogging.uuid IS NULL OR apiLogging.uuid = '')";

	private FinderPath _finderPathWithPaginationFindByRequestId;
	private FinderPath _finderPathWithoutPaginationFindByRequestId;
	private FinderPath _finderPathCountByRequestId;

	/**
	 * Returns all the api loggings where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @return the matching api loggings
	 */
	@Override
	public List<ApiLogging> findByRequestId(String requestId) {
		return findByRequestId(
			requestId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the api loggings where requestId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param requestId the request ID
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @return the range of matching api loggings
	 */
	@Override
	public List<ApiLogging> findByRequestId(
		String requestId, int start, int end) {

		return findByRequestId(requestId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the api loggings where requestId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param requestId the request ID
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching api loggings
	 */
	@Override
	public List<ApiLogging> findByRequestId(
		String requestId, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator) {

		return findByRequestId(requestId, start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the api loggings where requestId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param requestId the request ID
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching api loggings
	 */
	@Override
	public List<ApiLogging> findByRequestId(
		String requestId, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator,
		boolean useFinderCache) {

		requestId = Objects.toString(requestId, "");

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindByRequestId;
				finderArgs = new Object[] {requestId};
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindByRequestId;
			finderArgs = new Object[] {
				requestId, start, end, orderByComparator
			};
		}

		List<ApiLogging> list = null;

		if (useFinderCache) {
			list = (List<ApiLogging>)finderCache.getResult(
				finderPath, finderArgs, this);

			if ((list != null) && !list.isEmpty()) {
				for (ApiLogging apiLogging : list) {
					if (!requestId.equals(apiLogging.getRequestId())) {
						list = null;

						break;
					}
				}
			}
		}

		if (list == null) {
			StringBundler sb = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					3 + (orderByComparator.getOrderByFields().length * 2));
			}
			else {
				sb = new StringBundler(3);
			}

			sb.append(_SQL_SELECT_APILOGGING_WHERE);

			boolean bindRequestId = false;

			if (requestId.isEmpty()) {
				sb.append(_FINDER_COLUMN_REQUESTID_REQUESTID_3);
			}
			else {
				bindRequestId = true;

				sb.append(_FINDER_COLUMN_REQUESTID_REQUESTID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);
			}
			else {
				sb.append(ApiLoggingModelImpl.ORDER_BY_JPQL);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindRequestId) {
					queryPos.add(requestId);
				}

				list = (List<ApiLogging>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	@Override
	public ApiLogging findByRequestId_First(
			String requestId, OrderByComparator<ApiLogging> orderByComparator)
		throws NoSuchApiLoggingException {

		ApiLogging apiLogging = fetchByRequestId_First(
			requestId, orderByComparator);

		if (apiLogging != null) {
			return apiLogging;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("requestId=");
		sb.append(requestId);

		sb.append("}");

		throw new NoSuchApiLoggingException(sb.toString());
	}

	/**
	 * Returns the first api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	@Override
	public ApiLogging fetchByRequestId_First(
		String requestId, OrderByComparator<ApiLogging> orderByComparator) {

		List<ApiLogging> list = findByRequestId(
			requestId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	@Override
	public ApiLogging findByRequestId_Last(
			String requestId, OrderByComparator<ApiLogging> orderByComparator)
		throws NoSuchApiLoggingException {

		ApiLogging apiLogging = fetchByRequestId_Last(
			requestId, orderByComparator);

		if (apiLogging != null) {
			return apiLogging;
		}

		StringBundler sb = new StringBundler(4);

		sb.append(_NO_SUCH_ENTITY_WITH_KEY);

		sb.append("requestId=");
		sb.append(requestId);

		sb.append("}");

		throw new NoSuchApiLoggingException(sb.toString());
	}

	/**
	 * Returns the last api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	@Override
	public ApiLogging fetchByRequestId_Last(
		String requestId, OrderByComparator<ApiLogging> orderByComparator) {

		int count = countByRequestId(requestId);

		if (count == 0) {
			return null;
		}

		List<ApiLogging> list = findByRequestId(
			requestId, count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the api loggings before and after the current api logging in the ordered set where requestId = &#63;.
	 *
	 * @param apiLoggingId the primary key of the current api logging
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next api logging
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	@Override
	public ApiLogging[] findByRequestId_PrevAndNext(
			long apiLoggingId, String requestId,
			OrderByComparator<ApiLogging> orderByComparator)
		throws NoSuchApiLoggingException {

		requestId = Objects.toString(requestId, "");

		ApiLogging apiLogging = findByPrimaryKey(apiLoggingId);

		Session session = null;

		try {
			session = openSession();

			ApiLogging[] array = new ApiLoggingImpl[3];

			array[0] = getByRequestId_PrevAndNext(
				session, apiLogging, requestId, orderByComparator, true);

			array[1] = apiLogging;

			array[2] = getByRequestId_PrevAndNext(
				session, apiLogging, requestId, orderByComparator, false);

			return array;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	protected ApiLogging getByRequestId_PrevAndNext(
		Session session, ApiLogging apiLogging, String requestId,
		OrderByComparator<ApiLogging> orderByComparator, boolean previous) {

		StringBundler sb = null;

		if (orderByComparator != null) {
			sb = new StringBundler(
				4 + (orderByComparator.getOrderByConditionFields().length * 3) +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			sb = new StringBundler(3);
		}

		sb.append(_SQL_SELECT_APILOGGING_WHERE);

		boolean bindRequestId = false;

		if (requestId.isEmpty()) {
			sb.append(_FINDER_COLUMN_REQUESTID_REQUESTID_3);
		}
		else {
			bindRequestId = true;

			sb.append(_FINDER_COLUMN_REQUESTID_REQUESTID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields =
				orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				sb.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						sb.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(WHERE_GREATER_THAN);
					}
					else {
						sb.append(WHERE_LESSER_THAN);
					}
				}
			}

			sb.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				sb.append(_ORDER_BY_ENTITY_ALIAS);
				sb.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						sb.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						sb.append(ORDER_BY_ASC);
					}
					else {
						sb.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			sb.append(ApiLoggingModelImpl.ORDER_BY_JPQL);
		}

		String sql = sb.toString();

		Query query = session.createQuery(sql);

		query.setFirstResult(0);
		query.setMaxResults(2);

		QueryPos queryPos = QueryPos.getInstance(query);

		if (bindRequestId) {
			queryPos.add(requestId);
		}

		if (orderByComparator != null) {
			for (Object orderByConditionValue :
					orderByComparator.getOrderByConditionValues(apiLogging)) {

				queryPos.add(orderByConditionValue);
			}
		}

		List<ApiLogging> list = query.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the api loggings where requestId = &#63; from the database.
	 *
	 * @param requestId the request ID
	 */
	@Override
	public void removeByRequestId(String requestId) {
		for (ApiLogging apiLogging :
				findByRequestId(
					requestId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {

			remove(apiLogging);
		}
	}

	/**
	 * Returns the number of api loggings where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @return the number of matching api loggings
	 */
	@Override
	public int countByRequestId(String requestId) {
		requestId = Objects.toString(requestId, "");

		FinderPath finderPath = _finderPathCountByRequestId;

		Object[] finderArgs = new Object[] {requestId};

		Long count = (Long)finderCache.getResult(finderPath, finderArgs, this);

		if (count == null) {
			StringBundler sb = new StringBundler(2);

			sb.append(_SQL_COUNT_APILOGGING_WHERE);

			boolean bindRequestId = false;

			if (requestId.isEmpty()) {
				sb.append(_FINDER_COLUMN_REQUESTID_REQUESTID_3);
			}
			else {
				bindRequestId = true;

				sb.append(_FINDER_COLUMN_REQUESTID_REQUESTID_2);
			}

			String sql = sb.toString();

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				QueryPos queryPos = QueryPos.getInstance(query);

				if (bindRequestId) {
					queryPos.add(requestId);
				}

				count = (Long)query.uniqueResult();

				finderCache.putResult(finderPath, finderArgs, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_REQUESTID_REQUESTID_2 =
		"apiLogging.requestId = ?";

	private static final String _FINDER_COLUMN_REQUESTID_REQUESTID_3 =
		"(apiLogging.requestId IS NULL OR apiLogging.requestId = '')";

	public ApiLoggingPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("uuid", "uuid_");

		setDBColumnNames(dbColumnNames);

		setModelClass(ApiLogging.class);

		setModelImplClass(ApiLoggingImpl.class);
		setModelPKClass(long.class);

		setTable(ApiLoggingTable.INSTANCE);
	}

	/**
	 * Caches the api logging in the entity cache if it is enabled.
	 *
	 * @param apiLogging the api logging
	 */
	@Override
	public void cacheResult(ApiLogging apiLogging) {
		entityCache.putResult(
			ApiLoggingImpl.class, apiLogging.getPrimaryKey(), apiLogging);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the api loggings in the entity cache if it is enabled.
	 *
	 * @param apiLoggings the api loggings
	 */
	@Override
	public void cacheResult(List<ApiLogging> apiLoggings) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (apiLoggings.size() > _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (ApiLogging apiLogging : apiLoggings) {
			if (entityCache.getResult(
					ApiLoggingImpl.class, apiLogging.getPrimaryKey()) == null) {

				cacheResult(apiLogging);
			}
		}
	}

	/**
	 * Clears the cache for all api loggings.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(ApiLoggingImpl.class);

		finderCache.clearCache(ApiLoggingImpl.class);
	}

	/**
	 * Clears the cache for the api logging.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(ApiLogging apiLogging) {
		entityCache.removeResult(ApiLoggingImpl.class, apiLogging);
	}

	@Override
	public void clearCache(List<ApiLogging> apiLoggings) {
		for (ApiLogging apiLogging : apiLoggings) {
			entityCache.removeResult(ApiLoggingImpl.class, apiLogging);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(ApiLoggingImpl.class);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(ApiLoggingImpl.class, primaryKey);
		}
	}

	/**
	 * Creates a new api logging with the primary key. Does not add the api logging to the database.
	 *
	 * @param apiLoggingId the primary key for the new api logging
	 * @return the new api logging
	 */
	@Override
	public ApiLogging create(long apiLoggingId) {
		ApiLogging apiLogging = new ApiLoggingImpl();

		apiLogging.setNew(true);
		apiLogging.setPrimaryKey(apiLoggingId);

		String uuid = _portalUUID.generate();

		apiLogging.setUuid(uuid);

		return apiLogging;
	}

	/**
	 * Removes the api logging with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging that was removed
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	@Override
	public ApiLogging remove(long apiLoggingId)
		throws NoSuchApiLoggingException {

		return remove((Serializable)apiLoggingId);
	}

	/**
	 * Removes the api logging with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the api logging
	 * @return the api logging that was removed
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	@Override
	public ApiLogging remove(Serializable primaryKey)
		throws NoSuchApiLoggingException {

		Session session = null;

		try {
			session = openSession();

			ApiLogging apiLogging = (ApiLogging)session.get(
				ApiLoggingImpl.class, primaryKey);

			if (apiLogging == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchApiLoggingException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(apiLogging);
		}
		catch (NoSuchApiLoggingException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected ApiLogging removeImpl(ApiLogging apiLogging) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(apiLogging)) {
				apiLogging = (ApiLogging)session.get(
					ApiLoggingImpl.class, apiLogging.getPrimaryKeyObj());
			}

			if (apiLogging != null) {
				session.delete(apiLogging);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (apiLogging != null) {
			clearCache(apiLogging);
		}

		return apiLogging;
	}

	@Override
	public ApiLogging updateImpl(ApiLogging apiLogging) {
		boolean isNew = apiLogging.isNew();

		if (!(apiLogging instanceof ApiLoggingModelImpl)) {
			InvocationHandler invocationHandler = null;

			if (ProxyUtil.isProxyClass(apiLogging.getClass())) {
				invocationHandler = ProxyUtil.getInvocationHandler(apiLogging);

				throw new IllegalArgumentException(
					"Implement ModelWrapper in apiLogging proxy " +
						invocationHandler.getClass());
			}

			throw new IllegalArgumentException(
				"Implement ModelWrapper in custom ApiLogging implementation " +
					apiLogging.getClass());
		}

		ApiLoggingModelImpl apiLoggingModelImpl =
			(ApiLoggingModelImpl)apiLogging;

		if (Validator.isNull(apiLogging.getUuid())) {
			String uuid = _portalUUID.generate();

			apiLogging.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(apiLogging);
			}
			else {
				apiLogging = (ApiLogging)session.merge(apiLogging);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			ApiLoggingImpl.class, apiLoggingModelImpl, false, true);

		if (isNew) {
			apiLogging.setNew(false);
		}

		apiLogging.resetOriginalValues();

		return apiLogging;
	}

	/**
	 * Returns the api logging with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the api logging
	 * @return the api logging
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	@Override
	public ApiLogging findByPrimaryKey(Serializable primaryKey)
		throws NoSuchApiLoggingException {

		ApiLogging apiLogging = fetchByPrimaryKey(primaryKey);

		if (apiLogging == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchApiLoggingException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return apiLogging;
	}

	/**
	 * Returns the api logging with the primary key or throws a <code>NoSuchApiLoggingException</code> if it could not be found.
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	@Override
	public ApiLogging findByPrimaryKey(long apiLoggingId)
		throws NoSuchApiLoggingException {

		return findByPrimaryKey((Serializable)apiLoggingId);
	}

	/**
	 * Returns the api logging with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging, or <code>null</code> if a api logging with the primary key could not be found
	 */
	@Override
	public ApiLogging fetchByPrimaryKey(long apiLoggingId) {
		return fetchByPrimaryKey((Serializable)apiLoggingId);
	}

	/**
	 * Returns all the api loggings.
	 *
	 * @return the api loggings
	 */
	@Override
	public List<ApiLogging> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the api loggings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @return the range of api loggings
	 */
	@Override
	public List<ApiLogging> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the api loggings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of api loggings
	 */
	@Override
	public List<ApiLogging> findAll(
		int start, int end, OrderByComparator<ApiLogging> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the api loggings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of api loggings
	 */
	@Override
	public List<ApiLogging> findAll(
		int start, int end, OrderByComparator<ApiLogging> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<ApiLogging> list = null;

		if (useFinderCache) {
			list = (List<ApiLogging>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_APILOGGING);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_APILOGGING;

				sql = sql.concat(ApiLoggingModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<ApiLogging>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the api loggings from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (ApiLogging apiLogging : findAll()) {
			remove(apiLogging);
		}
	}

	/**
	 * Returns the number of api loggings.
	 *
	 * @return the number of api loggings
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_APILOGGING);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "apiLoggingId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_APILOGGING;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return ApiLoggingModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the api logging persistence.
	 */
	@Activate
	public void activate() {
		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_finderPathWithPaginationFindByUuid = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"uuid_"}, true);

		_finderPathWithoutPaginationFindByUuid = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] {String.class.getName()}, new String[] {"uuid_"},
			true);

		_finderPathCountByUuid = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] {String.class.getName()}, new String[] {"uuid_"},
			false);

		_finderPathWithPaginationFindByRequestId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByRequestId",
			new String[] {
				String.class.getName(), Integer.class.getName(),
				Integer.class.getName(), OrderByComparator.class.getName()
			},
			new String[] {"requestId"}, true);

		_finderPathWithoutPaginationFindByRequestId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByRequestId",
			new String[] {String.class.getName()}, new String[] {"requestId"},
			true);

		_finderPathCountByRequestId = new FinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByRequestId",
			new String[] {String.class.getName()}, new String[] {"requestId"},
			false);

		_setApiLoggingUtilPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		_setApiLoggingUtilPersistence(null);

		entityCache.removeCache(ApiLoggingImpl.class.getName());
	}

	private void _setApiLoggingUtilPersistence(
		ApiLoggingPersistence apiLoggingPersistence) {

		try {
			Field field = ApiLoggingUtil.class.getDeclaredField("_persistence");

			field.setAccessible(true);

			field.set(null, apiLoggingPersistence);
		}
		catch (ReflectiveOperationException reflectiveOperationException) {
			throw new RuntimeException(reflectiveOperationException);
		}
	}

	@Override
	@Reference(
		target = VILPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = VILPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = VILPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_APILOGGING =
		"SELECT apiLogging FROM ApiLogging apiLogging";

	private static final String _SQL_SELECT_APILOGGING_WHERE =
		"SELECT apiLogging FROM ApiLogging apiLogging WHERE ";

	private static final String _SQL_COUNT_APILOGGING =
		"SELECT COUNT(apiLogging) FROM ApiLogging apiLogging";

	private static final String _SQL_COUNT_APILOGGING_WHERE =
		"SELECT COUNT(apiLogging) FROM ApiLogging apiLogging WHERE ";

	private static final String _ORDER_BY_ENTITY_ALIAS = "apiLogging.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No ApiLogging exists with the primary key ";

	private static final String _NO_SUCH_ENTITY_WITH_KEY =
		"No ApiLogging exists with the key {";

	private static final Log _log = LogFactoryUtil.getLog(
		ApiLoggingPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"uuid"});

	@Override
	protected FinderCache getFinderCache() {
		return finderCache;
	}

	@Reference
	private PortalUUID _portalUUID;

}