/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.auditing.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import com.vil.auditing.model.ApiLogging;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ApiLogging in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class ApiLoggingCacheModel
	implements CacheModel<ApiLogging>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof ApiLoggingCacheModel)) {
			return false;
		}

		ApiLoggingCacheModel apiLoggingCacheModel =
			(ApiLoggingCacheModel)object;

		if (apiLoggingId == apiLoggingCacheModel.apiLoggingId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, apiLoggingId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", apiLoggingId=");
		sb.append(apiLoggingId);
		sb.append(", ipAddress=");
		sb.append(ipAddress);
		sb.append(", channelName=");
		sb.append(channelName);
		sb.append(", requestId=");
		sb.append(requestId);
		sb.append(", userID=");
		sb.append(userID);
		sb.append(", callingTime=");
		sb.append(callingTime);
		sb.append(", responseTime=");
		sb.append(responseTime);
		sb.append(", url=");
		sb.append(url);
		sb.append(", request=");
		sb.append(request);
		sb.append(", responseData=");
		sb.append(responseData);
		sb.append(", response=");
		sb.append(response);
		sb.append(", status=");
		sb.append(status);
		sb.append(", statusMessage=");
		sb.append(statusMessage);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public ApiLogging toEntityModel() {
		ApiLoggingImpl apiLoggingImpl = new ApiLoggingImpl();

		if (uuid == null) {
			apiLoggingImpl.setUuid("");
		}
		else {
			apiLoggingImpl.setUuid(uuid);
		}

		apiLoggingImpl.setApiLoggingId(apiLoggingId);

		if (ipAddress == null) {
			apiLoggingImpl.setIpAddress("");
		}
		else {
			apiLoggingImpl.setIpAddress(ipAddress);
		}

		if (channelName == null) {
			apiLoggingImpl.setChannelName("");
		}
		else {
			apiLoggingImpl.setChannelName(channelName);
		}

		if (requestId == null) {
			apiLoggingImpl.setRequestId("");
		}
		else {
			apiLoggingImpl.setRequestId(requestId);
		}

		apiLoggingImpl.setUserID(userID);

		if (callingTime == Long.MIN_VALUE) {
			apiLoggingImpl.setCallingTime(null);
		}
		else {
			apiLoggingImpl.setCallingTime(new Date(callingTime));
		}

		apiLoggingImpl.setResponseTime(responseTime);

		if (url == null) {
			apiLoggingImpl.setUrl("");
		}
		else {
			apiLoggingImpl.setUrl(url);
		}

		if (request == null) {
			apiLoggingImpl.setRequest("");
		}
		else {
			apiLoggingImpl.setRequest(request);
		}

		if (responseData == null) {
			apiLoggingImpl.setResponseData("");
		}
		else {
			apiLoggingImpl.setResponseData(responseData);
		}

		if (response == null) {
			apiLoggingImpl.setResponse("");
		}
		else {
			apiLoggingImpl.setResponse(response);
		}

		if (status == null) {
			apiLoggingImpl.setStatus("");
		}
		else {
			apiLoggingImpl.setStatus(status);
		}

		if (statusMessage == null) {
			apiLoggingImpl.setStatusMessage("");
		}
		else {
			apiLoggingImpl.setStatusMessage(statusMessage);
		}

		apiLoggingImpl.resetOriginalValues();

		return apiLoggingImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		apiLoggingId = objectInput.readLong();
		ipAddress = objectInput.readUTF();
		channelName = objectInput.readUTF();
		requestId = objectInput.readUTF();

		userID = objectInput.readLong();
		callingTime = objectInput.readLong();

		responseTime = objectInput.readLong();
		url = objectInput.readUTF();
		request = objectInput.readUTF();
		responseData = objectInput.readUTF();
		response = objectInput.readUTF();
		status = objectInput.readUTF();
		statusMessage = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(apiLoggingId);

		if (ipAddress == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(ipAddress);
		}

		if (channelName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(channelName);
		}

		if (requestId == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(requestId);
		}

		objectOutput.writeLong(userID);
		objectOutput.writeLong(callingTime);

		objectOutput.writeLong(responseTime);

		if (url == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(url);
		}

		if (request == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(request);
		}

		if (responseData == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(responseData);
		}

		if (response == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(response);
		}

		if (status == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(status);
		}

		if (statusMessage == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(statusMessage);
		}
	}

	public String uuid;
	public long apiLoggingId;
	public String ipAddress;
	public String channelName;
	public String requestId;
	public long userID;
	public long callingTime;
	public long responseTime;
	public String url;
	public String request;
	public String responseData;
	public String response;
	public String status;
	public String statusMessage;

}