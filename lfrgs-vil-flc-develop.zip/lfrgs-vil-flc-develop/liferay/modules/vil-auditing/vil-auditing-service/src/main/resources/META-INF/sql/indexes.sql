create index IX_2CEDF789 on VIL_ApiLogging (requestId[$COLUMN_LENGTH:75$]);
create index IX_37AB3F83 on VIL_ApiLogging (uuid_[$COLUMN_LENGTH:75$]);