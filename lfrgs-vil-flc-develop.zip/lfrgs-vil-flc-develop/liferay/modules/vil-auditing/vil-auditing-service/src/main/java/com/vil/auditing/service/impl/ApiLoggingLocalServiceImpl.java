/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.auditing.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;
import com.vil.auditing.model.ApiLogging;
import com.vil.auditing.service.ApiLoggingLocalService;
import com.vil.auditing.service.base.ApiLoggingLocalServiceBaseImpl;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;

import org.osgi.service.component.annotations.Component;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = "model.class.name=com.vil.auditing.model.ApiLogging",
	service = AopService.class
)
public class ApiLoggingLocalServiceImpl extends ApiLoggingLocalServiceBaseImpl {
	/**
	 * 
	 * This method is used to find partner master by official emailId
	 *
	 * @param officialEmailId
	 * @return
	 * @throws SystemException
	 * @throws PortalException
	 */
	public List<ApiLogging> findByRequestId(String requestId) throws SystemException, PortalException {
		return apiLoggingPersistence.findByRequestId(requestId);
	}
	
	/**
	 * This method is used to set Auditing of the API
	 * 
	 * @param apiLogging
	 * @param userId
	 * @param status
	 * @param responseObj
	 * @param payload
	 * @param callingDate
	 * @param message
	 * @param statusCode
	 * @param channelName
	 * @param apiLoggingLocalService
	 * @param request
	 * @throws UnknownHostException
	 */
	public void apiAuditting(ApiLogging apiLogging, Long userId, String status,
			Object responseObj, Date callingDate, String message, String ipAddress,
			String statusCode, String channelName, String url, String request,String response, String requestId) {
		apiLogging.setChannelName(channelName);
		apiLogging.setIpAddress(ipAddress);
		apiLogging.setRequest(request);
		apiLogging.setRequestId(requestId);
		apiLogging.setStatus(status);
		apiLogging.setStatusMessage(message);
		apiLogging.setUrl(url);
		if (Validator.isNotNull(userId)) {
			apiLogging.setUserID(userId);
		}
		apiLogging.setCallingTime(callingDate);
		//apiResponse.setReferenceNumber(CustomerConsentAPIConstant.VIL_API_ + apiLogging.getApiLoggingId());
		Date responseDate = new Date();
		long responseTime = responseDate.getTime() - callingDate.getTime();
		apiLogging.setResponseTime(responseTime);
		apiLogging.setResponseData(responseObj.toString());
		apiLogging.setResponse(response);
		addApiLogging(apiLogging);
	}
}