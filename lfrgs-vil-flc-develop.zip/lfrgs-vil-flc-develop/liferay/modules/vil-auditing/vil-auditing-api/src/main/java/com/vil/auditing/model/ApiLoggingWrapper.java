/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.auditing.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ApiLogging}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ApiLogging
 * @generated
 */
public class ApiLoggingWrapper
	extends BaseModelWrapper<ApiLogging>
	implements ApiLogging, ModelWrapper<ApiLogging> {

	public ApiLoggingWrapper(ApiLogging apiLogging) {
		super(apiLogging);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("apiLoggingId", getApiLoggingId());
		attributes.put("ipAddress", getIpAddress());
		attributes.put("channelName", getChannelName());
		attributes.put("requestId", getRequestId());
		attributes.put("userID", getUserID());
		attributes.put("callingTime", getCallingTime());
		attributes.put("responseTime", getResponseTime());
		attributes.put("url", getUrl());
		attributes.put("request", getRequest());
		attributes.put("responseData", getResponseData());
		attributes.put("response", getResponse());
		attributes.put("status", getStatus());
		attributes.put("statusMessage", getStatusMessage());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long apiLoggingId = (Long)attributes.get("apiLoggingId");

		if (apiLoggingId != null) {
			setApiLoggingId(apiLoggingId);
		}

		String ipAddress = (String)attributes.get("ipAddress");

		if (ipAddress != null) {
			setIpAddress(ipAddress);
		}

		String channelName = (String)attributes.get("channelName");

		if (channelName != null) {
			setChannelName(channelName);
		}

		String requestId = (String)attributes.get("requestId");

		if (requestId != null) {
			setRequestId(requestId);
		}

		Long userID = (Long)attributes.get("userID");

		if (userID != null) {
			setUserID(userID);
		}

		Date callingTime = (Date)attributes.get("callingTime");

		if (callingTime != null) {
			setCallingTime(callingTime);
		}

		Long responseTime = (Long)attributes.get("responseTime");

		if (responseTime != null) {
			setResponseTime(responseTime);
		}

		String url = (String)attributes.get("url");

		if (url != null) {
			setUrl(url);
		}

		String request = (String)attributes.get("request");

		if (request != null) {
			setRequest(request);
		}

		String responseData = (String)attributes.get("responseData");

		if (responseData != null) {
			setResponseData(responseData);
		}

		String response = (String)attributes.get("response");

		if (response != null) {
			setResponse(response);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String statusMessage = (String)attributes.get("statusMessage");

		if (statusMessage != null) {
			setStatusMessage(statusMessage);
		}
	}

	@Override
	public ApiLogging cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the api logging ID of this api logging.
	 *
	 * @return the api logging ID of this api logging
	 */
	@Override
	public long getApiLoggingId() {
		return model.getApiLoggingId();
	}

	/**
	 * Returns the calling time of this api logging.
	 *
	 * @return the calling time of this api logging
	 */
	@Override
	public Date getCallingTime() {
		return model.getCallingTime();
	}

	/**
	 * Returns the channel name of this api logging.
	 *
	 * @return the channel name of this api logging
	 */
	@Override
	public String getChannelName() {
		return model.getChannelName();
	}

	/**
	 * Returns the ip address of this api logging.
	 *
	 * @return the ip address of this api logging
	 */
	@Override
	public String getIpAddress() {
		return model.getIpAddress();
	}

	/**
	 * Returns the primary key of this api logging.
	 *
	 * @return the primary key of this api logging
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the request of this api logging.
	 *
	 * @return the request of this api logging
	 */
	@Override
	public String getRequest() {
		return model.getRequest();
	}

	/**
	 * Returns the request ID of this api logging.
	 *
	 * @return the request ID of this api logging
	 */
	@Override
	public String getRequestId() {
		return model.getRequestId();
	}

	/**
	 * Returns the response of this api logging.
	 *
	 * @return the response of this api logging
	 */
	@Override
	public String getResponse() {
		return model.getResponse();
	}

	/**
	 * Returns the response data of this api logging.
	 *
	 * @return the response data of this api logging
	 */
	@Override
	public String getResponseData() {
		return model.getResponseData();
	}

	/**
	 * Returns the response time of this api logging.
	 *
	 * @return the response time of this api logging
	 */
	@Override
	public long getResponseTime() {
		return model.getResponseTime();
	}

	/**
	 * Returns the status of this api logging.
	 *
	 * @return the status of this api logging
	 */
	@Override
	public String getStatus() {
		return model.getStatus();
	}

	/**
	 * Returns the status message of this api logging.
	 *
	 * @return the status message of this api logging
	 */
	@Override
	public String getStatusMessage() {
		return model.getStatusMessage();
	}

	/**
	 * Returns the url of this api logging.
	 *
	 * @return the url of this api logging
	 */
	@Override
	public String getUrl() {
		return model.getUrl();
	}

	/**
	 * Returns the user ID of this api logging.
	 *
	 * @return the user ID of this api logging
	 */
	@Override
	public long getUserID() {
		return model.getUserID();
	}

	/**
	 * Returns the uuid of this api logging.
	 *
	 * @return the uuid of this api logging
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the api logging ID of this api logging.
	 *
	 * @param apiLoggingId the api logging ID of this api logging
	 */
	@Override
	public void setApiLoggingId(long apiLoggingId) {
		model.setApiLoggingId(apiLoggingId);
	}

	/**
	 * Sets the calling time of this api logging.
	 *
	 * @param callingTime the calling time of this api logging
	 */
	@Override
	public void setCallingTime(Date callingTime) {
		model.setCallingTime(callingTime);
	}

	/**
	 * Sets the channel name of this api logging.
	 *
	 * @param channelName the channel name of this api logging
	 */
	@Override
	public void setChannelName(String channelName) {
		model.setChannelName(channelName);
	}

	/**
	 * Sets the ip address of this api logging.
	 *
	 * @param ipAddress the ip address of this api logging
	 */
	@Override
	public void setIpAddress(String ipAddress) {
		model.setIpAddress(ipAddress);
	}

	/**
	 * Sets the primary key of this api logging.
	 *
	 * @param primaryKey the primary key of this api logging
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the request of this api logging.
	 *
	 * @param request the request of this api logging
	 */
	@Override
	public void setRequest(String request) {
		model.setRequest(request);
	}

	/**
	 * Sets the request ID of this api logging.
	 *
	 * @param requestId the request ID of this api logging
	 */
	@Override
	public void setRequestId(String requestId) {
		model.setRequestId(requestId);
	}

	/**
	 * Sets the response of this api logging.
	 *
	 * @param response the response of this api logging
	 */
	@Override
	public void setResponse(String response) {
		model.setResponse(response);
	}

	/**
	 * Sets the response data of this api logging.
	 *
	 * @param responseData the response data of this api logging
	 */
	@Override
	public void setResponseData(String responseData) {
		model.setResponseData(responseData);
	}

	/**
	 * Sets the response time of this api logging.
	 *
	 * @param responseTime the response time of this api logging
	 */
	@Override
	public void setResponseTime(long responseTime) {
		model.setResponseTime(responseTime);
	}

	/**
	 * Sets the status of this api logging.
	 *
	 * @param status the status of this api logging
	 */
	@Override
	public void setStatus(String status) {
		model.setStatus(status);
	}

	/**
	 * Sets the status message of this api logging.
	 *
	 * @param statusMessage the status message of this api logging
	 */
	@Override
	public void setStatusMessage(String statusMessage) {
		model.setStatusMessage(statusMessage);
	}

	/**
	 * Sets the url of this api logging.
	 *
	 * @param url the url of this api logging
	 */
	@Override
	public void setUrl(String url) {
		model.setUrl(url);
	}

	/**
	 * Sets the user ID of this api logging.
	 *
	 * @param userID the user ID of this api logging
	 */
	@Override
	public void setUserID(long userID) {
		model.setUserID(userID);
	}

	/**
	 * Sets the uuid of this api logging.
	 *
	 * @param uuid the uuid of this api logging
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	protected ApiLoggingWrapper wrap(ApiLogging apiLogging) {
		return new ApiLoggingWrapper(apiLogging);
	}

}