/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.auditing.service;

import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.vil.auditing.model.ApiLogging;

import java.io.Serializable;

import java.util.List;

/**
 * Provides the local service utility for ApiLogging. This utility wraps
 * <code>com.vil.auditing.service.impl.ApiLoggingLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see ApiLoggingLocalService
 * @generated
 */
public class ApiLoggingLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.vil.auditing.service.impl.ApiLoggingLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the api logging to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ApiLoggingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param apiLogging the api logging
	 * @return the api logging that was added
	 */
	public static ApiLogging addApiLogging(ApiLogging apiLogging) {
		return getService().addApiLogging(apiLogging);
	}

	/**
	 * This method is used to set Auditing of the API
	 *
	 * @param apiLogging
	 * @param userId
	 * @param status
	 * @param responseObj
	 * @param payload
	 * @param callingDate
	 * @param message
	 * @param statusCode
	 * @param channelName
	 * @param apiLoggingLocalService
	 * @param request
	 * @throws UnknownHostException
	 */
	public static void apiAuditting(
		ApiLogging apiLogging, Long userId, String status, Object responseObj,
		java.util.Date callingDate, String message, String ipAddress,
		String statusCode, String channelName, String url, String request,
		String response, String requestId) {

		getService().apiAuditting(
			apiLogging, userId, status, responseObj, callingDate, message,
			ipAddress, statusCode, channelName, url, request, response,
			requestId);
	}

	/**
	 * Creates a new api logging with the primary key. Does not add the api logging to the database.
	 *
	 * @param apiLoggingId the primary key for the new api logging
	 * @return the new api logging
	 */
	public static ApiLogging createApiLogging(long apiLoggingId) {
		return getService().createApiLogging(apiLoggingId);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel createPersistedModel(
			Serializable primaryKeyObj)
		throws PortalException {

		return getService().createPersistedModel(primaryKeyObj);
	}

	/**
	 * Deletes the api logging from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ApiLoggingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param apiLogging the api logging
	 * @return the api logging that was removed
	 */
	public static ApiLogging deleteApiLogging(ApiLogging apiLogging) {
		return getService().deleteApiLogging(apiLogging);
	}

	/**
	 * Deletes the api logging with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ApiLoggingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging that was removed
	 * @throws PortalException if a api logging with the primary key could not be found
	 */
	public static ApiLogging deleteApiLogging(long apiLoggingId)
		throws PortalException {

		return getService().deleteApiLogging(apiLoggingId);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel deletePersistedModel(
			PersistedModel persistedModel)
		throws PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static <T> T dslQuery(DSLQuery dslQuery) {
		return getService().dslQuery(dslQuery);
	}

	public static int dslQueryCount(DSLQuery dslQuery) {
		return getService().dslQueryCount(dslQuery);
	}

	public static DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> List<T> dynamicQuery(DynamicQuery dynamicQuery) {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.auditing.model.impl.ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.auditing.model.impl.ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(DynamicQuery dynamicQuery) {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static ApiLogging fetchApiLogging(long apiLoggingId) {
		return getService().fetchApiLogging(apiLoggingId);
	}

	/**
	 * This method is used to find partner master by official emailId
	 *
	 * @param officialEmailId
	 * @return
	 * @throws SystemException
	 * @throws PortalException
	 */
	public static List<ApiLogging> findByRequestId(String requestId)
		throws PortalException, SystemException {

		return getService().findByRequestId(requestId);
	}

	public static com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return getService().getActionableDynamicQuery();
	}

	/**
	 * Returns the api logging with the primary key.
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging
	 * @throws PortalException if a api logging with the primary key could not be found
	 */
	public static ApiLogging getApiLogging(long apiLoggingId)
		throws PortalException {

		return getService().getApiLogging(apiLoggingId);
	}

	/**
	 * Returns a range of all the api loggings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.auditing.model.impl.ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @return the range of api loggings
	 */
	public static List<ApiLogging> getApiLoggings(int start, int end) {
		return getService().getApiLoggings(start, end);
	}

	/**
	 * Returns the number of api loggings.
	 *
	 * @return the number of api loggings
	 */
	public static int getApiLoggingsCount() {
		return getService().getApiLoggingsCount();
	}

	public static
		com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
			getIndexableActionableDynamicQuery() {

		return getService().getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel getPersistedModel(Serializable primaryKeyObj)
		throws PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	 * Updates the api logging in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect ApiLoggingLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param apiLogging the api logging
	 * @return the api logging that was updated
	 */
	public static ApiLogging updateApiLogging(ApiLogging apiLogging) {
		return getService().updateApiLogging(apiLogging);
	}

	public static ApiLoggingLocalService getService() {
		return _service;
	}

	private static volatile ApiLoggingLocalService _service;

}