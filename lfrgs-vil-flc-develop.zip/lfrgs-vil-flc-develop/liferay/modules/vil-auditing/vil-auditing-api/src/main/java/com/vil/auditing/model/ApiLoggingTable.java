/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.auditing.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;VIL_ApiLogging&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see ApiLogging
 * @generated
 */
public class ApiLoggingTable extends BaseTable<ApiLoggingTable> {

	public static final ApiLoggingTable INSTANCE = new ApiLoggingTable();

	public final Column<ApiLoggingTable, String> uuid = createColumn(
		"uuid_", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, Long> apiLoggingId = createColumn(
		"apiLoggingId", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<ApiLoggingTable, String> ipAddress = createColumn(
		"ipAddress", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> channelName = createColumn(
		"channelName", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> requestId = createColumn(
		"requestId", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, Long> userID = createColumn(
		"userID", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, Date> callingTime = createColumn(
		"callingTime", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, Long> responseTime = createColumn(
		"responseTime", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> url = createColumn(
		"url", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> request = createColumn(
		"request", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> responseData = createColumn(
		"responseData", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> response = createColumn(
		"response", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> status = createColumn(
		"status", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<ApiLoggingTable, String> statusMessage = createColumn(
		"statusMessage", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);

	private ApiLoggingTable() {
		super("VIL_ApiLogging", ApiLoggingTable::new);
	}

}