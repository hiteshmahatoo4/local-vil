/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.auditing.service.persistence;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.vil.auditing.model.ApiLogging;

import java.io.Serializable;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence utility for the api logging service. This utility wraps <code>com.vil.auditing.service.persistence.impl.ApiLoggingPersistenceImpl</code> and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see ApiLoggingPersistence
 * @generated
 */
public class ApiLoggingUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(ApiLogging apiLogging) {
		getPersistence().clearCache(apiLogging);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#fetchByPrimaryKeys(Set)
	 */
	public static Map<Serializable, ApiLogging> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {

		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<ApiLogging> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {

		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<ApiLogging> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<ApiLogging> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().findWithDynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static ApiLogging update(ApiLogging apiLogging) {
		return getPersistence().update(apiLogging);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static ApiLogging update(
		ApiLogging apiLogging, ServiceContext serviceContext) {

		return getPersistence().update(apiLogging, serviceContext);
	}

	/**
	 * Returns all the api loggings where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching api loggings
	 */
	public static List<ApiLogging> findByUuid(String uuid) {
		return getPersistence().findByUuid(uuid);
	}

	/**
	 * Returns a range of all the api loggings where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @return the range of matching api loggings
	 */
	public static List<ApiLogging> findByUuid(String uuid, int start, int end) {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	 * Returns an ordered range of all the api loggings where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching api loggings
	 */
	public static List<ApiLogging> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the api loggings where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching api loggings
	 */
	public static List<ApiLogging> findByUuid(
		String uuid, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByUuid(
			uuid, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	public static ApiLogging findByUuid_First(
			String uuid, OrderByComparator<ApiLogging> orderByComparator)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the first api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	public static ApiLogging fetchByUuid_First(
		String uuid, OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	 * Returns the last api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	public static ApiLogging findByUuid_Last(
			String uuid, OrderByComparator<ApiLogging> orderByComparator)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the last api logging in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	public static ApiLogging fetchByUuid_Last(
		String uuid, OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	 * Returns the api loggings before and after the current api logging in the ordered set where uuid = &#63;.
	 *
	 * @param apiLoggingId the primary key of the current api logging
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next api logging
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	public static ApiLogging[] findByUuid_PrevAndNext(
			long apiLoggingId, String uuid,
			OrderByComparator<ApiLogging> orderByComparator)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().findByUuid_PrevAndNext(
			apiLoggingId, uuid, orderByComparator);
	}

	/**
	 * Removes all the api loggings where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 */
	public static void removeByUuid(String uuid) {
		getPersistence().removeByUuid(uuid);
	}

	/**
	 * Returns the number of api loggings where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching api loggings
	 */
	public static int countByUuid(String uuid) {
		return getPersistence().countByUuid(uuid);
	}

	/**
	 * Returns all the api loggings where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @return the matching api loggings
	 */
	public static List<ApiLogging> findByRequestId(String requestId) {
		return getPersistence().findByRequestId(requestId);
	}

	/**
	 * Returns a range of all the api loggings where requestId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param requestId the request ID
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @return the range of matching api loggings
	 */
	public static List<ApiLogging> findByRequestId(
		String requestId, int start, int end) {

		return getPersistence().findByRequestId(requestId, start, end);
	}

	/**
	 * Returns an ordered range of all the api loggings where requestId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param requestId the request ID
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching api loggings
	 */
	public static List<ApiLogging> findByRequestId(
		String requestId, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().findByRequestId(
			requestId, start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the api loggings where requestId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param requestId the request ID
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of matching api loggings
	 */
	public static List<ApiLogging> findByRequestId(
		String requestId, int start, int end,
		OrderByComparator<ApiLogging> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findByRequestId(
			requestId, start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Returns the first api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	public static ApiLogging findByRequestId_First(
			String requestId, OrderByComparator<ApiLogging> orderByComparator)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().findByRequestId_First(
			requestId, orderByComparator);
	}

	/**
	 * Returns the first api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	public static ApiLogging fetchByRequestId_First(
		String requestId, OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().fetchByRequestId_First(
			requestId, orderByComparator);
	}

	/**
	 * Returns the last api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging
	 * @throws NoSuchApiLoggingException if a matching api logging could not be found
	 */
	public static ApiLogging findByRequestId_Last(
			String requestId, OrderByComparator<ApiLogging> orderByComparator)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().findByRequestId_Last(
			requestId, orderByComparator);
	}

	/**
	 * Returns the last api logging in the ordered set where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching api logging, or <code>null</code> if a matching api logging could not be found
	 */
	public static ApiLogging fetchByRequestId_Last(
		String requestId, OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().fetchByRequestId_Last(
			requestId, orderByComparator);
	}

	/**
	 * Returns the api loggings before and after the current api logging in the ordered set where requestId = &#63;.
	 *
	 * @param apiLoggingId the primary key of the current api logging
	 * @param requestId the request ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next api logging
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	public static ApiLogging[] findByRequestId_PrevAndNext(
			long apiLoggingId, String requestId,
			OrderByComparator<ApiLogging> orderByComparator)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().findByRequestId_PrevAndNext(
			apiLoggingId, requestId, orderByComparator);
	}

	/**
	 * Removes all the api loggings where requestId = &#63; from the database.
	 *
	 * @param requestId the request ID
	 */
	public static void removeByRequestId(String requestId) {
		getPersistence().removeByRequestId(requestId);
	}

	/**
	 * Returns the number of api loggings where requestId = &#63;.
	 *
	 * @param requestId the request ID
	 * @return the number of matching api loggings
	 */
	public static int countByRequestId(String requestId) {
		return getPersistence().countByRequestId(requestId);
	}

	/**
	 * Caches the api logging in the entity cache if it is enabled.
	 *
	 * @param apiLogging the api logging
	 */
	public static void cacheResult(ApiLogging apiLogging) {
		getPersistence().cacheResult(apiLogging);
	}

	/**
	 * Caches the api loggings in the entity cache if it is enabled.
	 *
	 * @param apiLoggings the api loggings
	 */
	public static void cacheResult(List<ApiLogging> apiLoggings) {
		getPersistence().cacheResult(apiLoggings);
	}

	/**
	 * Creates a new api logging with the primary key. Does not add the api logging to the database.
	 *
	 * @param apiLoggingId the primary key for the new api logging
	 * @return the new api logging
	 */
	public static ApiLogging create(long apiLoggingId) {
		return getPersistence().create(apiLoggingId);
	}

	/**
	 * Removes the api logging with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging that was removed
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	public static ApiLogging remove(long apiLoggingId)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().remove(apiLoggingId);
	}

	public static ApiLogging updateImpl(ApiLogging apiLogging) {
		return getPersistence().updateImpl(apiLogging);
	}

	/**
	 * Returns the api logging with the primary key or throws a <code>NoSuchApiLoggingException</code> if it could not be found.
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging
	 * @throws NoSuchApiLoggingException if a api logging with the primary key could not be found
	 */
	public static ApiLogging findByPrimaryKey(long apiLoggingId)
		throws com.vil.auditing.exception.NoSuchApiLoggingException {

		return getPersistence().findByPrimaryKey(apiLoggingId);
	}

	/**
	 * Returns the api logging with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param apiLoggingId the primary key of the api logging
	 * @return the api logging, or <code>null</code> if a api logging with the primary key could not be found
	 */
	public static ApiLogging fetchByPrimaryKey(long apiLoggingId) {
		return getPersistence().fetchByPrimaryKey(apiLoggingId);
	}

	/**
	 * Returns all the api loggings.
	 *
	 * @return the api loggings
	 */
	public static List<ApiLogging> findAll() {
		return getPersistence().findAll();
	}

	/**
	 * Returns a range of all the api loggings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @return the range of api loggings
	 */
	public static List<ApiLogging> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	 * Returns an ordered range of all the api loggings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of api loggings
	 */
	public static List<ApiLogging> findAll(
		int start, int end, OrderByComparator<ApiLogging> orderByComparator) {

		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	 * Returns an ordered range of all the api loggings.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>ApiLoggingModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of api loggings
	 * @param end the upper bound of the range of api loggings (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of api loggings
	 */
	public static List<ApiLogging> findAll(
		int start, int end, OrderByComparator<ApiLogging> orderByComparator,
		boolean useFinderCache) {

		return getPersistence().findAll(
			start, end, orderByComparator, useFinderCache);
	}

	/**
	 * Removes all the api loggings from the database.
	 */
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	 * Returns the number of api loggings.
	 *
	 * @return the number of api loggings
	 */
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static ApiLoggingPersistence getPersistence() {
		return _persistence;
	}

	private static volatile ApiLoggingPersistence _persistence;

}