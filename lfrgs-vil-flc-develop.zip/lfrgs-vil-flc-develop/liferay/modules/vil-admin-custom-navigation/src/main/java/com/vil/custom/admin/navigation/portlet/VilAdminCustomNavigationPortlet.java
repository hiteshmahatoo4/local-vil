package com.vil.custom.admin.navigation.portlet;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Layout;
import com.liferay.portal.kernel.model.ResourceConstants;
import com.liferay.portal.kernel.model.ResourcePermission;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.role.RoleConstants;
import com.liferay.portal.kernel.module.configuration.ConfigurationException;
import com.liferay.portal.kernel.module.configuration.ConfigurationProviderUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.security.permission.ActionKeys;
import com.liferay.portal.kernel.service.GroupLocalServiceUtil;
import com.liferay.portal.kernel.service.LayoutLocalServiceUtil;
import com.liferay.portal.kernel.service.ResourcePermissionLocalServiceUtil;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.service.permission.LayoutPermissionUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.site.navigation.model.SiteNavigationMenu;
import com.liferay.site.navigation.model.SiteNavigationMenuItem;
import com.liferay.site.navigation.service.SiteNavigationMenuItemLocalServiceUtil;
import com.liferay.site.navigation.service.SiteNavigationMenuLocalServiceUtil;
import com.vil.custom.admin.navigation.constants.VilAdminCustomNavigationPortletKeys;
import com.vil.system.settings.VilSiteConfiguration;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

/**
 * @author abhishek
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=false",
		"javax.portlet.display-name=VilAdminCustomNavigation",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + VilAdminCustomNavigationPortletKeys.VILADMINCUSTOMNAVIGATION,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class VilAdminCustomNavigationPortlet extends MVCPortlet {
	
	private static final Log log = LogFactoryUtil.getLog(VilAdminCustomNavigationPortlet.class);

	/**
	 * Display menus and sub menus having view permission for the user and not having view permission for the guest
	 */
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		
		ThemeDisplay themeDisplay = (ThemeDisplay)renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();
		long companyId =  themeDisplay.getCompanyId();
		String siteNavMenuName = "Admin Partner Menu";
		try {
			String groupFriendlyURL = "/vil";
			try {
				VilSiteConfiguration  vilSiteConfiguration = ConfigurationProviderUtil.getCompanyConfiguration(VilSiteConfiguration.class, companyId);
				groupFriendlyURL = vilSiteConfiguration.vilSiteFriendlyUrl();
				siteNavMenuName = vilSiteConfiguration.siteNavigationMenuName();
			}catch(ConfigurationException e) {
				log.debug(e);
			}
			groupId = GroupLocalServiceUtil.fetchFriendlyURLGroup(companyId, groupFriendlyURL).getGroupId();
			renderRequest.setAttribute("vilGroupFriendlyURL", groupFriendlyURL);
		}catch(Exception e) {
			log.debug("No such site : "+e);
		}
		final String siteNavMenuNameFinal = siteNavMenuName;
		SiteNavigationMenu siteNavigationMenu = SiteNavigationMenuLocalServiceUtil.getAutoSiteNavigationMenus(groupId).stream().
				filter(siteNavMenu -> siteNavMenuNameFinal.equals(siteNavMenu.getName())).findAny().orElse(null);
		if(Validator.isNotNull(siteNavigationMenu)) {
			long siteNavigationMenuId = siteNavigationMenu.getSiteNavigationMenuId();
			List<SiteNavigationMenuItem> listSiteNavigationMenuItem = SiteNavigationMenuItemLocalServiceUtil.getSiteNavigationMenuItems(siteNavigationMenuId)
					.stream().sorted(Comparator.comparing(SiteNavigationMenuItem::getOrder)).collect(Collectors.toList());
			Map<Long, List<Long>> mapLayout = new HashMap<Long, List<Long>>();
			List<Long> listPlids = new ArrayList<>();
			Role roleGuest = null;
			try {
				roleGuest = RoleLocalServiceUtil.getRole(companyId, RoleConstants.GUEST);
			}catch (PortalException e) {
				log.error(e.getMessage());
			}catch (Exception e) {
				log.error(e);
			}
			if(ListUtil.isNotEmpty(listSiteNavigationMenuItem)) {
				for(SiteNavigationMenuItem siteNavigationMenuItem: listSiteNavigationMenuItem) {
					try {
						Properties properties = new Properties();
						String siteNavigationTypeSettings = siteNavigationMenuItem.getTypeSettings();
						InputStream inStream = new ByteArrayInputStream(siteNavigationTypeSettings.getBytes(StandardCharsets.UTF_8));
						properties.load(inStream);
						inStream.close();
						
						Enumeration<Object> enumKeys = properties.keys();
						String uuid = "";
			            while (enumKeys.hasMoreElements()) {
			                String key = (String) enumKeys.nextElement();
			                if("layoutUuid".equalsIgnoreCase(key)) {
			                	uuid = properties.getProperty(key);
			                }
			            }
			            
			            Layout layout = LayoutLocalServiceUtil.getLayoutByUuidAndGroupId(uuid, groupId, false);
						
						boolean hasViewPermission = LayoutPermissionUtil.contains(themeDisplay.getPermissionChecker(), layout.getPlid(), ActionKeys.VIEW);
						ResourcePermission resPermission = ResourcePermissionLocalServiceUtil.getResourcePermission(
								companyId, Layout.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
								String.valueOf(layout.getPlid()), roleGuest.getRoleId());
						
						if(hasViewPermission && !resPermission.hasActionId(ActionKeys.VIEW)) {
							if(layout.getParentPlid()==0L) {
								listPlids.add(layout.getPlid());
								
								List<SiteNavigationMenuItem> childSiteNavigationMenuItemList = SiteNavigationMenuItemLocalServiceUtil.getSiteNavigationMenuItems(siteNavigationMenuId, siteNavigationMenuItem.getSiteNavigationMenuItemId())
										.stream().sorted(Comparator.comparing(SiteNavigationMenuItem::getOrder)).collect(Collectors.toList());
								
								
								if(ListUtil.isNotEmpty(childSiteNavigationMenuItemList)) {
									List<Long> listChildPlidsWithPermission = new ArrayList<>();
									for(SiteNavigationMenuItem childSiteNavigationMenuItem: childSiteNavigationMenuItemList) {
										Properties propertiesChild = new Properties();
										String childSiteNavigationTypeSettings = childSiteNavigationMenuItem.getTypeSettings();
										InputStream inputStream = new ByteArrayInputStream(childSiteNavigationTypeSettings.getBytes(StandardCharsets.UTF_8));
										propertiesChild.load(inputStream);
										inputStream.close();
										Enumeration<Object> enumChildKeys = propertiesChild.keys();
										String childLayoutUuid = "";
							            while (enumChildKeys.hasMoreElements()) {
							                String key = (String) enumChildKeys.nextElement();
							                if("layoutUuid".equalsIgnoreCase(key)) {
							                	childLayoutUuid = propertiesChild.getProperty(key);
							                }
							            }
							            
							            Layout childLayout = LayoutLocalServiceUtil.getLayoutByUuidAndGroupId(childLayoutUuid, groupId, false);
										
										boolean hasViewPermissionChild = LayoutPermissionUtil.contains(themeDisplay.getPermissionChecker(), 
												childLayout.getPlid(), ActionKeys.VIEW);
										ResourcePermission resPermissionChild = ResourcePermissionLocalServiceUtil.getResourcePermission(
												companyId, Layout.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
												String.valueOf(childLayout.getPlid()), roleGuest.getRoleId());
										if(hasViewPermissionChild && !resPermissionChild.hasActionId(ActionKeys.VIEW)) {
											listChildPlidsWithPermission.add(childLayout.getPlid());
										}
									}
									if(ListUtil.isNotEmpty(listChildPlidsWithPermission)) {
										mapLayout.put(layout.getPlid(), listChildPlidsWithPermission);
									}
								}
							}
						}
					}
					catch (PortalException e) {
						log.error(e.getMessage());
					}catch (Exception e) {
						log.error(e);
					}
					
				}
			}
			
			renderRequest.setAttribute("listPlid", listPlids);
			renderRequest.setAttribute("mapLayout", mapLayout);
		}
		include(viewTemplate, renderRequest, renderResponse);		
	}
	
}