package com.vil.custom.admin.navigation.util;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.Layout;
import com.liferay.portal.kernel.service.LayoutLocalServiceUtil;
import com.liferay.portal.kernel.util.LocaleUtil;

import java.util.Locale;

public class VilAdminCustomNavigationUtil {
	
	private static final Log log = LogFactoryUtil.getLog(VilAdminCustomNavigationUtil.class);
	
	private VilAdminCustomNavigationUtil() {
		//disable external instantiation
	}

	/**
	 * Returns json containing name, friendlyURL, icon image id of the layout
	 * @param plid
	 * @return
	 */
	public static JSONObject getLayoutDetails(long plid) {
		
		try {
			Layout layout = LayoutLocalServiceUtil.getLayout(plid);
			JSONObject layoutDetails = JSONFactoryUtil.createJSONObject();
			Locale siteLocale = LocaleUtil.getSiteDefault();
			layoutDetails.put("name", layout.getName(siteLocale));
			layoutDetails.put("url", layout.getFriendlyURL(siteLocale));
			layoutDetails.put("icon", layout.getIconImageId());
			return layoutDetails;
		} catch (PortalException e) {
			log.error(e.getMessage());
		}catch (Exception e) {
			log.error(e);
		}
		
		return null;
		
	}
}
