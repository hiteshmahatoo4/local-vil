package com.vil.custom.admin.navigation.constants;

/**
 * @author abhishek
 */
public class VilAdminCustomNavigationPortletKeys {

	public static final String VILADMINCUSTOMNAVIGATION =
		"vil_admin_custom_navigation_VilAdminCustomNavigationPortlet";

}