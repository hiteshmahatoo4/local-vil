/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.bulkupload.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;vil_productdetails&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see VilProductDetails
 * @generated
 */
public class VilProductDetailsTable extends BaseTable<VilProductDetailsTable> {

	public static final VilProductDetailsTable INSTANCE =
		new VilProductDetailsTable();

	public final Column<VilProductDetailsTable, String> uuid = createColumn(
		"uuid_", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Long> id = createColumn(
		"id_", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<VilProductDetailsTable, Long> groupId = createColumn(
		"groupId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Long> companyId = createColumn(
		"companyId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Long> userId = createColumn(
		"userId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> userName = createColumn(
		"userName", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Long> partnerId = createColumn(
		"partnerId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Date> createDate = createColumn(
		"createDate", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Date> modifiedDate =
		createColumn(
			"modifiedDate", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Long> cpdefinitionId =
		createColumn(
			"cpdefinitionId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> enableReviewRating =
		createColumn(
			"enableReviewRating", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> showReviewRating =
		createColumn(
			"showReviewRating", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> imageLink1 =
		createColumn(
			"imageLink1", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> imageLink2 =
		createColumn(
			"imageLink2", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> imageLink3 =
		createColumn(
			"imageLink3", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> fullfilmentName =
		createColumn(
			"fullfilmentName", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> fullfilmentType =
		createColumn(
			"fullfilmentType", String.class, Types.VARCHAR,
			Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> termsCondtions =
		createColumn(
			"termsCondtions", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, Integer> validity =
		createColumn(
			"validity", Integer.class, Types.INTEGER, Column.FLAG_DEFAULT);
	public final Column<VilProductDetailsTable, String> validityType =
		createColumn(
			"validityType", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);

	private VilProductDetailsTable() {
		super("vil_productdetails", VilProductDetailsTable::new);
	}

}