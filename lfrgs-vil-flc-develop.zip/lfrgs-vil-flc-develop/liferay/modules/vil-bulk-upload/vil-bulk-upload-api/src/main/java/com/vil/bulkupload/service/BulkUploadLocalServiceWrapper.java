/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.bulkupload.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link BulkUploadLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see BulkUploadLocalService
 * @generated
 */
public class BulkUploadLocalServiceWrapper
	implements BulkUploadLocalService, ServiceWrapper<BulkUploadLocalService> {

	public BulkUploadLocalServiceWrapper() {
		this(null);
	}

	public BulkUploadLocalServiceWrapper(
		BulkUploadLocalService bulkUploadLocalService) {

		_bulkUploadLocalService = bulkUploadLocalService;
	}

	/**
	 * Adds the bulk upload to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param bulkUpload the bulk upload
	 * @return the bulk upload that was added
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload addBulkUpload(
		com.vil.bulkupload.model.BulkUpload bulkUpload) {

		return _bulkUploadLocalService.addBulkUpload(bulkUpload);
	}

	/**
	 * Creates a new bulk upload with the primary key. Does not add the bulk upload to the database.
	 *
	 * @param id the primary key for the new bulk upload
	 * @return the new bulk upload
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload createBulkUpload(long id) {
		return _bulkUploadLocalService.createBulkUpload(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel createPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _bulkUploadLocalService.createPersistedModel(primaryKeyObj);
	}

	/**
	 * Deletes the bulk upload from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param bulkUpload the bulk upload
	 * @return the bulk upload that was removed
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload deleteBulkUpload(
		com.vil.bulkupload.model.BulkUpload bulkUpload) {

		return _bulkUploadLocalService.deleteBulkUpload(bulkUpload);
	}

	/**
	 * Deletes the bulk upload with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param id the primary key of the bulk upload
	 * @return the bulk upload that was removed
	 * @throws PortalException if a bulk upload with the primary key could not be found
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload deleteBulkUpload(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _bulkUploadLocalService.deleteBulkUpload(id);
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
			com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _bulkUploadLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public <T> T dslQuery(com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {
		return _bulkUploadLocalService.dslQuery(dslQuery);
	}

	@Override
	public int dslQueryCount(
		com.liferay.petra.sql.dsl.query.DSLQuery dslQuery) {

		return _bulkUploadLocalService.dslQueryCount(dslQuery);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _bulkUploadLocalService.dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _bulkUploadLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.bulkupload.model.impl.BulkUploadModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {

		return _bulkUploadLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.bulkupload.model.impl.BulkUploadModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {

		return _bulkUploadLocalService.dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {

		return _bulkUploadLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return _bulkUploadLocalService.dynamicQueryCount(
			dynamicQuery, projection);
	}

	@Override
	public com.vil.bulkupload.model.BulkUpload fetchBulkUpload(long id) {
		return _bulkUploadLocalService.fetchBulkUpload(id);
	}

	/**
	 * Returns the bulk upload matching the UUID and group.
	 *
	 * @param uuid the bulk upload's UUID
	 * @param groupId the primary key of the group
	 * @return the matching bulk upload, or <code>null</code> if a matching bulk upload could not be found
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload fetchBulkUploadByUuidAndGroupId(
		String uuid, long groupId) {

		return _bulkUploadLocalService.fetchBulkUploadByUuidAndGroupId(
			uuid, groupId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return _bulkUploadLocalService.getActionableDynamicQuery();
	}

	/**
	 * Returns the bulk upload with the primary key.
	 *
	 * @param id the primary key of the bulk upload
	 * @return the bulk upload
	 * @throws PortalException if a bulk upload with the primary key could not be found
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload getBulkUpload(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _bulkUploadLocalService.getBulkUpload(id);
	}

	/**
	 * Returns the bulk upload matching the UUID and group.
	 *
	 * @param uuid the bulk upload's UUID
	 * @param groupId the primary key of the group
	 * @return the matching bulk upload
	 * @throws PortalException if a matching bulk upload could not be found
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload getBulkUploadByUuidAndGroupId(
			String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _bulkUploadLocalService.getBulkUploadByUuidAndGroupId(
			uuid, groupId);
	}

	/**
	 * Returns a range of all the bulk uploads.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.bulkupload.model.impl.BulkUploadModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of bulk uploads
	 * @param end the upper bound of the range of bulk uploads (not inclusive)
	 * @return the range of bulk uploads
	 */
	@Override
	public java.util.List<com.vil.bulkupload.model.BulkUpload> getBulkUploads(
		int start, int end) {

		return _bulkUploadLocalService.getBulkUploads(start, end);
	}

	/**
	 * Returns all the bulk uploads matching the UUID and company.
	 *
	 * @param uuid the UUID of the bulk uploads
	 * @param companyId the primary key of the company
	 * @return the matching bulk uploads, or an empty list if no matches were found
	 */
	@Override
	public java.util.List<com.vil.bulkupload.model.BulkUpload>
		getBulkUploadsByUuidAndCompanyId(String uuid, long companyId) {

		return _bulkUploadLocalService.getBulkUploadsByUuidAndCompanyId(
			uuid, companyId);
	}

	/**
	 * Returns a range of bulk uploads matching the UUID and company.
	 *
	 * @param uuid the UUID of the bulk uploads
	 * @param companyId the primary key of the company
	 * @param start the lower bound of the range of bulk uploads
	 * @param end the upper bound of the range of bulk uploads (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the range of matching bulk uploads, or an empty list if no matches were found
	 */
	@Override
	public java.util.List<com.vil.bulkupload.model.BulkUpload>
		getBulkUploadsByUuidAndCompanyId(
			String uuid, long companyId, int start, int end,
			com.liferay.portal.kernel.util.OrderByComparator
				<com.vil.bulkupload.model.BulkUpload> orderByComparator) {

		return _bulkUploadLocalService.getBulkUploadsByUuidAndCompanyId(
			uuid, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns the number of bulk uploads.
	 *
	 * @return the number of bulk uploads
	 */
	@Override
	public int getBulkUploadsCount() {
		return _bulkUploadLocalService.getBulkUploadsCount();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ExportActionableDynamicQuery
		getExportActionableDynamicQuery(
			com.liferay.exportimport.kernel.lar.PortletDataContext
				portletDataContext) {

		return _bulkUploadLocalService.getExportActionableDynamicQuery(
			portletDataContext);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
		getIndexableActionableDynamicQuery() {

		return _bulkUploadLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _bulkUploadLocalService.getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
			java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _bulkUploadLocalService.getPersistedModel(primaryKeyObj);
	}

	@Override
	public java.util.List<com.vil.bulkupload.model.BulkUpload>
		getUsersByKeywords(String keywords, int start, int end) {

		return _bulkUploadLocalService.getUsersByKeywords(keywords, start, end);
	}

	@Override
	public long getUsersCountsByKeywords(String keywords) {
		return _bulkUploadLocalService.getUsersCountsByKeywords(keywords);
	}

	/**
	 * Updates the bulk upload in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param bulkUpload the bulk upload
	 * @return the bulk upload that was updated
	 */
	@Override
	public com.vil.bulkupload.model.BulkUpload updateBulkUpload(
		com.vil.bulkupload.model.BulkUpload bulkUpload) {

		return _bulkUploadLocalService.updateBulkUpload(bulkUpload);
	}

	@Override
	public BulkUploadLocalService getWrappedService() {
		return _bulkUploadLocalService;
	}

	@Override
	public void setWrappedService(
		BulkUploadLocalService bulkUploadLocalService) {

		_bulkUploadLocalService = bulkUploadLocalService;
	}

	private BulkUploadLocalService _bulkUploadLocalService;

}