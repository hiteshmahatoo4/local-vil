/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.bulkupload.service;

import com.liferay.petra.sql.dsl.query.DSLQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.util.OrderByComparator;

import com.vil.bulkupload.model.BulkUpload;

import java.io.Serializable;

import java.util.List;

/**
 * Provides the local service utility for BulkUpload. This utility wraps
 * <code>com.vil.bulkupload.service.impl.BulkUploadLocalServiceImpl</code> and
 * is an access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see BulkUploadLocalService
 * @generated
 */
public class BulkUploadLocalServiceUtil {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to <code>com.vil.bulkupload.service.impl.BulkUploadLocalServiceImpl</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * Adds the bulk upload to the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param bulkUpload the bulk upload
	 * @return the bulk upload that was added
	 */
	public static BulkUpload addBulkUpload(BulkUpload bulkUpload) {
		return getService().addBulkUpload(bulkUpload);
	}

	/**
	 * Creates a new bulk upload with the primary key. Does not add the bulk upload to the database.
	 *
	 * @param id the primary key for the new bulk upload
	 * @return the new bulk upload
	 */
	public static BulkUpload createBulkUpload(long id) {
		return getService().createBulkUpload(id);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel createPersistedModel(
			Serializable primaryKeyObj)
		throws PortalException {

		return getService().createPersistedModel(primaryKeyObj);
	}

	/**
	 * Deletes the bulk upload from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param bulkUpload the bulk upload
	 * @return the bulk upload that was removed
	 */
	public static BulkUpload deleteBulkUpload(BulkUpload bulkUpload) {
		return getService().deleteBulkUpload(bulkUpload);
	}

	/**
	 * Deletes the bulk upload with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param id the primary key of the bulk upload
	 * @return the bulk upload that was removed
	 * @throws PortalException if a bulk upload with the primary key could not be found
	 */
	public static BulkUpload deleteBulkUpload(long id) throws PortalException {
		return getService().deleteBulkUpload(id);
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel deletePersistedModel(
			PersistedModel persistedModel)
		throws PortalException {

		return getService().deletePersistedModel(persistedModel);
	}

	public static <T> T dslQuery(DSLQuery dslQuery) {
		return getService().dslQuery(dslQuery);
	}

	public static int dslQueryCount(DSLQuery dslQuery) {
		return getService().dslQueryCount(dslQuery);
	}

	public static DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	 * Performs a dynamic query on the database and returns the matching rows.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the matching rows
	 */
	public static <T> List<T> dynamicQuery(DynamicQuery dynamicQuery) {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	 * Performs a dynamic query on the database and returns a range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.bulkupload.model.impl.BulkUploadModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @return the range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {

		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * Performs a dynamic query on the database and returns an ordered range of the matching rows.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.bulkupload.model.impl.BulkUploadModelImpl</code>.
	 * </p>
	 *
	 * @param dynamicQuery the dynamic query
	 * @param start the lower bound of the range of model instances
	 * @param end the upper bound of the range of model instances (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching rows
	 */
	public static <T> List<T> dynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<T> orderByComparator) {

		return getService().dynamicQuery(
			dynamicQuery, start, end, orderByComparator);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(DynamicQuery dynamicQuery) {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	 * Returns the number of rows matching the dynamic query.
	 *
	 * @param dynamicQuery the dynamic query
	 * @param projection the projection to apply to the query
	 * @return the number of rows matching the dynamic query
	 */
	public static long dynamicQueryCount(
		DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {

		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static BulkUpload fetchBulkUpload(long id) {
		return getService().fetchBulkUpload(id);
	}

	/**
	 * Returns the bulk upload matching the UUID and group.
	 *
	 * @param uuid the bulk upload's UUID
	 * @param groupId the primary key of the group
	 * @return the matching bulk upload, or <code>null</code> if a matching bulk upload could not be found
	 */
	public static BulkUpload fetchBulkUploadByUuidAndGroupId(
		String uuid, long groupId) {

		return getService().fetchBulkUploadByUuidAndGroupId(uuid, groupId);
	}

	public static com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery
		getActionableDynamicQuery() {

		return getService().getActionableDynamicQuery();
	}

	/**
	 * Returns the bulk upload with the primary key.
	 *
	 * @param id the primary key of the bulk upload
	 * @return the bulk upload
	 * @throws PortalException if a bulk upload with the primary key could not be found
	 */
	public static BulkUpload getBulkUpload(long id) throws PortalException {
		return getService().getBulkUpload(id);
	}

	/**
	 * Returns the bulk upload matching the UUID and group.
	 *
	 * @param uuid the bulk upload's UUID
	 * @param groupId the primary key of the group
	 * @return the matching bulk upload
	 * @throws PortalException if a matching bulk upload could not be found
	 */
	public static BulkUpload getBulkUploadByUuidAndGroupId(
			String uuid, long groupId)
		throws PortalException {

		return getService().getBulkUploadByUuidAndGroupId(uuid, groupId);
	}

	/**
	 * Returns a range of all the bulk uploads.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>com.vil.bulkupload.model.impl.BulkUploadModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of bulk uploads
	 * @param end the upper bound of the range of bulk uploads (not inclusive)
	 * @return the range of bulk uploads
	 */
	public static List<BulkUpload> getBulkUploads(int start, int end) {
		return getService().getBulkUploads(start, end);
	}

	/**
	 * Returns all the bulk uploads matching the UUID and company.
	 *
	 * @param uuid the UUID of the bulk uploads
	 * @param companyId the primary key of the company
	 * @return the matching bulk uploads, or an empty list if no matches were found
	 */
	public static List<BulkUpload> getBulkUploadsByUuidAndCompanyId(
		String uuid, long companyId) {

		return getService().getBulkUploadsByUuidAndCompanyId(uuid, companyId);
	}

	/**
	 * Returns a range of bulk uploads matching the UUID and company.
	 *
	 * @param uuid the UUID of the bulk uploads
	 * @param companyId the primary key of the company
	 * @param start the lower bound of the range of bulk uploads
	 * @param end the upper bound of the range of bulk uploads (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the range of matching bulk uploads, or an empty list if no matches were found
	 */
	public static List<BulkUpload> getBulkUploadsByUuidAndCompanyId(
		String uuid, long companyId, int start, int end,
		OrderByComparator<BulkUpload> orderByComparator) {

		return getService().getBulkUploadsByUuidAndCompanyId(
			uuid, companyId, start, end, orderByComparator);
	}

	/**
	 * Returns the number of bulk uploads.
	 *
	 * @return the number of bulk uploads
	 */
	public static int getBulkUploadsCount() {
		return getService().getBulkUploadsCount();
	}

	public static com.liferay.portal.kernel.dao.orm.ExportActionableDynamicQuery
		getExportActionableDynamicQuery(
			com.liferay.exportimport.kernel.lar.PortletDataContext
				portletDataContext) {

		return getService().getExportActionableDynamicQuery(portletDataContext);
	}

	public static
		com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery
			getIndexableActionableDynamicQuery() {

		return getService().getIndexableActionableDynamicQuery();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	public static String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	/**
	 * @throws PortalException
	 */
	public static PersistedModel getPersistedModel(Serializable primaryKeyObj)
		throws PortalException {

		return getService().getPersistedModel(primaryKeyObj);
	}

	public static List<BulkUpload> getUsersByKeywords(
		String keywords, int start, int end) {

		return getService().getUsersByKeywords(keywords, start, end);
	}

	public static long getUsersCountsByKeywords(String keywords) {
		return getService().getUsersCountsByKeywords(keywords);
	}

	/**
	 * Updates the bulk upload in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	 *
	 * <p>
	 * <strong>Important:</strong> Inspect BulkUploadLocalServiceImpl for overloaded versions of the method. If provided, use these entry points to the API, as the implementation logic may require the additional parameters defined there.
	 * </p>
	 *
	 * @param bulkUpload the bulk upload
	 * @return the bulk upload that was updated
	 */
	public static BulkUpload updateBulkUpload(BulkUpload bulkUpload) {
		return getService().updateBulkUpload(bulkUpload);
	}

	public static BulkUploadLocalService getService() {
		return _service;
	}

	private static volatile BulkUploadLocalService _service;

}