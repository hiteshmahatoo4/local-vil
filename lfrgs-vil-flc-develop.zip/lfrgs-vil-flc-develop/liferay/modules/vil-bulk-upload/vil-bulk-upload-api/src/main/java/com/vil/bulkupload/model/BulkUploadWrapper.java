/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.bulkupload.model;

import com.liferay.exportimport.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link BulkUpload}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see BulkUpload
 * @generated
 */
public class BulkUploadWrapper
	extends BaseModelWrapper<BulkUpload>
	implements BulkUpload, ModelWrapper<BulkUpload> {

	public BulkUploadWrapper(BulkUpload bulkUpload) {
		super(bulkUpload);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("fileName", getFileName());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("partnerId", getPartnerId());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("uploadType", getUploadType());
		attributes.put("categoryId", getCategoryId());
		attributes.put("rowDetail", getRowDetail());
		attributes.put("status", getStatus());
		attributes.put("remark", getRemark());
		attributes.put("successCount", getSuccessCount());
		attributes.put("failedCount", getFailedCount());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String fileName = (String)attributes.get("fileName");

		if (fileName != null) {
			setFileName(fileName);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Long partnerId = (Long)attributes.get("partnerId");

		if (partnerId != null) {
			setPartnerId(partnerId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String uploadType = (String)attributes.get("uploadType");

		if (uploadType != null) {
			setUploadType(uploadType);
		}

		Long categoryId = (Long)attributes.get("categoryId");

		if (categoryId != null) {
			setCategoryId(categoryId);
		}

		String rowDetail = (String)attributes.get("rowDetail");

		if (rowDetail != null) {
			setRowDetail(rowDetail);
		}

		String status = (String)attributes.get("status");

		if (status != null) {
			setStatus(status);
		}

		String remark = (String)attributes.get("remark");

		if (remark != null) {
			setRemark(remark);
		}

		Long successCount = (Long)attributes.get("successCount");

		if (successCount != null) {
			setSuccessCount(successCount);
		}

		Long failedCount = (Long)attributes.get("failedCount");

		if (failedCount != null) {
			setFailedCount(failedCount);
		}
	}

	@Override
	public BulkUpload cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the category ID of this bulk upload.
	 *
	 * @return the category ID of this bulk upload
	 */
	@Override
	public long getCategoryId() {
		return model.getCategoryId();
	}

	/**
	 * Returns the company ID of this bulk upload.
	 *
	 * @return the company ID of this bulk upload
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the create date of this bulk upload.
	 *
	 * @return the create date of this bulk upload
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the failed count of this bulk upload.
	 *
	 * @return the failed count of this bulk upload
	 */
	@Override
	public long getFailedCount() {
		return model.getFailedCount();
	}

	/**
	 * Returns the file name of this bulk upload.
	 *
	 * @return the file name of this bulk upload
	 */
	@Override
	public String getFileName() {
		return model.getFileName();
	}

	/**
	 * Returns the group ID of this bulk upload.
	 *
	 * @return the group ID of this bulk upload
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the ID of this bulk upload.
	 *
	 * @return the ID of this bulk upload
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the modified date of this bulk upload.
	 *
	 * @return the modified date of this bulk upload
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the partner ID of this bulk upload.
	 *
	 * @return the partner ID of this bulk upload
	 */
	@Override
	public long getPartnerId() {
		return model.getPartnerId();
	}

	/**
	 * Returns the primary key of this bulk upload.
	 *
	 * @return the primary key of this bulk upload
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the remark of this bulk upload.
	 *
	 * @return the remark of this bulk upload
	 */
	@Override
	public String getRemark() {
		return model.getRemark();
	}

	/**
	 * Returns the row detail of this bulk upload.
	 *
	 * @return the row detail of this bulk upload
	 */
	@Override
	public String getRowDetail() {
		return model.getRowDetail();
	}

	/**
	 * Returns the status of this bulk upload.
	 *
	 * @return the status of this bulk upload
	 */
	@Override
	public String getStatus() {
		return model.getStatus();
	}

	/**
	 * Returns the success count of this bulk upload.
	 *
	 * @return the success count of this bulk upload
	 */
	@Override
	public long getSuccessCount() {
		return model.getSuccessCount();
	}

	/**
	 * Returns the upload type of this bulk upload.
	 *
	 * @return the upload type of this bulk upload
	 */
	@Override
	public String getUploadType() {
		return model.getUploadType();
	}

	/**
	 * Returns the user ID of this bulk upload.
	 *
	 * @return the user ID of this bulk upload
	 */
	@Override
	public long getUserId() {
		return model.getUserId();
	}

	/**
	 * Returns the user name of this bulk upload.
	 *
	 * @return the user name of this bulk upload
	 */
	@Override
	public String getUserName() {
		return model.getUserName();
	}

	/**
	 * Returns the user uuid of this bulk upload.
	 *
	 * @return the user uuid of this bulk upload
	 */
	@Override
	public String getUserUuid() {
		return model.getUserUuid();
	}

	/**
	 * Returns the uuid of this bulk upload.
	 *
	 * @return the uuid of this bulk upload
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the category ID of this bulk upload.
	 *
	 * @param categoryId the category ID of this bulk upload
	 */
	@Override
	public void setCategoryId(long categoryId) {
		model.setCategoryId(categoryId);
	}

	/**
	 * Sets the company ID of this bulk upload.
	 *
	 * @param companyId the company ID of this bulk upload
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the create date of this bulk upload.
	 *
	 * @param createDate the create date of this bulk upload
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the failed count of this bulk upload.
	 *
	 * @param failedCount the failed count of this bulk upload
	 */
	@Override
	public void setFailedCount(long failedCount) {
		model.setFailedCount(failedCount);
	}

	/**
	 * Sets the file name of this bulk upload.
	 *
	 * @param fileName the file name of this bulk upload
	 */
	@Override
	public void setFileName(String fileName) {
		model.setFileName(fileName);
	}

	/**
	 * Sets the group ID of this bulk upload.
	 *
	 * @param groupId the group ID of this bulk upload
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the ID of this bulk upload.
	 *
	 * @param id the ID of this bulk upload
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the modified date of this bulk upload.
	 *
	 * @param modifiedDate the modified date of this bulk upload
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the partner ID of this bulk upload.
	 *
	 * @param partnerId the partner ID of this bulk upload
	 */
	@Override
	public void setPartnerId(long partnerId) {
		model.setPartnerId(partnerId);
	}

	/**
	 * Sets the primary key of this bulk upload.
	 *
	 * @param primaryKey the primary key of this bulk upload
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the remark of this bulk upload.
	 *
	 * @param remark the remark of this bulk upload
	 */
	@Override
	public void setRemark(String remark) {
		model.setRemark(remark);
	}

	/**
	 * Sets the row detail of this bulk upload.
	 *
	 * @param rowDetail the row detail of this bulk upload
	 */
	@Override
	public void setRowDetail(String rowDetail) {
		model.setRowDetail(rowDetail);
	}

	/**
	 * Sets the status of this bulk upload.
	 *
	 * @param status the status of this bulk upload
	 */
	@Override
	public void setStatus(String status) {
		model.setStatus(status);
	}

	/**
	 * Sets the success count of this bulk upload.
	 *
	 * @param successCount the success count of this bulk upload
	 */
	@Override
	public void setSuccessCount(long successCount) {
		model.setSuccessCount(successCount);
	}

	/**
	 * Sets the upload type of this bulk upload.
	 *
	 * @param uploadType the upload type of this bulk upload
	 */
	@Override
	public void setUploadType(String uploadType) {
		model.setUploadType(uploadType);
	}

	/**
	 * Sets the user ID of this bulk upload.
	 *
	 * @param userId the user ID of this bulk upload
	 */
	@Override
	public void setUserId(long userId) {
		model.setUserId(userId);
	}

	/**
	 * Sets the user name of this bulk upload.
	 *
	 * @param userName the user name of this bulk upload
	 */
	@Override
	public void setUserName(String userName) {
		model.setUserName(userName);
	}

	/**
	 * Sets the user uuid of this bulk upload.
	 *
	 * @param userUuid the user uuid of this bulk upload
	 */
	@Override
	public void setUserUuid(String userUuid) {
		model.setUserUuid(userUuid);
	}

	/**
	 * Sets the uuid of this bulk upload.
	 *
	 * @param uuid the uuid of this bulk upload
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	public StagedModelType getStagedModelType() {
		return model.getStagedModelType();
	}

	@Override
	protected BulkUploadWrapper wrap(BulkUpload bulkUpload) {
		return new BulkUploadWrapper(bulkUpload);
	}

}