/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.bulkupload.model;

import com.liferay.petra.sql.dsl.Column;
import com.liferay.petra.sql.dsl.base.BaseTable;

import java.sql.Types;

import java.util.Date;

/**
 * The table class for the &quot;vil_bulkupload&quot; database table.
 *
 * @author Brian Wing Shun Chan
 * @see BulkUpload
 * @generated
 */
public class BulkUploadTable extends BaseTable<BulkUploadTable> {

	public static final BulkUploadTable INSTANCE = new BulkUploadTable();

	public final Column<BulkUploadTable, String> uuid = createColumn(
		"uuid_", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> id = createColumn(
		"id_", Long.class, Types.BIGINT, Column.FLAG_PRIMARY);
	public final Column<BulkUploadTable, String> fileName = createColumn(
		"fileName", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> groupId = createColumn(
		"groupId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> companyId = createColumn(
		"companyId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> userId = createColumn(
		"userId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, String> userName = createColumn(
		"userName", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> partnerId = createColumn(
		"partnerId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Date> createDate = createColumn(
		"createDate", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Date> modifiedDate = createColumn(
		"modifiedDate", Date.class, Types.TIMESTAMP, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, String> uploadType = createColumn(
		"uploadType", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> categoryId = createColumn(
		"categoryId", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, String> rowDetail = createColumn(
		"rowDetail", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, String> status = createColumn(
		"status", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, String> remark = createColumn(
		"remark", String.class, Types.VARCHAR, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> successCount = createColumn(
		"successCount", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);
	public final Column<BulkUploadTable, Long> failedCount = createColumn(
		"failedCount", Long.class, Types.BIGINT, Column.FLAG_DEFAULT);

	private BulkUploadTable() {
		super("vil_bulkupload", BulkUploadTable::new);
	}

}