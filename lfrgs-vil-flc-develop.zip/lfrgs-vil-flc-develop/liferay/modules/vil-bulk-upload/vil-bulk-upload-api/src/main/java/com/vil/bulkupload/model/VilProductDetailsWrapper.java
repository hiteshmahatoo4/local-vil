/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.vil.bulkupload.model;

import com.liferay.exportimport.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link VilProductDetails}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see VilProductDetails
 * @generated
 */
public class VilProductDetailsWrapper
	extends BaseModelWrapper<VilProductDetails>
	implements ModelWrapper<VilProductDetails>, VilProductDetails {

	public VilProductDetailsWrapper(VilProductDetails vilProductDetails) {
		super(vilProductDetails);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("partnerId", getPartnerId());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("cpdefinitionId", getCpdefinitionId());
		attributes.put("enableReviewRating", getEnableReviewRating());
		attributes.put("showReviewRating", getShowReviewRating());
		attributes.put("imageLink1", getImageLink1());
		attributes.put("imageLink2", getImageLink2());
		attributes.put("imageLink3", getImageLink3());
		attributes.put("fullfilmentName", getFullfilmentName());
		attributes.put("fullfilmentType", getFullfilmentType());
		attributes.put("termsCondtions", getTermsCondtions());
		attributes.put("validity", getValidity());
		attributes.put("validityType", getValidityType());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Long partnerId = (Long)attributes.get("partnerId");

		if (partnerId != null) {
			setPartnerId(partnerId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		Long cpdefinitionId = (Long)attributes.get("cpdefinitionId");

		if (cpdefinitionId != null) {
			setCpdefinitionId(cpdefinitionId);
		}

		String enableReviewRating = (String)attributes.get(
			"enableReviewRating");

		if (enableReviewRating != null) {
			setEnableReviewRating(enableReviewRating);
		}

		String showReviewRating = (String)attributes.get("showReviewRating");

		if (showReviewRating != null) {
			setShowReviewRating(showReviewRating);
		}

		String imageLink1 = (String)attributes.get("imageLink1");

		if (imageLink1 != null) {
			setImageLink1(imageLink1);
		}

		String imageLink2 = (String)attributes.get("imageLink2");

		if (imageLink2 != null) {
			setImageLink2(imageLink2);
		}

		String imageLink3 = (String)attributes.get("imageLink3");

		if (imageLink3 != null) {
			setImageLink3(imageLink3);
		}

		String fullfilmentName = (String)attributes.get("fullfilmentName");

		if (fullfilmentName != null) {
			setFullfilmentName(fullfilmentName);
		}

		String fullfilmentType = (String)attributes.get("fullfilmentType");

		if (fullfilmentType != null) {
			setFullfilmentType(fullfilmentType);
		}

		String termsCondtions = (String)attributes.get("termsCondtions");

		if (termsCondtions != null) {
			setTermsCondtions(termsCondtions);
		}

		Integer validity = (Integer)attributes.get("validity");

		if (validity != null) {
			setValidity(validity);
		}

		String validityType = (String)attributes.get("validityType");

		if (validityType != null) {
			setValidityType(validityType);
		}
	}

	@Override
	public VilProductDetails cloneWithOriginalValues() {
		return wrap(model.cloneWithOriginalValues());
	}

	/**
	 * Returns the company ID of this vil product details.
	 *
	 * @return the company ID of this vil product details
	 */
	@Override
	public long getCompanyId() {
		return model.getCompanyId();
	}

	/**
	 * Returns the cpdefinition ID of this vil product details.
	 *
	 * @return the cpdefinition ID of this vil product details
	 */
	@Override
	public long getCpdefinitionId() {
		return model.getCpdefinitionId();
	}

	/**
	 * Returns the create date of this vil product details.
	 *
	 * @return the create date of this vil product details
	 */
	@Override
	public Date getCreateDate() {
		return model.getCreateDate();
	}

	/**
	 * Returns the enable review rating of this vil product details.
	 *
	 * @return the enable review rating of this vil product details
	 */
	@Override
	public String getEnableReviewRating() {
		return model.getEnableReviewRating();
	}

	/**
	 * Returns the fullfilment name of this vil product details.
	 *
	 * @return the fullfilment name of this vil product details
	 */
	@Override
	public String getFullfilmentName() {
		return model.getFullfilmentName();
	}

	/**
	 * Returns the fullfilment type of this vil product details.
	 *
	 * @return the fullfilment type of this vil product details
	 */
	@Override
	public String getFullfilmentType() {
		return model.getFullfilmentType();
	}

	/**
	 * Returns the group ID of this vil product details.
	 *
	 * @return the group ID of this vil product details
	 */
	@Override
	public long getGroupId() {
		return model.getGroupId();
	}

	/**
	 * Returns the ID of this vil product details.
	 *
	 * @return the ID of this vil product details
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the image link1 of this vil product details.
	 *
	 * @return the image link1 of this vil product details
	 */
	@Override
	public String getImageLink1() {
		return model.getImageLink1();
	}

	/**
	 * Returns the image link2 of this vil product details.
	 *
	 * @return the image link2 of this vil product details
	 */
	@Override
	public String getImageLink2() {
		return model.getImageLink2();
	}

	/**
	 * Returns the image link3 of this vil product details.
	 *
	 * @return the image link3 of this vil product details
	 */
	@Override
	public String getImageLink3() {
		return model.getImageLink3();
	}

	/**
	 * Returns the modified date of this vil product details.
	 *
	 * @return the modified date of this vil product details
	 */
	@Override
	public Date getModifiedDate() {
		return model.getModifiedDate();
	}

	/**
	 * Returns the partner ID of this vil product details.
	 *
	 * @return the partner ID of this vil product details
	 */
	@Override
	public long getPartnerId() {
		return model.getPartnerId();
	}

	/**
	 * Returns the primary key of this vil product details.
	 *
	 * @return the primary key of this vil product details
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the show review rating of this vil product details.
	 *
	 * @return the show review rating of this vil product details
	 */
	@Override
	public String getShowReviewRating() {
		return model.getShowReviewRating();
	}

	/**
	 * Returns the terms condtions of this vil product details.
	 *
	 * @return the terms condtions of this vil product details
	 */
	@Override
	public String getTermsCondtions() {
		return model.getTermsCondtions();
	}

	/**
	 * Returns the user ID of this vil product details.
	 *
	 * @return the user ID of this vil product details
	 */
	@Override
	public long getUserId() {
		return model.getUserId();
	}

	/**
	 * Returns the user name of this vil product details.
	 *
	 * @return the user name of this vil product details
	 */
	@Override
	public String getUserName() {
		return model.getUserName();
	}

	/**
	 * Returns the user uuid of this vil product details.
	 *
	 * @return the user uuid of this vil product details
	 */
	@Override
	public String getUserUuid() {
		return model.getUserUuid();
	}

	/**
	 * Returns the uuid of this vil product details.
	 *
	 * @return the uuid of this vil product details
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	/**
	 * Returns the validity of this vil product details.
	 *
	 * @return the validity of this vil product details
	 */
	@Override
	public int getValidity() {
		return model.getValidity();
	}

	/**
	 * Returns the validity type of this vil product details.
	 *
	 * @return the validity type of this vil product details
	 */
	@Override
	public String getValidityType() {
		return model.getValidityType();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the company ID of this vil product details.
	 *
	 * @param companyId the company ID of this vil product details
	 */
	@Override
	public void setCompanyId(long companyId) {
		model.setCompanyId(companyId);
	}

	/**
	 * Sets the cpdefinition ID of this vil product details.
	 *
	 * @param cpdefinitionId the cpdefinition ID of this vil product details
	 */
	@Override
	public void setCpdefinitionId(long cpdefinitionId) {
		model.setCpdefinitionId(cpdefinitionId);
	}

	/**
	 * Sets the create date of this vil product details.
	 *
	 * @param createDate the create date of this vil product details
	 */
	@Override
	public void setCreateDate(Date createDate) {
		model.setCreateDate(createDate);
	}

	/**
	 * Sets the enable review rating of this vil product details.
	 *
	 * @param enableReviewRating the enable review rating of this vil product details
	 */
	@Override
	public void setEnableReviewRating(String enableReviewRating) {
		model.setEnableReviewRating(enableReviewRating);
	}

	/**
	 * Sets the fullfilment name of this vil product details.
	 *
	 * @param fullfilmentName the fullfilment name of this vil product details
	 */
	@Override
	public void setFullfilmentName(String fullfilmentName) {
		model.setFullfilmentName(fullfilmentName);
	}

	/**
	 * Sets the fullfilment type of this vil product details.
	 *
	 * @param fullfilmentType the fullfilment type of this vil product details
	 */
	@Override
	public void setFullfilmentType(String fullfilmentType) {
		model.setFullfilmentType(fullfilmentType);
	}

	/**
	 * Sets the group ID of this vil product details.
	 *
	 * @param groupId the group ID of this vil product details
	 */
	@Override
	public void setGroupId(long groupId) {
		model.setGroupId(groupId);
	}

	/**
	 * Sets the ID of this vil product details.
	 *
	 * @param id the ID of this vil product details
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the image link1 of this vil product details.
	 *
	 * @param imageLink1 the image link1 of this vil product details
	 */
	@Override
	public void setImageLink1(String imageLink1) {
		model.setImageLink1(imageLink1);
	}

	/**
	 * Sets the image link2 of this vil product details.
	 *
	 * @param imageLink2 the image link2 of this vil product details
	 */
	@Override
	public void setImageLink2(String imageLink2) {
		model.setImageLink2(imageLink2);
	}

	/**
	 * Sets the image link3 of this vil product details.
	 *
	 * @param imageLink3 the image link3 of this vil product details
	 */
	@Override
	public void setImageLink3(String imageLink3) {
		model.setImageLink3(imageLink3);
	}

	/**
	 * Sets the modified date of this vil product details.
	 *
	 * @param modifiedDate the modified date of this vil product details
	 */
	@Override
	public void setModifiedDate(Date modifiedDate) {
		model.setModifiedDate(modifiedDate);
	}

	/**
	 * Sets the partner ID of this vil product details.
	 *
	 * @param partnerId the partner ID of this vil product details
	 */
	@Override
	public void setPartnerId(long partnerId) {
		model.setPartnerId(partnerId);
	}

	/**
	 * Sets the primary key of this vil product details.
	 *
	 * @param primaryKey the primary key of this vil product details
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the show review rating of this vil product details.
	 *
	 * @param showReviewRating the show review rating of this vil product details
	 */
	@Override
	public void setShowReviewRating(String showReviewRating) {
		model.setShowReviewRating(showReviewRating);
	}

	/**
	 * Sets the terms condtions of this vil product details.
	 *
	 * @param termsCondtions the terms condtions of this vil product details
	 */
	@Override
	public void setTermsCondtions(String termsCondtions) {
		model.setTermsCondtions(termsCondtions);
	}

	/**
	 * Sets the user ID of this vil product details.
	 *
	 * @param userId the user ID of this vil product details
	 */
	@Override
	public void setUserId(long userId) {
		model.setUserId(userId);
	}

	/**
	 * Sets the user name of this vil product details.
	 *
	 * @param userName the user name of this vil product details
	 */
	@Override
	public void setUserName(String userName) {
		model.setUserName(userName);
	}

	/**
	 * Sets the user uuid of this vil product details.
	 *
	 * @param userUuid the user uuid of this vil product details
	 */
	@Override
	public void setUserUuid(String userUuid) {
		model.setUserUuid(userUuid);
	}

	/**
	 * Sets the uuid of this vil product details.
	 *
	 * @param uuid the uuid of this vil product details
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	/**
	 * Sets the validity of this vil product details.
	 *
	 * @param validity the validity of this vil product details
	 */
	@Override
	public void setValidity(int validity) {
		model.setValidity(validity);
	}

	/**
	 * Sets the validity type of this vil product details.
	 *
	 * @param validityType the validity type of this vil product details
	 */
	@Override
	public void setValidityType(String validityType) {
		model.setValidityType(validityType);
	}

	@Override
	public String toXmlString() {
		return model.toXmlString();
	}

	@Override
	public StagedModelType getStagedModelType() {
		return model.getStagedModelType();
	}

	@Override
	protected VilProductDetailsWrapper wrap(
		VilProductDetails vilProductDetails) {

		return new VilProductDetailsWrapper(vilProductDetails);
	}

}