package com.vil.assetcategories.servicewrapper;

import com.liferay.asset.kernel.service.AssetCategoryLocalService;
import com.liferay.asset.kernel.service.AssetCategoryLocalServiceWrapper;
import com.liferay.asset.kernel.service.persistence.AssetCategoryPersistence;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.ServiceWrapper;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Chinmay Abhyankar
 */
@Component(
	immediate = true,
	property = {
	},
	service = ServiceWrapper.class
)
public class VilAssetCategoriesServiceWrapper extends AssetCategoryLocalServiceWrapper {

	public VilAssetCategoriesServiceWrapper() {
		super(null);
	}
	
	@Override
	public int getChildCategoriesCount(long parentCategoryId) {
		try {
			DynamicQuery query = assetCategoryLocalService.dynamicQuery();
			Criterion criterion = RestrictionsFactoryUtil.ne("groupId", -1L);
			criterion = RestrictionsFactoryUtil.and(criterion, RestrictionsFactoryUtil.eq("parentCategoryId", parentCategoryId));
			query.add(criterion);
			query.setProjection(PropertyFactoryUtil.forName("categoryId").count());
			
			List<Object>list = assetCategoryLocalService.dynamicQuery(query);
			Long v = (Long)list.get(0);
			return v.intValue();
		}catch (Exception e) {
			return assetCategoryPersistence.countByParentCategoryId(parentCategoryId);
		}

	}

	@Reference
	AssetCategoryPersistence assetCategoryPersistence;
	
	@Reference
	AssetCategoryLocalService assetCategoryLocalService;
	
	private static final Log _log = LogFactoryUtil.getLog(VilAssetCategoriesServiceWrapper.class.getName());
}