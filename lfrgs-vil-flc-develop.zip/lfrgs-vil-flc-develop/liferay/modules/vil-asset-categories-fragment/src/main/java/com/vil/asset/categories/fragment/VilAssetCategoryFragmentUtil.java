package com.vil.asset.categories.fragment;

import com.liferay.asset.category.property.model.AssetCategoryProperty;
import com.liferay.asset.category.property.service.AssetCategoryPropertyLocalServiceUtil;
import com.liferay.asset.kernel.model.AssetCategoryDisplay;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * The purpose of this class is utility class for fragment
 *
 *
 *@author Chinmay Abhyankar
 *
 */
public class VilAssetCategoryFragmentUtil {

	/**
	 * 
	 * This method is used to get category property by category Id
	 *
	 * @param categoryId
	 * @return : list of category property
	 */
	public static List<AssetCategoryProperty> getCategoryPropertyByCategoryId(long categoryId) {
		try {
			_log.debug("category id ::"+categoryId);
			DynamicQuery dynamicQuery = AssetCategoryPropertyLocalServiceUtil.dynamicQuery();
			Criterion criterion = RestrictionsFactoryUtil.eq("categoryId", categoryId);
			dynamicQuery.add(criterion);
			
			List<AssetCategoryProperty> categoryPropertyList = AssetCategoryPropertyLocalServiceUtil.dynamicQuery(dynamicQuery);
			_log.debug("Category Property List ::"+categoryPropertyList);
			return Validator.isNotNull(categoryPropertyList) ? categoryPropertyList : new ArrayList<>();
		}catch (Exception e) {
			_log.error("Error in getting category properties : "+e);
			return new ArrayList<>();
		}
	}
	
	/**
	 * 
	 * This method is used to category is end level category
	 *
	 * @param categoryId
	 * @return : true if end category
	 */
	public static boolean checkEndCategory(long categoryId) {
		boolean result = false;
		try {
			AssetCategoryProperty categoryProperty = AssetCategoryPropertyLocalServiceUtil.fetchCategoryProperty(categoryId,END_CATEGORY);
			String value = Validator.isNotNull(categoryProperty) ? categoryProperty.getValue() : "";
			if(!value.isEmpty()) {
				_log.info("wht is calue : "+value);
				result = value.equalsIgnoreCase("true")? true : false;
			}
		}catch (Exception e) {
			_log.error(e);
		}
		return result;
	}

	
	public static final String END_CATEGORY = "END_CATEGORY";
	public static final String APPLICABLE_AS_LEAD = "APPLICABLE_AS_LEAD";
	public static final String FULFILMENT_BY_ADMIN = "FULFILMENT_BY_ADMIN";
	public static final String FULFILMENT_BY_VI = "FULFILMENT_BY_VI";
	private static final Log _log = LogFactoryUtil.getLog(VilAssetCategoryFragmentUtil.class.getName());
}
